# EventHub requested changes in this package

This package is based on the ZIP supplied in this conversation. Only the requested areas were edited; existing team definitions and booking/payment business logic were not intentionally changed.

## Changes made
- User booking review no longer displays the booking Terms and Conditions block or its checkbox gate; footer no longer links to Terms & Conditions.
- Desktop public navigation is horizontally centered.
- Footer has additional EventHub/service/help information.
- Phone validation now accepts exactly 11 digits beginning with `09`, on client and API validators; phone placeholders show `09XXXXXXXXX`.
- New Admin-created Organizer/staff accounts use the real contact email as the account/login email. Login also accepts the real contact email for legacy Organizer accounts so older generated addresses remain usable.
- Staff invitation emails no longer fall back to a localhost URL. Set `PUBLIC_APP_URL` (preferred) or `CLIENT_URL` to the public app URL for a setup link; if neither is configured, the email tells the recipient to contact the administrator rather than embedding localhost.
- Admin Dashboard Alerts are displayed in clearer severity-labelled cards.
- Booking-submitted Admin notification now includes the submitting user's name and company name.
- Staff/Organizers page wording and login-email preview updated to reflect actual staff positions and real email addresses. Existing team position field and team setup were preserved.

## Important verification notes
- Backend JavaScript files passed `node --check` syntax checks.
- Frontend production build could not be run in this environment because frontend dependencies were not installed; an install attempt timed out. Please run `npm install` at the project root and then `npm run build` locally.
- Email delivery was not tested against Gmail SMTP. Confirm `GMAIL_USER`, `GMAIL_APP_PASSWORD`, and `PUBLIC_APP_URL` or `CLIENT_URL` in your local environment. Do not share `.env` or Gmail app passwords.
- Existing Organizer records keep their current stored accountEmail. Login by their real contact email is supported; newly created Organizer records use the contact email as accountEmail.
- No database seed or migration was run, and existing team records were not modified.
