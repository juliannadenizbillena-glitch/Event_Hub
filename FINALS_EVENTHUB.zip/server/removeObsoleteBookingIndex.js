
require('dotenv').config();
const mongoose = require('mongoose');

async function main() {
  try {
    await mongoose.connect(process.env.MONGO_URI);

    const collection = mongoose.connection.collection('bookings');
    const indexes = await collection.indexes();
    const obsoleteIndex = indexes.find(
      index => index.name === 'reference_1'
        && index.unique === true
        && index.key?.reference === 1
        && Object.keys(index.key).length === 1
    );

    if (!obsoleteIndex) {
      console.log('Safety check stopped: reference_1 was not found as expected.');
      return;
    }

    const referenceCount = await collection.countDocuments({
      reference: { $exists: true }
    });

    if (referenceCount !== 0) {
      console.log('Safety check stopped: documents still contain reference fields.');
      return;
    }

    await collection.dropIndex('reference_1');
    console.log('Removed obsolete index: reference_1');

    console.log('\nRemaining indexes:');
    console.log(JSON.stringify(await collection.indexes(), null, 2));
  } finally {
    await mongoose.disconnect();
  }
}

main().catch(error => {
  console.error('Index maintenance failed:', error.message);
  process.exitCode = 1;
});
