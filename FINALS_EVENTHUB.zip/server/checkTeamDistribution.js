
require('dotenv').config();

const mongoose = require('mongoose');
const Team = require('./models/Team');
const Branch = require('./models/Branch');
const EventType = require('./models/EventType');

async function main() {
  await mongoose.connect(process.env.MONGO_URI);

  console.log('\n--- BRANCH COUNT ---');
  console.log('Total branches:', await Branch.countDocuments());

  console.log('\n--- EVENT TYPE COUNT ---');
  console.log('Total event types:', await EventType.countDocuments());

  console.log('\n--- TEAMS PER BRANCH AND EVENT TYPE ---');

  const results = await Team.aggregate([
    {
      $group: {
        _id: {
          branch: '$branch',
          eventType: '$eventType',
        },
        total: { $sum: 1 },
        active: {
          $sum: { $cond: ['$isActive', 1, 0] },
        },
      },
    },
    {
      $sort: {
        '_id.branch': 1,
        '_id.eventType': 1,
      },
    },
    {
      $lookup: {
        from: 'branches',
        localField: '_id.branch',
        foreignField: '_id',
        as: 'branchInfo',
      },
    },
    {
      $lookup: {
        from: 'eventtypes',
        localField: '_id.eventType',
        foreignField: '_id',
        as: 'typeInfo',
      },
    },
    {
      $project: {
        _id: 0,
        branch: { $arrayElemAt: ['$branchInfo.name', 0] },
        eventType: { $arrayElemAt: ['$typeInfo.name', 0] },
        total: 1,
        active: 1,
      },
    },
  ]);

  results.forEach((row) => {
    console.log(
      `${row.branch || 'UNKNOWN BRANCH'} | ${row.eventType || 'UNKNOWN EVENT TYPE'} | Total: ${row.total} | Active: ${row.active}`
    );
  });

  console.log('\n--- DUPLICATE TEAM NUMBERS ---');

  const duplicates = await Team.aggregate([
    {
      $group: {
        _id: {
          branch: '$branch',
          eventType: '$eventType',
          number: '$number',
        },
        count: { $sum: 1 },
        names: { $push: '$name' },
      },
    },
    { $match: { count: { $gt: 1 } } },
    { $limit: 30 },
  ]);

  console.log('Duplicate team-number groups:', duplicates.length);
  duplicates.forEach((item) => console.log(item));

  await mongoose.disconnect();
}

main().catch(async (error) => {
  console.error(error);
  await mongoose.disconnect().catch(() => {});
  process.exitCode = 1;
});
