
require('dotenv').config();

const mongoose = require('mongoose');
const Branch = require('./models/Branch');
const Team = require('./models/Team');
const Booking = require('./models/Booking');

async function main() {
  await mongoose.connect(process.env.MONGO_URI);

  const branches = await Branch.find().sort({ name: 1 });

  for (const branch of branches) {
    const teamCount = await Team.countDocuments({ branch: branch._id });

    const bookingCount = await Booking.countDocuments({
      branch: branch._id,
    });

    console.log({
      branch: branch.name,
      code: branch.code,
      branchId: String(branch._id),
      teams: teamCount,
      bookings: bookingCount,
    });
  }

  await mongoose.disconnect();
}

main().catch(async (error) => {
  console.error(error);
  await mongoose.disconnect().catch(() => {});
  process.exitCode = 1;
});
