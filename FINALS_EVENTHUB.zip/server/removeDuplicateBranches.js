﻿require('dotenv').config();
const mongoose = require('mongoose');

const legacy = [
  { id: '6ad12158d5c8815883f826e4', name: 'Manila' },
  { id: '6ad12158d5c8815883f826e5', name: 'Quezon City' },
  { id: '6ad12159d5c8815883f826e6', name: 'Makati' },
  { id: '6ad12159d5c8815883f826e7', name: 'Cebu' },
  { id: '6ad12159d5c8815883f826e8', name: 'Davao' },
];

const canonical = [
  { id: '6ad24c7dd5c8815883f83000', name: 'Manila Branch', code: 'MNL' },
  { id: '6ad24c7dd5c8815883f83001', name: 'Makati Branch', code: 'MKT' },
  { id: '6ad24c7dd5c8815883f83002', name: 'Quezon City Branch', code: 'QC' },
  { id: '6ad24c7dd5c8815883f83003', name: 'Cebu Branch', code: 'CEB' },
  { id: '6ad24c7dd5c8815883f83004', name: 'Davao Branch', code: 'DVO' },
];

async function main() {
  const confirmed = process.argv.includes('--confirm');
  await mongoose.connect(process.env.MONGO_URI);

  const db = mongoose.connection.db;
  const branches = db.collection('branches');
  const teams = db.collection('teams');
  const bookings = db.collection('bookings');

  const legacyIds = legacy.map(x => new mongoose.Types.ObjectId(x.id));
  const canonicalIds = canonical.map(x => new mongoose.Types.ObjectId(x.id));

  for (const item of legacy) {
    const branch = await branches.findOne({ _id: new mongoose.Types.ObjectId(item.id) });
    if (!branch || branch.name !== item.name || branch.code) {
      throw new Error(`Safety check failed for legacy branch ${item.name}. Nothing deleted.`);
    }
    const count = await teams.countDocuments({ branch: new mongoose.Types.ObjectId(item.id) });
    if (count !== 55) {
      throw new Error(`${item.name} has ${count} teams, not 55. Nothing deleted.`);
    }
  }

  for (const item of canonical) {
    const branch = await branches.findOne({ _id: new mongoose.Types.ObjectId(item.id) });
    if (!branch || branch.name !== item.name || branch.code !== item.code) {
      throw new Error(`Canonical branch check failed for ${item.name}. Nothing deleted.`);
    }
    const count = await teams.countDocuments({ branch: new mongoose.Types.ObjectId(item.id) });
    if (count !== 55) {
      throw new Error(`${item.name} has ${count} teams, not 55. Nothing deleted.`);
    }
  }

  const legacyTeamCount = await teams.countDocuments({ branch: { $in: legacyIds } });
  const canonicalTeamCount = await teams.countDocuments({ branch: { $in: canonicalIds } });
  const bookingCount = await bookings.countDocuments({});

  if (legacyTeamCount !== 275 || canonicalTeamCount !== 275 || bookingCount !== 0) {
    throw new Error(
      `Safety check failed: legacy teams=${legacyTeamCount}, canonical teams=${canonicalTeamCount}, bookings=${bookingCount}. Nothing deleted.`
    );
  }

  console.log('SAFETY CHECKS PASSED');
  console.log('Legacy branches to remove:', legacy.length);
  console.log('Legacy teams to remove:', legacyTeamCount);
  console.log('Canonical branches to keep:', canonical.length);
  console.log('Canonical teams to keep:', canonicalTeamCount);
  console.log('Bookings in database:', bookingCount);

  if (!confirmed) {
    console.log('PREVIEW ONLY. No data was changed.');
    console.log('To execute after reviewing, run: node .\\removeDuplicateBranches.js --confirm');
    return;
  }

  const session = await mongoose.startSession();
  try {
    await session.withTransaction(async () => {
      const currentLegacyTeams = await teams.countDocuments(
        { branch: { $in: legacyIds } }, { session }
      );
      const currentCanonicalTeams = await teams.countDocuments(
        { branch: { $in: canonicalIds } }, { session }
      );
      const currentBookings = await bookings.countDocuments({}, { session });

      if (currentLegacyTeams !== 275 || currentCanonicalTeams !== 275 || currentBookings !== 0) {
        throw new Error('Database changed after preview. Transaction cancelled.');
      }

      const deletedTeams = await teams.deleteMany(
        { branch: { $in: legacyIds } }, { session }
      );
      if (deletedTeams.deletedCount !== 275) {
        throw new Error(`Expected to delete 275 teams; deleted ${deletedTeams.deletedCount}.`);
      }

      const deletedBranches = await branches.deleteMany(
        { _id: { $in: legacyIds } }, { session }
      );
      if (deletedBranches.deletedCount !== 5) {
        throw new Error(`Expected to delete 5 branches; deleted ${deletedBranches.deletedCount}.`);
      }

      const remainingLegacyTeams = await teams.countDocuments(
        { branch: { $in: legacyIds } }, { session }
      );
      const remainingCanonicalTeams = await teams.countDocuments(
        { branch: { $in: canonicalIds } }, { session }
      );
      const remainingLegacyBranches = await branches.countDocuments(
        { _id: { $in: legacyIds } }, { session }
      );

      if (remainingLegacyTeams !== 0 ||
          remainingCanonicalTeams !== 275 ||
          remainingLegacyBranches !== 0) {
        throw new Error('Post-cleanup verification failed. Transaction cancelled.');
      }
    });
    console.log('CLEANUP SUCCESSFUL');
    console.log('Removed 5 legacy branches and 275 duplicate teams.');
    console.log('Preserved 5 canonical branches and 275 canonical teams.');
  } finally {
    await session.endSession();
  }
}

main()
  .catch(error => {
    console.error('STOPPED:', error.message);
    process.exitCode = 1;
  })
  .finally(async () => {
    await mongoose.disconnect().catch(() => {});
  });
