const mongoose = require('mongoose');

// One active code per user per purpose. Only a hash of the 6-digit code is stored.
const verificationCodeSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  purpose: { type: String, enum: ['verify_email', 'reset_password', 'change_email'], required: true },
  codeHash: { type: String, required: true },
  // The address the code was emailed to. A code only counts for that exact address.
  target: { type: String, lowercase: true, trim: true },
  attempts: { type: Number, default: 0 },
  lastSentAt: { type: Date, default: Date.now },
  expiresAt: { type: Date, required: true },
});

verificationCodeSchema.index({ user: 1, purpose: 1 }, { unique: true });
// MongoDB removes the document automatically once expiresAt has passed.
verificationCodeSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

module.exports = mongoose.model('VerificationCode', verificationCodeSchema);
