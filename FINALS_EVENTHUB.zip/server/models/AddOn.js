
const mongoose = require('mongoose');

// Global add-on list. Quantity is the fixed number of units supplied
// when this add-on is selected. Price remains a flat price per add-on.
const addOnSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      maxlength: 80,
    },
    description: {
      type: String,
      trim: true,
      maxlength: 300,
    },
    quantity: {
      type: Number,
      required: true,
      min: 1,
      max: 10000,
      default: 1,
    },
    price: {
      type: Number,
      required: true,
      min: 1,
      max: 10000000,
    },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

addOnSchema.set('toJSON', {
  transform: (doc, ret) => {
    delete ret.__v;
    return ret;
  },
});

module.exports = mongoose.model('AddOn', addOnSchema);
