const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const ROLES = ['user', 'organizer', 'admin'];

const userSchema = new mongoose.Schema(
  {
    firstName: { type: String, required: true, trim: true, maxlength: 50 },
    lastName: { type: String, required: true, trim: true, maxlength: 50 },
    // Only User/Company accounts have a company.
    companyName: {
      type: String,
      trim: true,
      maxlength: 100,
      required: function () {
        return this.role === 'user';
      },
    },

    // ---- Two emails, two jobs ----
    // accountEmail: the generated EventHub LOGIN identity. Created once (after verification for a User,
    //   at creation for Organizer/Admin) and never changed, even if the name changes later.
    //   Absent until then; the unique index is sparse so unverified accounts do not collide.
    accountEmail: { type: String, lowercase: true, trim: true },
    // contactEmail: the person's REAL email. Verification, setup and notification mail goes here.
    //   It is never accepted as a login.
    contactEmail: { type: String, required: true, lowercase: true, trim: true },
    // A new contact email waiting for its 6-digit code. contactEmail only changes once confirmed.
    pendingContactEmail: { type: String, lowercase: true, trim: true },

    phone: { type: String, trim: true },
    // Not required at schema level: Admin-created Organizers set their own password
    // through the Forgot Password (6-digit code) flow.
    password: { type: String, select: false },
    role: { type: String, enum: ROLES, default: 'user', required: true },
    // Organizer/Staff are assigned to one branch.
    branch: { type: mongoose.Schema.Types.ObjectId, ref: 'Branch' },
    position: { type: String, trim: true },
    isVerified: { type: Boolean, default: false },
    status: { type: String, enum: ['active', 'inactive'], default: 'active' },
    isArchived: { type: Boolean, default: false, index: true },
    passwordChangedAt: Date,
    lastLoginAt: Date,
    accountEmailSentAt: Date, // cooldown for "send my account email again"
    isDemo: { type: Boolean, default: false },
  },
  // Indexes are built by prepareDatabase() AFTER the legacy-email migration has run.
  { timestamps: true, autoIndex: false }
);

userSchema.index({ accountEmail: 1 }, { unique: true, sparse: true });
userSchema.index({ contactEmail: 1 }, { unique: true });

userSchema.pre('save', async function () {
  if (!this.isModified('password') || !this.password) return;
  this.password = await bcrypt.hash(this.password, 12);
});

userSchema.methods.comparePassword = function (candidate) {
  if (!this.password) return false;
  return bcrypt.compare(candidate, this.password);
};

userSchema.virtual('fullName').get(function () {
  return `${this.firstName} ${this.lastName}`;
});

userSchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    delete ret.password;
    delete ret.__v;
    delete ret.id;
    // The generated EventHub login email is delivered by email only, never shown on the website.
    // Admin endpoints add it back explicitly (staff and company management).
    delete ret.accountEmail;
    return ret;
  },
});

module.exports = mongoose.model('User', userSchema);
module.exports.ROLES = ROLES;
