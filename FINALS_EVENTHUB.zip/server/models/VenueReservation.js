const mongoose = require('mongoose');

// One venue can host only one event per date. The unique (venue, date) index enforces it in the database.
const venueReservationSchema = new mongoose.Schema(
  {
    venue: { type: mongoose.Schema.Types.ObjectId, ref: 'Venue', required: true },
    booking: { type: mongoose.Schema.Types.ObjectId, ref: 'Booking', required: true, index: true },
    date: { type: String, required: true },
  },
  { timestamps: true }
);
venueReservationSchema.index({ venue: 1, date: 1 }, { unique: true });

module.exports = mongoose.model('VenueReservation', venueReservationSchema);
