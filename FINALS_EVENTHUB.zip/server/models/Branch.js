const mongoose = require('mongoose');

const branchSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, unique: true, trim: true, maxlength: 60 },
    // Short code, fixed after creation (used in future booking references).
    code: { type: String, required: true, unique: true, uppercase: true, trim: true, maxlength: 6 },
    address: { type: String, trim: true, maxlength: 200 },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

branchSchema.set('toJSON', { transform: (doc, ret) => { delete ret.__v; return ret; } });

module.exports = mongoose.model('Branch', branchSchema);
