
const mongoose = require('mongoose');

const LEVELS = ['Basic', 'Standard', 'Premium', 'Executive'];

const inclusionItemSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      maxlength: 80,
    },
    quantity: {
      type: Number,
      required: true,
      min: 1,
      max: 10000,
      default: 1,
    },
  },
  { _id: false }
);

// Existing string inclusions are migrated by the controller when saved.
const list = {
  type: [inclusionItemSchema],
  default: [],
};

const bundleSchema = new mongoose.Schema(
  {
    eventType: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'EventType',
      required: true,
    },
    level: { type: Number, required: true, min: 1, max: 4 },
    name: { type: String, required: true, trim: true, maxlength: 80 },
    description: { type: String, trim: true, maxlength: 400 },
    capacity: { type: Number, required: true, min: 100, max: 500 },
    price: { type: Number, required: true, min: 1, max: 10000000 },
    inclusions: {
      equipment: list,
      services: list,
      resources: list,
    },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

bundleSchema.index({ eventType: 1, level: 1 }, { unique: true });

bundleSchema.virtual('tier').get(function () {
  return LEVELS[this.level - 1];
});

bundleSchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    delete ret.__v;
    delete ret.id;
    return ret;
  },
});

module.exports = mongoose.model('Bundle', bundleSchema);
module.exports.LEVELS = LEVELS;
