const mongoose = require('mongoose');

const CATEGORIES = ['fuel', 'transportation', 'equipment', 'utilities', 'printing_materials', 'cleaning', 'staff_transport_meals', 'venue_preparation', 'other'];

// What it cost EventHub to deliver an event. Admin only: never shown to Users or Organizers.
const internalCostSchema = new mongoose.Schema(
  {
    booking: { type: mongoose.Schema.Types.ObjectId, ref: 'Booking', required: true, index: true },
    category: { type: String, enum: CATEGORIES, required: true },
    amount: { type: Number, required: true, min: 1, max: 100000000 },
    note: { type: String, trim: true, maxlength: 200 },
    incurredOn: { type: String }, // YYYY-MM-DD
    recordedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    isDemo: { type: Boolean, default: false },
  },
  { timestamps: true }
);
internalCostSchema.set('toJSON', { transform: (doc, ret) => { delete ret.__v; return ret; } });

module.exports = mongoose.model('InternalCost', internalCostSchema);
module.exports.CATEGORIES = CATEGORIES;
