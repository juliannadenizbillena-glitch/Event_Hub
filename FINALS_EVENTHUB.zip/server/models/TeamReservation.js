const mongoose = require('mongoose');

// One row = one team committed to one booking on one date.
//   held   : Admin approved; kept until `heldUntil` (24h payment window). While a payment is under
//            review, heldUntil is cleared so the hold cannot lapse mid-verification.
//   locked : the 50% down payment was verified; the booking is Confirmed.
// The UNIQUE (team, date) index is what makes double-booking impossible, even when two Admins
// approve at the same moment.
const teamReservationSchema = new mongoose.Schema(
  {
    team: { type: mongoose.Schema.Types.ObjectId, ref: 'Team', required: true },
    booking: { type: mongoose.Schema.Types.ObjectId, ref: 'Booking', required: true, index: true },
    branch: { type: mongoose.Schema.Types.ObjectId, ref: 'Branch', required: true },
    eventType: { type: mongoose.Schema.Types.ObjectId, ref: 'EventType', required: true },
    date: { type: String, required: true },
    status: { type: String, enum: ['held', 'locked'], default: 'held' },
    heldUntil: Date,
  },
  { timestamps: true }
);

teamReservationSchema.index({ team: 1, date: 1 }, { unique: true });
teamReservationSchema.index({ branch: 1, eventType: 1, date: 1 });

module.exports = mongoose.model('TeamReservation', teamReservationSchema);
