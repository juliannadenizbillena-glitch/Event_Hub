const mongoose = require('mongoose');

// One of the 11 EventHub event types. `staffing` is the fixed team structure that all
// 5 teams of this type (in every branch) follow, e.g. 15 members.
const staffingSchema = new mongoose.Schema(
  {
    role: { type: String, required: true, trim: true, maxlength: 40 },
    count: { type: Number, required: true, min: 1, max: 50 },
  },
  { _id: false }
);

const eventTypeSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, unique: true, trim: true },
    slug: { type: String, required: true, unique: true },
    description: { type: String, trim: true, maxlength: 400 },

// Booking duration options configured per event type.
durationModes: {
  type: [{
    type: String,
    enum: ['hourly', 'multi_day'],
  }],
  default: ['hourly'],
},

staffing: { type: [staffingSchema], default: [] },
isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

eventTypeSchema.virtual('teamSize').get(function () {
  return (this.staffing || []).reduce((sum, s) => sum + s.count, 0);
});

eventTypeSchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => { delete ret.__v; delete ret.id; return ret; },
});

module.exports = mongoose.model('EventType', eventTypeSchema);
