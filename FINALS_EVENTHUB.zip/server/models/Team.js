const mongoose = require('mongoose');

// "Makati Branch -> Seminar -> Seminar Team 3".  5 branches x 11 event types x 5 teams = 275.
const assignmentSchema = new mongoose.Schema(
  {
    position: { type: String, required: true, trim: true, maxlength: 40 },
    staff: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  },
  { _id: false }
);

const teamSchema = new mongoose.Schema(
  {
    branch: { type: mongoose.Schema.Types.ObjectId, ref: 'Branch', required: true },
    eventType: { type: mongoose.Schema.Types.ObjectId, ref: 'EventType', required: true },
    number: { type: Number, required: true, min: 1, max: 5 },
    name: { type: String, required: true },
    // Admin-only assignments of actual staff accounts to the event type's existing positions.
    assignments: { type: [assignmentSchema], default: [] },
    // Admin can take a team out of rotation. Reservations come with the Booking module.
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

teamSchema.index({ branch: 1, eventType: 1, number: 1 }, { unique: true });

teamSchema.set('toJSON', { transform: (doc, ret) => { delete ret.__v; return ret; } });

module.exports = mongoose.model('Team', teamSchema);
