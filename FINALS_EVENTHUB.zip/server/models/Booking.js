const mongoose = require('mongoose');

const STATUSES = [
  'pending_approval', 'rejected', 'payment_required', 'payment_verification', 'confirmed', 'ongoing',
  'completed_pending_final', 'fully_paid', // completed_pending_final = event finished, final balance (+ approved damage) due
  'payment_expired', 'payment_overdue', 'cancelled',
];

const file = { path: String, mimeType: String, originalName: String, size: Number };

const bookingSchema = new mongoose.Schema(
  {
    code: { type: String, required: true, unique: true },
    company: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },

    eventName: { type: String, required: true, trim: true, maxlength: 100 },
    eventType: { type: mongoose.Schema.Types.ObjectId, ref: 'EventType', required: true },
    branch: { type: mongoose.Schema.Types.ObjectId, ref: 'Branch', required: true },
    date: { type: String, required: true }, // Event start date
    endDate: { type: String }, // Event end date; optional for older bookings
    durationMode: {
      type: String,
      enum: ['hourly', 'multi_day'],
      default: 'hourly',
},
    startTime: { type: String, required: true }, // HH:MM
    endTime: { type: String, required: true },

    attendees: { type: Number, required: true, min: 1, max: 500 },
    teamsRequired: { type: Number, required: true, min: 1, max: 5 },

    // Snapshot copied from the price list at submission. Later price changes never touch it.
    
bundle: {
  bundle: { type: mongoose.Schema.Types.ObjectId, ref: 'Bundle' },
  name: String,
  level: Number,
  capacity: Number,
  price: Number,
  inclusions: {
    equipment: [{
      _id: false,
      name: String,
      quantity: { type: Number, default: 1, min: 1 },
    }],
    services: [{
      _id: false,
      name: String,
      quantity: { type: Number, default: 1, min: 1 },
    }],
    resources: [{
      _id: false,
      name: String,
      quantity: { type: Number, default: 1, min: 1 },
    }],
  },
},

addOns: [{
  _id: false,
  addOn: { type: mongoose.Schema.Types.ObjectId, ref: 'AddOn' },
  name: String,
  quantity: { type: Number, default: 1, min: 1 },
  price: Number,
}],

    bundleTotal: Number,
    addOnsTotal: Number,
    total: { type: Number, required: true },
    downPaymentAmount: { type: Number, required: true },
    remainingAmount: { type: Number, required: true },

    requirements: { type: String, trim: true, maxlength: 1000 },
    referenceImage: file,
    agreement: { accepted: Boolean, acceptedAt: Date, version: String },

    status: { type: String, enum: STATUSES, default: 'pending_approval', index: true },
    paymentDeadline: Date,
    approvedAt: Date, approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    rejectedAt: Date, rejectedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, rejectionReason: String,
    confirmedAt: Date,
    expiredAt: Date,
    assignedTeams: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Team' }],

    // ---- event operations (Organizer) ----
    operations: {
      venue: { type: mongoose.Schema.Types.ObjectId, ref: 'Venue' },
      venueName: String,
      equipment: [{ _id: false, equipment: { type: mongoose.Schema.Types.ObjectId, ref: 'Equipment' }, name: String, quantity: Number, status: { type: String, enum: ['planned', 'prepared', 'returned'], default: 'planned' } }],
      checklist: [{ _id: false, label: String, done: { type: Boolean, default: false } }],
      notes: { type: String, trim: true, maxlength: 1000 },
      ready: { type: Boolean, default: false }, readyAt: Date,
      startedAt: Date, completedAt: Date,
    },
    // ---- after the event: inspection, damage, final payment ----
    inspection: { status: { type: String, enum: ['pending', 'completed'] }, completedAt: Date, notes: { type: String, trim: true, maxlength: 500 } },
    damageTotal: { type: Number, default: 0 }, // sum of Admin-APPROVED damage charges
    finalAmountDue: Number, // remainingAmount + damageTotal, fixed when the inspection is completed
    finalPaymentDueAt: Date,
    finalPaidAt: Date,
    cancelledAt: Date, cancelledByRole: String, cancellationReason: String,

    history: [{ _id: false, status: String, at: { type: Date, default: Date.now }, byRole: String, note: String }],
    isArchived: { type: Boolean, default: false },
    archivedAt: Date,
    isDemo: { type: Boolean, default: false }, // marks intentionally prepared presentation data
  },
  { timestamps: true }
);

bookingSchema.index({ branch: 1, date: 1 });

module.exports = mongoose.model('Booking', bookingSchema);
module.exports.STATUSES = STATUSES;
