const mongoose = require('mongoose');

const CATEGORIES = ['audio', 'video', 'lighting', 'furniture', 'staging', 'networking', 'signage', 'safety', 'other'];
const CONDITIONS = ['good', 'fair', 'needs_repair', 'out_of_service'];
const STATUSES = ['available', 'maintenance', 'retired'];

// Inventory. `branch` null = shared by every branch. Quantity is the TOTAL owned; how many are free on a
// date is worked out from the events that allocate it.
const equipmentSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 80 },
    category: { type: String, enum: CATEGORIES, required: true },
    quantity: { type: Number, required: true, min: 0, max: 100000 },
    condition: { type: String, enum: CONDITIONS, default: 'good' },
    status: { type: String, enum: STATUSES, default: 'available' },
    branch: { type: mongoose.Schema.Types.ObjectId, ref: 'Branch', default: null },
    notes: { type: String, trim: true, maxlength: 300 },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);
equipmentSchema.index({ branch: 1, name: 1 }, { unique: true });
equipmentSchema.set('toJSON', { transform: (doc, ret) => { delete ret.__v; return ret; } });

module.exports = mongoose.model('Equipment', equipmentSchema);
module.exports.CATEGORIES = CATEGORIES;
module.exports.CONDITIONS = CONDITIONS;
module.exports.STATUSES = STATUSES;
