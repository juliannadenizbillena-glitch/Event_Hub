const mongoose = require('mongoose');

// `down` is the 50% payment (this module). `final` is the post-event balance (later module).
const paymentSchema = new mongoose.Schema(
  {
    booking: { type: mongoose.Schema.Types.ObjectId, ref: 'Booking', required: true, index: true },
    type: { type: String, enum: ['down', 'final'], required: true },
    amount: { type: Number, required: true },
    method: { type: String, enum: ['gcash', 'bank_transfer'], required: true },
    referenceNumber: { type: String, required: true, trim: true },
    receipt: { path: String, mimeType: String, originalName: String, size: Number },
    status: { type: String, enum: ['pending', 'verified', 'rejected'], default: 'pending' },
    rejectionReason: String,
    submittedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    reviewedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    reviewedAt: Date,
  },
  { timestamps: true }
);

module.exports = mongoose.model('Payment', paymentSchema);
