const mongoose = require('mongoose');

const venueSchema = new mongoose.Schema(
  {
    branch: { type: mongoose.Schema.Types.ObjectId, ref: 'Branch', required: true },
    name: { type: String, required: true, trim: true, maxlength: 80 },
    capacity: { type: Number, required: true, min: 1, max: 5000 },
    status: { type: String, enum: ['available', 'maintenance'], default: 'available' },
    address: { type: String, trim: true, maxlength: 200 },
    facilities: { type: [{ type: String, trim: true, maxlength: 60 }], default: [] },
    notes: { type: String, trim: true, maxlength: 300 },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);
venueSchema.index({ branch: 1, name: 1 }, { unique: true });
venueSchema.set('toJSON', { transform: (doc, ret) => { delete ret.__v; return ret; } });

module.exports = mongoose.model('Venue', venueSchema);
