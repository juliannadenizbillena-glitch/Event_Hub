const mongoose = require('mongoose');

// Filed by the Organizer after the event. It is only a PROPOSAL: nothing is charged until Admin approves,
// and Admin decides the approved amount.
const damageReportSchema = new mongoose.Schema(
  {
    booking: { type: mongoose.Schema.Types.ObjectId, ref: 'Booking', required: true, index: true },
    reportedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    item: { type: String, required: true, trim: true, maxlength: 80 },
    description: { type: String, required: true, trim: true, maxlength: 500 },
    quantity: { type: Number, required: true, min: 1, max: 10000 },
    details: { type: String, trim: true, maxlength: 500 },
    estimatedCost: { type: Number, required: true, min: 1, max: 10000000 },
    evidence: [{ _id: false, path: String, mimeType: String, originalName: String, size: Number }],
    status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
    approvedAmount: Number,
    reviewNote: { type: String, trim: true, maxlength: 300 },
    reviewedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    reviewedAt: Date,
    isDemo: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model('DamageReport', damageReportSchema);
