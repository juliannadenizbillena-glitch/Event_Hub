
require('dotenv').config();
const mongoose = require('mongoose');

const legacyBranchIds = [
  '6ad12158d5c8815883f826e4', // Manila
  '6ad12159d5c8815883f826e6', // Makati
  '6ad12158d5c8815883f826e5', // Quezon City
  '6ad12159d5c8815883f826e7', // Cebu
  '6ad12159d5c8815883f826e8', // Davao
];

function collectIds(value, path, results) {
  if (value == null) return;

  if (Array.isArray(value)) {
    value.forEach((item, index) =>
      collectIds(item, `${path}[${index}]`, results)
    );
    return;
  }

  if (typeof value === 'object') {
    if (value._bsontype === 'ObjectId') {
      results.push({ path, value: value.toString() });
      return;
    }

    for (const [key, child] of Object.entries(value)) {
      collectIds(child, path ? `${path}.${key}` : key, results);
    }
    return;
  }

  if (typeof value === 'string' && /^[a-f0-9]{24}$/i.test(value)) {
    results.push({ path, value: value.toLowerCase() });
  }
}

async function main() {
  await mongoose.connect(process.env.MONGO_URI);

  const db = mongoose.connection.db;
  const branches = await db.collection('branches').find({}).toArray();

  const legacyIds = new Set(legacyBranchIds);
  const legacyNames = [
    'Manila',
    'Makati',
    'Quezon City',
    'Cebu',
    'Davao',
  ];

  const legacyBranches = branches.filter(
    branch => legacyNames.includes(branch.name) &&
      legacyIds.has(String(branch._id))
  );

  const legacyBranchObjectIds = legacyBranches.map(b => b._id);
  const legacyTeams = await db.collection('teams')
    .find({ branch: { $in: legacyBranchObjectIds } })
    .toArray();

  const teamIds = new Set(legacyTeams.map(t => String(t._id)));
  const branchIdSet = new Set(legacyBranchObjectIds.map(String));

  console.log(`Legacy teams found: ${legacyTeams.length}`);
  console.log(`Canonical teams kept: ${await db.collection('teams').countDocuments() - legacyTeams.length}`);

  let totalReferences = 0;

  for (const { name, type } of await db.listCollections().toArray()) {
    const docs = await db.collection(name).find({}).toArray();
    const matches = [];

    for (const doc of docs) {
      const found = [];
      collectIds(doc, '', found);

      for (const item of found) {
        const isTeamId = teamIds.has(item.value);
        const isBranchId = branchIdSet.has(item.value);

        // Ignore each team's own _id; we want references to it elsewhere.
        if (name === 'teams' && item.path === '_id' && isTeamId) continue;

        if (isTeamId || isBranchId) {
          matches.push({
            documentId: String(doc._id),
            path: item.path,
            matchedId: item.value,
            kind: isTeamId ? 'legacy team ID' : 'legacy branch ID',
          });
        }
      }
    }

    if (matches.length) {
      totalReferences += matches.length;
      console.log(`\nCollection: ${name} (${matches.length} matches)`);
      console.log(matches.slice(0, 30));
      if (matches.length > 30) console.log('More matches omitted.');
    }
  }

  console.log(`\nTotal reference matches: ${totalReferences}`);
  console.log('Read-only scan complete. No data was changed.');

  await mongoose.disconnect();
}

main().catch(async error => {
  console.error(error);
  await mongoose.disconnect().catch(() => {});
  process.exitCode = 1;
});
