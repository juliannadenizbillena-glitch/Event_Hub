// End-to-end check of the account model and authentication flow against MONGO_URI.
//   npm run test:auth
//
// accountEmail = the generated EventHub LOGIN email.  contactEmail = the real email (codes and notices only).
// Uses throwaway users, sends no real email, and removes everything it created (including a scratch
// database used to test the legacy-data migration).
require('dotenv').config();
process.env.GMAIL_USER = '';
process.env.GMAIL_APP_PASSWORD = '';
process.env.NODE_ENV = 'development';
process.env.JWT_SECRET = process.env.JWT_SECRET || 'e2e_test_secret';
if (!process.env.MONGO_URI) { console.error('MONGO_URI is not set. Add it to .env first.'); process.exit(1); }

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const VerificationCode = require('../models/VerificationCode');
const { hashCode } = require('../utils/codes');
const { ensureAccountEmail } = require('../utils/accountEmail');
const { prepareDatabase } = require('../services/emailMigration');
const app = require('../app');

const run = Date.now().toString(36);
const SFX = run.replace(/[0-9]/g, (d) => 'abcdefghij'[d]); // letters only, so names stay valid and addresses stay unique per run
const contact = (tag) => `eh.test.${run}.${tag}@example.com`;
const LAST = `Deniz Billena${SFX}`;
const LOCAL = `juliannadenizbillena${SFX}`;
const acct = (n) => `${LOCAL}${n > 1 ? n : ''}@user.eventhub.com`;
const PASS = 'Passw0rdOne';
const PASS2 = 'Passw0rdTwo';
const KNOWN = '123456';

let server, base, passed = 0, failed = 0;
const sentMail = [];
const realLog = console.log;
console.log = (...a) => { const t = a.join(' '); if (t.includes('[DEV EMAIL]')) sentMail.push(t); else realLog(...a); };
const results = [];
const check = (name, ok, extra = '') => { (ok ? passed++ : failed++); results.push(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok ? '' : '  -> ' + extra}`); };

async function api(method, path, { body, cookie } = {}) {
  const res = await fetch(base + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const set = res.headers.getSetCookie?.() || [];
  const tokenCookie = set.map((c) => c.split(';')[0]).find((c) => c.startsWith('eventhub_token='));
  return { status: res.status, json: await res.json().catch(() => ({})), cookie: tokenCookie };
}

// Real codes are only ever emailed (and stored hashed): replace the stored one with a known code.
async function knowCode(contactEmail, purpose, target) {
  const user = await User.findOne({ contactEmail });
  await VerificationCode.updateOne(
    { user: user._id, purpose },
    { codeHash: hashCode(KNOWN), attempts: 0, ...(target ? { target } : {}), expiresAt: new Date(Date.now() + 600000) }
  );
}

const reg = (c, over = {}) => ({
  firstName: 'Julianna', lastName: LAST, companyName: 'Example Company', contactEmail: c,
  phone: '09171234567', password: PASS, confirmPassword: PASS, ...over,
});
const login = (accountEmail, password = PASS) => api('POST', '/api/auth/login', { body: { accountEmail, password } });

async function registerAndVerify(c, over = {}) {
  let r = await api('POST', '/api/auth/register', { body: reg(c, over) });
  if (r.status !== 201) return { r };
  await knowCode(c, 'verify_email');
  r = await api('POST', '/api/auth/verify-email', { body: { contactEmail: c, code: KNOWN } });
  return { r, accountEmail: (await User.findOne({ contactEmail: c })).accountEmail };
}

let scratch = null;
async function cleanup() {
  const users = await User.find({ contactEmail: new RegExp(`^eh\\.test\\.${run}\\.`) });
  const ids = users.map((u) => u._id);
  await VerificationCode.deleteMany({ user: { $in: ids } });
  await User.deleteMany({ _id: { $in: ids } });
  if (scratch) { try { await scratch.dropDatabase(); await scratch.close(); } catch { /* ignore */ } }
}

async function main() {
  await mongoose.connect(process.env.MONGO_URI);
  realLog(`Connected to database "${mongoose.connection.name}" on ${mongoose.connection.host}\n`);
  await prepareDatabase();
  server = app.listen(0);
  base = `http://127.0.0.1:${server.address().port}`;
  let r;

  // =============== A. New user: contact email vs generated login email ===============
  const C1 = contact('julianna');
  r = await api('POST', '/api/auth/register', { body: { ...reg(C1), role: 'admin', accountEmail: 'hacker@admin.eventhub.com' } });
  const created = await User.findOne({ contactEmail: C1 }).select('+password');
  check('register: account created (201)', r.status === 201 && r.json.contactEmail === C1, JSON.stringify(r.json));
  check('register: role forced to "user"; a client-supplied accountEmail is ignored', created?.role === 'user' && !created.accountEmail);
  check('register: the entered email is stored as contactEmail, unverified, password hashed', created.contactEmail === C1 && created.isVerified === false && created.password.startsWith('$2'));
  const rec = await VerificationCode.findOne({ user: created._id, purpose: 'verify_email' });
  check('register: a hashed 6-digit code is addressed to the CONTACT email', rec?.codeHash?.length === 64 && rec.target === C1);
  check('before verification there is no login email yet (accountEmail not generated)', created.accountEmail === undefined);
  check('login with the contact email is refused (401)', (await login(C1)).status === 401);
  check('login with the predicted account email is refused until verified (401)', (await login(acct(1))).status === 401);

  await knowCode(C1, 'verify_email');
  r = await api('POST', '/api/auth/verify-email', { body: { contactEmail: C1, code: '000000' } });
  check('verification: wrong code rejected', r.status === 400 && r.json.code === 'INVALID_CODE');
  r = await api('POST', '/api/auth/verify-email', { body: { contactEmail: C1, code: KNOWN } });
  check('verification: success message says the account information was sent to the registered email', r.status === 200 && r.json.message === 'Email verified successfully. Your EventHub account information has been sent to your registered email address.', JSON.stringify(r.json));
  check('verification: the response does NOT contain the account email (never shown on the website)', !JSON.stringify(r.json).includes('eventhub.com') && !('accountEmail' in r.json));
  const delivered = sentMail.find((m) => m.includes(`Account ready -> ${C1}`));
  check(`verification: the generated account email (${acct(1)}) was sent to the CONTACT email`, !!delivered && delivered.includes(acct(1)), delivered);
  const verified = await User.findOne({ contactEmail: C1 });
  check('verification: contactEmail unchanged, accountEmail stored, account verified', verified.contactEmail === C1 && verified.accountEmail === acct(1) && verified.isVerified === true);
  r = await api('POST', '/api/auth/verify-email', { body: { contactEmail: C1, code: KNOWN } });
  check('verification: the code is single use; a repeat does not reveal the account email', r.status === 200 && !('accountEmail' in r.json) && (await VerificationCode.countDocuments({ user: created._id, purpose: 'verify_email' })) === 0);
  r = await api('POST', '/api/auth/register', { body: reg(C1) });
  check('register: a verified contact email cannot register again (409)', r.status === 409 && r.json.code === 'EMAIL_TAKEN');

  // =============== Login uses accountEmail only ===============
  r = await login(C1);
  check('login: the real contact email is NOT accepted as a login (401)', r.status === 401 && r.json.code === 'INVALID_CREDENTIALS');
  r = await login(acct(1), 'WrongPass1');
  check('login: wrong password -> 401', r.status === 401);
  r = await login(acct(1).toUpperCase());
  const cookie1 = r.cookie;
  check('login: the account email works (letter case ignored) and sets an httpOnly cookie', r.status === 200 && !!cookie1 && r.json.user.role === 'user');
  check('login: the response shows the contact email but neither the password nor the account email', r.json.user.contactEmail === C1 && !('password' in r.json.user) && !('accountEmail' in r.json.user) && !('email' in r.json.user));
  r = await api('GET', '/api/auth/me', { cookie: cookie1 });
  check('/me returns the session user without the account email', r.status === 200 && r.json.user.contactEmail === C1 && !('accountEmail' in r.json.user));
  r = await api('GET', '/api/profile', { cookie: cookie1 });
  check('profile: the account email is not returned either', r.status === 200 && !('accountEmail' in r.json.user));
  r = await api('POST', '/api/profile/account-email/resend', { cookie: cookie1 });
  const resent = sentMail.filter((m) => m.includes(`Account ready -> ${C1}`)).length;
  check('profile: "send my account email again" emails it to the contact address (and shows nothing)', r.status === 200 && resent === 2 && !JSON.stringify(r.json).includes('eventhub.com'));
  r = await api('POST', '/api/profile/account-email/resend', { cookie: cookie1 });
  check('profile: that resend has a 60-second cooldown (429)', r.status === 429);

  // =============== Profile: names / account email are fixed ===============
  r = await api('PATCH', '/api/profile', { cookie: cookie1, body: { phone: '09181112222', firstName: 'Hacker', lastName: 'Changed', accountEmail: 'new@user.eventhub.com', contactEmail: contact('sneaky') } });
  let after = await User.findOne({ contactEmail: C1 });
  check('profile: phone is editable; names, accountEmail and contactEmail are ignored in a plain update', r.status === 200 && after.phone === '09181112222' && after.firstName === 'Julianna' && after.accountEmail === acct(1) && after.contactEmail === C1);
  await User.updateOne({ _id: after._id }, { firstName: 'Julia', lastName: 'Renamed' });
  r = await api('GET', '/api/auth/me', { cookie: cookie1 });
  check('the account email stays the same even if the name changes later', (await User.findOne({ contactEmail: C1 })).accountEmail === acct(1));
  await User.updateOne({ _id: after._id }, { firstName: 'Julianna', lastName: LAST });

  // =============== B. Duplicate names get 2, 3, ... ===============
  const C2 = contact('julianna2'), C3 = contact('julianna3');
  const second = await registerAndVerify(C2);
  const third = await registerAndVerify(C3);
  check(`duplicate name #2 -> ${acct(2)}`, second.accountEmail === acct(2), second.accountEmail);
  check(`duplicate name #3 -> ${acct(3)}`, third.accountEmail === acct(3), third.accountEmail);
  r = await api('POST', '/api/auth/register', { body: reg(contact('alias'), { contactEmail: `x${run}@user.eventhub.com` }) });
  check('an EventHub-generated address cannot be used as a contact email (422)', r.status === 422 && r.json.errors.some((e) => e.field === 'contactEmail' && /real email/.test(e.message)));
  r = await api('POST', '/api/auth/register', { body: reg(contact('alias'), { contactEmail: `x${run}@organizer.eventhub.com` }) });
  check('...for any EventHub domain (422)', r.status === 422);

  // =============== C. Server-side validation is authoritative ===============
  r = await api('POST', '/api/auth/register', { body: {} });
  const f = (r.json.errors || []).map((e) => e.field);
  check('register: empty body rejected with a message per field (422)', r.status === 422 && ['firstName', 'lastName', 'companyName', 'contactEmail', 'phone', 'password', 'confirmPassword'].every((x) => f.includes(x)), f.join());
  const bad = async (over, field, re) => { const x = await api('POST', '/api/auth/register', { body: reg(contact('v'), over) }); return x.status === 422 && x.json.errors.some((e) => e.field === field && (!re || re.test(e.message))); };
  check('validation: malformed email', await bad({ contactEmail: 'not-an-email' }, 'contactEmail', /valid email/));
  check('validation: email over 254 characters', await bad({ contactEmail: `${'a'.repeat(250)}@example.com` }, 'contactEmail'));
  check('validation: invalid phone', await bad({ phone: '12345' }, 'phone', /mobile number/));
  check('validation: weak password', await bad({ password: 'weak', confirmPassword: 'weak' }, 'password'));
  check('validation: password over 72 characters', await bad({ password: `Aa1${'x'.repeat(80)}`, confirmPassword: `Aa1${'x'.repeat(80)}` }, 'password', /72/));
  check('validation: password mismatch', await bad({ confirmPassword: 'Different1' }, 'confirmPassword', /match/));
  check('validation: a name with digits is refused', await bad({ firstName: 'Jul1anna' }, 'firstName', /valid first name/));
  check('validation: empty company name', await bad({ companyName: '  ' }, 'companyName'));
  r = await api('POST', '/api/auth/login', { body: { accountEmail: 'nope', password: 'x' } });
  check('login: malformed email rejected (422), missing password rejected', r.status === 422 && (await api('POST', '/api/auth/login', { body: { accountEmail: acct(1) } })).status === 422);
  r = await api('POST', '/api/auth/verify-email', { body: { contactEmail: C1, code: '12' } });
  check('verification: code must be 6 digits (422)', r.status === 422);

  // =============== Code attempt limit ===============
  await api('POST', '/api/auth/forgot-password', { body: { email: acct(1) } });
  await knowCode(C1, 'reset_password');
  for (let i = 0; i < 5; i++) await api('POST', '/api/auth/verify-reset-code', { body: { email: acct(1), code: '999999' } });
  r = await api('POST', '/api/auth/verify-reset-code', { body: { email: acct(1), code: KNOWN } });
  check('after 5 wrong attempts even the right code is refused', r.status >= 400 && !r.json.resetToken);
  await VerificationCode.deleteMany({ purpose: 'reset_password', user: created._id });

  // =============== D. Password recovery keeps the two emails apart ===============
  r = await api('POST', '/api/auth/forgot-password', { body: { email: contact('nobody') } });
  check('recovery: unknown email gets the same generic 200 (no account leak)', r.status === 200 && /If that email is registered/.test(r.json.message));
  r = await api('POST', '/api/auth/forgot-password', { body: { email: acct(1) } });
  const resetRec = await VerificationCode.findOne({ user: created._id, purpose: 'reset_password' });
  check('recovery by ACCOUNT email: the code is sent to the CONTACT email', r.status === 200 && resetRec?.target === C1, resetRec?.target);
  await VerificationCode.deleteMany({ user: created._id, purpose: 'reset_password' });
  r = await api('POST', '/api/auth/forgot-password', { body: { email: C1 } });
  const resetRec2 = await VerificationCode.findOne({ user: created._id, purpose: 'reset_password' });
  check('recovery by CONTACT email also works, and the code still goes to the contact email', r.status === 200 && resetRec2?.target === C1);
  await knowCode(C1, 'reset_password');
  r = await api('POST', '/api/auth/verify-reset-code', { body: { email: C1, code: KNOWN } });
  const resetToken = r.json.resetToken;
  check('recovery: a verified code returns a reset token and does not reveal the account email', r.status === 200 && !!resetToken && !('accountEmail' in r.json));
  r = await api('POST', '/api/auth/reset-password', { body: { resetToken, password: PASS2, confirmPassword: 'Different1' } });
  check('recovery: mismatched confirmation rejected (422)', r.status === 422);
  r = await api('POST', '/api/auth/reset-password', { body: { resetToken, password: PASS2, confirmPassword: PASS2 } });
  const mailsBefore = sentMail.length;
  check('recovery: password reset works and tells the user the information was sent by email', r.status === 200 && /sent to your registered email/.test(r.json.message) && !('accountEmail' in r.json));
  check('recovery: the account information is emailed again to the contact email', sentMail.slice(mailsBefore - 1).some((m) => m.includes(`Account ready -> ${C1}`) && m.includes(acct(1))));
  check('recovery: the reset token cannot be used twice', (await api('POST', '/api/auth/reset-password', { body: { resetToken, password: 'Passw0rdNine', confirmPassword: 'Passw0rdNine' } })).status === 400);
  check('recovery: old password stops working, new one works with the ACCOUNT email', (await login(acct(1), PASS)).status === 401 && (await login(acct(1), PASS2)).status === 200);
  check('recovery: the contact email is still not a login', (await login(C1, PASS2)).status === 401);
  r = await api('GET', '/api/auth/me', { cookie: cookie1 });
  check('recovery: the older session is logged out after the reset', r.status === 401);

  // unverified account that forgets its password: proving the contact email finishes verification
  const C5 = contact('pending');
  await api('POST', '/api/auth/register', { body: reg(C5, { firstName: 'Pending', lastName: `Person${SFX}` }) });
  await api('POST', '/api/auth/forgot-password', { body: { email: C5 } });
  await knowCode(C5, 'reset_password');
  r = await api('POST', '/api/auth/verify-reset-code', { body: { email: C5, code: KNOWN } });
  check('unverified account: the code works', r.status === 200 && !!r.json.resetToken);
  r = await api('POST', '/api/auth/reset-password', { body: { resetToken: r.json.resetToken, password: PASS, confirmPassword: PASS } });
  const pendingAcct = `pendingperson${SFX}@user.eventhub.com`;
  check('unverified account: resetting verifies it and generates its account email (emailed, not shown)', r.status === 200 && !('accountEmail' in r.json) && (await User.findOne({ contactEmail: C5 })).accountEmail === pendingAcct && sentMail.some((m) => m.includes(`Account ready -> ${C5}`) && m.includes(pendingAcct)), JSON.stringify(r.json));
  check('...and that account can now log in', (await login(pendingAcct)).status === 200);

  // =============== E. Contact email change (login email untouched) ===============
  r = await api('POST', '/api/auth/login', { body: { accountEmail: acct(1), password: PASS2 } });
  const cookie2 = r.cookie;
  await User.create({ firstName: 'Other', lastName: `Person${SFX}`, companyName: 'X', contactEmail: contact('taken'), password: PASS, role: 'user', isVerified: true });
  const NEW = contact('newcontact');
  r = await api('POST', '/api/profile/email/request', { cookie: cookie2, body: { newContactEmail: NEW, currentPassword: 'WrongPass1' } });
  check('contact email change: needs the current password', r.status === 400 && r.json.code === 'WRONG_PASSWORD');
  r = await api('POST', '/api/profile/email/request', { cookie: cookie2, body: { newContactEmail: contact('taken'), currentPassword: PASS2 } });
  check('contact email change: an address used by another account is refused (409)', r.status === 409);
  r = await api('POST', '/api/profile/email/request', { cookie: cookie2, body: { newContactEmail: `z${run}@user.eventhub.com`, currentPassword: PASS2 } });
  check('contact email change: an EventHub address is refused (422)', r.status === 422);
  r = await api('POST', '/api/profile/email/request', { cookie: cookie2, body: { newContactEmail: NEW, currentPassword: PASS2 } });
  let u = await User.findOne({ accountEmail: acct(1) });
  check('contact email change: pending only; contactEmail and accountEmail unchanged', r.status === 200 && u.pendingContactEmail === NEW && u.contactEmail === C1 && u.accountEmail === acct(1));
  r = await api('POST', '/api/profile/email/request', { cookie: cookie2, body: { newContactEmail: contact('other'), currentPassword: PASS2 } });
  u = await User.findOne({ accountEmail: acct(1) });
  check('contact email change: a second request inside the cooldown is blocked (429), pending unchanged', r.status === 429 && u.pendingContactEmail === NEW);
  await knowCode(C1, 'change_email', contact('someone-else'));
  r = await api('POST', '/api/profile/email/confirm', { cookie: cookie2, body: { code: KNOWN } });
  check('contact email change: a code sent to a different address cannot confirm it', r.status === 400 && (await User.findOne({ accountEmail: acct(1) })).contactEmail === C1);
  await knowCode(C1, 'change_email', NEW);
  r = await api('POST', '/api/profile/email/confirm', { cookie: cookie2, body: { code: '000000' } });
  check('contact email change: a wrong code changes nothing', r.status === 400 && (await User.findOne({ accountEmail: acct(1) })).contactEmail === C1);
  r = await api('POST', '/api/profile/email/confirm', { cookie: cookie2, body: { code: KNOWN } });
  u = await User.findOne({ accountEmail: acct(1) });
  check('contact email change: confirmed -> contactEmail changes, accountEmail does NOT', r.status === 200 && u.contactEmail === NEW && u.accountEmail === acct(1) && !u.pendingContactEmail, JSON.stringify(r.json));
  check('...login still uses the same account email; neither contact email logs in', (await login(acct(1), PASS2)).status === 200 && (await login(NEW, PASS2)).status === 401 && (await login(C1, PASS2)).status === 401);
  await api('POST', '/api/auth/forgot-password', { body: { email: acct(1) } });
  const rec3 = await VerificationCode.findOne({ user: u._id, purpose: 'reset_password' });
  check('...and recovery codes now go to the NEW contact email', rec3?.target === NEW, rec3?.target);

  // =============== F. Change password (logged in) ===============
  const sessionBefore = (await login(acct(1), PASS2)).cookie; // issued moments before the change
  r = await api('PATCH', '/api/profile/password', { cookie: sessionBefore, body: { currentPassword: PASS2, newPassword: PASS, confirmPassword: PASS } });
  const sessionAfter = r.cookie;
  check('change password works and re-issues this session', r.status === 200 && !!sessionAfter);
  check('...every older session is logged out immediately (even one started in the same second)', (await api('GET', '/api/auth/me', { cookie: sessionBefore })).status === 401 && (await api('GET', '/api/auth/me', { cookie: cookie2 })).status === 401);
  check('...the re-issued session keeps working', (await api('GET', '/api/auth/me', { cookie: sessionAfter })).status === 200);

  // =============== G. Admin-created organizer logs in with the generated email ===============
  const org = await User.create({ firstName: 'Maria', lastName: `Santos${SFX}`, contactEmail: contact('org'), phone: '09170001111', role: 'organizer', isVerified: true });
  const orgAcct = await ensureAccountEmail(org);
  check(`organizer account email is generated on the organizer domain (${`mariasantos${SFX}@organizer.eventhub.com`})`, orgAcct === `mariasantos${SFX}@organizer.eventhub.com`, orgAcct);
  check('organizer with no password cannot log in yet (401)', (await login(orgAcct)).status === 401);
  await api('POST', '/api/auth/forgot-password', { body: { email: orgAcct } });
  await knowCode(contact('org'), 'reset_password');
  r = await api('POST', '/api/auth/verify-reset-code', { body: { email: orgAcct, code: KNOWN } });
  r = await api('POST', '/api/auth/reset-password', { body: { resetToken: r.json.resetToken, password: PASS, confirmPassword: PASS } });
  r = await login(orgAcct);
  check('organizer sets a password, then logs in with the ACCOUNT email and gets role "organizer"', r.status === 200 && r.json.user.role === 'organizer');
  check('...the organizer\'s real email is not a login', (await login(contact('org'))).status === 401);

  // =============== H. Deactivated account ===============
  const off = await User.create({ firstName: 'Off', lastName: `User${SFX}`, companyName: 'Off Co', contactEmail: contact('off'), password: PASS, role: 'user', isVerified: true, status: 'inactive' });
  const offAcct = await ensureAccountEmail(off);
  r = await login(offAcct);
  check('deactivated account cannot log in (403)', r.status === 403 && r.json.code === 'ACCOUNT_DISABLED');

  // =============== I. Existing databases: safe migration ===============
  try {
    const dbName = `${mongoose.connection.name}_migration_${run}`.slice(0, 60);
    scratch = mongoose.connection.useDb(dbName, { useCache: false });
    const Legacy = scratch.model('User', User.schema);
    const col = Legacy.collection;
    await col.createIndex({ email: 1 }, { unique: true, name: 'email_1' });
    const hash = await bcrypt.hash('OldPassw0rd', 4);
    await col.insertMany([
      { firstName: 'Old', lastName: 'Admin', email: `old.admin.${run}@example.com`, password: hash, role: 'admin', isVerified: true, status: 'active', isArchived: false },
      { firstName: 'Old', lastName: 'Customer', companyName: 'Legacy Co', email: `old.customer.${run}@example.com`, password: hash, role: 'user', isVerified: true, status: 'active', isArchived: false, pendingEmail: `old.new.${run}@example.com` },
      { firstName: 'Old', lastName: 'Unverified', companyName: 'Legacy Co', email: `old.unverified.${run}@example.com`, password: hash, role: 'user', isVerified: false, status: 'active', isArchived: false },
    ]);
    const first = await prepareDatabase(Legacy);
    const indexes = await col.indexes();
    const admin = await col.findOne({ firstName: 'Old', lastName: 'Admin' });
    const cust = await col.findOne({ lastName: 'Customer' });
    const unv = await col.findOne({ lastName: 'Unverified' });
    check('migration: every legacy account is converted (3)', first.migrated === 3);
    check('migration: the old email becomes contactEmail; the legacy "email" field and unique index are gone', admin.contactEmail === `old.admin.${run}@example.com` && !('email' in admin) && !indexes.some((i) => i.key && 'email' in i.key));
    check('migration: verified accounts get a login email on the role domain', admin.accountEmail === 'oldadmin@admin.eventhub.com' && cust.accountEmail === 'oldcustomer@user.eventhub.com', `${admin.accountEmail} ${cust.accountEmail}`);
    check('migration: an unverified account gets its login email when it verifies (none yet)', unv.contactEmail && !unv.accountEmail);
    check('migration: pending email change is carried over', cust.pendingContactEmail === `old.new.${run}@example.com` && !('pendingEmail' in cust));
    check('migration: passwords are untouched (the old password still verifies)', await bcrypt.compare('OldPassw0rd', admin.password));
    const second2 = await prepareDatabase(Legacy);
    const adminAgain = await col.findOne({ lastName: 'Admin', firstName: 'Old' });
    check('migration: running it again changes nothing (idempotent)', second2.migrated === 0 && adminAgain.accountEmail === admin.accountEmail);
    check('migration: new indexes exist after migration (unique contactEmail, sparse unique accountEmail)', (await col.indexes()).filter((i) => i.unique && (i.key.contactEmail || i.key.accountEmail)).length === 2);
  } catch (err) {
    check('migration test could not run', false, err.message);
  }
}

main()
  .catch((err) => { failed++; results.push(`FAIL  test crashed -> ${err.stack || err.message}`); })
  .finally(async () => {
    let cleaned = false;
    if (mongoose.connection.readyState === 1) {
      try { await cleanup(); cleaned = true; } catch (e) { console.error('Cleanup problem:', e.message); }
    }
    realLog(results.join('\n'));
    realLog(`\n${passed} passed, ${failed} failed.${cleaned ? ' Test data removed.' : ''}`);
    server?.close();
    await mongoose.disconnect();
    process.exit(failed ? 1 : 0);
  });
