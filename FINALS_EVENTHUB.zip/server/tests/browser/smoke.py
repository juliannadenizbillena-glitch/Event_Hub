# Browser smoke test: visits every page of every role against a seeded demo database (npm run seed:demo) and checks for errors, the footer, and key content.
# Needs: python3, `pip install playwright`, `playwright install chromium`, the app running on http://localhost:5173. Run: python3 server/tests/browser/smoke.py
import re, sys, time, os
from playwright.sync_api import sync_playwright

BASE = "http://localhost:5173"
OUT = os.environ.get("SHOTS_DIR", "./shots"); os.makedirs(OUT, exist_ok=True)
results = []
def check(name, ok, extra=""): results.append(("PASS" if ok else "FAIL") + "  " + name + ("" if ok else "  -> " + str(extra)[:240]))

ACCOUNTS = {
  "admin": ("eventhubadmin@admin.eventhub.com", "Admin@12345"),
  "organizer": ("mariasantos@organizer.eventhub.com", "Demo@12345"),
  "user": ("carlomendoza@user.eventhub.com", "Demo@12345"),
  "user2": ("glorianavarro@user.eventhub.com", "Demo@12345"),
}
errors = []

def visit(page, role, path, expect=None, shot=None, wait=None):
    errs_before = len(errors)
    page.goto(f"{BASE}{path}")
    try:
        page.wait_for_load_state("networkidle", timeout=8000)
    except Exception: pass
    if wait:
        try: page.get_by_text(wait).first.wait_for(timeout=7000)
        except Exception: pass
    body = page.locator("body").inner_text()
    ok = True; why = []
    if "Something went wrong" in body or "Cannot reach the server" in body or "Route not found" in body: ok = False; why.append("error text on page")
    if expect and expect not in body: ok = False; why.append(f"missing '{expect}'")
    if page.locator("[data-testid=global-footer]").count() == 0: ok = False; why.append("no footer")
    if len(errors) > errs_before: ok = False; why.append(f"console/page errors: {errors[errs_before:][:2]}")
    check(f"{role}: {path}", ok, "; ".join(why))
    if shot: page.screenshot(path=f"{OUT}/{shot}.png", full_page=True)

def login(page, who):
    acct, pw = ACCOUNTS[who]
    page.goto(f"{BASE}/login")
    page.get_by_label("Email address").fill(acct); page.get_by_label("Password", exact=True).fill(pw)
    page.get_by_role("button", name="Log in").click()
    page.wait_for_url(re.compile(r".*/(admin|organizer|dashboard)$"), timeout=15000)

with sync_playwright() as p:
    browser = p.chromium.launch()
    def newpage(w=1360, h=900):
        pg = browser.new_context(viewport={"width": w, "height": h}).new_page()
        pg.on("pageerror", lambda e: errors.append(f"pageerror {e}"))
        pg.on("console", lambda m: errors.append(f"console {m.text}") if m.type == "error" and "Failed to load resource" not in m.text else None)
        return pg

    # ---------------- public ----------------
    pub = newpage()
    for path, exp, shot in [("/", "Events, planned and delivered.", "01_landing"), ("/about", "About EventHub", None), ("/contact", "Contact", None), ("/privacy", "Privacy Policy", None), ("/terms", "Terms & Conditions", None), ("/login", "Welcome back", "02_login"), ("/register", "Create your account", "03_register"), ("/forgot-password", "Forgot your password?", None)]:
        visit(pub, "public", path, exp, shot)
    pub.goto(f"{BASE}/"); 
    check("public: the footer has the four quick links and the 2026 copyright", all(pub.get_by_role("link", name=n).count() for n in ["About", "Contact", "Privacy Policy", "Terms & Conditions"]) and pub.get_by_text("© 2026 EventHub Event Management Services. All rights reserved.").is_visible())

    # ---------------- admin ----------------
    adm = newpage(); login(adm, "admin")
    for path, exp, shot, wait in [
        ("/admin", "Pending requests", "10_admin_dashboard", "Revenue (all time)"), ("/admin/booking-requests", "Booking Requests", "11_admin_requests", "Pinnacle"), ("/admin/events", "Events", "12_admin_events", None),
        ("/admin/branches", "Branches", "13_admin_branches", "Makati Branch"), ("/admin/teams", "Teams", "14_admin_teams", "Seminar Team 1"), ("/admin/staff", "Staff / Organizers", "15_admin_staff", "Maria"),
        ("/admin/companies", "Companies", "16_admin_companies", "Pinnacle Logistics"), ("/admin/event-types", "Event Types", None, "Seminar"), ("/admin/bundles", "Bundles & Pricing", "17_admin_pricing", "Standard"),
        ("/admin/equipment", "Equipment", "18_admin_equipment", "Wireless Microphones"), ("/admin/venues", "Venues", "19_admin_venues", "Grand Ballroom"), ("/admin/archive", "Archive", "20_admin_archive", None),
        ("/admin/reports", "Reports", "21_admin_reports", "Profit"), ("/profile", "Profile", None, None)]:
        visit(adm, "admin", path, exp, shot, wait)
    # events: calendar view, a booking in each key state
    adm.goto(f"{BASE}/admin/events"); adm.get_by_role("tab", name="Calendar").click()
    time.sleep(1.2); adm.screenshot(path=f"{OUT}/22_admin_events_calendar.png", full_page=True)
    check("admin: Events has a system-wide calendar", adm.get_by_test_id("event-calendar").is_visible())
    adm.goto(f"{BASE}/admin/booking-requests"); time.sleep(1.5)
    for status, shot in [("Pending Approval", "23_admin_review_request"), ("Payment Verification", "24_admin_verify_payment")]:
        adm.get_by_label("Status").select_option(label=status); time.sleep(1.2)
        links = adm.locator("table a").all() or []
        if links: links[0].click(); adm.wait_for_url(re.compile(r".*/booking-requests/[0-9a-f]{24}$")); time.sleep(1.5); adm.screenshot(path=f"{OUT}/{shot}.png", full_page=True); adm.go_back(); time.sleep(0.8)
    adm.goto(f"{BASE}/admin/events"); time.sleep(1); adm.get_by_role("tab", name="List").click()
    for status, shot, expect in [("Completed — Final Payment Due", "25_admin_damage_review", "Damage reports"), ("Completed / Fully Paid", "26_admin_completed_costs", "Internal costs and profit")]:
        adm.get_by_label("Status").select_option(label=status); time.sleep(1.2)
        links = adm.locator("table a").all()
        if links:
            links[0].click(); adm.wait_for_url(re.compile(r".*/events/[0-9a-f]{24}$")); time.sleep(1.8)
            body = adm.locator("body").inner_text(); check(f"admin: booking details ({status}) show '{expect}'", expect in body, body[:200])
            adm.screenshot(path=f"{OUT}/{shot}.png", full_page=True); adm.go_back(); time.sleep(0.8)
    adm.goto(f"{BASE}/admin/companies"); time.sleep(1.5); adm.locator("table a").first.click(); time.sleep(2)
    check("admin: company details (history, payments, outstanding)", all(x in adm.locator("body").inner_text() for x in ["Booking history", "Payment history", "Outstanding payments"]))
    adm.screenshot(path=f"{OUT}/27_admin_company_details.png", full_page=True)

    # ---------------- organizer ----------------
    org = newpage(); login(org, "organizer")
    for path, exp, shot, wait in [("/organizer", "Today", "30_org_dashboard", "Preparation complete"), ("/organizer/my-events", "My Events", "31_org_events", None), ("/organizer/booking-requests", "Booking Requests", None, None),
        ("/organizer/calendar", "Calendar", "32_org_calendar", None), ("/organizer/teams", "Teams", None, "Team 1"), ("/organizer/event-setup", "Event Setup", None, None),
        ("/organizer/equipment", "Equipment", "33_org_equipment", "Wireless"), ("/organizer/venues", "Venues", None, "Makati"), ("/profile", "Profile", "34_profile", None)]:
        visit(org, "organizer", path, exp, shot, wait)
    org.goto(f"{BASE}/organizer/my-events"); time.sleep(1.5)
    for status, shot in [("Confirmed", "35_org_operations"), ("Completed — Final Payment Due", "36_org_inspection_damage")]:
        org.get_by_label("Status").select_option(label=status); time.sleep(1.2)
        links = org.locator("table a").all()
        if links:
            links[0].click(); org.wait_for_url(re.compile(r".*/my-events/[0-9a-f]{24}$")); time.sleep(2.0)
            body = org.locator("body").inner_text(); check(f"organizer: operations/inspection screen ({status})", "Event operations" in body or "Damage reports" in body or "Inspection" in body, body[:200])
            check(f"organizer ({status}): no prices anywhere", "₱" not in body.replace("estimated", "") or "Estimated" in body, "")
            org.screenshot(path=f"{OUT}/{shot}.png", full_page=True); org.go_back(); time.sleep(0.8)

    # ---------------- user ----------------
    usr = newpage(); login(usr, "user")
    for path, exp, shot, wait in [("/dashboard", "Active bookings", "40_user_dashboard", "Outstanding payment"), ("/book-event", "Book an Event", "41_user_book", None), ("/my-events", "My Events", "42_user_events", None), ("/calendar", "Calendar", "43_user_calendar", None), ("/profile", "Profile", None, None)]:
        visit(usr, "user", path, exp, shot, wait)
    usr.goto(f"{BASE}/my-events"); time.sleep(1.5)
    for status, shot, expect in [("Approved — Payment Required", "44_user_pay_down", "Down payment required")]:
        usr.get_by_label("Status").select_option(label=status); time.sleep(1.2)
        links = usr.locator("table a").all()
        if links:
            links[0].click(); usr.wait_for_url(re.compile(r".*/my-events/[0-9a-f]{24}$")); time.sleep(2)
            body = usr.locator("body").inner_text(); check(f"user: {status} details", expect in body, body[:200])
            usr.screenshot(path=f"{OUT}/{shot}.png", full_page=True); usr.go_back(); time.sleep(0.8)
        else: check(f"user: has a booking in '{status}'", False, "none in the demo data for this user")
    u2 = newpage(); login(u2, "user2"); u2.goto(f"{BASE}/my-events"); time.sleep(1.5)
    u2.get_by_label("Status").select_option(label="Completed — Final Payment Due"); time.sleep(1.2)
    u2.locator("table a").first.click(); u2.wait_for_url(re.compile(r".*/my-events/[0-9a-f]{24}$")); time.sleep(2)
    body = u2.locator("body").inner_text()
    check("user: Final payment required (remaining balance + approved damage, with payment form)", "Final payment required" in body and "Approved damage charges" in body and u2.get_by_label("Reference number").is_visible(), body[:200])
    u2.screenshot(path=f"{OUT}/45_user_pay_final.png", full_page=True)
    usr.goto(f"{BASE}/profile"); time.sleep(2)
    usr.get_by_text("Send it to me again").first.wait_for(timeout=8000)
    check("user: Profile does NOT show the account email (it is sent by email)", "@user.eventhub.com" not in usr.locator("body").inner_text() and usr.get_by_text("Send it to me again").is_visible())

    # ---------------- responsive ----------------
    mob = newpage(390, 800); login(mob, "admin")
    for path, shot in [("/admin", "50_mobile_dashboard"), ("/admin/companies", "51_mobile_table")]:
        mob.goto(f"{BASE}{path}"); time.sleep(2); mob.screenshot(path=f"{OUT}/{shot}.png")
        check(f"mobile: {path} has no horizontal scroll", mob.evaluate("document.documentElement.scrollWidth <= window.innerWidth"))
    check("mobile: tables become cards", mob.get_by_test_id("table-cards").is_visible())
    tab = newpage(820, 1000); login(tab, "organizer"); tab.goto(f"{BASE}/organizer"); time.sleep(2); tab.screenshot(path=f"{OUT}/52_tablet_dashboard.png")
    check("tablet: no horizontal scroll", tab.evaluate("document.documentElement.scrollWidth <= window.innerWidth"))
    browser.close()

print("\n".join(results)); print(f"\n{sum(r.startswith('PASS') for r in results)} passed, {sum(r.startswith('FAIL') for r in results)} failed")
sys.exit(1 if any(r.startswith('FAIL') for r in results) else 0)
