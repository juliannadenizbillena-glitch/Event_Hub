// No database needed.  npm run test:accounts
const assert = require('assert');
const { normalizeNamePart, localPartFor, addressFor } = require('../utils/accountEmail');
const { isEventHubAddress } = require('../config/accounts');

// Normalisation: lowercase, no spaces, no accents, no special characters, letters and numbers only
assert.strictEqual(normalizeNamePart('Juan Dela Cruz'), 'juandelacruz');
assert.strictEqual(normalizeNamePart('  María  José '), 'mariajose');
assert.strictEqual(normalizeNamePart('Zoë'), 'zoe');
assert.strictEqual(normalizeNamePart("O'Brien-Smith Jr."), 'obriensmithjr');
assert.strictEqual(normalizeNamePart('Łukasz'), 'lukasz');
assert.strictEqual(normalizeNamePart('Nuño'), 'nuno');
assert.strictEqual(normalizeNamePart('Agent 007'), 'agent007');
assert.strictEqual(normalizeNamePart(''), '');

// The examples from the spec
assert.strictEqual(addressFor(localPartFor('Julianna', 'Deniz Billena', 'user'), 1, 'user'), 'juliannadenizbillena@user.eventhub.com');
assert.strictEqual(addressFor(localPartFor('Juan', 'Dela Cruz', 'organizer'), 1, 'organizer'), 'juandelacruz@organizer.eventhub.com');
assert.strictEqual(addressFor(localPartFor('Maria', 'Santos', 'user'), 1, 'user'), 'mariasantos@user.eventhub.com');
assert.strictEqual(addressFor(localPartFor('EventHub', 'Admin', 'admin'), 1, 'admin'), 'eventhubadmin@admin.eventhub.com');

// Duplicates get 2, 3, ... (never random characters)
assert.strictEqual(addressFor('juandelacruz', 2, 'user'), 'juandelacruz2@user.eventhub.com');
assert.strictEqual(addressFor('juandelacruz', 3, 'user'), 'juandelacruz3@user.eventhub.com');

// Names with no latin letters fall back to the role word; very long names are capped
assert.strictEqual(localPartFor('王', '小明', 'user'), 'user');
assert.strictEqual(localPartFor('', '', 'organizer'), 'organizer');
assert.ok(localPartFor('a'.repeat(60), 'b'.repeat(60), 'user').length === 40);

// A real contact email can never be an EventHub-generated address
assert.ok(isEventHubAddress('juan@user.eventhub.com') && isEventHubAddress('x@organizer.eventhub.com') && isEventHubAddress('x@eventhub.com'));
assert.ok(!isEventHubAddress('juan.delacruz@gmail.com') && !isEventHubAddress('x@noteventhub.com') && !isEventHubAddress('x@eventhub.com.ph'));

console.log('account email generation: normalisation, spec examples, numbering and reserved-domain checks passed.');
