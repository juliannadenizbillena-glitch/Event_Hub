// The complete EventHub workflow, end to end, through the real API.   npm run test:lifecycle
//   register -> verify -> login -> book -> approve -> 50% payment -> confirmed -> organizer prepares ->
//   ongoing -> completed -> damage -> final payment -> fully paid -> archive
// plus the failure scenarios, security checks, companies, costs/profit, reports, dashboards and calendar.
// Uses throwaway data and far-future dates, restores edited records, and removes its files.
require('dotenv').config();
const fs = require('fs');
const os = require('os');
const path = require('path');
process.env.UPLOAD_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'eh-life-'));
process.env.GMAIL_USER = '';
process.env.GMAIL_APP_PASSWORD = '';
process.env.NODE_ENV = 'development';
process.env.JWT_SECRET = process.env.JWT_SECRET || 'e2e_test_secret';
if (!process.env.MONGO_URI) { console.error('MONGO_URI is not set. Add it to .env first.'); process.exit(1); }

const mongoose = require('mongoose');
const User = require('../models/User');
const Branch = require('../models/Branch');
const EventType = require('../models/EventType');
const Team = require('../models/Team');
const Bundle = require('../models/Bundle');
const AddOn = require('../models/AddOn');
const Booking = require('../models/Booking');
const Payment = require('../models/Payment');
const TeamReservation = require('../models/TeamReservation');
const VenueReservation = require('../models/VenueReservation');
const Venue = require('../models/Venue');
const Equipment = require('../models/Equipment');
const DamageReport = require('../models/DamageReport');
const InternalCost = require('../models/InternalCost');
const Notification = require('../models/Notification');
const VerificationCode = require('../models/VerificationCode');
const { hashCode } = require('../utils/codes');
const { ensureAccountEmail } = require('../utils/accountEmail');
const { ensureAllSetup } = require('../services/setup');
const { prepareDatabase } = require('../services/emailMigration');
const { expireOverdue } = require('../services/bookingService');
const { todayManila, addDays } = require('../config/rules');
const app = require('../app');

const run = Date.now().toString(36);
const SFX = run.replace(/[0-9]/g, (d) => 'abcdefghij'[d]);
const contact = (t) => `eh.test.${run}.${t}@example.com`;
const PASS = 'Passw0rdOne';
const KNOWN = '123456';
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
const OFFSET = 100 + (parseInt(run, 36) % 200);
const D = (i) => addDays(todayManila(), OFFSET + i);

let server, base, passed = 0, failed = 0;
const results = [];
const saved = { bundles: [], addOns: [], teams: [] };
const sentMail = [];
const realLog = console.log;
console.log = (...a) => { const t = a.join(' '); if (t.includes('[DEV EMAIL]')) sentMail.push(t); else realLog(...a); };
const check = (name, ok, extra = '') => { (ok ? passed++ : failed++); results.push(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok ? '' : '  -> ' + String(extra).slice(0, 220)}`); };

async function api(method, p, { body, cookie } = {}) {
  const res = await fetch(base + p, { method, headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const set = res.headers.getSetCookie?.() || [];
  const tokenCookie = set.map((c) => c.split(';')[0]).find((c) => c.startsWith('eventhub_token='));
  const type = res.headers.get('content-type') || '';
  return { status: res.status, type, json: type.includes('json') ? await res.json().catch(() => ({})) : {}, cookie: tokenCookie };
}
async function upload(p, cookie, { fields = {}, files = [], field = 'receipt', mime = 'image/png' } = {}) {
  const fd = new FormData();
  Object.entries(fields).forEach(([k, v]) => fd.append(k, v));
  files.forEach((buf, i) => fd.append(field, new Blob([buf], { type: mime }), `file${i}.png`));
  const res = await fetch(base + p, { method: 'POST', headers: cookie ? { Cookie: cookie } : {}, body: fd });
  return { status: res.status, json: await res.json().catch(() => ({})) };
}
const login = async (accountEmail, password = PASS) => api('POST', '/api/auth/login', { body: { accountEmail, password } });
const loginCookie = async (acc) => (await login(acc)).cookie;
const knowCode = async (contactEmail, purpose) => {
  const u = await User.findOne({ contactEmail });
  await VerificationCode.updateOne({ user: u._id, purpose }, { codeHash: hashCode(KNOWN), attempts: 0, expiresAt: new Date(Date.now() + 600000) });
};
// Move an event to another date (to "reach" the event day without waiting)
async function timeTravel(bookingId, date) {
  await Booking.updateOne({ _id: bookingId }, { date });
  await TeamReservation.updateMany({ booking: bookingId }, { date });
  await VenueReservation.updateMany({ booking: bookingId }, { date });
}

async function cleanup() {
  const users = await User.find({ contactEmail: new RegExp(`^eh\\.test\\.${run}\\.`) });
  const ids = users.map((u) => u._id);
  const bookings = await Booking.find({ company: { $in: ids } }).select('_id');
  const bids = bookings.map((b) => b._id);
  await TeamReservation.deleteMany({ booking: { $in: bids } });
  await VenueReservation.deleteMany({ $or: [{ booking: { $in: bids } }, { date: { $gte: D(-5), $lte: D(60) } }] });
  await Payment.deleteMany({ booking: { $in: bids } });
  await DamageReport.deleteMany({ booking: { $in: bids } });
  await InternalCost.deleteMany({ booking: { $in: bids } });
  await Notification.deleteMany({ $or: [{ user: { $in: ids } }, { booking: { $in: bids } }] });
  await VerificationCode.deleteMany({ user: { $in: ids } });
  await Booking.deleteMany({ _id: { $in: bids } });
  await User.deleteMany({ _id: { $in: ids } });
  await Equipment.deleteMany({ name: new RegExp(`^Test ${SFX}`) });
  await Venue.deleteMany({ name: new RegExp(`^Test ${SFX}`) });
  for (const b of saved.bundles) await Bundle.updateOne({ _id: b._id }, { capacity: b.capacity, price: b.price, isActive: b.isActive });
  for (const a of saved.addOns) await AddOn.updateOne({ _id: a._id }, { price: a.price, isActive: a.isActive });
  for (const t of saved.teams) await Team.updateOne({ _id: t._id }, { isActive: t.isActive });
  fs.rmSync(process.env.UPLOAD_DIR, { recursive: true, force: true });
}

async function main() {
  await mongoose.connect(process.env.MONGO_URI);
  realLog(`Connected to database "${mongoose.connection.name}" on ${mongoose.connection.host}\n`);
  await prepareDatabase();
  server = app.listen(0);
  base = `http://127.0.0.1:${server.address().port}`;
  let r;

  await ensureAllSetup();
  const makati = await Branch.findOne({ code: 'MKT' }), cebu = await Branch.findOne({ code: 'CEB' });
  const seminar = await EventType.findOne({ slug: 'seminar' });
  const bundles = await Bundle.find({ eventType: seminar._id }).sort('level');
  const [basic, standard] = bundles;
  const addOnDocs = await AddOn.find({ name: { $in: ['LED Display', 'Photography', 'Additional Microphones'] } });
  const led = addOnDocs.find((a) => a.name === 'LED Display'), photo = addOnDocs.find((a) => a.name === 'Photography'), mics = addOnDocs.find((a) => a.name === 'Additional Microphones');
  const teams = await Team.find({ branch: makati._id, eventType: seminar._id }).sort('number');
  saved.bundles = bundles.map((b) => b.toObject()); saved.addOns = addOnDocs.map((a) => a.toObject()); saved.teams = teams.map((t) => t.toObject());
  await Bundle.bulkWrite([{ updateOne: { filter: { _id: basic._id }, update: { capacity: 100, price: 25000, isActive: true } } }, { updateOne: { filter: { _id: standard._id }, update: { capacity: 200, price: 40000, isActive: true } } }]);
  await AddOn.bulkWrite([{ updateOne: { filter: { _id: led._id }, update: { price: 8000, isActive: true } } }, { updateOne: { filter: { _id: photo._id }, update: { price: 6000, isActive: true } } }, { updateOne: { filter: { _id: mics._id }, update: { price: 1500, isActive: true } } }]);
  await Team.updateMany({ _id: { $in: teams.map((t) => t._id) } }, { isActive: true });

  const mkStaff = async (tag, role, branch, first) => {
    const u = await User.create({ firstName: first, lastName: `Test${SFX}`, contactEmail: contact(tag), password: PASS, role, isVerified: true, branch: branch?._id, position: 'Organizer' });
    return { doc: u, acct: await ensureAccountEmail(u) };
  };
  const adminA = await mkStaff('admin', 'admin', null, 'Ada');
  const orgM = await mkStaff('orgm', 'organizer', makati, 'Mia');
  const orgC = await mkStaff('orgc', 'organizer', cebu, 'Cleo');
  const admin = await loginCookie(adminA.acct), oM = await loginCookie(orgM.acct), oC = await loginCookie(orgC.acct);

  // ================= 1-6  Register, verify, accountEmail, login =================
  const C = contact('company');
  const reg = { firstName: 'Julianna', lastName: `Deniz Billena${SFX}`, companyName: 'Example Company', contactEmail: C, phone: '09171234567', password: PASS, confirmPassword: PASS };
  r = await api('POST', '/api/auth/register', { body: { ...reg, phone: '123' } });
  check('FAIL-CASE invalid registration is rejected (422)', r.status === 422);
  r = await api('POST', '/api/auth/register', { body: reg });
  check('STEP 1 register a user', r.status === 201);
  r = await api('POST', '/api/auth/register', { body: { ...reg } });
  await knowCode(C, 'verify_email');
  r = await api('POST', '/api/auth/verify-email', { body: { contactEmail: C, code: '000000' } });
  check('FAIL-CASE invalid verification code (400)', r.status === 400 && r.json.code === 'INVALID_CODE');
  await VerificationCode.updateOne({ user: (await User.findOne({ contactEmail: C }))._id, purpose: 'verify_email' }, { expiresAt: new Date(Date.now() - 1000) });
  r = await api('POST', '/api/auth/verify-email', { body: { contactEmail: C, code: KNOWN } });
  check('FAIL-CASE expired verification code (400)', r.status === 400 && r.json.code === 'INVALID_CODE');
  await api('POST', '/api/auth/resend-code', { body: { contactEmail: C } }); // cooldown may swallow it; force a fresh known code
  await VerificationCode.updateOne({ user: (await User.findOne({ contactEmail: C }))._id, purpose: 'verify_email' }, { codeHash: hashCode(KNOWN), attempts: 0, expiresAt: new Date(Date.now() + 600000) });
  r = await api('POST', '/api/auth/verify-email', { body: { contactEmail: C, code: KNOWN } });
  check('STEP 2 verify the contact email; STEP 5 success message', r.status === 200 && r.json.message === 'Email verified successfully. Your EventHub account information has been sent to your registered email address.');
  const cDoc = await User.findOne({ contactEmail: C });
  const expected = `juliannadenizbillena${SFX}@user.eventhub.com`;
  check('STEP 3 the account email is generated', cDoc.accountEmail === expected, cDoc.accountEmail);
  check('STEP 4 the account email is sent to the contact email, never returned by the API', sentMail.some((m) => m.includes(`Account ready -> ${C}`) && m.includes(expected)) && !JSON.stringify(r.json).includes(expected));
  r = await api('POST', '/api/auth/register', { body: reg });
  check('FAIL-CASE duplicate account (409)', r.status === 409);
  check('FAIL-CASE wrong password (401)', (await login(expected, 'WrongPass1')).status === 401);
  check('contact email is not a login (401)', (await login(C)).status === 401);
  r = await login(expected);
  const u1 = r.cookie;
  check('STEP 6 login with the account email', r.status === 200 && r.json.user.role === 'user');
  check('FAIL-CASE wrong role: a User cannot use Admin endpoints (403)', (await api('GET', '/api/admin/companies', { cookie: u1 })).status === 403 && (await api('POST', '/api/payments/000000000000000000000000/verify', { cookie: u1 })).status === 403);

  // ================= 7-18  Create the booking =================
  const body = (over = {}) => ({ eventName: 'Annual Company Conference 2026', eventType: String(seminar._id), attendees: 150, branch: String(makati._id), date: D(0), startTime: '09:00', endTime: '17:00', bundle: String(standard._id), addOns: [led, photo, mics].map((a) => String(a._id)), requirements: 'Need 2 additional microphones and a registration table', agreement: true, ...over });
  r = await api('POST', '/api/pricing/quote', { cookie: u1, body: { eventType: seminar._id, attendees: 150, bundle: standard._id, addOns: [led, photo, mics].map((a) => String(a._id)) } });
  check('STEP 16 review price: 40,000 + 15,500 = 55,500', r.json.quote?.total === 55500 && r.json.quote.teamsRequired === 2);
  r = await api('POST', '/api/bookings', { cookie: u1, body: body({ agreement: false }) });
  check('STEP 17 the agreement must be accepted (422)', r.status === 422);
  r = await api('POST', '/api/bookings', { cookie: u1, body: body() });
  const b1 = r.json.booking;
  check('STEPS 7-18 booking submitted: Pending Approval, 50% = 27,750', r.status === 201 && b1.status === 'pending_approval' && b1.total === 55500 && b1.downPaymentAmount === 27750 && b1.agreementAccepted !== false);
  r = await upload(`/api/bookings/${b1._id}/reference-image`, u1, { field: 'referenceImage', files: [PNG] });
  check('STEP 15 reference image uploaded', r.status === 200);

  // ================= 19-22  Admin reviews, approves =================
  r = await api('GET', '/api/bookings?scope=requests&status=pending_approval', { cookie: admin });
  check('STEP 19 Admin sees the booking as Pending Approval', r.json.bookings.some((x) => x._id === b1._id));
  r = await api('GET', `/api/bookings/${b1._id}`, { cookie: admin });
  check('STEP 20 Admin reviews: company, price, teams availability', r.json.booking.company.companyName === 'Example Company' && r.json.booking.teamAvailability.free === 5 && r.json.booking.total === 55500);
  r = await api('POST', `/api/bookings/${b1._id}/approve`, { cookie: oM });
  check('an Organizer cannot approve a booking (403)', r.status === 403);
  r = await api('POST', `/api/bookings/${b1._id}/approve`, { cookie: admin });
  check('STEP 21 Admin approves (teams held 24h)', r.status === 200 && (await TeamReservation.countDocuments({ booking: b1._id, status: 'held' })) === 2);
  r = await api('GET', `/api/bookings/${b1._id}`, { cookie: u1 });
  check('STEP 22 the user sees Approved — Payment Required', r.json.booking.status === 'payment_required');

  // ================= 23-25  50% payment, verification, Confirmed =================
  r = await upload(`/api/bookings/${b1._id}/payments`, u1, { fields: { method: 'gcash', referenceNumber: 'GCASH-1001' }, files: [PNG] });
  check('STEP 23 the user submits the 50% payment', r.status === 201 && (await Payment.findOne({ booking: b1._id })).amount === 27750);
  const pay1 = await Payment.findOne({ booking: b1._id });
  r = await api('POST', `/api/payments/${pay1._id}/verify`, { cookie: admin });
  const conf = await Booking.findById(b1._id);
  check('STEPS 24-25 Admin verifies: Confirmed, teams locked', r.status === 200 && conf.status === 'confirmed' && (await TeamReservation.countDocuments({ booking: b1._id, status: 'locked' })) === 2);

  // ================= 26-27  Organizer sees and prepares =================
  r = await api('GET', '/api/bookings?scope=events', { cookie: oM });
  check('STEP 26 the Organizer sees the assigned event (no prices)', r.json.bookings.some((x) => x._id === b1._id) && r.json.bookings.every((x) => !('total' in x)));
  check('an Organizer of another branch gets 403 on it', (await api('GET', `/api/bookings/${b1._id}`, { cookie: oC })).status === 403 && (await api('POST', `/api/bookings/${b1._id}/operations/start`, { cookie: oC })).status === 403 && (await api('GET', `/api/bookings/${b1._id}/operations/options`, { cookie: oC })).status === 403);
  r = await api('GET', `/api/bookings/${b1._id}`, { cookie: oM });
  check('the confirmed event has its default preparation checklist', r.json.booking.operations.checklist.length === 6 && r.json.booking.operations.ready === false);
  r = await api('POST', `/api/bookings/${b1._id}/operations/ready`, { cookie: oM });
  check('STEP 27 cannot be marked ready before a venue and checklist (409)', r.status === 409 && r.json.code === 'NOT_READY');
  r = await api('GET', `/api/bookings/${b1._id}/operations/options`, { cookie: oM });
  const venues = r.json.venues, equip = r.json.equipment;
  const small = venues.find((v) => v.name === 'Makati Training Room'), fn = venues.find((v) => v.name === 'Makati Function Room');
  check('options list only this branch\'s venues and equipment with free counts', venues.length >= 4 && equip.every((e) => typeof e.free === 'number') && small.fits === false && fn.fits === true);
  r = await api('PUT', `/api/bookings/${b1._id}/operations/venue`, { cookie: oM, body: { venue: small._id } });
  check('a venue smaller than the attendee count is refused (400)', r.status === 400 && r.json.code === 'VENUE_TOO_SMALL');
  const ghost = await VenueReservation.create({ venue: fn._id, booking: new mongoose.Types.ObjectId(), date: D(0) });
  r = await api('PUT', `/api/bookings/${b1._id}/operations/venue`, { cookie: oM, body: { venue: fn._id } });
  check('a venue already used by another event that date is refused (409)', r.status === 409 && r.json.code === 'VENUE_TAKEN');
  await ghost.deleteOne();
  r = await api('PUT', `/api/bookings/${b1._id}/operations/venue`, { cookie: oM, body: { venue: fn._id } });
  check('the venue is assigned', r.status === 200 && (await Booking.findById(b1._id)).operations.venueName === 'Makati Function Room');
  const cebuVenue = await Venue.findOne({ branch: cebu._id });
  r = await api('PUT', `/api/bookings/${b1._id}/operations/venue`, { cookie: oM, body: { venue: cebuVenue._id } });
  check('a venue of another branch is refused (400)', r.status === 400);
  const mic = equip.find((e) => e.name === 'Wireless Microphones'), tables = equip.find((e) => e.name === 'Banquet Tables');
  r = await api('PUT', `/api/bookings/${b1._id}/operations/equipment`, { cookie: oM, body: { items: [{ equipment: mic._id, quantity: mic.free + 1 }] } });
  check('asking for more equipment than is free is refused (409)', r.status === 409 && r.json.code === 'EQUIPMENT_SHORTAGE');
  r = await api('PUT', `/api/bookings/${b1._id}/operations/equipment`, { cookie: oM, body: { items: [{ equipment: mic._id, quantity: 4 }, { equipment: tables._id, quantity: 20 }] } });
  check('equipment is planned (only what this event needs)', r.status === 200 && (await Booking.findById(b1._id)).operations.equipment.length === 2);
  const cebuEq = await Equipment.findOne({ branch: cebu._id });
  r = await api('PUT', `/api/bookings/${b1._id}/operations/equipment`, { cookie: oM, body: { items: [{ equipment: cebuEq._id, quantity: 1 }] } });
  check('equipment of another branch is refused (403)', r.status === 403);
  await api('PUT', `/api/bookings/${b1._id}/operations/equipment`, { cookie: oM, body: { items: [{ equipment: mic._id, quantity: 4 }, { equipment: tables._id, quantity: 20 }] } });
  r = await api('POST', `/api/bookings/${b1._id}/operations/ready`, { cookie: oM });
  check('still not ready: the checklist is unfinished (409)', r.status === 409);
  for (let i = 0; i < 6; i += 1) await api('PATCH', `/api/bookings/${b1._id}/operations/checklist/${i}`, { cookie: oM, body: { done: true } });
  r = await api('POST', `/api/bookings/${b1._id}/operations/ready`, { cookie: oM });
  check('STEP 27 preparation complete: ready', r.status === 200 && (await Booking.findById(b1._id)).operations.ready === true);
  await api('PATCH', `/api/bookings/${b1._id}/operations/equipment/${mic._id}`, { cookie: oM, body: { status: 'prepared' } });
  check('equipment usage is recorded (prepared)', (await Booking.findById(b1._id)).operations.equipment.find((e) => e.name === 'Wireless Microphones').status === 'prepared');

  // ================= 28-29  Ongoing and completed =================
  r = await api('POST', `/api/bookings/${b1._id}/operations/start`, { cookie: oM });
  check('STEP 28 the event cannot start before its date (409)', r.status === 409 && r.json.code === 'EVENT_NOT_TODAY');
  check('a User cannot start events (403)', (await api('POST', `/api/bookings/${b1._id}/operations/start`, { cookie: u1 })).status === 403);
  await timeTravel(b1._id, todayManila());
  r = await api('POST', `/api/bookings/${b1._id}/operations/start`, { cookie: oM });
  check('STEP 28 on the event day the Organizer starts it: Ongoing', r.status === 200 && (await Booking.findById(b1._id)).status === 'ongoing');
  r = await api('POST', `/api/bookings/${b1._id}/operations/complete`, { cookie: oM });
  check('STEP 29 the event finishes: completed, inspection pending', r.status === 200 && (await Booking.findById(b1._id)).status === 'completed_pending_final' && (await Booking.findById(b1._id)).inspection.status === 'pending');

  // ================= 30-32  Damage =================
  const dmg = (over = {}) => ({ item: 'Projector', description: 'Lens cracked', quantity: 1, details: 'Dropped during teardown', estimatedCost: 8000, ...over });
  r = await upload(`/api/bookings/${b1._id}/damage-reports`, oC, { fields: dmg(), files: [PNG], field: 'evidence' });
  check('STEP 30 an Organizer of another branch cannot report damage (403)', r.status === 403);
  r = await upload(`/api/bookings/${b1._id}/damage-reports`, oM, { fields: dmg({ estimatedCost: 'abc' }), files: [PNG], field: 'evidence' });
  check('damage report validation (422)', r.status === 422);
  r = await upload(`/api/bookings/${b1._id}/damage-reports`, oM, { fields: dmg(), files: [PNG, PNG], field: 'evidence' });
  check('STEP 30 the Organizer submits a damage report with evidence photos', r.status === 201 && (await DamageReport.findOne({ booking: b1._id })).evidence.length === 2, JSON.stringify(r.json));
  r = await upload(`/api/bookings/${b1._id}/damage-reports`, oM, { fields: dmg({ item: 'Microphone', description: 'Cable frayed', estimatedCost: 1500 }), files: [PNG], field: 'evidence' });
  const reports = await DamageReport.find({ booking: b1._id }).sort('createdAt');
  check('the Organizer cannot charge the customer: the final balance is not changed by a report', (await Booking.findById(b1._id)).finalAmountDue === undefined && reports.length === 2 && reports.every((x) => x.status === 'pending'));
  r = await api('POST', `/api/damage-reports/${reports[0]._id}/review`, { cookie: oM, body: { decision: 'approve', approvedAmount: 5000 } });
  check('an Organizer cannot approve damage (403)', r.status === 403);
  r = await upload(`/api/bookings/${b1._id}/final-payment`, u1, { fields: { method: 'gcash', referenceNumber: 'GCASH-EARLY' }, files: [PNG] });
  check('the final payment is not possible before the inspection is finished and reviewed (409)', r.status === 409 && r.json.code === 'FINAL_NOT_READY');
  r = await api('POST', `/api/bookings/${b1._id}/inspection/finish`, { cookie: oM, body: { notes: 'Two damaged items reported' } });
  check('the Organizer finishes the inspection; the balance waits for Admin review', r.status === 200 && (await Booking.findById(b1._id)).finalAmountDue === undefined);
  r = await api('POST', `/api/damage-reports/${reports[1]._id}/review`, { cookie: admin, body: { decision: 'reject', note: '' } });
  check('STEP 31 rejecting damage needs a reason (422)', r.status === 422);
  r = await api('POST', `/api/damage-reports/${reports[1]._id}/review`, { cookie: admin, body: { decision: 'reject', note: 'Normal wear, not caused by the customer' } });
  check('STEP 31 Admin REJECTS one damage report', r.status === 200 && (await DamageReport.findById(reports[1]._id)).status === 'rejected');
  r = await api('POST', `/api/damage-reports/${reports[0]._id}/review`, { cookie: admin, body: { decision: 'approve', approvedAmount: 5000 } });
  const afterDamage = await Booking.findById(b1._id);
  check('STEP 31 Admin APPROVES the other at 5,000: final balance = 27,750 + 5,000 = 32,750', r.status === 200 && afterDamage.damageTotal === 5000 && afterDamage.finalAmountDue === 32750, JSON.stringify({ d: afterDamage.damageTotal, f: afterDamage.finalAmountDue }));
  r = await api('POST', `/api/damage-reports/${reports[0]._id}/review`, { cookie: admin, body: { decision: 'reject', note: 'again' } });
  check('a reviewed report cannot be reviewed twice (409)', r.status === 409);
  r = await api('GET', `/api/bookings/${b1._id}`, { cookie: u1 });
  const ub = r.json.booking;
  check('STEP 32 the user sees the remaining balance and ONLY the approved damage', ub.finalAmountDue === 32750 && ub.remainingAmount === 27750 && ub.damageCharges.length === 1 && ub.damageCharges[0].approvedAmount === 5000 && !('damageReports' in ub));
  r = await api('GET', `/api/bookings/${b1._id}`, { cookie: oM });
  check('the Organizer sees their reports but no approved money, no internal costs', r.json.booking.damageReports.length === 2 && r.json.booking.damageReports.every((d) => !('approvedAmount' in d)) && !('internalCosts' in r.json.booking) && !('finalAmountDue' in r.json.booking));
  r = await api('GET', `/api/damage-reports/${reports[0]._id}/evidence/0`, { cookie: oM });
  check('evidence photos: Admin and the branch Organizer can open them; other branch/User cannot', r.status === 200 && (await api('GET', `/api/damage-reports/${reports[0]._id}/evidence/1`, { cookie: admin })).status === 200 && (await api('GET', `/api/damage-reports/${reports[0]._id}/evidence/0`, { cookie: oC })).status === 403 && (await api('GET', `/api/damage-reports/${reports[0]._id}/evidence/0`, { cookie: u1 })).status === 403);

  // ================= 33-35  Final payment and Fully Paid =================
  r = await upload(`/api/bookings/${b1._id}/final-payment`, u1, { fields: { method: 'bank_transfer', referenceNumber: 'BANK-2002' }, files: [PNG] });
  const fin1 = await Payment.findOne({ booking: b1._id, type: 'final' });
  check('STEP 33 the user submits the final payment (the amount is set by the server: 32,750)', r.status === 201 && fin1.amount === 32750);
  r = await upload(`/api/bookings/${b1._id}/final-payment`, u1, { fields: { method: 'bank_transfer', referenceNumber: 'BANK-2003' }, files: [PNG] });
  check('a second final payment while one is under review is refused (409)', r.status === 409);
  r = await api('POST', `/api/payments/${fin1._id}/verify`, { cookie: oM });
  check('an Organizer cannot verify payments (403)', r.status === 403);
  r = await api('POST', `/api/payments/${fin1._id}/verify`, { cookie: admin });
  const paid = await Booking.findById(b1._id);
  check('STEPS 34-35 Admin verifies the final payment: Completed / Fully Paid', r.status === 200 && paid.status === 'fully_paid' && !!paid.finalPaidAt);
  check('the user is notified the event is completed', (await Notification.countDocuments({ user: cDoc._id, type: 'booking_completed' })) === 1);

  // ---- internal costs and profit (Admin only) ----
  for (const [category, amount] of [['fuel', 1500], ['transportation', 2500], ['equipment', 3000]]) {
    r = await api('POST', `/api/bookings/${b1._id}/costs`, { cookie: admin, body: { category, amount, note: 'test' } });
  }
  check('internal costs: an Organizer and a User cannot record them (403)', (await api('POST', `/api/bookings/${b1._id}/costs`, { cookie: oM, body: { category: 'fuel', amount: 10 } })).status === 403 && (await api('POST', `/api/bookings/${b1._id}/costs`, { cookie: u1, body: { category: 'fuel', amount: 10 } })).status === 403);
  r = await api('GET', `/api/bookings/${b1._id}`, { cookie: admin });
  const ic = r.json.booking.internalCosts;
  check('profit = revenue - internal costs: 60,500 - 7,000 = 53,500', ic.revenue === 60500 && ic.total === 7000 && ic.profit === 53500, JSON.stringify(ic));
  check('a User never sees internal costs or profit', !('internalCosts' in (await api('GET', `/api/bookings/${b1._id}`, { cookie: u1 })).json.booking));

  // ================= 36  Archive =================
  r = await api('POST', `/api/bookings/${b1._id}/archive`, { cookie: oM });
  check('an Organizer cannot archive (403)', r.status === 403);
  r = await api('POST', `/api/bookings/${b1._id}/archive`, { cookie: admin });
  check('STEP 36 Admin archives the completed booking', r.status === 200 && (await Booking.findById(b1._id)).isArchived === true);
  r = await api('GET', '/api/bookings?scope=events', { cookie: admin });
  check('archived bookings leave the normal lists', !r.json.bookings.some((x) => x._id === b1._id));
  r = await api('GET', `/api/admin/archive?search=${encodeURIComponent('Example Company')}&status=fully_paid`, { cookie: admin });
  check('the Archive lists it, with search and status filters', r.json.bookings.some((x) => x._id === b1._id));
  check('the Archive is Admin only', (await api('GET', '/api/admin/archive', { cookie: oM })).status === 403 && (await api('GET', '/api/admin/archive', { cookie: u1 })).status === 403);
  r = await api('POST', `/api/bookings/${b1._id}/restore`, { cookie: admin });
  check('Admin restores it', r.status === 200 && (await Booking.findById(b1._id)).isArchived === false);
  await api('POST', `/api/bookings/${b1._id}/archive`, { cookie: admin });
  r = await api('POST', `/api/bookings/${(await api('POST', '/api/bookings', { cookie: u1, body: body({ date: D(10) }) })).json.booking._id}/archive`, { cookie: admin });
  check('a pending booking cannot be archived (409)', r.status === 409 && r.json.code === 'NOT_ARCHIVABLE');

  // ================= Failure scenarios =================
  // rejected booking
  const bRej = (await api('POST', '/api/bookings', { cookie: u1, body: body({ date: D(11) }) })).json.booking;
  r = await api('POST', `/api/bookings/${bRej._id}/reject`, { cookie: admin, body: { reason: 'Requested schedule is no longer available.' } });
  check('FAIL-CASE rejected booking: the reason is shown to the user', r.status === 200 && (await api('GET', `/api/bookings/${bRej._id}`, { cookie: u1 })).json.booking.rejectionReason.startsWith('Requested schedule'));
  r = await api('POST', `/api/bookings/${bRej._id}/archive`, { cookie: admin });
  check('a rejected booking can be archived', r.status === 200);
  // insufficient teams / unavailable date
  await Team.updateMany({ _id: { $in: teams.slice(1).map((t) => t._id) } }, { isActive: false });
  r = await api('POST', '/api/bookings', { cookie: u1, body: body({ date: D(12) }) });
  check('FAIL-CASE insufficient teams: 150 attendees need 2, only 1 active (409)', r.status === 409 && /select another date/i.test(r.json.message));
  await Team.updateMany({ _id: { $in: teams.map((t) => t._id) } }, { isActive: true });
  await TeamReservation.insertMany(teams.map((t) => ({ team: t._id, booking: new mongoose.Types.ObjectId(), branch: makati._id, eventType: seminar._id, date: D(13), status: 'locked' })));
  r = await api('POST', '/api/bookings', { cookie: u1, body: body({ date: D(13) }) });
  check('FAIL-CASE unavailable date (all teams taken) (409)', r.status === 409);
  await TeamReservation.deleteMany({ date: D(13), branch: makati._id });
  // payment rejected then resubmitted; payment expired
  const bPay = (await api('POST', '/api/bookings', { cookie: u1, body: body({ date: D(14), attendees: 50, bundle: String(basic._id), addOns: [] }) })).json.booking;
  await api('POST', `/api/bookings/${bPay._id}/approve`, { cookie: admin });
  await upload(`/api/bookings/${bPay._id}/payments`, u1, { fields: { method: 'gcash', referenceNumber: 'GCASH-3001' }, files: [PNG] });
  let pp = await Payment.findOne({ booking: bPay._id });
  r = await api('POST', `/api/payments/${pp._id}/reject`, { cookie: admin, body: { reason: 'Receipt is blurry.' } });
  check('FAIL-CASE rejected payment returns to Payment Required', r.status === 200 && (await Booking.findById(bPay._id)).status === 'payment_required');
  r = await upload(`/api/bookings/${bPay._id}/payments`, u1, { fields: { method: 'gcash', referenceNumber: 'GCASH-3002' }, files: [PNG] });
  check('...and the user can resubmit', r.status === 201);
  pp = await Payment.findOne({ booking: bPay._id, status: 'pending' });
  await api('POST', `/api/payments/${pp._id}/reject`, { cookie: admin, body: { reason: 'Wrong amount.' } });
  await Booking.updateOne({ _id: bPay._id }, { paymentDeadline: new Date(Date.now() - 1000) });
  await TeamReservation.updateMany({ booking: bPay._id }, { heldUntil: new Date(Date.now() - 1000) });
  await expireOverdue();
  check('FAIL-CASE expired payment: Payment Expired, teams released', (await Booking.findById(bPay._id)).status === 'payment_expired' && (await TeamReservation.countDocuments({ booking: bPay._id })) === 0);
  // cancellation
  const bCan = (await api('POST', '/api/bookings', { cookie: u1, body: body({ date: D(15), attendees: 50, bundle: String(basic._id), addOns: [] }) })).json.booking;
  r = await api('POST', `/api/bookings/${bCan._id}/cancel`, { cookie: u1, body: { reason: 'Plans changed' } });
  check('a company can cancel a pending booking', r.status === 200 && (await Booking.findById(bCan._id)).status === 'cancelled');
  const bCan2 = (await api('POST', '/api/bookings', { cookie: u1, body: body({ date: D(16), attendees: 50, bundle: String(basic._id), addOns: [] }) })).json.booking;
  await api('POST', `/api/bookings/${bCan2._id}/approve`, { cookie: admin });
  await upload(`/api/bookings/${bCan2._id}/payments`, u1, { fields: { method: 'gcash', referenceNumber: 'GCASH-4001' }, files: [PNG] });
  await api('POST', `/api/payments/${(await Payment.findOne({ booking: bCan2._id }))._id}/verify`, { cookie: admin });
  r = await api('POST', `/api/bookings/${bCan2._id}/cancel`, { cookie: u1, body: {} });
  check('cancelling a CONFIRMED booking: the 50% down payment is non-refundable, teams released', r.status === 200 && /non-refundable/.test(r.json.message) && (await TeamReservation.countDocuments({ booking: bCan2._id })) === 0);
  r = await api('POST', `/api/bookings/${bCan2._id}/cancel`, { cookie: admin, body: {} });
  check('an already cancelled booking cannot be cancelled again (409)', r.status === 409);
  // final payment overdue blocks new bookings, but can still be paid
  const bLate = (await api('POST', '/api/bookings', { cookie: u1, body: body({ date: D(17), attendees: 50, bundle: String(basic._id), addOns: [] }) })).json.booking;
  await api('POST', `/api/bookings/${bLate._id}/approve`, { cookie: admin });
  await upload(`/api/bookings/${bLate._id}/payments`, u1, { fields: { method: 'gcash', referenceNumber: 'GCASH-5001' }, files: [PNG] });
  await api('POST', `/api/payments/${(await Payment.findOne({ booking: bLate._id }))._id}/verify`, { cookie: admin });
  await timeTravel(bLate._id, addDays(todayManila(), -1)); // an event that took place yesterday (its teams differ from b1's, which is today)
  const lateOps = [`/api/bookings/${bLate._id}/operations/venue`];
  const fn2 = (await api('GET', `/api/bookings/${bLate._id}/operations/options`, { cookie: oM })).json.venues.find((v) => v.name === 'Makati Training Room');
  await api('PUT', lateOps[0], { cookie: oM, body: { venue: fn2._id } });
  for (let i = 0; i < 6; i += 1) await api('PATCH', `/api/bookings/${bLate._id}/operations/checklist/${i}`, { cookie: oM, body: { done: true } });
  await api('POST', `/api/bookings/${bLate._id}/operations/ready`, { cookie: oM });
  await api('POST', `/api/bookings/${bLate._id}/operations/start`, { cookie: oM });
  await api('POST', `/api/bookings/${bLate._id}/operations/complete`, { cookie: oM });
  await api('POST', `/api/bookings/${bLate._id}/inspection/finish`, { cookie: oM, body: {} });
  check('no damage: the final balance is just the remaining 50% (12,500)', (await Booking.findById(bLate._id)).finalAmountDue === 12500, (await Booking.findById(bLate._id)).finalAmountDue);
  await Booking.updateOne({ _id: bLate._id }, { finalPaymentDueAt: new Date(Date.now() - 1000) });
  await expireOverdue();
  check('FAIL-CASE final payment overdue: Payment Overdue', (await Booking.findById(bLate._id)).status === 'payment_overdue');
  r = await api('POST', '/api/bookings', { cookie: u1, body: body({ date: D(18) }) });
  check('an outstanding overdue balance blocks new bookings (403)', r.status === 403 && r.json.code === 'OUTSTANDING_BALANCE');
  r = await upload(`/api/bookings/${bLate._id}/final-payment`, u1, { fields: { method: 'gcash', referenceNumber: 'GCASH-5002' }, files: [PNG] });
  check('an overdue balance can still be paid', r.status === 201);
  await api('POST', `/api/payments/${(await Payment.findOne({ booking: bLate._id, type: 'final' }))._id}/verify`, { cookie: admin });
  check('...and paying it clears the overdue status', (await Booking.findById(bLate._id)).status === 'fully_paid' && (await api('POST', '/api/bookings', { cookie: u1, body: body({ date: D(18) }) })).status === 201);
  // payment under review never goes overdue
  const bRev = await Booking.findById(bLate._id);
  check('overdue: the booking record keeps its history', bRev.history.some((h) => h.status === 'payment_overdue'));

  // ================= Companies (Admin) =================
  r = await api('GET', `/api/admin/companies?search=${encodeURIComponent('Example Company')}`, { cookie: admin });
  const comp = r.json.companies.find((c) => c.contactEmail === C);
  check('Companies: the Admin sees the company with contact person, both emails, phone, role, status and stats', comp && comp.accountEmail === expected && comp.firstName === 'Julianna' && comp.role === 'user' && comp.status === 'active' && comp.bookings >= 3 && comp.completedEvents >= 2 && !('password' in comp));
  r = await api('GET', `/api/admin/companies/${cDoc._id}`, { cookie: admin });
  check('Companies: details include booking history, payment history and approved damage charges', r.json.bookingHistory.length >= 3 && r.json.payments.length >= 4 && r.json.damageCharges.some((d) => d.approvedAmount === 5000) && r.json.stats.totalPaid >= 60500);
  check('Companies: not available to Organizers or Users (403)', (await api('GET', '/api/admin/companies', { cookie: oM })).status === 403 && (await api('GET', '/api/admin/companies', { cookie: u1 })).status === 403);
  r = await api('PATCH', `/api/admin/companies/${cDoc._id}/status`, { cookie: admin, body: { status: 'inactive' } });
  check('Companies: Admin deactivates an account; its open session stops and login is refused', r.status === 200 && (await api('GET', '/api/auth/me', { cookie: u1 })).status === 403 && (await login(expected)).status === 403);
  await api('PATCH', `/api/admin/companies/${cDoc._id}/status`, { cookie: admin, body: { status: 'active' } });
  check('Companies: reactivation restores access', (await login(expected)).status === 200);
  check('Companies: a company only sees its own data (cross-company 403)', await (async () => {
    const other = await User.create({ firstName: 'Zed', lastName: `Other${SFX}`, companyName: 'Other Co', contactEmail: contact('other'), password: PASS, role: 'user', isVerified: true });
    const oc = await loginCookie(await ensureAccountEmail(other));
    return (await api('GET', `/api/bookings/${b1._id}`, { cookie: oc })).status === 403 && (await upload(`/api/bookings/${bLate._id}/final-payment`, oc, { fields: { method: 'gcash', referenceNumber: 'GCASH-9999' }, files: [PNG] })).status === 403 && (await api('POST', `/api/bookings/${bLate._id}/cancel`, { cookie: oc, body: {} })).status === 403;
  })());

  // ================= Reports =================
  r = await api('GET', `/api/admin/reports?from=${addDays(todayManila(), -3)}&to=${D(20)}&branch=${makati._id}`, { cookie: admin });
  const rep = r.json.report;
  check('Reports: totals by status and the event count', rep.totals.bookings >= 6 && rep.totals.byStatus.fully_paid >= 2 && rep.totals.events >= 2);
  check('Reports: revenue = verified payments; down + final; approved damage', rep.revenue.collected >= 60500 && rep.revenue.downPayments > 0 && rep.revenue.finalPayments >= 32750 && rep.revenue.damageCharges >= 5000);
  check('Reports: profit = revenue - internal costs', rep.profit.profit === Math.round((rep.profit.revenue - rep.profit.costs) * 100) / 100 && rep.costs.total >= 7000 && rep.costs.byCategory.some((c) => c.category === 'fuel'));
  check('Reports: events by type, branch and month; attendees; team usage', rep.events.byType.some((t) => t.label === 'Seminar') && rep.events.byBranch[0].label === 'Makati Branch' && rep.events.byMonth.length >= 1 && rep.totals.attendees >= 200 && rep.teamUsage.totalTeamAssignments >= 2);
  r = await api('GET', `/api/admin/reports?status=fully_paid&eventType=${seminar._id}&from=${addDays(todayManila(), -3)}&to=${D(20)}`, { cookie: admin });
  check('Reports: the status, event type and date filters narrow the result', r.json.report.totals.bookings >= 1 && Object.keys(r.json.report.totals.byStatus).every((k) => k === 'fully_paid'));
  r = await api('GET', `/api/admin/reports?branch=${cebu._id}&from=${addDays(todayManila(), -3)}&to=${D(20)}`, { cookie: admin });
  check('Reports: another branch shows none of these events', r.json.report.totals.bookings === 0);
  check('Reports: Admin only (403) and a bad date range is rejected (422)', (await api('GET', '/api/admin/reports', { cookie: oM })).status === 403 && (await api('GET', '/api/admin/reports', { cookie: u1 })).status === 403 && (await api('GET', `/api/admin/reports?from=${D(5)}&to=${D(1)}`, { cookie: admin })).status === 422);

  // ================= Equipment and venues (Admin CRUD, Organizer scope) =================
  r = await api('POST', '/api/equipment', { cookie: oM, body: { name: `Test ${SFX} Gear`, category: 'audio', quantity: 3, condition: 'good', status: 'available' } });
  check('Equipment: an Organizer cannot create (403)', r.status === 403);
  r = await api('POST', '/api/equipment', { cookie: admin, body: { name: `Test ${SFX} Gear`, category: 'audio', quantity: 3, condition: 'good', status: 'available', branch: String(makati._id) } });
  const eqId = r.json.equipment?._id;
  check('Equipment: Admin creates, duplicate refused (409), validation (422)', r.status === 201 && (await api('POST', '/api/equipment', { cookie: admin, body: { name: `Test ${SFX} Gear`, category: 'audio', quantity: 3, condition: 'good', status: 'available', branch: String(makati._id) } })).status === 409 && (await api('POST', '/api/equipment', { cookie: admin, body: { name: '', category: 'x', quantity: -1 } })).status === 422);
  r = await api('PATCH', `/api/equipment/${eqId}`, { cookie: admin, body: { name: `Test ${SFX} Gear`, category: 'audio', quantity: 5, condition: 'fair', status: 'maintenance', branch: String(makati._id) } });
  check('Equipment: Admin updates quantity, condition and status', r.status === 200 && r.json.equipment.quantity === 5 && r.json.equipment.status === 'maintenance');
  r = await api('GET', '/api/equipment', { cookie: oM });
  check('Equipment: an Organizer sees only own-branch and shared items', r.status === 200 && r.json.equipment.every((e) => !e.branch || e.branch.name === 'Makati Branch'));
  check('Equipment: another branch is refused (403) and Users have no access (403)', (await api('GET', `/api/equipment?branch=${cebu._id}`, { cookie: oM })).status === 403 && (await api('GET', '/api/equipment', { cookie: u1 })).status === 403);
  r = await api('POST', '/api/venues', { cookie: admin, body: { branch: String(makati._id), name: `Test ${SFX} Hall`, capacity: 120, status: 'available', facilities: ['Stage', 'Wi-Fi'] } });
  const vId = r.json.venue?._id;
  check('Venues: Admin creates a venue (capacity, facilities); an Organizer cannot (403)', r.status === 201 && (await api('POST', '/api/venues', { cookie: oM, body: { branch: String(makati._id), name: 'x', capacity: 1, status: 'available' } })).status === 403);
  check('Venues: an Organizer sees own branch only; another branch is refused (403)', (await api('GET', '/api/venues', { cookie: oM })).json.venues.every((v) => v.branch.name === 'Makati Branch') && (await api('GET', `/api/venues?branch=${cebu._id}`, { cookie: oM })).status === 403);
  r = await api('PATCH', `/api/venues/${vId}/status`, { cookie: admin, body: { isActive: false } });
  check('Venues: Admin deactivates a venue', r.status === 200 && r.json.venue.isActive === false);

  // ================= Bundles: minimum 100 pax =================
  r = await api('PATCH', `/api/bundles/${basic._id}`, { cookie: admin, body: { name: 'Basic Seminar', capacity: 99, price: 25000, inclusions: { equipment: [], services: [], resources: [] } } });
  check('Bundles: capacity below 100 is refused (422)', r.status === 422);

  // ================= Dashboards =================
  r = await api('GET', '/api/dashboard', { cookie: u1 });
  check('Dashboard (User): active bookings, upcoming, outstanding, recent activity', r.json.role === 'user' && Array.isArray(r.json.recent) && 'outstanding' in r.json && 'counts' in r.json && !('revenue' in r.json));
  r = await api('GET', '/api/dashboard', { cookie: oM });
  check('Dashboard (Organizer): today, upcoming, preparation, reminders, no financial data', r.json.role === 'organizer' && Array.isArray(r.json.today) && 'preparation' in r.json && Array.isArray(r.json.reminders) && !('revenue' in r.json) && !('outstanding' in r.json));
  r = await api('GET', '/api/dashboard', { cookie: admin });
  check('Dashboard (Admin): pending, payments to verify, outstanding, system, revenue, alerts', r.json.role === 'admin' && 'pendingRequests' in r.json && 'outstanding' in r.json && 'system' in r.json && r.json.revenue.total >= 60500 && Array.isArray(r.json.alerts));

  // ================= Calendar =================
  const range = `from=${D(-3)}&to=${D(30)}`;
  r = await api('GET', `/api/calendar?${range}`, { cookie: u1 });
  check('Calendar (User): only their own bookings', r.status === 200 && r.json.events.every((e) => !e.company));
  r = await api('GET', `/api/calendar?from=${todayManila()}&to=${todayManila()}`, { cookie: oM });
  check('Calendar (Organizer): their branch events', r.status === 200 && r.json.events.every((e) => e.branch === 'Makati Branch'));
  check('Calendar (Organizer): another branch is refused (403)', (await api('GET', `/api/calendar?${range}&branch=${cebu._id}`, { cookie: oM })).status === 403);
  r = await api('GET', `/api/calendar?from=${addDays(todayManila(), -1)}&to=${todayManila()}`, { cookie: admin });
  check('Calendar (Admin): the system-wide schedule', r.status === 200 && r.json.events.some((e) => e.code === bLate.code));
  check('Calendar: a bad range is rejected (422)', (await api('GET', '/api/calendar?from=x&to=y', { cookie: admin })).status === 422);

  // ================= Security: role escalation and unauthenticated access =================
  check('visitors are refused on every module (401)', (await Promise.all(['/api/dashboard', '/api/calendar?from=2026-01-01&to=2026-01-02', '/api/equipment', '/api/venues', '/api/admin/reports', '/api/admin/archive', '/api/admin/companies', '/api/bookings'].map((p) => api('GET', p)))).every((x) => x.status === 401));
  r = await api('PATCH', '/api/profile', { cookie: u1, body: { role: 'admin', phone: '09170000000' } });
  check('role escalation through the profile is impossible', r.status === 200 && (await User.findById(cDoc._id)).role === 'user');
  r = await api('POST', '/api/auth/register', { body: { ...reg, contactEmail: contact('esc'), role: 'admin' } });
  check('role escalation through registration is impossible', (await User.findOne({ contactEmail: contact('esc') })).role === 'user');
  check('a malformed id is a clean 422, not a server error', (await api('GET', '/api/bookings/not-an-id', { cookie: admin })).status === 422 && (await api('GET', '/api/bookings/000000000000000000000000', { cookie: admin })).status === 404);
}

main()
  .catch((err) => { failed++; results.push(`FAIL  test crashed -> ${err.stack || err.message}`); })
  .finally(async () => {
    let cleaned = false;
    if (mongoose.connection.readyState === 1) {
      try { await cleanup(); cleaned = true; } catch (e) { realLog('Cleanup problem:', e.message); }
    }
    realLog(results.join('\n'));
    realLog(`\n${passed} passed, ${failed} failed.${cleaned ? ' Test data removed and edited records restored.' : ''}`);
    server?.close();
    await mongoose.disconnect();
    process.exit(failed ? 1 : 0);
  });
