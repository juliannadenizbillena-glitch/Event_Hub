// End-to-end check of Step 4 (bundles, add-ons, global pricing, quote/snapshot) against MONGO_URI.
// Run:  npm run test:pricing
//
// It runs the idempotent setup seed first (never overwrites Admin edits). It temporarily changes a few
// Seminar bundles / starter add-ons to known values, and restores every one of them at the end.
require('dotenv').config();
process.env.GMAIL_USER = '';
process.env.GMAIL_APP_PASSWORD = '';
process.env.NODE_ENV = 'development';
process.env.JWT_SECRET = process.env.JWT_SECRET || 'e2e_test_secret';
if (!process.env.MONGO_URI) { console.error('MONGO_URI is not set. Add it to .env first.'); process.exit(1); }

const mongoose = require('mongoose');
const User = require('../models/User');
const EventType = require('../models/EventType');
const Bundle = require('../models/Bundle');
const AddOn = require('../models/AddOn');
const { ensureAllSetup, ADD_ONS } = require('../services/setup');
const app = require('../app');

const run = Date.now().toString(36);
const mail = (tag) => `eh.test.${run}.${tag}@example.com`;
const DOM = { user: 'user.eventhub.com', organizer: 'organizer.eventhub.com', admin: 'admin.eventhub.com' };
const acct = (c, role) => `${c.split('@')[0]}@${DOM[role]}`; // generated login email for a test account

const E = { admin: mail('admin'), org: mail('org'), user: mail('user') };
const PASS = 'Passw0rdOne';

let server, base, passed = 0, failed = 0;
const results = [];
const saved = { bundles: [], addOns: [] };
const check = (name, ok, extra = '') => { (ok ? passed++ : failed++); results.push(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok ? '' : '  -> ' + extra}`); };

async function api(method, path, { body, cookie } = {}) {
  const res = await fetch(base + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const set = res.headers.getSetCookie?.() || [];
  const tokenCookie = set.map((c) => c.split(';')[0]).find((c) => c.startsWith('eventhub_token='));
  return { status: res.status, json: await res.json().catch(() => ({})), cookie: tokenCookie };
}
const login = async (accountEmail) => (await api('POST', '/api/auth/login', { body: { accountEmail, password: PASS } })).cookie;

async function cleanup() {
  await User.deleteMany({ contactEmail: new RegExp(`^eh\\.test\\.${run}\\.`) });
  const temp = await EventType.find({ slug: `test-type-${run}` });
  await Bundle.deleteMany({ eventType: { $in: temp.map((t) => t._id) } });
  await EventType.deleteMany({ _id: { $in: temp.map((t) => t._id) } });
  await AddOn.deleteMany({ name: new RegExp(`^Test Add-on ${run}`) });
  for (const b of saved.bundles) await Bundle.updateOne({ _id: b._id }, { name: b.name, description: b.description, capacity: b.capacity, price: b.price, inclusions: b.inclusions, isActive: b.isActive });
  for (const a of saved.addOns) await AddOn.updateOne({ _id: a._id }, { name: a.name, description: a.description, price: a.price, isActive: a.isActive });
}

async function main() {
  await mongoose.connect(process.env.MONGO_URI);
  console.log(`Connected to database "${mongoose.connection.name}" on ${mongoose.connection.host}\n`);
  await Promise.all([User.init(), Bundle.init(), AddOn.init(), EventType.init()]).catch(() => {});
  server = app.listen(0);
  base = `http://127.0.0.1:${server.address().port}`;
  let r;

  // ---------- Seed ----------
  const totals = await ensureAllSetup();
  const again = await ensureAllSetup();
  check('seed: 4 bundles per event type (at least 44 in total)', totals.bundles >= 44 && totals.bundles === totals.eventTypes * 4, JSON.stringify(totals));
  check('seed: the six starter add-ons exist', (await AddOn.countDocuments({ name: { $in: ADD_ONS.map((a) => a.name) } })) === 6);
  check('seed: running it twice changes nothing (idempotent)', JSON.stringify(totals) === JSON.stringify(again));

  // ---------- Accounts ----------
  await User.create({ firstName: 'Ad', lastName: 'Min', contactEmail: E.admin, accountEmail: acct(E.admin, 'admin'), password: PASS, role: 'admin', isVerified: true });
  await User.create({ firstName: 'Or', lastName: 'Ganizer', contactEmail: E.org, accountEmail: acct(E.org, 'organizer'), password: PASS, role: 'organizer', isVerified: true, position: 'Organizer' });
  await User.create({ firstName: 'Us', lastName: 'Er', companyName: 'Test Co', contactEmail: E.user, accountEmail: acct(E.user, 'user'), password: PASS, role: 'user', isVerified: true });
  const admin = await login(acct(E.admin, 'admin')), org = await login(acct(E.org, 'organizer')), user = await login(acct(E.user, 'user'));

  const seminar = await EventType.findOne({ slug: 'seminar' });
  const workshop = await EventType.findOne({ slug: 'workshop' });
  const seminarBundles = await Bundle.find({ eventType: seminar._id }).sort('level');
  const [basic, standard, premium, executive] = seminarBundles;
  saved.bundles = seminarBundles.map((b) => b.toObject());
  const workshopStandard = await Bundle.findOne({ eventType: workshop._id, level: 2 });
  const starter = await AddOn.find({ name: { $in: ['LED Display', 'Photography', 'Additional Microphones'] } });
  saved.addOns = starter.map((a) => a.toObject());
  const led = starter.find((a) => a.name === 'LED Display'), photo = starter.find((a) => a.name === 'Photography'), mics = starter.find((a) => a.name === 'Additional Microphones');

  // Known values for the flow example (restored at the end)
  await Bundle.bulkWrite([
    { updateOne: { filter: { _id: basic._id }, update: { capacity: 100, price: 25000, isActive: true } } },
    { updateOne: { filter: { _id: standard._id }, update: { capacity: 200, price: 40000, isActive: true } } },
    { updateOne: { filter: { _id: premium._id }, update: { capacity: 300, price: 65000, isActive: true } } },
    { updateOne: { filter: { _id: executive._id }, update: { capacity: 500, price: 100000, isActive: true } } },
  ]);
  await AddOn.bulkWrite([
    { updateOne: { filter: { _id: led._id }, update: { price: 8000, isActive: true } } },
    { updateOne: { filter: { _id: photo._id }, update: { price: 6000, isActive: true } } },
    { updateOne: { filter: { _id: mics._id }, update: { price: 1500, isActive: true } } },
  ]);

  // ---------- Reading ----------
  r = await api('GET', '/api/bundles');
  check('logged-out visitors cannot see pricing (401)', r.status === 401);
  r = await api('GET', `/api/bundles?eventType=${seminar._id}`, { cookie: admin });
  check('admin: the 4 Seminar bundles in order Basic, Standard, Premium, Executive', r.status === 200 && r.json.bundles.map((b) => b.name).join() === 'Basic Seminar,Standard Seminar,Premium Seminar,Executive Seminar', r.json.bundles?.map((b) => b.name).join());

  // ---------- Who may write ----------
  const bundleBody = { name: 'X', description: '', capacity: 100, price: 1000, inclusions: { equipment: [], services: [], resources: [] } };
  for (const [label, cookie] of [['organizer', org], ['user', user]]) {
    r = await api('PATCH', `/api/bundles/${standard._id}`, { cookie, body: { ...bundleBody, name: 'Hacked', price: 1 } });
    const a = r.status === 403;
    r = await api('PATCH', `/api/bundles/${standard._id}/status`, { cookie, body: { isActive: false } });
    const b = r.status === 403;
    r = await api('POST', '/api/bundles', { cookie, body: { ...bundleBody, eventType: seminar._id, level: 1 } });
    const c = r.status === 403;
    r = await api('POST', '/api/add-ons', { cookie, body: { name: `Test Add-on ${run} nope`, price: 100 } });
    const d = r.status === 403;
    r = await api('PATCH', `/api/add-ons/${led._id}`, { cookie, body: { name: 'LED Display', price: 1 } });
    const e = r.status === 403;
    r = await api('PATCH', `/api/add-ons/${led._id}/status`, { cookie, body: { isActive: false } });
    const f = r.status === 403;
    check(`${label}: cannot create, edit, price or deactivate bundles and add-ons (all 403)`, a && b && c && d && e && f);
  }
  const untouched = await Bundle.findById(standard._id);
  check('no price or name was changed by those attempts', untouched.price === 40000 && untouched.name === 'Standard Seminar');

  // ---------- Validation ----------
  const put = (patch) => api('PATCH', `/api/bundles/${standard._id}`, { cookie: admin, body: { ...bundleBody, ...patch } });
  check('bundle: price 0 rejected (422)', (await put({ price: 0 })).status === 422);
  check('bundle: fractional price rejected (422)', (await put({ price: 1500.5 })).status === 422);
  check('bundle: capacity above 500 rejected (422)', (await put({ capacity: 501 })).status === 422);
  check('bundle: empty name rejected (422)', (await put({ name: '  ' })).status === 422);
  check('bundle: bad inclusions rejected (422)', (await put({ inclusions: { equipment: 'projector' } })).status === 422);
  r = await api('POST', '/api/add-ons', { cookie: admin, body: { name: 'Free thing', price: 0 } });
  check('add-on: price 0 rejected (422)', r.status === 422);

  // ---------- Admin edits a bundle ----------
  r = await api('PATCH', `/api/bundles/${standard._id}`, { cookie: admin, body: {
    name: 'Standard Seminar', description: 'Edited by test', capacity: 200, price: 40000,
    eventType: workshop._id, level: 4,
    inclusions: { equipment: ['  Projector  ', '', 'Sound system'], services: ['Coordination'], resources: [] } } });
  const edited = await Bundle.findById(standard._id);
  check('admin edits a bundle; blank inclusion lines are dropped', r.status === 200 && edited.inclusions.equipment.join('|') === 'Projector|Sound system' && edited.description === 'Edited by test');
  check('event type and level cannot be changed by an edit', String(edited.eventType) === String(seminar._id) && edited.level === 2);

  // ---------- 4 bundles per event type ----------
  r = await api('POST', '/api/bundles', { cookie: admin, body: { ...bundleBody, eventType: seminar._id, level: 2 } });
  check('creating a 5th/duplicate-level bundle is refused (409)', r.status === 409 && r.json.code === 'BUNDLE_LEVEL_TAKEN');
  const temp = await EventType.create({ name: `Test Type ${run}`, slug: `test-type-${run}`, staffing: [{ role: 'Lead', count: 1 }], isActive: true });
  r = await api('POST', '/api/bundles', { cookie: admin, body: { ...bundleBody, name: 'Temp Basic', eventType: temp._id, level: 1 } });
  check('admin can create a bundle for a free level', r.status === 201 && r.json.bundle.tier === 'Basic');
  r = await api('POST', '/api/bundles', { cookie: admin, body: { ...bundleBody, name: 'Temp Basic again', eventType: temp._id, level: 1 } });
  check('that level is then taken (409)', r.status === 409);

  // ---------- Visibility: deactivation ----------
  r = await api('PATCH', `/api/bundles/${premium._id}/status`, { cookie: admin, body: { isActive: false } });
  check('admin deactivates a bundle', r.status === 200 && r.json.bundle.isActive === false);
  r = await api('GET', `/api/bundles?eventType=${seminar._id}`, { cookie: user });
  check('user sees only the 3 active Seminar bundles', r.status === 200 && r.json.bundles.length === 3 && r.json.bundles.every((b) => b.isActive));
  r = await api('GET', `/api/bundles?eventType=${seminar._id}`, { cookie: org });
  check('organizer still sees all 4 (view only), including the inactive one', r.json.bundles.length === 4 && r.json.bundles.some((b) => !b.isActive));
  r = await api('GET', `/api/bundles?eventType=${seminar._id}&status=inactive`, { cookie: admin });
  check('admin status filter finds the inactive bundle', r.json.bundles.length === 1);
  r = await api('GET', `/api/bundles?eventType=${seminar._id}&attendees=150`, { cookie: user });
  const fits = Object.fromEntries(r.json.bundles.map((b) => [b.tier, b.fits]));
  check('capacity flag for 150 attendees: Basic no, Standard yes, Executive yes', fits.Basic === false && fits.Standard === true && fits.Executive === true, JSON.stringify(fits));
  await EventType.updateOne({ _id: temp._id }, { isActive: false });
  r = await api('GET', `/api/bundles?eventType=${temp._id}`, { cookie: user });
  check('bundles of an inactive event type are hidden from users', r.status === 200 && r.json.bundles.length === 0);

  // ---------- Add-ons ----------
  const name = `Test Add-on ${run}`;
  r = await api('POST', '/api/add-ons', { cookie: admin, body: { name, description: 'for tests', price: 1234 } });
  const addOnId = r.json.addOn?._id;
  check('admin creates an add-on with its own price', r.status === 201 && r.json.addOn.price === 1234);
  r = await api('POST', '/api/add-ons', { cookie: admin, body: { name: name.toUpperCase(), price: 5 } });
  check('duplicate add-on name (any letter case) rejected (409)', r.status === 409);
  r = await api('PATCH', `/api/add-ons/${addOnId}`, { cookie: admin, body: { name, description: 'edited', price: 2000 } });
  check('admin edits the add-on price', r.status === 200 && r.json.addOn.price === 2000);
  await api('PATCH', `/api/add-ons/${addOnId}/status`, { cookie: admin, body: { isActive: false } });
  r = await api('GET', '/api/add-ons', { cookie: user });
  check('user does not see the deactivated add-on', r.status === 200 && !r.json.addOns.some((a) => a._id === addOnId) && r.json.addOns.some((a) => a.name === 'LED Display'));
  r = await api('GET', '/api/add-ons', { cookie: org });
  check('organizer sees it (view only) with status', r.json.addOns.find((a) => a._id === addOnId)?.isActive === false);

  // ---------- Quote: the flow example ----------
  const ids = [led._id, photo._id, mics._id].map(String);
  const q = (over = {}) => api('POST', '/api/pricing/quote', { cookie: user, body: { eventType: seminar._id, attendees: 150, bundle: standard._id, addOns: ids, ...over } });
  r = await q();
  const quote = r.json.quote;
  check('flow example: Standard Seminar 40,000 + add-ons 15,500 = 55,500', r.status === 200 && quote.bundleTotal === 40000 && quote.addOnsTotal === 15500 && quote.total === 55500, JSON.stringify(quote));
  check('flow example: 150 attendees need 2 teams', quote.teamsRequired === 2);
  check('quote copies names and prices (the booking snapshot)', quote.bundle.name === 'Standard Seminar' && quote.bundle.price === 40000 && quote.addOns.map((a) => `${a.name}:${a.price}`).join() === 'LED Display:8000,Photography:6000,Additional Microphones:1500');
  const t1 = (await q({ attendees: 100 })).json.quote, t3 = (await q({ attendees: 200 })).json.quote;
  check('price is flat: 100 and 200 attendees give the same total, teams 1 and 2', t1.total === 55500 && t3.total === 55500 && t1.teamsRequired === 1 && t3.teamsRequired === 2);
  r = await q({ attendees: 250 });
  check('250 attendees: Standard (capacity 200) refused, teams are NOT the limit (400)', r.status === 400 && r.json.code === 'BUNDLE_CAPACITY');
  r = await q({ attendees: 250, bundle: premium._id });
  check('inactive bundle refused for new bookings (400)', r.status === 400 && r.json.code === 'BUNDLE_INACTIVE');
  r = await q({ attendees: 250, bundle: executive._id, addOns: [] });
  check('250 attendees with Executive: 3 teams, flat 100,000', r.status === 200 && r.json.quote.teamsRequired === 3 && r.json.quote.total === 100000);
  r = await q({ bundle: workshopStandard._id });
  check('bundle of another event type refused (400)', r.status === 400 && r.json.code === 'BUNDLE_MISMATCH');
  r = await q({ addOns: [addOnId] });
  check('deactivated add-on refused for new bookings (400)', r.status === 400 && r.json.code === 'ADDON_INACTIVE');
  r = await q({ addOns: [ids[0], ids[0]] });
  check('same add-on twice refused (400)', r.status === 400 && r.json.code === 'DUPLICATE_ADDON');
  r = await q({ addOns: [new mongoose.Types.ObjectId().toString()] });
  check('unknown add-on refused (400)', r.status === 400 && r.json.code === 'ADDON_NOT_FOUND');
  r = await q({ attendees: 501 });
  check('501 attendees refused (422)', r.status === 422);
  r = await api('POST', '/api/pricing/quote', { cookie: org, body: { eventType: seminar._id, attendees: 150, bundle: standard._id, addOns: [] } });
  check('organizer can also view a quote', r.status === 200 && r.json.quote.total === 40000);

  // ---------- Price change does not alter an earlier snapshot ----------
  await api('PATCH', `/api/bundles/${standard._id}`, { cookie: admin, body: { name: 'Standard Seminar', capacity: 200, price: 45000, inclusions: { equipment: [], services: [], resources: [] } } });
  const later = (await q()).json.quote;
  check('after Admin raises the price, new quotes use it but the stored snapshot keeps 55,500', later.total === 60500 && quote.total === 55500);
}

main()
  .catch((err) => { failed++; results.push(`FAIL  test crashed -> ${err.stack || err.message}`); })
  .finally(async () => {
    let cleaned = false;
    if (mongoose.connection.readyState === 1) {
      try { await cleanup(); cleaned = true; } catch (e) { console.error('Cleanup problem:', e.message); }
    }
    console.log(results.join('\n'));
    console.log(`\n${passed} passed, ${failed} failed.${cleaned ? ' Test data removed and edited records restored.' : ''}`);
    server?.close();
    await mongoose.disconnect();
    process.exit(failed ? 1 : 0);
  });
