// End-to-end check of Step 3 (branches, event types, teams, Admin-created staff) against the
// database in MONGO_URI.  Run:  npm run test:setup
//
// NOTE: it first runs the idempotent setup seed, so a fresh database ends up with the real
// 5 branches, 11 event types and 275 teams (running it again changes nothing).
// All throwaway data (users, a test branch and its teams) is deleted at the end.
require('dotenv').config();
process.env.GMAIL_USER = '';
process.env.GMAIL_APP_PASSWORD = '';
process.env.NODE_ENV = 'development';
process.env.JWT_SECRET = process.env.JWT_SECRET || 'e2e_test_secret';
if (!process.env.MONGO_URI) { console.error('MONGO_URI is not set. Add it to .env first.'); process.exit(1); }

const mongoose = require('mongoose');
const User = require('../models/User');
const Branch = require('../models/Branch');
const EventType = require('../models/EventType');
const Team = require('../models/Team');
const VerificationCode = require('../models/VerificationCode');
const { hashCode } = require('../utils/codes');
const { ensureAllSetup } = require('../services/setup');
const app = require('../app');

const run = Date.now().toString(36);
const mail = (tag) => `eh.test.${run}.${tag}@example.com`;
const DOM = { user: 'user.eventhub.com', organizer: 'organizer.eventhub.com', admin: 'admin.eventhub.com' };
const acct = (c, role) => `${c.split('@')[0]}@${DOM[role]}`; // generated login email for a test account
const SFX = run.replace(/[0-9]/g, (d) => 'abcdefghij'[d]); // letters only: unique names per run
const ORG_LOCAL = `juandelacruz${SFX}`;
const E = { admin: mail('admin'), user: mail('user'), org: mail('org'), org2: mail('org2'), bad: mail('bad') };
const PASS = 'Passw0rdOne';
const KNOWN = '123456';
const letters = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
const TEST_CODE = Array.from({ length: 4 }, () => letters[Math.floor(Math.random() * letters.length)]).join('');
const TEST_BRANCH = `Test Branch ${run}`;

let server, base, passed = 0, failed = 0, originalEventType = null;
const results = [];
const check = (name, ok, extra = '') => { (ok ? passed++ : failed++); results.push(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok ? '' : '  -> ' + extra}`); };

async function api(method, path, { body, cookie } = {}) {
  const res = await fetch(base + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const set = res.headers.getSetCookie?.() || [];
  const tokenCookie = set.map((c) => c.split(';')[0]).find((c) => c.startsWith('eventhub_token='));
  return { status: res.status, json: await res.json().catch(() => ({})), cookie: tokenCookie };
}
const login = async (accountEmail) => (await api('POST', '/api/auth/login', { body: { accountEmail, password: PASS } }));

async function cleanup() {
  const users = await User.find({ contactEmail: new RegExp(`^eh\\.test\\.${run}\\.`) });
  const ids = users.map((u) => u._id);
  await VerificationCode.deleteMany({ user: { $in: ids } });
  await User.deleteMany({ _id: { $in: ids } });
  const branches = await Branch.find({ name: TEST_BRANCH });
  const bids = branches.map((b) => b._id);
  await Team.deleteMany({ branch: { $in: bids } });
  await Branch.deleteMany({ _id: { $in: bids } });
  if (originalEventType) {
    await EventType.updateOne({ _id: originalEventType._id }, { description: originalEventType.description, staffing: originalEventType.staffing, isActive: originalEventType.isActive });
  }
}

async function main() {
  await mongoose.connect(process.env.MONGO_URI);
  console.log(`Connected to database "${mongoose.connection.name}" on ${mongoose.connection.host}\n`);
  await Promise.all([User.init(), Branch.init(), EventType.init(), Team.init()]).catch(() => {});
  server = app.listen(0);
  base = `http://127.0.0.1:${server.address().port}`;
  let r;

  // ---------- Seed: 5 branches x 11 event types x 5 teams = 275 ----------
  const totals = await ensureAllSetup();
  const again = await ensureAllSetup();
  check('seed: at least 5 branches and exactly 11 event types', totals.branches >= 5 && totals.eventTypes === 11, JSON.stringify(totals));
  check('seed: teams = branches x event types x 5', totals.teams === totals.branches * totals.eventTypes * 5, JSON.stringify(totals));
  check('seed: running it twice changes nothing (idempotent)', JSON.stringify(totals) === JSON.stringify(again));
  const makati = await Branch.findOne({ code: 'MKT' });
  check('seed: Makati Branch has 55 teams', (await Team.countDocuments({ branch: makati._id })) === 55);
  check('seed: team names look like "Seminar Team 3"', !!(await Team.findOne({ name: 'Seminar Team 3', branch: makati._id })));

  // ---------- Accounts ----------
  await User.create({ firstName: 'Ad', lastName: 'Min', contactEmail: E.admin, accountEmail: acct(E.admin, 'admin'), password: PASS, role: 'admin', isVerified: true });
  await User.create({ firstName: 'Us', lastName: 'Er', companyName: 'Test Co', contactEmail: E.user, accountEmail: acct(E.user, 'user'), password: PASS, role: 'user', isVerified: true });
  const adminCookie = (await login(acct(E.admin, 'admin'))).cookie;
  const userCookie = (await login(acct(E.user, 'user'))).cookie;

  r = await api('GET', '/api/branches');
  check('logged-out visitors cannot list branches (401)', r.status === 401);

  // ---------- Reading: who sees what ----------
  r = await api('GET', '/api/branches', { cookie: adminCookie });
  const mk = r.json.branches?.find((b) => b.code === 'MKT');
  check('admin sees all branches with team counts', r.status === 200 && mk?.teamCount === 55 && 'staffCount' in mk);
  r = await api('GET', '/api/branches', { cookie: userCookie });
  check('user sees active branches with name and code only', r.status === 200 && r.json.branches.length >= 5 && !('teamCount' in r.json.branches[0]));
  r = await api('GET', '/api/teams', { cookie: userCookie });
  check('user cannot list teams (403)', r.status === 403);
  r = await api('GET', '/api/admin/staff', { cookie: userCookie });
  check('user cannot open admin staff endpoints (403)', r.status === 403);

  // ---------- Branches (admin) ----------
  r = await api('POST', '/api/branches', { cookie: adminCookie, body: { name: TEST_BRANCH, code: 'x' } });
  check('branch: invalid code rejected (422)', r.status === 422);
  r = await api('POST', '/api/branches', { cookie: adminCookie, body: { name: TEST_BRANCH, code: TEST_CODE, address: '1 Test Street' } });
  const tb = r.json.branch;
  check('branch: admin creates a branch and it gets 55 teams automatically', r.status === 201 && tb?.teamCount === 55, JSON.stringify(r.json));
  r = await api('POST', '/api/branches', { cookie: adminCookie, body: { name: TEST_BRANCH, code: 'ZZZZZ' } });
  check('branch: duplicate name rejected (409)', r.status === 409);
  r = await api('PATCH', `/api/branches/${tb._id}`, { cookie: adminCookie, body: { name: TEST_BRANCH, address: '2 Updated Street' } });
  check('branch: edit address; code stays the same', r.status === 200 && r.json.branch.address === '2 Updated Street' && r.json.branch.code === TEST_CODE);

  // ---------- Staff creation (admin) ----------
  const staffBody = { firstName: 'Juan', lastName: `Dela Cruz${SFX}`, contactEmail: E.org, phone: '09171230001', branch: tb._id, position: 'Organizer' };
  r = await api('POST', '/api/admin/staff', { cookie: adminCookie, body: { ...staffBody, contactEmail: 'not-an-email' } });
  check('staff: a malformed email is rejected (422)', r.status === 422);
  r = await api('POST', '/api/admin/staff', { cookie: adminCookie, body: { ...staffBody, contactEmail: `x${run}@organizer.eventhub.com` } });
  check('staff: an EventHub address cannot be the real contact email (422)', r.status === 422);
  r = await api('POST', '/api/admin/staff', { cookie: adminCookie, body: { ...staffBody, firstName: 'Jua1n' } });
  check('staff: a name with digits is rejected (422)', r.status === 422);
  r = await api('POST', '/api/admin/staff', { cookie: adminCookie, body: { ...staffBody, role: 'admin', accountEmail: 'chosen@organizer.eventhub.com' } });
  const staff = r.json.staff;
  const dbStaff = await User.findOne({ contactEmail: E.org }).select('+password');
  const orgAcct = `${ORG_LOCAL}@organizer.eventhub.com`;
  check(`staff: real email stored as contactEmail; login email generated as ${orgAcct}`, r.status === 201 && dbStaff.contactEmail === E.org && dbStaff.accountEmail === orgAcct, dbStaff?.accountEmail);
  check('staff: the organizer cannot choose their own account email (body value ignored)', dbStaff.accountEmail !== 'chosen@organizer.eventhub.com');
  check('staff: the response and the message show the generated login email', staff.accountEmail === orgAcct && staff.contactEmail === E.org && r.json.message.includes(orgAcct));
  const dup = await api('POST', '/api/admin/staff', { cookie: adminCookie, body: { ...staffBody, contactEmail: E.org2 } });
  check(`staff: a second Juan Dela Cruz gets ${ORG_LOCAL}2@organizer.eventhub.com`, dup.status === 201 && dup.json.staff.accountEmail === `${ORG_LOCAL}2@organizer.eventhub.com`, dup.json.staff?.accountEmail);
  await User.deleteOne({ contactEmail: E.org2 });
  check('staff: created as role "organizer" even if the body asks for admin', r.status === 201 && dbStaff?.role === 'organizer');
  check('staff: verified, assigned to the branch, no password yet', dbStaff.isVerified && String(dbStaff.branch) === tb._id && !dbStaff.password && staff.passwordSet === false);
  r = await api('POST', '/api/admin/staff', { cookie: adminCookie, body: staffBody });
  check('staff: a contact email already in use is rejected (409)', r.status === 409);
  r = await api('POST', '/api/admin/staff', { cookie: adminCookie, body: { ...staffBody, contactEmail: E.bad, branch: new mongoose.Types.ObjectId().toString() } });
  check('staff: unknown branch rejected (400)', r.status === 400);

  r = await api('GET', `/api/admin/staff?search=${encodeURIComponent('delacruz' + SFX)}&branch=${tb._id}`, { cookie: adminCookie });
  check('staff: list supports search + branch filter and shows "invite pending"', r.status === 200 && r.json.staff.length === 1 && r.json.staff[0].passwordSet === false && r.json.staff[0].branch?.name === TEST_BRANCH, JSON.stringify(r.json).slice(0, 200));

  r = await api('POST', `/api/admin/staff/${staff._id}/resend-invite`, { cookie: adminCookie });
  check('staff: invite can be resent before a password is set', r.status === 200);

  // ---------- Organizer sets first password, logs in ----------
  r = await login(orgAcct);
  check('organizer cannot log in before setting a password (401)', r.status === 401);
  r = await api('POST', '/api/auth/forgot-password', { body: { email: orgAcct } });
  const inviteCode = await VerificationCode.findOne({ user: dbStaff._id, purpose: 'reset_password' });
  check('organizer setup: the code goes to the REAL (contact) email', r.status === 200 && inviteCode?.target === E.org, inviteCode?.target);
  await VerificationCode.updateOne({ user: dbStaff._id, purpose: 'reset_password' }, { codeHash: hashCode(KNOWN), attempts: 0, expiresAt: new Date(Date.now() + 600000) });
  r = await api('POST', '/api/auth/verify-reset-code', { body: { email: orgAcct, code: KNOWN } });
  r = await api('POST', '/api/auth/reset-password', { body: { resetToken: r.json.resetToken, password: PASS, confirmPassword: PASS } });
  r = await login(orgAcct);
  const orgCookie = r.cookie;
  check('organizer logs in with the GENERATED email; the response includes the branch name', r.status === 200 && r.json.user.role === 'organizer' && r.json.user.branch?.name === TEST_BRANCH, JSON.stringify(r.json.user));
  r = await api('POST', `/api/admin/staff/${staff._id}/resend-invite`, { cookie: adminCookie });
  check('invite cannot be resent after the password is set (409)', r.status === 409);

  // ---------- Organizer permissions ----------
  r = await api('GET', '/api/teams', { cookie: orgCookie });
  check('organizer sees ONLY their own branch teams (55)', r.status === 200 && r.json.total === 55 && r.json.teams.every((t) => t.branch.name === TEST_BRANCH), `total ${r.json.total}`);
  r = await api('GET', `/api/teams?branch=${makati._id}`, { cookie: orgCookie });
  check('organizer asking for ANOTHER branch\'s teams is refused (403)', r.status === 403 && r.json.code === 'FORBIDDEN_BRANCH');
  r = await api('GET', `/api/teams?branch=${tb._id}`, { cookie: orgCookie });
  check('...but may name their own branch explicitly', r.status === 200 && r.json.total === 55);
  r = await api('GET', '/api/event-types', { cookie: orgCookie });
  r = await api('GET', '/api/event-types', { cookie: orgCookie });
const seminar = r.json.eventTypes?.find((t) => t.name === 'Seminar');

check('organizer can VIEW event types and their team structure',
  r.status === 200 &&
  r.json.eventTypes.length >= 1 &&
  Array.isArray(seminar?.staffing) &&
  seminar.teamSize >= 1
);
  
  check('organizer can VIEW event types and their team structure', r.status === 200 && r.json.eventTypes.length >= 1 && Array.isArray(seminar?.staffing) && seminar.teamSize >= 1);
  r = await api('PATCH', `/api/event-types/${seminar._id}`, { cookie: orgCookie, body: { description: 'hacked' } });
  check('organizer cannot edit event types (403)', r.status === 403);
  const someTeam = await Team.findOne({ branch: tb._id });
  r = await api('PATCH', `/api/teams/${someTeam._id}/status`, { cookie: orgCookie, body: { isActive: false } });
  check('organizer cannot change team status (403)', r.status === 403);
  r = await api('POST', '/api/branches', { cookie: orgCookie, body: { name: 'Nope', code: 'NOPE' } });
  check('organizer cannot create branches (403)', r.status === 403);
  r = await api('PATCH', `/api/branches/${tb._id}/status`, { cookie: orgCookie, body: { isActive: false } });
  check('organizer cannot deactivate branches (403)', r.status === 403);
  r = await api('GET', '/api/admin/staff', { cookie: orgCookie });
  check('organizer cannot open admin staff endpoints (403)', r.status === 403);

  // ---------- Event types (admin) ----------
  originalEventType = await EventType.findById(seminar._id).lean();
  r = await api('PATCH', `/api/event-types/${seminar._id}`, { cookie: adminCookie, body: { staffing: [{ role: 'Lead', count: 2 }, { role: 'lead', count: 3 }] } });
  check('event type: duplicate roles rejected (422)', r.status === 422);
  r = await api('PATCH', `/api/event-types/${seminar._id}`, { cookie: adminCookie, body: { staffing: [{ role: 'Lead', count: 50 }, { role: 'Crew', count: 50 }, { role: 'Extra', count: 1 }] } });
  check('event type: more than 100 members rejected (422)', r.status === 422);
  r = await api('PATCH', `/api/event-types/${seminar._id}`, { cookie: adminCookie, body: { description: 'Updated by test', staffing: [{ role: 'Lead', count: 2 }, { role: 'Crew', count: 8 }] } });
  check('event type: admin edits structure and team size updates (10)', r.status === 200 && r.json.eventType.teamSize === 10 && r.json.eventType.name === 'Seminar');
  r = await api('PATCH', `/api/event-types/${seminar._id}`, { cookie: adminCookie, body: { name: 'Renamed' } });
  check('event type: name stays fixed', (await EventType.findById(seminar._id)).name === 'Seminar');

  // ---------- Teams (admin) ----------
  r = await api('GET', `/api/teams?branch=${tb._id}&eventType=${seminar._id}`, { cookie: adminCookie });
  check('teams: admin filters by branch and event type (5 Seminar teams)', r.status === 200 && r.json.total === 5 && r.json.teams.map((t) => t.number).join() === '1,2,3,4,5');
  r = await api('GET', `/api/teams?branch=${tb._id}&search=${encodeURIComponent('seminar team 2')}`, { cookie: adminCookie });
  check('teams: search by name', r.json.total === 1 && r.json.teams[0].name === 'Seminar Team 2');
  r = await api('PATCH', `/api/teams/${someTeam._id}/status`, { cookie: adminCookie, body: { isActive: false } });
  check('teams: admin can deactivate a team', r.status === 200 && r.json.team.isActive === false);
  r = await api('GET', `/api/teams?branch=${tb._id}&status=inactive`, { cookie: adminCookie });
  check('teams: status filter finds it', r.json.total === 1);
  await api('PATCH', `/api/teams/${someTeam._id}/status`, { cookie: adminCookie, body: { isActive: true } });

  // ---------- Staff update / deactivate ----------
  r = await api('PATCH', `/api/admin/staff/${staff._id}`, { cookie: adminCookie, body: { firstName: 'Maria', lastName: 'Renamed', phone: '09179998888', branch: makati._id.toString(), position: 'Lead Organizer' } });
  check('staff: admin edits phone, position and branch; contact and login emails unchanged', r.status === 200 && r.json.staff.branch.code === 'MKT' && r.json.staff.position === 'Lead Organizer' && r.json.staff.contactEmail === E.org && r.json.staff.accountEmail === orgAcct);
  await api('PATCH', `/api/admin/staff/${staff._id}`, { cookie: adminCookie, body: { firstName: 'Maria', lastName: 'Renamed', phone: '09179998888', branch: tb._id, position: 'Organizer' } });

  r = await api('PATCH', `/api/branches/${tb._id}/status`, { cookie: adminCookie, body: { isActive: false } });
  check('branch: cannot be deactivated while it has active staff (409)', r.status === 409 && r.json.code === 'BRANCH_HAS_STAFF');
  r = await api('PATCH', `/api/admin/staff/${staff._id}/status`, { cookie: adminCookie, body: { status: 'inactive' } });
  check('staff: admin deactivates a staff member', r.status === 200 && r.json.staff.status === 'inactive');
  r = await login(orgAcct);
  check('deactivated staff cannot log in (403)', r.status === 403 && r.json.code === 'ACCOUNT_DISABLED');
  r = await api('GET', '/api/teams', { cookie: orgCookie });
  check('deactivated staff session stops working immediately (403)', r.status === 403);
  r = await api('PATCH', `/api/branches/${tb._id}/status`, { cookie: adminCookie, body: { isActive: false } });
  check('branch: can be deactivated once its staff are inactive', r.status === 200 && r.json.branch.isActive === false);
  r = await api('POST', '/api/admin/staff', { cookie: adminCookie, body: { ...staffBody, contactEmail: E.org2 } });
  check('staff: cannot be assigned to an inactive branch (400)', r.status === 400);
  await api('PATCH', `/api/branches/${tb._id}/status`, { cookie: adminCookie, body: { isActive: true } });
  await api('PATCH', `/api/admin/staff/${staff._id}/status`, { cookie: adminCookie, body: { status: 'active' } });
  r = await login(orgAcct);
  check('reactivated staff can log in again', r.status === 200);
}

main()
  .catch((err) => { failed++; results.push(`FAIL  test crashed -> ${err.stack || err.message}`); })
  .finally(async () => {
    let cleaned = false;
    if (mongoose.connection.readyState === 1) {
      try { await cleanup(); cleaned = true; } catch (e) { console.error('Cleanup problem:', e.message); }
    }
    console.log(results.join('\n'));
    console.log(`\n${passed} passed, ${failed} failed.${cleaned ? ' Test data removed.' : ''}`);
    server?.close();
    await mongoose.disconnect();
    process.exit(failed ? 1 : 0);
  });
