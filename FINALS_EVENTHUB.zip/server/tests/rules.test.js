// No database needed.  npm run test:rules
const assert = require('assert');
const { teamsRequired } = require('../config/rules');

const cases = [[1, 1], [100, 1], [101, 2], [150, 2], [200, 2], [201, 3], [250, 3], [300, 3], [301, 4], [400, 4], [401, 5], [500, 5]];
cases.forEach(([attendees, teams]) => assert.strictEqual(teamsRequired(attendees), teams, `${attendees} attendees`));
[0, -5, 501, 1000, 12.5, 'abc', null].forEach((bad) => assert.throws(() => teamsRequired(bad), RangeError, `reject ${bad}`));
assert.strictEqual(teamsRequired('250'), 3, 'numeric strings from forms are accepted');

console.log(`teamsRequired: ${cases.length} boundary cases and 7 invalid inputs passed.`);

// ---- booking rules ----
const { splitPayment, addDays, isValidDate, isValidTime, isSelectableDate, bookableRange, todayManila } = require('../config/rules');
assert.deepStrictEqual(splitPayment(55500), { down: 27750, remaining: 27750 }, 'flow example: 50% of 55,500');
assert.deepStrictEqual(splitPayment(55501), { down: 27750.5, remaining: 27750.5 });
assert.deepStrictEqual(splitPayment(1), { down: 0.5, remaining: 0.5 });
assert.strictEqual(addDays('2026-12-31', 1), '2027-01-01');
assert.strictEqual(addDays('2026-03-01', -1), '2026-02-28');
assert.ok(isValidDate('2026-02-28') && !isValidDate('2026-02-30') && !isValidDate('2026-2-3') && !isValidDate(null));
assert.ok(isValidTime('09:30') && isValidTime('23:59') && !isValidTime('24:00') && !isValidTime('9:30'));
const { min, max } = bookableRange();
assert.strictEqual(min, addDays(todayManila(), 1), 'tomorrow is the first bookable date');
assert.ok(!isSelectableDate(todayManila()) && isSelectableDate(min) && isSelectableDate(max) && !isSelectableDate(addDays(max, 1)));
console.log('booking rules: payment split, date and time helpers passed.');
