// End-to-end check of the Booking module against MONGO_URI.   Run:  npm run test:booking
//
// Covers: availability calendar, booking creation, the team hold (24h) / lock / release flow,
// Admin approval with re-check, 50% down payment submission and verification, expiry,
// role visibility, secure file access, notifications.
// It uses throwaway users and far-future dates, temporarily sets known prices/teams, and restores
// everything (including uploaded files, which go to a temp folder) at the end.
require('dotenv').config();
const fs = require('fs');
const os = require('os');
const path = require('path');
process.env.UPLOAD_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'eh-uploads-'));
process.env.GMAIL_USER = '';
process.env.GMAIL_APP_PASSWORD = '';
process.env.NODE_ENV = 'development';
process.env.JWT_SECRET = process.env.JWT_SECRET || 'e2e_test_secret';
if (!process.env.MONGO_URI) { console.error('MONGO_URI is not set. Add it to .env first.'); process.exit(1); }

const mongoose = require('mongoose');
const User = require('../models/User');
const Branch = require('../models/Branch');
const EventType = require('../models/EventType');
const Team = require('../models/Team');
const Bundle = require('../models/Bundle');
const AddOn = require('../models/AddOn');
const Booking = require('../models/Booking');
const Payment = require('../models/Payment');
const TeamReservation = require('../models/TeamReservation');
const Notification = require('../models/Notification');
const { ensureAllSetup } = require('../services/setup');
const { todayManila, addDays } = require('../config/rules');
const app = require('../app');

const run = Date.now().toString(36);
const mail = (tag) => `eh.test.${run}.${tag}@example.com`;
const DOM = { user: 'user.eventhub.com', organizer: 'organizer.eventhub.com', admin: 'admin.eventhub.com' };
const acct = (c, role) => `${c.split('@')[0]}@${DOM[role]}`; // generated login email for a test account

const E = { admin: mail('admin'), orgMkt: mail('orgmkt'), orgCeb: mail('orgceb'), u1: mail('u1'), u2: mail('u2') };
const PASS = 'Passw0rdOne';
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');

const OFFSET = 120 + (parseInt(run, 36) % 120);
const D = (i) => addDays(todayManila(), OFFSET + i);

let server, base, passed = 0, failed = 0;
const results = [];
const saved = { bundles: [], addOns: [], teams: [] };
const check = (name, ok, extra = '') => { (ok ? passed++ : failed++); results.push(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok ? '' : '  -> ' + extra}`); };

async function api(method, p, { body, cookie } = {}) {
  const res = await fetch(base + p, { method, headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const set = res.headers.getSetCookie?.() || [];
  const tokenCookie = set.map((c) => c.split(';')[0]).find((c) => c.startsWith('eventhub_token='));
  const type = res.headers.get('content-type') || '';
  return { status: res.status, type, json: type.includes('json') ? await res.json().catch(() => ({})) : {}, cookie: tokenCookie };
}
async function upload(p, cookie, { fields = {}, file, field = 'receipt', mime = 'image/png', name = 'file.png' } = {}) {
  const fd = new FormData();
  Object.entries(fields).forEach(([k, v]) => fd.append(k, v));
  if (file) fd.append(field, new Blob([file], { type: mime }), name);
  const res = await fetch(base + p, { method: 'POST', headers: cookie ? { Cookie: cookie } : {}, body: fd });
  return { status: res.status, json: await res.json().catch(() => ({})) };
}
const login = async (accountEmail) => (await api('POST', '/api/auth/login', { body: { accountEmail, password: PASS } })).cookie;

async function cleanup() {
  const users = await User.find({ contactEmail: new RegExp(`^eh\\.test\\.${run}\\.`) });
  const ids = users.map((u) => u._id);
  const bookings = await Booking.find({ company: { $in: ids } }).select('_id');
  const bids = bookings.map((b) => b._id);
  await TeamReservation.deleteMany({ booking: { $in: bids } });
  await Payment.deleteMany({ booking: { $in: bids } });
  await Notification.deleteMany({ $or: [{ user: { $in: ids } }, { booking: { $in: bids } }] });
  await Booking.deleteMany({ _id: { $in: bids } });
  await User.deleteMany({ _id: { $in: ids } });
  for (const b of saved.bundles) await Bundle.updateOne({ _id: b._id }, { capacity: b.capacity, price: b.price, isActive: b.isActive });
  for (const a of saved.addOns) await AddOn.updateOne({ _id: a._id }, { price: a.price, isActive: a.isActive });
  for (const t of saved.teams) await Team.updateOne({ _id: t._id }, { isActive: t.isActive });
  fs.rmSync(process.env.UPLOAD_DIR, { recursive: true, force: true });
}

async function main() {
  await mongoose.connect(process.env.MONGO_URI);
  console.log(`Connected to database "${mongoose.connection.name}" on ${mongoose.connection.host}\n`);
  await Promise.all([User.init(), Booking.init(), Payment.init(), TeamReservation.init(), Team.init()]).catch(() => {});
  server = app.listen(0);
  base = `http://127.0.0.1:${server.address().port}`;
  let r;

  await ensureAllSetup();
  const makati = await Branch.findOne({ code: 'MKT' });
  const cebu = await Branch.findOne({ code: 'CEB' });
  const seminar = await EventType.findOne({ slug: 'seminar' });
  const bundles = await Bundle.find({ eventType: seminar._id }).sort('level');
  const [basic, standard, premium] = bundles;
  const addOns = await AddOn.find({ name: { $in: ['LED Display', 'Photography', 'Additional Microphones'] } });
  const led = addOns.find((a) => a.name === 'LED Display'), photo = addOns.find((a) => a.name === 'Photography'), mics = addOns.find((a) => a.name === 'Additional Microphones');
  const teams = await Team.find({ branch: makati._id, eventType: seminar._id }).sort('number');
  saved.bundles = bundles.map((b) => b.toObject());
  saved.addOns = addOns.map((a) => a.toObject());
  saved.teams = teams.map((t) => t.toObject());
  await Bundle.bulkWrite([
    { updateOne: { filter: { _id: basic._id }, update: { capacity: 100, price: 25000, isActive: true } } },
    { updateOne: { filter: { _id: standard._id }, update: { capacity: 200, price: 40000, isActive: true } } },
  ]);
  await AddOn.bulkWrite([
    { updateOne: { filter: { _id: led._id }, update: { price: 8000, isActive: true } } },
    { updateOne: { filter: { _id: photo._id }, update: { price: 6000, isActive: true } } },
    { updateOne: { filter: { _id: mics._id }, update: { price: 1500, isActive: true } } },
  ]);
  await Team.updateMany({ _id: { $in: teams.map((t) => t._id) } }, { isActive: true });

  await User.create({ firstName: 'Ad', lastName: 'Min', contactEmail: E.admin, accountEmail: acct(E.admin, 'admin'), password: PASS, role: 'admin', isVerified: true });
  await User.create({ firstName: 'Mk', lastName: 'Org', contactEmail: E.orgMkt, accountEmail: acct(E.orgMkt, 'organizer'), password: PASS, role: 'organizer', isVerified: true, branch: makati._id, position: 'Organizer' });
  await User.create({ firstName: 'Cb', lastName: 'Org', contactEmail: E.orgCeb, accountEmail: acct(E.orgCeb, 'organizer'), password: PASS, role: 'organizer', isVerified: true, branch: cebu._id, position: 'Organizer' });
  await User.create({ firstName: 'Una', lastName: 'One', companyName: 'ABC Company', contactEmail: E.u1, accountEmail: acct(E.u1, 'user'), password: PASS, role: 'user', isVerified: true, phone: '09170000001' });
  await User.create({ firstName: 'Dos', lastName: 'Two', companyName: 'Zeta Corp', contactEmail: E.u2, accountEmail: acct(E.u2, 'user'), password: PASS, role: 'user', isVerified: true, phone: '09170000002' });
  const [admin, orgMkt, orgCeb, u1, u2] = await Promise.all([acct(E.admin, 'admin'), acct(E.orgMkt, 'organizer'), acct(E.orgCeb, 'organizer'), acct(E.u1, 'user'), acct(E.u2, 'user')].map(login));
  const u1Doc = await User.findOne({ contactEmail: E.u1 }), u2Doc = await User.findOne({ contactEmail: E.u2 });

  const payload = (over = {}) => ({
    eventName: 'ABC Leadership Seminar 2026', eventType: String(seminar._id), attendees: 150, branch: String(makati._id),
    date: D(0), startTime: '09:00', endTime: '17:00', bundle: String(standard._id),
    addOns: [led, photo, mics].map((a) => String(a._id)), requirements: 'Classroom-style seating and registration tables near the entrance.', agreement: true, ...over,
  });
  const reservations = (id) => TeamReservation.find({ booking: id });
  const month = (d) => d.slice(0, 7);

  // ================= Availability calendar =================
  r = await api('GET', `/api/availability?branch=${makati._id}&eventType=${seminar._id}&attendees=150&month=${month(D(0))}`, { cookie: u1 });
  const dayU = r.json.days?.find((d) => d.date === D(0));
  check('calendar: a far-future date is available; user sees no team counts', r.status === 200 && dayU?.status === 'available' && !('freeTeams' in dayU) && r.json.requiredTeams === 2);
  r = await api('GET', `/api/availability?branch=${makati._id}&eventType=${seminar._id}&attendees=150&month=${todayManila().slice(0, 7)}`, { cookie: admin });
  const today = r.json.days.find((d) => d.date === todayManila());
  check('calendar: today and past dates are "past" (not selectable); admin sees free-team counts', today?.status === 'past' && r.json.days.every((d) => d.status === 'past' || 'freeTeams' in d));
  r = await api('GET', `/api/availability?branch=${makati._id}&eventType=${seminar._id}&attendees=501&month=${month(D(0))}`, { cookie: u1 });
  check('calendar: 501 attendees refused (422)', r.status === 422);
  r = await api('GET', `/api/availability?eventType=${seminar._id}&attendees=150&month=${month(D(0))}`, { cookie: orgCeb });
  check('calendar: an Organizer sees their own branch', r.status === 200 && r.json.branch?.name === cebu.name, r.json.branch?.name);
  r = await api('GET', `/api/availability?branch=${makati._id}&eventType=${seminar._id}&attendees=150&month=${month(D(0))}`, { cookie: orgCeb });
  check('calendar: an Organizer asking for another branch is refused (403)', r.status === 403 && r.json.code === 'FORBIDDEN_BRANCH');
  r = await api('GET', `/api/availability?eventType=${seminar._id}&attendees=150&month=${month(D(0))}`);
  check('calendar: logged-out visitors refused (401)', r.status === 401);

  // ================= Creating a booking =================
  r = await api('POST', '/api/bookings', { cookie: admin, body: payload() });
  const a = r.status === 403;
  r = await api('POST', '/api/bookings', { cookie: orgMkt, body: payload() });
  check('only a User/Company can create a booking (Admin and Organizer get 403)', a && r.status === 403);
  const bad = async (over, status, code) => { const x = await api('POST', '/api/bookings', { cookie: u1, body: payload(over) }); return x.status === status && (!code || x.json.code === code); };
  check('creation: today is not selectable (400)', await bad({ date: todayManila() }, 400, 'DATE_NOT_SELECTABLE'));
  check('creation: past date refused (400)', await bad({ date: addDays(todayManila(), -3) }, 400, 'DATE_NOT_SELECTABLE'));
  check('creation: date beyond the booking window refused (400)', await bad({ date: addDays(todayManila(), 500) }, 400, 'DATE_NOT_SELECTABLE'));
  check('creation: end time must be after start time (400)', await bad({ startTime: '17:00', endTime: '09:00' }, 400, 'BAD_TIME'));
  check('creation: terms must be accepted (422)', await bad({ agreement: false }, 422));
  check('creation: 501 attendees refused (422)', await bad({ attendees: 501 }, 422));
  check('creation: bundle capacity is enforced (Basic cannot take 150) (400)', await bad({ bundle: String(basic._id) }, 400, 'BUNDLE_CAPACITY'));

  r = await api('POST', '/api/bookings', { cookie: u1, body: payload() });
  const b1 = r.json.booking;
  check('creation: booking submitted as Pending Admin Approval', r.status === 201 && b1.status === 'pending_approval' && /^EH-\d{4}-\d{5}$/.test(b1.code), JSON.stringify(r.json).slice(0, 200));
  check('creation: flow example totals 55,500 / down payment 27,750 / remaining 27,750, 2 teams', b1.total === 55500 && b1.downPaymentAmount === 27750 && b1.remainingAmount === 27750 && b1.teamsRequired === 2);
  check('creation: bundle and add-on names and prices are copied into the booking', b1.bundle.name === 'Standard Seminar' && b1.bundle.price === 40000 && b1.addOns.map((x) => `${x.name}:${x.price}`).join() === 'LED Display:8000,Photography:6000,Additional Microphones:1500');
  check('creation: Admin is notified of the new request', (await Notification.countDocuments({ type: 'booking_submitted', booking: b1._id })) >= 1);
  check('a pending booking holds NO teams', (await reservations(b1._id)).length === 0);
 r = await api('POST', '/api/bookings', {
  cookie: u2,
  body: payload({ eventName: 'Zeta Seminar' }),
});
const b2 = r.json.booking;

r = await api('POST', '/api/bookings', {
  cookie: u1,
  body: payload({ eventName: 'ABC Second Seminar' }),
});
const b3 = r.json.booking;

  check('several pending bookings can request the same date', !!b2 && !!b3 && b2.status === 'pending_approval' && b3.status === 'pending_approval');
  r = await api('GET', `/api/availability?branch=${makati._id}&eventType=${seminar._id}&attendees=150&month=${month(D(0))}`, { cookie: admin });
  check('availability is unchanged by pending bookings (5 teams free)', r.json.days.find((d) => d.date === D(0)).freeTeams === 5);

  // ================= Reference image & file access =================
  r = await upload(`/api/bookings/${b1._id}/reference-image`, u1, { field: 'referenceImage', file: PNG, name: 'layout.png' });
  check('reference image: user uploads a valid image', r.status === 200, JSON.stringify(r.json));
  r = await upload(`/api/bookings/${b1._id}/reference-image`, u1, { field: 'referenceImage', file: Buffer.from('this is not a png'), name: 'fake.png' });
  check('reference image: a fake image (wrong file signature) is refused (400)', r.status === 400 && r.json.code === 'BAD_FILE');
  r = await upload(`/api/bookings/${b1._id}/reference-image`, u1, { field: 'referenceImage', file: Buffer.from('hello'), mime: 'text/plain', name: 'a.txt' });
  check('reference image: unsupported file type refused (400)', r.status === 400);
  r = await upload(`/api/bookings/${b1._id}/reference-image`, u1, { field: 'referenceImage', file: Buffer.alloc(5 * 1024 * 1024 + 10), name: 'big.png' });
  check('reference image: files over 5 MB refused (400)', r.status === 400);
  r = await upload(`/api/bookings/${b1._id}/reference-image`, u2, { field: 'referenceImage', file: PNG, name: 'x.png' });
  check('reference image: another company cannot upload to this booking (403)', r.status === 403);
  const imgGet = (cookie) => api('GET', `/api/bookings/${b1._id}/reference-image`, { cookie });
  r = await imgGet(u1); const own = r.status === 200 && r.type.includes('image/png');
  check('reference image: owner can view it', own);
  check('reference image: Admin and the branch Organizer can view it', (await imgGet(admin)).status === 200 && (await imgGet(orgMkt)).status === 200);
  check('reference image: other branch Organizer and other company are refused (403), visitors 401', (await imgGet(orgCeb)).status === 403 && (await imgGet(u2)).status === 403 && (await imgGet()).status === 401);

  // ================= Who sees what =================
  r = await api('GET', `/api/bookings/${b1._id}`, { cookie: u2 });
  check('another company cannot open this booking (403)', r.status === 403);
  r = await api('GET', `/api/bookings/${b1._id}`, { cookie: orgCeb });
  check('an Organizer of another branch cannot open it (403)', r.status === 403);
  r = await api('GET', `/api/bookings/${b1._id}`, { cookie: orgMkt });
  const ob = r.json.booking;
  check('the branch Organizer sees event details but NO prices or payments', r.status === 200 && ob.company?.companyName === 'ABC Company' && !('total' in ob) && !('payments' in ob) && !('downPaymentAmount' in ob) && !('price' in ob.bundle) && ob.addOns.every((x) => !('price' in x)));
  r = await api('GET', `/api/bookings/${b1._id}`, { cookie: admin });
  check('Admin sees everything, plus team availability for a pending request', r.json.booking.total === 55500 && r.json.booking.teamAvailability?.required === 2 && r.json.booking.teamAvailability?.free === 5);
  r = await api('GET', '/api/bookings', { cookie: u1 });
  check('a company lists only its own bookings', r.json.bookings.length === 2 && r.json.bookings.every((x) => x.company?.companyName === 'ABC Company'));
  r = await api('GET', '/api/bookings?scope=requests', { cookie: orgMkt });
  check('Organizer list: own-branch requests, with no totals', r.json.total >= 3 && r.json.bookings.every((x) => !('total' in x)));
  r = await api('GET', '/api/bookings?scope=events', { cookie: admin });
  check('Events scope excludes unconfirmed bookings', !r.json.bookings.some((x) => x._id === b1._id));
  r = await api('GET', `/api/bookings?search=${encodeURIComponent('zeta')}`, { cookie: admin });
  check('Admin can search by company name', r.json.bookings.some((x) => x._id === b2._id) && !r.json.bookings.some((x) => x._id === b1._id));
  r = await api('GET', `/api/bookings?search=${encodeURIComponent(b1.code)}`, { cookie: admin });
  check('Admin can search by booking code', r.json.total === 1 && r.json.bookings[0]._id === b1._id);
  r = await api('GET', '/api/bookings?limit=1&page=2&scope=requests', { cookie: admin });
  check('pagination works', r.json.bookings.length === 1 && r.json.page === 2 && r.json.pages >= 3);

  // ================= Admin approval: hold teams for 24 hours =================
  for (const [label, cookie] of [['user', u1], ['organizer', orgMkt]]) {
    r = await api('POST', `/api/bookings/${b1._id}/approve`, { cookie });
    check(`${label} cannot approve or reject (403)`, r.status === 403 && (await api('POST', `/api/bookings/${b1._id}/reject`, { cookie, body: { reason: 'nope nope' } })).status === 403);
  }
  r = await api('POST', `/api/bookings/${b1._id}/approve`, { cookie: admin });
  const ap1 = await Booking.findById(b1._id);
  const hold1 = await reservations(b1._id);
  check('approval: status becomes Payment Required', r.status === 200 && ap1.status === 'payment_required', JSON.stringify(r.json));
  const hrs = (ap1.paymentDeadline - Date.now()) / 3600000;
  check('approval: the payment deadline is 24 hours away', hrs > 23.98 && hrs <= 24.001, hrs);
  check('approval: exactly the 2 required teams are HELD until the deadline', hold1.length === 2 && hold1.every((x) => x.status === 'held' && +x.heldUntil === +ap1.paymentDeadline) && ap1.assignedTeams.length === 2);
  check('approval: the company is notified', (await Notification.countDocuments({ user: u1Doc._id, type: 'booking_approved' })) === 1);
  r = await api('GET', `/api/availability?branch=${makati._id}&eventType=${seminar._id}&attendees=150&month=${month(D(0))}`, { cookie: admin });
  check('held teams are no longer free (3 left), still bookable for 150 attendees', r.json.days.find((d) => d.date === D(0)).freeTeams === 3 && r.json.days.find((d) => d.date === D(0)).status === 'available');
  r = await api('POST', `/api/bookings/${b1._id}/approve`, { cookie: admin });
  check('a booking cannot be approved twice (409)', r.status === 409 && r.json.code === 'INVALID_STATE');
  r = await api('POST', `/api/bookings/${b2._id}/approve`, { cookie: admin });
  const hold2 = await reservations(b2._id);
  const teamIds = new Set([...hold1, ...hold2].map((x) => String(x.team)));
  check('second approval gets DIFFERENT teams (4 distinct teams held)', r.status === 200 && teamIds.size === 4);
  r = await api('GET', `/api/availability?branch=${makati._id}&eventType=${seminar._id}&attendees=150&month=${month(D(0))}`, { cookie: u1 });
  check('now the date shows Unavailable for 150 attendees (needs 2, 1 free)', r.json.days.find((d) => d.date === D(0)).status === 'unavailable');
  r = await api('POST', `/api/bookings/${b3._id}/approve`, { cookie: admin });
  check('availability is RE-CHECKED at approval: not enough teams left (409)', r.status === 409 && r.json.code === 'NO_TEAMS_AVAILABLE' && (await reservations(b3._id)).length === 0);
  r = await api('POST', '/api/bookings', { cookie: u1, body: payload({ eventName: 'Late request' }) });
  check('a new request for that date is refused with the flow message (409)', r.status === 409 && r.json.message === 'No team is available for your selected schedule. Please select another date.');

  // ---- reject ----
  r = await api('POST', `/api/bookings/${b3._id}/reject`, { cookie: admin, body: { reason: '' } });
  check('rejecting needs a reason (422)', r.status === 422);
  r = await api('POST', `/api/bookings/${b3._id}/reject`, { cookie: admin, body: { reason: 'Requested schedule is no longer available.' } });
  const rej = await Booking.findById(b3._id);
  check('reject: status Rejected with the reason, company notified', r.status === 200 && rej.status === 'rejected' && rej.rejectionReason.startsWith('Requested schedule') && (await Notification.countDocuments({ user: u1Doc._id, type: 'booking_rejected' })) === 1);
  r = await api('POST', `/api/bookings/${b3._id}/approve`, { cookie: admin });
  check('a rejected booking cannot be approved (409)', r.status === 409);

  // ================= Concurrency: two Admins, one free team =================
  await Team.updateMany({ _id: { $in: teams.slice(1).map((t) => t._id) } }, { isActive: false });
  const small = (over) => payload({ attendees: 50, bundle: String(basic._id), addOns: [], date: D(1), ...over });
  const c1 = (await api('POST', '/api/bookings', { cookie: u1, body: small({ eventName: 'Race one' }) })).json.booking;
  const c2 = (await api('POST', '/api/bookings', { cookie: u2, body: small({ eventName: 'Race two' }) })).json.booking;
  const race = await Promise.all([api('POST', `/api/bookings/${c1._id}/approve`, { cookie: admin }), api('POST', `/api/bookings/${c2._id}/approve`, { cookie: admin })]);
  const codes = race.map((x) => x.status).sort();
  check('concurrent approvals for the last free team: exactly one wins (200 + 409)', codes.join() === '200,409', codes.join());
  check('only one team is reserved on that date (no double booking)', (await TeamReservation.countDocuments({ date: D(1), branch: makati._id })) === 1);
  await Team.updateMany({ _id: { $in: teams.map((t) => t._id) } }, { isActive: true });

  // ================= Down payment (50%) =================
  const pay = (id, cookie, fields, file, mime = 'image/png', name = 'receipt.png') => upload(`/api/bookings/${id}/payments`, cookie, { fields, file, mime, name });
  const good = { method: 'gcash', referenceNumber: 'GC1234567' };
  r = await pay(b2._id, u1, good, PNG);
  check('payment: another company cannot pay for this booking (403)', r.status === 403);
  const b5 = (await api('POST', '/api/bookings', { cookie: u1, body: payload({ date: D(2), eventName: 'Pending one' }) })).json.booking;
  r = await pay(b5._id, u1, good, PNG);
  check('payment: not allowed before Admin approval (409)', r.status === 409);
  r = await pay(b3._id, u1, good, PNG);
  check('payment: not allowed on a rejected booking (409)', r.status === 409);
  r = await pay(b1._id, u1, { method: 'cash', referenceNumber: 'GC1234567' }, PNG);
  check('payment: only GCash or Bank Transfer (422)', r.status === 422);
  r = await pay(b1._id, u1, { method: 'gcash', referenceNumber: 'x' }, PNG);
  check('payment: a reference number is required (422)', r.status === 422);
  r = await pay(b1._id, u1, good, undefined);
  check('payment: a receipt is required (400)', r.status === 400);
  r = await pay(b1._id, u1, good, Buffer.from('not an image'));
  check('payment: a fake receipt is refused (400)', r.status === 400);
  check('payment: nothing changed after those failures', (await Booking.findById(b1._id)).status === 'payment_required' && (await Payment.countDocuments({ booking: b1._id })) === 0);
  r = await pay(b1._id, u1, good, PNG);
  const sub1 = await Booking.findById(b1._id);
  const pay1 = await Payment.findOne({ booking: b1._id });
  check('payment: submitted -> Payment Verification, amount = 50% (27,750)', r.status === 201 && sub1.status === 'payment_verification' && pay1.amount === 27750 && pay1.status === 'pending');
  const heldNow = await reservations(b1._id);
  check('payment: teams stay held, and the hold can no longer lapse during review', heldNow.length === 2 && heldNow.every((x) => x.status === 'held' && !x.heldUntil));
  check('payment: Admin is notified', (await Notification.countDocuments({ type: 'payment_submitted', booking: b1._id })) >= 1);
  r = await pay(b1._id, u1, { method: 'gcash', referenceNumber: 'GC7654321' }, PNG);
  check('payment: a second submission while under review is refused (409)', r.status === 409);
  r = await pay(b2._id, u2, good, PNG);
  check('payment: a reference number cannot be reused (409)', r.status === 409 && r.json.code === 'REFERENCE_USED');

  // under review, the deadline passes: the booking must NOT expire
  await Booking.updateOne({ _id: b1._id }, { paymentDeadline: new Date(Date.now() - 3600 * 1000) });
  r = await api('GET', `/api/bookings/${b1._id}`, { cookie: u1 });
  check('a booking whose payment is under review does NOT expire at the deadline', r.json.booking.status === 'payment_verification' && (await reservations(b1._id)).length === 2);
  r = await api('GET', `/api/bookings/${b1._id}`, { cookie: admin });
  const payId1 = r.json.booking.payments[0]._id;
  check('receipt: Admin and the paying company can view it; Organizer and other companies cannot', (await api('GET', `/api/payments/${payId1}/receipt`, { cookie: admin })).status === 200 && (await api('GET', `/api/payments/${payId1}/receipt`, { cookie: u1 })).status === 200 && (await api('GET', `/api/payments/${payId1}/receipt`, { cookie: orgMkt })).status === 403 && (await api('GET', `/api/payments/${payId1}/receipt`, { cookie: u2 })).status === 403 && (await api('GET', `/api/payments/${payId1}/receipt`)).status === 401);

  // reject AFTER the deadline: nothing left to pay into -> expires (strict 24-hour rule)
  for (const [label, cookie] of [['user', u1], ['organizer', orgMkt]]) {
    r = await api('POST', `/api/payments/${payId1}/verify`, { cookie });
    check(`${label} cannot verify or reject payments (403)`, r.status === 403 && (await api('POST', `/api/payments/${payId1}/reject`, { cookie, body: { reason: 'nope nope' } })).status === 403);
  }
  r = await api('POST', `/api/payments/${payId1}/reject`, { cookie: admin, body: { reason: '' } });
  check('rejecting a payment needs a reason (422)', r.status === 422);
  r = await api('POST', `/api/payments/${payId1}/reject`, { cookie: admin, body: { reason: 'Amount does not match.' } });
  const exp1 = await Booking.findById(b1._id);
  check('payment rejected AFTER the deadline: booking expires and the teams are released', r.status === 200 && exp1.status === 'payment_expired' && (await reservations(b1._id)).length === 0, JSON.stringify(r.json));

  // ---- normal path on b2: reject inside the window, resubmit, verify ----
  r = await pay(b2._id, u2, { method: 'bank_transfer', referenceNumber: 'BT-0001' }, PNG);
  check('b2: payment submitted', r.status === 201);
  const payId2 = (await Payment.findOne({ booking: b2._id }))._id;
  const deadline2 = (await Booking.findById(b2._id)).paymentDeadline;
  r = await api('POST', `/api/payments/${payId2}/reject`, { cookie: admin, body: { reason: 'The receipt is blurry.' } });
  const back = await Booking.findById(b2._id);
  const backHold = await reservations(b2._id);
  check('payment rejected inside the window: back to Payment Required, SAME deadline', r.status === 200 && back.status === 'payment_required' && +back.paymentDeadline === +deadline2);
  check('the teams stay held until the original deadline', backHold.length === 2 && backHold.every((x) => x.status === 'held' && +x.heldUntil === +deadline2));
  check('the company is told why', (await Notification.countDocuments({ user: u2Doc._id, type: 'payment_rejected', message: /blurry/ })) === 1);
  r = await pay(b2._id, u2, { method: 'bank_transfer', referenceNumber: 'BT-0002' }, PNG, 'application/pdf'.replace('application/pdf', 'image/png'));
  check('the company can submit a corrected payment', r.status === 201);
  const payId3 = (await Payment.findOne({ booking: b2._id, status: 'pending' }))._id;
  r = await api('POST', `/api/payments/${payId3}/verify`, { cookie: admin });
  const conf = await Booking.findById(b2._id);
  const lock = await reservations(b2._id);
  check('verified: booking is CONFIRMED', r.status === 200 && conf.status === 'confirmed' && !!conf.confirmedAt, JSON.stringify(r.json));
  check('verified: the 2 teams are LOCKED (no expiry any more)', lock.length === 2 && lock.every((x) => x.status === 'locked' && !x.heldUntil));
  check('verified: the company is notified', (await Notification.countDocuments({ user: u2Doc._id, type: 'booking_confirmed' })) === 1);
  r = await api('POST', `/api/payments/${payId3}/verify`, { cookie: admin });
  check('a payment cannot be verified twice (409)', r.status === 409);
  r = await api('GET', `/api/bookings/${b2._id}`, { cookie: u2 });
  check('the company sees both payment attempts (rejected, then verified)', r.json.booking.payments.map((p) => p.status).join() === 'rejected,verified');
  r = await api('GET', `/api/bookings/${b2._id}`, { cookie: orgMkt });
  const oh = r.json.booking.history;
  check('Organizer timeline has no payment steps or payment notes', oh.every((h) => h.status !== 'payment_verification' && !h.note) && oh.filter((h) => h.status === 'payment_required').length === 1 && !JSON.stringify(r.json.booking).match(/blurry|ayment submitted|ayment rejected|Down payment/), JSON.stringify(oh));
  r = await api('GET', `/api/bookings/${b2._id}`, { cookie: admin });
  check('Admin timeline keeps the full payment history', r.json.booking.history.some((h) => h.status === 'payment_verification') && r.json.booking.history.some((h) => /blurry/.test(h.note || '')));
  r = await api('GET', '/api/bookings?scope=events', { cookie: orgMkt });
  check('the confirmed event appears in the Organizer\'s events (no prices)', r.json.bookings.some((x) => x._id === b2._id) && r.json.bookings.every((x) => !('total' in x)));
  r = await api('GET', `/api/availability?branch=${makati._id}&eventType=${seminar._id}&attendees=150&month=${month(D(0))}`, { cookie: admin });
  check('after expiry released b1 and b2 locked: 3 teams free on the date', r.json.days.find((d) => d.date === D(0)).freeTeams === 3);

  // ================= 24-hour expiry while waiting for a payment =================
  const b6 = (await api('POST', '/api/bookings', { cookie: u1, body: small({ date: D(3), eventName: 'Will expire' }) })).json.booking;
  await api('POST', `/api/bookings/${b6._id}/approve`, { cookie: admin });
  check('b6 approved: 1 team held', (await reservations(b6._id)).length === 1);
  await Booking.updateOne({ _id: b6._id }, { paymentDeadline: new Date(Date.now() - 1000) });
  await TeamReservation.updateMany({ booking: b6._id }, { heldUntil: new Date(Date.now() - 1000) });
  r = await api('GET', `/api/availability?branch=${makati._id}&eventType=${seminar._id}&attendees=50&month=${month(D(3))}`, { cookie: u1 });
  check('a lapsed hold never blocks the calendar', r.json.days.find((d) => d.date === D(3)).status === 'available');
  r = await api('GET', `/api/bookings/${b6._id}`, { cookie: u1 });
  const e6 = r.json.booking;
  check('deadline passed without payment: Payment Expired, hold released', e6.status === 'payment_expired' && (await reservations(b6._id)).length === 0);
  check('expiry is recorded in the history by the system and the company is notified', e6.history.some((h) => h.status === 'payment_expired' && h.byRole === 'system') && (await Notification.countDocuments({ user: u1Doc._id, type: 'booking_expired', booking: b6._id })) === 1);
  r = await pay(b6._id, u1, { method: 'gcash', referenceNumber: 'GC9999999' }, PNG);
  check('an expired booking cannot be paid (409)', r.status === 409);
  await Booking.updateOne({ _id: b2._id }, { paymentDeadline: new Date(Date.now() - 86400000) });
  await api('GET', '/api/bookings', { cookie: admin });
  check('a CONFIRMED booking is never expired, whatever its old deadline', (await Booking.findById(b2._id)).status === 'confirmed' && (await reservations(b2._id)).every((x) => x.status === 'locked'));

  // ================= Outstanding balance rule =================
  await Booking.updateOne({ _id: b2._id }, { status: 'payment_overdue' });
  r = await api('POST', '/api/bookings', { cookie: u2, body: payload({ date: D(5), eventName: 'Blocked' }) });
  check('a company with an overdue balance cannot book again (403)', r.status === 403 && r.json.code === 'OUTSTANDING_BALANCE');
  await Booking.updateOne({ _id: b2._id }, { status: 'confirmed' });

  // ================= Summary & notifications =================
  r = await api('GET', '/api/bookings/summary', { cookie: u2 });
  check('summary: counts by status for the caller only', r.json.counts.confirmed === 1);
  r = await api('GET', '/api/bookings/terms', { cookie: u1 });
  check('terms: the four clauses (cancellation, damage, damage fee, payment)', r.json.terms.items.map((i) => i.title).join() === 'Cancellation,Damage,Damage fee,Payment');
  r = await api('GET', '/api/notifications', { cookie: u1 });
  const unread0 = r.json.unread;
  check('notifications: unread count and newest first', unread0 >= 3 && r.json.notifications[0].createdAt >= r.json.notifications[r.json.notifications.length - 1].createdAt);
  const mine = r.json.notifications[0]._id;
  check('notifications: nobody else can mark them read (404)', (await api('PATCH', `/api/notifications/${mine}/read`, { cookie: u2 })).status === 404);
  await api('PATCH', `/api/notifications/${mine}/read`, { cookie: u1 });
  r = await api('GET', '/api/notifications', { cookie: u1 });
  check('notifications: mark one read', r.json.unread === unread0 - 1);
  await api('POST', '/api/notifications/read-all', { cookie: u1 });
  r = await api('GET', '/api/notifications', { cookie: u1 });
  check('notifications: mark all read', r.json.unread === 0);
}

main()
  .catch((err) => { failed++; results.push(`FAIL  test crashed -> ${err.stack || err.message}`); })
  .finally(async () => {
    let cleaned = false;
    if (mongoose.connection.readyState === 1) {
      try { await cleanup(); cleaned = true; } catch (e) { console.error('Cleanup problem:', e.message); }
    }
    console.log(results.join('\n'));
    console.log(`\n${passed} passed, ${failed} failed.${cleaned ? ' Test data removed and edited records restored.' : ''}`);
    server?.close();
    await mongoose.disconnect();
    process.exit(failed ? 1 : 0);
  });
