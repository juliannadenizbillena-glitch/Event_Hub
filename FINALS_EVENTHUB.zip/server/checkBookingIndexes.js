
require('dotenv').config();
const mongoose = require('mongoose');

async function main() {
  try {
    await mongoose.connect(process.env.MONGO_URI);

    const collection = mongoose.connection.collection('bookings');

    const indexes = await collection.indexes();
    const withReference = await collection.countDocuments({
      reference: { $exists: true }
    });
    const withNullReference = await collection.countDocuments({
      reference: null
    });

    console.log('\nBOOKING INDEXES:');
    console.log(JSON.stringify(indexes, null, 2));

    console.log('\nDOCUMENTS WITH reference FIELD:', withReference);
    console.log('DOCUMENTS WITH reference NULL:', withNullReference);
  } finally {
    await mongoose.disconnect();
  }
}

main().catch(error => {
  console.error('Inspection failed:', error.message);
  process.exitCode = 1;
});
