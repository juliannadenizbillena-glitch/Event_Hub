
require('dotenv').config();
const mongoose = require('mongoose');
const Branch = require('./models/Branch');
const Team = require('./models/Team');
const EventType = require('./models/EventType');

const pairs = [
  ['Manila', 'Manila Branch'],
  ['Makati', 'Makati Branch'],
  ['Quezon City', 'Quezon City Branch'],
  ['Cebu', 'Cebu Branch'],
  ['Davao', 'Davao Branch'],
];

async function main() {
  await mongoose.connect(process.env.MONGO_URI);

  for (const [oldName, newName] of pairs) {
    const oldBranch = await Branch.findOne({ name: oldName });
    const newBranch = await Branch.findOne({ name: newName });

    if (!oldBranch || !newBranch) {
      console.log(`MISSING BRANCH: ${oldName} / ${newName}`);
      continue;
    }

    const oldTeams = await Team.find({ branch: oldBranch._id }).lean();
    const newTeams = await Team.find({ branch: newBranch._id }).lean();

    console.log(`\n=== ${oldName} vs ${newName} ===`);
    console.log(`Old branch teams: ${oldTeams.length}`);
    console.log(`Canonical branch teams: ${newTeams.length}`);

    const oldTypeCounts = {};
    const newTypeCounts = {};

    for (const team of oldTeams) {
      const key = String(team.eventType);
      oldTypeCounts[key] = (oldTypeCounts[key] || 0) + 1;
    }

    for (const team of newTeams) {
      const key = String(team.eventType);
      newTypeCounts[key] = (newTypeCounts[key] || 0) + 1;
    }

    console.log('Old team examples:', oldTeams.slice(0, 3).map(t => ({
      id: String(t._id),
      name: t.name,
      teamNumber: t.teamNumber,
      eventType: String(t.eventType),
      isActive: t.isActive,
    })));

    console.log('Canonical team examples:', newTeams.slice(0, 3).map(t => ({
      id: String(t._id),
      name: t.name,
      teamNumber: t.teamNumber,
      eventType: String(t.eventType),
      isActive: t.isActive,
    })));

    console.log('Old event-type counts:', oldTypeCounts);
    console.log('Canonical event-type counts:', newTypeCounts);
  }

  await mongoose.disconnect();
}

main().catch(async error => {
  console.error(error);
  await mongoose.disconnect().catch(() => {});
  process.exitCode = 1;
});
