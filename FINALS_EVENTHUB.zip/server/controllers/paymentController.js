const Booking = require('../models/Booking');
const Payment = require('../models/Payment');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const service = require('../services/bookingService');
const { UPLOAD_ROOT, removeFile } = require('../middleware/upload');

// Placeholder payment details. Set the real ones in .env (an Admin settings screen can come later).
const instructions = () => ({
  gcash: { accountName: process.env.PAYMENT_GCASH_NAME || 'EventHub Inc.', number: process.env.PAYMENT_GCASH_NUMBER || '0917 000 0000' },
  bankTransfer: {
    bank: process.env.PAYMENT_BANK_NAME || 'Sample Bank',
    accountName: process.env.PAYMENT_BANK_ACCOUNT_NAME || 'EventHub Inc.',
    accountNumber: process.env.PAYMENT_BANK_ACCOUNT_NUMBER || '0000-0000-00',
  },
});

// GET /api/payments/instructions  (User, Admin)
exports.instructions = (req, res) => res.json({ instructions: instructions() });

// POST /api/bookings/:id/final-payment  (User) multipart: method, referenceNumber, receipt
exports.submitFinal = asyncHandler(async (req, res) => {
  if (!req.file) throw new AppError('Upload your receipt or a screenshot of the payment.', 400, 'BAD_FILE');
  try {
    const payment = await service.submitFinalPayment(req.user, req.params.id, req.body, req.file);
    res.status(201).json({ message: 'Final payment submitted. EventHub will verify it shortly.', paymentId: payment._id });
  } catch (err) {
    removeFile(req.file.rel);
    throw err;
  }
});

// POST /api/bookings/:id/payments  (User) multipart: method, referenceNumber, receipt
exports.submit = asyncHandler(async (req, res) => {
  if (!req.file) throw new AppError('Upload your receipt or a screenshot of the payment.', 400, 'BAD_FILE');
  try {
    const payment = await service.submitDownPayment(req.user, req.params.id, req.body, req.file);
    res.status(201).json({ message: 'Payment submitted. EventHub will verify it shortly.', paymentId: payment._id });
  } catch (err) {
    removeFile(req.file.rel); // nothing was saved, so do not keep the file
    throw err;
  }
});

// GET /api/payments/:id/receipt  (the paying User or Admin only; never Organizers)
exports.getReceipt = asyncHandler(async (req, res) => {
  const payment = await Payment.findById(req.params.id);
  if (!payment?.receipt?.path) throw new AppError('Receipt not found.', 404, 'NOT_FOUND');
  if (req.user.role !== 'admin') {
    const own = await Booking.exists({ _id: payment.booking, company: req.user._id });
    if (!own) throw new AppError('You do not have access to this receipt.', 403, 'FORBIDDEN');
  }
  res.type(payment.receipt.mimeType).sendFile(payment.receipt.path, { root: UPLOAD_ROOT });
});

// POST /api/payments/:id/verify  (Admin)
exports.verify = asyncHandler(async (req, res) => {
  const payment = await Payment.findById(req.params.id);
  if (!payment) throw new AppError('Payment not found.', 404, 'NOT_FOUND');
  if (payment.type === 'final') {
    await service.verifyFinalPayment(req.params.id, req.user);
    return res.json({ message: 'Final payment verified. The event is now completed and fully paid.' });
  }
  await service.verifyPayment(req.params.id, req.user);
  res.json({ message: 'Payment verified. The booking is confirmed and the teams are locked.' });
});

// POST /api/payments/:id/reject  (Admin)
exports.reject = asyncHandler(async (req, res) => {
  const existing = await Payment.findById(req.params.id);
  if (!existing) throw new AppError('Payment not found.', 404, 'NOT_FOUND');
  if (existing.type === 'final') {
    await service.rejectFinalPayment(req.params.id, req.user, req.body.reason);
    return res.json({ message: 'Final payment rejected. The company can submit it again.' });
  }
  const { booking } = await service.rejectPayment(req.params.id, req.user, req.body.reason);
  res.json({
    message: booking.status === 'payment_expired'
      ? 'Payment rejected. The 24-hour window had already ended, so the booking expired and the teams were released.'
      : 'Payment rejected. The company can submit it again before the original deadline.',
  });
});
