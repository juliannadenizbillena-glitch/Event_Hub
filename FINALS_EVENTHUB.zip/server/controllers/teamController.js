const Team = require('../models/Team');
const User = require('../models/User');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// GET /api/teams?branch=&eventType=&status=&search=
// Admin: all branches.  Organizer: ALWAYS limited to their own branch (the filter is ignored).
exports.list = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.user.role === 'organizer') {
    const branchId = req.user.branch?._id || req.user.branch;
    if (!branchId) throw new AppError('You are not assigned to a branch yet. Contact Admin.', 403, 'NO_BRANCH');
    if (req.query.branch && String(req.query.branch) !== String(branchId)) {
      throw new AppError('You can only view teams of your assigned branch.', 403, 'FORBIDDEN_BRANCH');
    }
    filter.branch = branchId;
  } else if (req.query.branch) {
    filter.branch = req.query.branch;
  }
  if (req.query.eventType) filter.eventType = req.query.eventType;
  if (req.query.status === 'active') filter.isActive = true;
  if (req.query.status === 'inactive') filter.isActive = false;
  if (req.query.search) filter.name = { $regex: escapeRegex(String(req.query.search).slice(0, 60)), $options: 'i' };

  const teams = await Team.find(filter)
    .populate('branch', 'name code')
    .populate('eventType', 'name staffing isActive')
    .populate('assignments.staff', 'firstName lastName position branch role status isArchived');

  teams.sort((a, b) =>
    (a.branch?.name || '').localeCompare(b.branch?.name || '') ||
    (a.eventType?.name || '').localeCompare(b.eventType?.name || '') ||
    a.number - b.number
  );
  res.json({ teams, total: teams.length });
});

// PATCH /api/teams/:id/status (admin) — take a team out of / back into rotation.
exports.setStatus = asyncHandler(async (req, res) => {
  const team = await Team.findById(req.params.id);
  if (!team) throw new AppError('Team not found.', 404, 'NOT_FOUND');
  team.isActive = req.body.isActive;
  await team.save();
  await team.populate([{ path: 'branch', select: 'name code' }, { path: 'eventType', select: 'name staffing isActive' }, { path: 'assignments.staff', select: 'firstName lastName position branch role status isArchived' }]);
  res.json({ message: team.isActive ? 'Team activated.' : 'Team deactivated.', team });
});


// PUT /api/teams/:id/assignments (admin only). Only existing active staff accounts
// from this team's branch can be assigned, and each position's configured headcount is enforced.
exports.setAssignments = asyncHandler(async (req, res) => {
  const team = await Team.findById(req.params.id).populate('eventType', 'name staffing');
  if (!team) throw new AppError('Team not found.', 404, 'NOT_FOUND');
  const assignments = req.body.assignments;
  if (!Array.isArray(assignments)) throw new AppError('Assignments must be a list.', 400, 'BAD_ASSIGNMENTS');

  const allowedCounts = new Map((team.eventType?.staffing || []).map((item) => [item.role, item.count]));
  const counts = new Map();
  const staffIds = [];
  const normalized = [];
  for (const item of assignments) {
    const position = String(item?.position || '').trim();
    const staffId = item?.staff ? String(item.staff) : null;
    if (!position || !allowedCounts.has(position)) throw new AppError(`Invalid team position: ${position || '(empty)'}.`, 400, 'BAD_POSITION');
    counts.set(position, (counts.get(position) || 0) + 1);
    if (counts.get(position) > allowedCounts.get(position)) throw new AppError(`Too many assignments for ${position}.`, 400, 'POSITION_CAPACITY');
    if (staffId) staffIds.push(staffId);
    normalized.push({ position, staff: staffId });
  }
  if (new Set(staffIds).size !== staffIds.length) throw new AppError('A staff member can only be assigned once per team.', 400, 'DUPLICATE_STAFF');

  if (staffIds.length) {
    const staff = await User.find({
      _id: { $in: staffIds }, role: 'organizer', status: 'active', isArchived: false, branch: team.branch,
    }).select('_id');
    if (staff.length !== staffIds.length) throw new AppError('Choose active staff members assigned to this team’s branch.', 400, 'INVALID_STAFF');
  }
  team.assignments = normalized;
  await team.save();
  await team.populate([
    { path: 'branch', select: 'name code' },
    { path: 'eventType', select: 'name staffing isActive' },
    { path: 'assignments.staff', select: 'firstName lastName position branch role status isArchived' },
  ]);
  res.json({ message: 'Team staff assignments saved.', team });
});
