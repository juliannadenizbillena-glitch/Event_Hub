const asyncHandler = require('../utils/asyncHandler');
const AppError = require('../utils/AppError');
const { isValidDate } = require('../config/rules');
const { buildReport } = require('../services/reportService');

// GET /api/admin/reports?from=&to=&branch=&eventType=&status=   (Admin only)
exports.report = asyncHandler(async (req, res) => {
  const { from, to, branch, eventType, status } = req.query;
  if ((from && !isValidDate(from)) || (to && !isValidDate(to))) throw new AppError('Dates must look like 2026-11-20.', 422, 'BAD_DATE');
  if (from && to && from > to) throw new AppError('The start date must not be after the end date.', 422, 'BAD_DATE');
  res.json({ report: await buildReport({ from, to, branch, eventType, status }) });
});
