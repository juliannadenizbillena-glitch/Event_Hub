const User = require('../models/User');
const Booking = require('../models/Booking');
const Payment = require('../models/Payment');
const DamageReport = require('../models/DamageReport');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const { presentSummary } = require('../services/presenters');

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const ACTIVE = ['pending_approval', 'payment_required', 'payment_verification', 'confirmed', 'ongoing', 'completed_pending_final', 'payment_overdue'];
const { owed, round2 } = require('../services/finance');

// The Admin view of a customer company. The generated login email is included here (Admin only).
const profile = (u) => ({
  _id: u._id, companyName: u.companyName, firstName: u.firstName, lastName: u.lastName, contactEmail: u.contactEmail, accountEmail: u.accountEmail,
  phone: u.phone, role: u.role, status: u.status, isVerified: u.isVerified, createdAt: u.createdAt, lastLoginAt: u.lastLoginAt,
});

// GET /api/admin/companies?search=&status=&page=
exports.list = asyncHandler(async (req, res) => {
  const filter = { role: 'user', isVerified: true };
  if (['active', 'inactive'].includes(req.query.status)) filter.status = req.query.status;
  if (req.query.search) {
    const rx = { $regex: escapeRegex(String(req.query.search).slice(0, 60)), $options: 'i' };
    filter.$or = [{ companyName: rx }, { firstName: rx }, { lastName: rx }, { contactEmail: rx }, { accountEmail: rx }];
  }
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 100);
  const [total, users] = await Promise.all([User.countDocuments(filter), User.find(filter).sort('companyName').skip((page - 1) * limit).limit(limit)]);
  const bookings = await Booking.find({ company: { $in: users.map((u) => u._id) } }).select('company status downPaymentAmount remainingAmount damageTotal finalAmountDue paymentDeadline finalPaymentDueAt');
  const byCompany = {};
  bookings.forEach((b) => { (byCompany[String(b.company)] ||= []).push(b); });
  res.json({
    total, page, pages: Math.max(Math.ceil(total / limit), 1),
    companies: users.map((u) => {
      const list = byCompany[String(u._id)] || [];
      const outstanding = list.map(owed).filter((o) => o && o.due).reduce((s, o) => s + o.amount, 0);
      return { ...profile(u), bookings: list.length, activeBookings: list.filter((b) => ACTIVE.includes(b.status)).length, completedEvents: list.filter((b) => b.status === 'fully_paid').length, outstanding: round2(outstanding), hasOverdue: list.some((b) => b.status === 'payment_overdue') };
    }),
  });
});

// GET /api/admin/companies/:id
exports.get = asyncHandler(async (req, res) => {
  const user = await User.findOne({ _id: req.params.id, role: 'user' });
  if (!user) throw new AppError('Company not found.', 404, 'NOT_FOUND');
  const bookings = await Booking.find({ company: user._id }).populate('eventType', 'name').populate('branch', 'name code').sort({ date: -1 });
  const ids = bookings.map((b) => b._id);
  const [payments, damage] = await Promise.all([
    Payment.find({ booking: { $in: ids } }).sort('createdAt'),
    DamageReport.find({ booking: { $in: ids }, status: 'approved' }),
  ]);
  const code = Object.fromEntries(bookings.map((b) => [String(b._id), b.code]));
  const outstanding = bookings.map((b) => ({ b, o: owed(b) })).filter(({ o }) => o).map(({ b, o }) => ({ bookingId: b._id, code: b.code, eventName: b.eventName, status: b.status, ...o }));
  res.json({
    company: profile(user),
    stats: {
      bookings: bookings.length, active: bookings.filter((b) => ACTIVE.includes(b.status)).length, completed: bookings.filter((b) => b.status === 'fully_paid').length,
      totalPaid: round2(payments.filter((p) => p.status === 'verified').reduce((s, p) => s + p.amount, 0)),
      outstandingNow: round2(outstanding.filter((o) => o.due).reduce((s, o) => s + o.amount, 0)),
    },
    bookingHistory: bookings.map((b) => presentSummary(b, 'admin')).map((s, i) => ({ ...s, isArchived: bookings[i].isArchived })),
    outstanding,
    payments: payments.map((p) => ({ _id: p._id, bookingCode: code[String(p.booking)], bookingId: p.booking, type: p.type, amount: p.amount, method: p.method, referenceNumber: p.referenceNumber, status: p.status, rejectionReason: p.rejectionReason, submittedAt: p.createdAt, reviewedAt: p.reviewedAt })),
    damageCharges: damage.map((d) => ({ bookingCode: code[String(d.booking)], item: d.item, description: d.description, quantity: d.quantity, approvedAmount: d.approvedAmount })),
  });
});

// PATCH /api/admin/companies/:id/status  { status: active | inactive }
// An inactive company cannot log in (any open session stops working) but its records stay intact.
exports.setStatus = asyncHandler(async (req, res) => {
  const user = await User.findOne({ _id: req.params.id, role: 'user' });
  if (!user) throw new AppError('Company not found.', 404, 'NOT_FOUND');
  user.status = req.body.status;
  await user.save();
  res.json({ message: user.status === 'active' ? 'Company account reactivated.' : 'Company account deactivated. They can no longer log in.', company: profile(user) });
});
