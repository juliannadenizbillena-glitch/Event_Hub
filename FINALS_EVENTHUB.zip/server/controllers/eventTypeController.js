const EventType = require('../models/EventType');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

// GET /api/event-types — Admin sees all; everyone else only active types.
exports.list = asyncHandler(async (req, res) => {
  const filter = req.user.role === 'admin' ? {} : { isActive: true };
  const eventTypes = await EventType.find(filter).sort('name');
  res.json({ eventTypes });
});

// PATCH /api/event-types/:id (admin) — description, team structure, active flag.
// The 11 event types themselves are fixed; names are not editable.
exports.update = asyncHandler(async (req, res) => {
  const eventType = await EventType.findById(req.params.id);
  if (!eventType) throw new AppError('Event type not found.', 404, 'NOT_FOUND');

  const { description, staffing, isActive, durationModes } = req.body;
  if (description !== undefined) eventType.description = description;

if (staffing !== undefined) {
  eventType.staffing = staffing.map((s) => ({
    role: s.role.trim(),
    count: s.count,
  }));
}

if (durationModes !== undefined) {
  const allowedModes = ['hourly', 'multi_day'];

  if (
    !Array.isArray(durationModes) ||
    durationModes.length === 0 ||
    durationModes.some((mode) => !allowedModes.includes(mode))
  ) {
    throw new AppError(
      'Select at least one valid booking duration option.',
      400,
      'BAD_DURATION_MODES'
    );
  }

  eventType.durationModes = [...new Set(durationModes)];
}

if (isActive !== undefined) eventType.isActive = isActive;
  await eventType.save();

  res.json({ message: 'Event type updated.', eventType });
});
