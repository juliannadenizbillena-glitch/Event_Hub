const Branch = require('../models/Branch');
const EventType = require('../models/EventType');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const { teamsRequired } = require('../config/rules');
const { monthAvailability } = require('../services/availability');

// GET /api/availability?branch=&eventType=&attendees=&month=YYYY-MM
// Each day is available, unavailable or past (not selectable). Staff also see the free-team count.
// An Organizer is always limited to their own branch.
exports.month = asyncHandler(async (req, res) => {
  let branchId = req.query.branch;
  if (req.user.role === 'organizer') {
    const own = req.user.branch?._id || req.user.branch;
    if (!own) throw new AppError('You are not assigned to a branch yet. Contact Admin.', 403, 'NO_BRANCH');
    if (branchId && String(branchId) !== String(own)) throw new AppError('You can only view availability for your assigned branch.', 403, 'FORBIDDEN_BRANCH');
    branchId = own;
  }
  const [branch, eventType] = await Promise.all([Branch.findById(branchId), EventType.findById(req.query.eventType)]);
  if (!branch || !branch.isActive) throw new AppError('Choose an active branch.', 400, 'BAD_BRANCH');
  if (!eventType || !eventType.isActive) throw new AppError('That event type is not available.', 400, 'EVENT_TYPE_UNAVAILABLE');

  const result = await monthAvailability({
    branchId: branch._id, eventTypeId: eventType._id, month: req.query.month, required: teamsRequired(req.query.attendees),
  });
  if (req.user.role === 'user') result.days.forEach((d) => { delete d.freeTeams; }); // customers only need the colour
  res.json({ ...result, branch: { _id: branch._id, name: branch.name }, eventType: { _id: eventType._id, name: eventType.name } });
});
