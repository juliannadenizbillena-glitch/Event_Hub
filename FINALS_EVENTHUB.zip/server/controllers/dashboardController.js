const Booking = require('../models/Booking');
const Payment = require('../models/Payment');
const Branch = require('../models/Branch');
const Team = require('../models/Team');
const User = require('../models/User');
const DamageReport = require('../models/DamageReport');
const asyncHandler = require('../utils/asyncHandler');
const { presentSummary } = require('../services/presenters');
const { owed, round2 } = require('../services/finance');
const { todayManila, addDays } = require('../config/rules');

const full = (q) => q.populate('eventType', 'name').populate('branch', 'name code').populate('company', 'companyName').populate('assignedTeams', 'name');
const countBy = (list) => list.reduce((m, b) => { m[b.status] = (m[b.status] || 0) + 1; return m; }, {});

// GET /api/dashboard — a different payload for each role (the data a role needs, nothing more).
exports.dashboard = asyncHandler(async (req, res) => {
  const today = todayManila();
  const role = req.user.role;

  if (role === 'user') {
    const mine = await full(Booking.find({ company: req.user._id, isArchived: { $ne: true } }).sort({ updatedAt: -1 }));
    const outstanding = mine.map((b) => ({ b, o: owed(b) })).filter(({ o }) => o && o.due).map(({ b, o }) => ({ bookingId: b._id, code: b.code, eventName: b.eventName, status: b.status, amount: o.amount, reason: o.reason, dueAt: o.dueAt }));
    const upcoming = mine.filter((b) => ['confirmed', 'ongoing'].includes(b.status) && b.date >= today).sort((a, b) => a.date.localeCompare(b.date))[0];
    return res.json({
      role, counts: countBy(mine),
      activeBookings: mine.filter((b) => !['rejected', 'payment_expired', 'cancelled', 'fully_paid'].includes(b.status)).length,
      upcoming: upcoming ? presentSummary(upcoming, 'user') : null,
      outstanding: { total: round2(outstanding.reduce((s, o) => s + o.amount, 0)), items: outstanding },
      recent: mine.slice(0, 6).map((b) => ({ ...presentSummary(b, 'user'), lastNote: b.history.at(-1)?.note, lastAt: b.history.at(-1)?.at })),
    });
  }

  if (role === 'organizer') {
    const branch = req.user.branch?._id || req.user.branch;
    const events = await full(Booking.find({ branch, status: { $in: ['confirmed', 'ongoing', 'completed_pending_final'] }, isArchived: { $ne: true } }).sort({ date: 1 }));
    const confirmed = events.filter((b) => b.status === 'confirmed');
    const inInspection = events.filter((b) => b.status === 'completed_pending_final' && b.inspection?.status === 'pending');
    const reminders = [];
    confirmed.filter((b) => b.date <= addDays(today, 3) && !b.operations?.ready).forEach((b) => reminders.push({ bookingId: b._id, text: `${b.code} on ${b.date} is not marked ready yet.` }));
    events.filter((b) => b.status === 'ongoing').forEach((b) => reminders.push({ bookingId: b._id, text: `${b.code} is ongoing. Complete it when the event ends.` }));
    inInspection.forEach((b) => reminders.push({ bookingId: b._id, text: `${b.code}: finish the inspection and report any damage.` }));
    return res.json({
      role, branch: req.user.branch?.name,
      today: events.filter((b) => b.date === today && ['confirmed', 'ongoing'].includes(b.status)).map((b) => presentSummary(b, 'organizer')),
      upcoming: confirmed.filter((b) => b.date >= today).slice(0, 6).map((b) => ({ ...presentSummary(b, 'organizer'), ready: !!b.operations?.ready, venue: b.operations?.venueName, teams: b.assignedTeams.map((t) => t.name) })),
      preparation: { ready: confirmed.filter((b) => b.operations?.ready).length, notReady: confirmed.filter((b) => !b.operations?.ready).length },
      damageAttention: inInspection.map((b) => presentSummary(b, 'organizer')),
      reminders,
    });
  }

  // admin
  const [all, branches, teams, staff, pendingFinal, pendingDamage] = await Promise.all([
    full(Booking.find({ isArchived: { $ne: true } })),
    Branch.countDocuments({ isActive: true }), Team.countDocuments({ isActive: true }), User.countDocuments({ role: 'organizer', status: 'active', isArchived: false }),
    Payment.countDocuments({ type: 'final', status: 'pending' }), DamageReport.countDocuments({ status: 'pending' }),
  ]);
  const outstanding = all.map(owed).filter(Boolean);
  const verified = await Payment.find({ status: 'verified' });
  const month = today.slice(0, 7);
  const alerts = [];
  const overdue = all.filter((b) => b.status === 'payment_overdue');
  if (overdue.length) alerts.push({ level: 'danger', text: `${overdue.length} booking(s) have an overdue final balance.`, link: '/admin/events' });
  const toVerify = all.filter((b) => b.status === 'payment_verification').length + pendingFinal;
  if (toVerify) alerts.push({ level: 'warn', text: `${toVerify} payment(s) are waiting for verification.`, link: '/admin/booking-requests' });
  if (pendingDamage) alerts.push({ level: 'warn', text: `${pendingDamage} damage report(s) are waiting for review.`, link: '/admin/events' });
  const pending = all.filter((b) => b.status === 'pending_approval').length;
  if (pending) alerts.push({ level: 'info', text: `${pending} booking request(s) are waiting for approval.`, link: '/admin/booking-requests' });
  return res.json({
    role, counts: countBy(all),
    pendingRequests: pending, paymentsToVerify: toVerify, damageToReview: pendingDamage,
    upcomingEvents: all.filter((b) => ['confirmed', 'ongoing'].includes(b.status) && b.date >= today).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 6).map((b) => presentSummary(b, 'admin')),
    outstanding: { dueNow: round2(outstanding.filter((o) => o.due).reduce((s, o) => s + o.amount, 0)), upcoming: round2(outstanding.filter((o) => !o.due).reduce((s, o) => s + o.amount, 0)), overdueCount: overdue.length },
    system: { activeBranches: branches, activeTeams: teams, activeStaff: staff },
    revenue: { total: round2(verified.reduce((s, p) => s + p.amount, 0)), thisMonth: round2(verified.filter((p) => (p.reviewedAt || p.createdAt).toISOString().slice(0, 7) === month).reduce((s, p) => s + p.amount, 0)) },
    alerts,
  });
});
