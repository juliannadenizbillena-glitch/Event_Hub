const Booking = require('../models/Booking');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const { isValidDate } = require('../config/rules');

const OPERATIONAL = ['confirmed', 'ongoing', 'completed_pending_final', 'payment_overdue', 'fully_paid'];
const OWN_VISIBLE = ['pending_approval', 'payment_required', 'payment_verification', ...OPERATIONAL];

// GET /api/calendar?from=&to=&branch=
// User: their own bookings.  Organizer: events of their branch.  Admin: the whole system (optionally one branch).
exports.events = asyncHandler(async (req, res) => {
  const { from, to } = req.query;
  if (!isValidDate(from) || !isValidDate(to) || from > to) throw new AppError('Choose a valid date range (from, to).', 422, 'BAD_DATE');
  const filter = { date: { $gte: from, $lte: to }, isArchived: { $ne: true } };
  if (req.user.role === 'user') { filter.company = req.user._id; filter.status = { $in: OWN_VISIBLE }; }
  else if (req.user.role === 'organizer') {
    const own = req.user.branch?._id || req.user.branch;
    if (req.query.branch && String(req.query.branch) !== String(own)) throw new AppError('You can only view the schedule of your assigned branch.', 403, 'FORBIDDEN_BRANCH');
    filter.branch = own; filter.status = { $in: OPERATIONAL };
  } else { filter.status = { $in: OPERATIONAL }; if (req.query.branch) filter.branch = req.query.branch; }
  const bookings = await Booking.find(filter).populate('eventType', 'name').populate('branch', 'name code').populate('company', 'companyName').sort({ date: 1, startTime: 1 });
  res.json({
    events: bookings.map((b) => ({
      _id: b._id, code: b.code, eventName: b.eventName, date: b.date, startTime: b.startTime, endTime: b.endTime, status: b.status,
      eventType: b.eventType?.name, branch: b.branch?.name, attendees: b.attendees, ...(req.user.role === 'user' ? {} : { company: b.company?.companyName }),
    })),
  });
});
