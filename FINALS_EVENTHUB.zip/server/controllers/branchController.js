const Branch = require('../models/Branch');
const Team = require('../models/Team');
const User = require('../models/User');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const { ensureTeamsForBranch } = require('../services/setup');

const countsBy = async (Model, match) => {
  const rows = await Model.aggregate([{ $match: match }, { $group: { _id: '$branch', n: { $sum: 1 } } }]);
  return Object.fromEntries(rows.map((r) => [String(r._id), r.n]));
};

// GET /api/branches
// Admin: every branch with team and staff counts.  Everyone else: active branches only (for booking forms).
exports.list = asyncHandler(async (req, res) => {
  if (req.user.role !== 'admin') {
    const branches = await Branch.find({ isActive: true }).select('name code').sort('name');
    return res.json({ branches });
  }
  const [branches, teams, staff] = await Promise.all([
    Branch.find().sort('name'),
    countsBy(Team, {}),
    countsBy(User, { role: 'organizer', isArchived: false }),
  ]);
  res.json({
    branches: branches.map((b) => ({ ...b.toJSON(), teamCount: teams[b.id] || 0, staffCount: staff[b.id] || 0 })),
  });
});

// POST /api/branches  (admin) — a new branch automatically gets its 55 teams (11 types x 5).
exports.create = asyncHandler(async (req, res) => {
  const { name, code, address } = req.body;
  if (await Branch.exists({ $or: [{ name }, { code }] })) {
    throw new AppError('A branch with that name or code already exists.', 409, 'BRANCH_EXISTS');
  }
  const branch = await Branch.create({ name, code, address });
  await ensureTeamsForBranch(branch);
  const teamCount = await Team.countDocuments({ branch: branch._id });
  res.status(201).json({ message: 'Branch created.', branch: { ...branch.toJSON(), teamCount, staffCount: 0 } });
});

// PATCH /api/branches/:id  (admin) — name and address. The code never changes.
exports.update = asyncHandler(async (req, res) => {
  const branch = await Branch.findById(req.params.id);
  if (!branch) throw new AppError('Branch not found.', 404, 'NOT_FOUND');
  if (await Branch.exists({ name: req.body.name, _id: { $ne: branch._id } })) {
    throw new AppError('A branch with that name already exists.', 409, 'BRANCH_EXISTS');
  }
  branch.name = req.body.name;
  branch.address = req.body.address || undefined;
  await branch.save();
  res.json({ message: 'Branch updated.', branch });
});

// PATCH /api/branches/:id/status  (admin)
exports.setStatus = asyncHandler(async (req, res) => {
  const branch = await Branch.findById(req.params.id);
  if (!branch) throw new AppError('Branch not found.', 404, 'NOT_FOUND');

  if (req.body.isActive === false) {
    const staff = await User.countDocuments({ role: 'organizer', branch: branch._id, status: 'active', isArchived: false });
    if (staff > 0) {
      throw new AppError(
        `This branch still has ${staff} active staff member(s). Reassign or deactivate them first.`,
        409,
        'BRANCH_HAS_STAFF'
      );
    }
  }
  branch.isActive = req.body.isActive;
  await branch.save();
  res.json({ message: branch.isActive ? 'Branch activated.' : 'Branch deactivated.', branch });
});
