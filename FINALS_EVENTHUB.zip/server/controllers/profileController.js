const User = require('../models/User');
const VerificationCode = require('../models/VerificationCode');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const { issueCode, verifyCode } = require('../utils/codes');
const { sendEmailChangedNotice, sendAccountReadyEmail } = require('../utils/mailer');
const { signAuthToken, setAuthCookie } = require('../utils/token');

// GET /api/profile
exports.getProfile = (req, res) => res.json({ user: req.user });

// PATCH /api/profile — phone only.
// Name, role, branch, company and the account email are read-only; the contact email has its own verified flow.
exports.updateProfile = asyncHandler(async (req, res) => {
  req.user.phone = req.body.phone;
  await req.user.save();
  res.json({ message: 'Profile updated.', user: req.user });
});

// POST /api/profile/email/request  { newContactEmail, currentPassword }
// Changes the CONTACT email only (where codes and notices go). The login (account) email never changes.
// 1) re-check the password  2) email a 6-digit code to the NEW address  3) remember it as pending.
exports.requestEmailChange = asyncHandler(async (req, res) => {
  const { newContactEmail, currentPassword } = req.body;
  const user = await User.findById(req.user._id).select('+password');

  if (!(await user.comparePassword(currentPassword))) {
    throw new AppError('Current password is incorrect.', 400, 'WRONG_PASSWORD');
  }
  if (newContactEmail === user.contactEmail) {
    throw new AppError('That is already your contact email.', 400, 'SAME_EMAIL');
  }
  if (await User.exists({ contactEmail: newContactEmail })) {
    throw new AppError('That email is already in use.', 409, 'EMAIL_TAKEN');
  }

  // Code first: if the resend cooldown blocks it, the pending address is left untouched,
  // so an older code can never be used to confirm a different address.
  await issueCode(user, 'change_email', { to: newContactEmail });
  user.pendingContactEmail = newContactEmail;
  await user.save();

  res.json({
    message: `We sent a 6-digit code to ${newContactEmail}. Enter it to confirm the change.`,
    pendingContactEmail: newContactEmail,
  });
});

// POST /api/profile/email/confirm  { code }
exports.confirmEmailChange = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).populate('branch', 'name code isActive');
  if (!user.pendingContactEmail) {
    throw new AppError('There is no contact email change in progress.', 400, 'NO_PENDING_EMAIL');
  }

  // The code must have been sent to exactly the pending address.
  await verifyCode(user, 'change_email', req.body.code, user.pendingContactEmail);

  if (await User.exists({ contactEmail: user.pendingContactEmail, _id: { $ne: user._id } })) {
    user.pendingContactEmail = undefined;
    await user.save();
    throw new AppError('That email was taken in the meantime.', 409, 'EMAIL_TAKEN');
  }

  const oldContact = user.contactEmail;
  user.contactEmail = user.pendingContactEmail;
  user.pendingContactEmail = undefined;
  await user.save(); // the unique index on contactEmail is the last line of defence

  // Tell the old address (best effort; never blocks the change).
  sendEmailChangedNotice({ to: oldContact, name: user.firstName, newEmail: user.contactEmail });

  res.json({ message: 'Contact email updated.', user });
});

// DELETE /api/profile/email/pending
exports.cancelEmailChange = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).populate('branch', 'name code isActive');
  user.pendingContactEmail = undefined;
  await user.save();
  await VerificationCode.deleteOne({ user: user._id, purpose: 'change_email' });
  res.json({ message: 'Contact email change cancelled.', user });
});

// POST /api/profile/account-email/resend
// The EventHub login email is never displayed. It is sent to the registered contact email on request.
exports.resendAccountEmail = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);
  if (user.accountEmailSentAt && Date.now() - user.accountEmailSentAt.getTime() < 60 * 1000) {
    throw new AppError('Please wait a minute before requesting it again.', 429, 'RESEND_COOLDOWN');
  }
  await sendAccountReadyEmail({ to: user.contactEmail, name: user.firstName, accountEmail: user.accountEmail });
  user.accountEmailSentAt = new Date();
  await user.save();
  res.json({ message: 'Your EventHub account information was sent to your registered email address.' });
});

// PATCH /api/profile/password
exports.changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  const user = await User.findById(req.user._id).select('+password');

  if (!(await user.comparePassword(currentPassword))) {
    throw new AppError('Current password is incorrect.', 400, 'WRONG_PASSWORD');
  }
  if (await user.comparePassword(newPassword)) {
    throw new AppError('New password must be different from the current one.', 400, 'SAME_PASSWORD');
  }

  user.password = newPassword;
  user.passwordChangedAt = new Date();
  await user.save();

  setAuthCookie(res, signAuthToken(user)); // keep this session; other sessions are invalidated
  res.json({ message: 'Password changed.' });
});
