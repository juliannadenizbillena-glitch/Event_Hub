const Booking = require('../models/Booking');
const User = require('../models/User');
const asyncHandler = require('../utils/asyncHandler');
const { presentSummary } = require('../services/presenters');

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// GET /api/admin/archive?search=&status=&branch=&eventType=&from=&to=&page=
exports.list = asyncHandler(async (req, res) => {
  const filter = { isArchived: true };
  const { status, branch, eventType, from, to, search } = req.query;
  if (status) filter.status = status;
  if (branch) filter.branch = branch;
  if (eventType) filter.eventType = eventType;
  if (from || to) filter.date = { ...(from ? { $gte: from } : {}), ...(to ? { $lte: to } : {}) };
  if (search) {
    const rx = { $regex: escapeRegex(String(search).slice(0, 60)), $options: 'i' };
    const companies = await User.find({ role: 'user', companyName: rx }).select('_id');
    filter.$or = [{ code: rx }, { eventName: rx }, ...(companies.length ? [{ company: { $in: companies.map((c) => c._id) } }] : [])];
  }
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 100);
  const [total, rows] = await Promise.all([
    Booking.countDocuments(filter),
    Booking.find(filter).populate('eventType', 'name').populate('branch', 'name code').populate('company', 'companyName').sort({ archivedAt: -1 }).skip((page - 1) * limit).limit(limit),
  ]);
  res.json({ total, page, pages: Math.max(Math.ceil(total / limit), 1), bookings: rows.map((b) => ({ ...presentSummary(b, 'admin'), archivedAt: b.archivedAt })) });
});
