const Equipment = require('../models/Equipment');
const Branch = require('../models/Branch');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const branchOf = (u) => u.branch?._id || u.branch;

// GET /api/equipment  — Admin: everything. Organizer: their branch + shared items only (another branch = 403).
exports.list = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.user.role === 'organizer') {
    const own = branchOf(req.user);
    if (!own) throw new AppError('You are not assigned to a branch yet. Contact Admin.', 403, 'NO_BRANCH');
    if (req.query.branch && String(req.query.branch) !== String(own)) throw new AppError('You can only view equipment of your assigned branch.', 403, 'FORBIDDEN_BRANCH');
    filter.$or = [{ branch: own }, { branch: null }];
    filter.isActive = true;
  } else if (req.query.branch) {
    filter.branch = req.query.branch === 'shared' ? null : req.query.branch;
  }
  if (req.query.category) filter.category = req.query.category;
  if (req.query.status) filter.status = req.query.status;
  if (req.query.search) filter.name = { $regex: escapeRegex(String(req.query.search).slice(0, 60)), $options: 'i' };
  const items = await Equipment.find(filter).populate('branch', 'name code').sort('name');
  res.json({ equipment: items, total: items.length });
});

const body = (b) => ({ name: b.name, category: b.category, quantity: b.quantity, condition: b.condition, status: b.status, branch: b.branch || null, notes: b.notes || undefined });

exports.create = asyncHandler(async (req, res) => {
  if (req.body.branch && !(await Branch.exists({ _id: req.body.branch }))) throw new AppError('Branch not found.', 400, 'BAD_BRANCH');
  if (await Equipment.exists({ branch: req.body.branch || null, name: new RegExp(`^${escapeRegex(req.body.name)}$`, 'i') })) {
    throw new AppError('That equipment already exists for this branch.', 409, 'EQUIPMENT_EXISTS');
  }
  const item = await Equipment.create(body(req.body));
  await item.populate('branch', 'name code');
  res.status(201).json({ message: 'Equipment added.', equipment: item });
});

exports.update = asyncHandler(async (req, res) => {
  const item = await Equipment.findById(req.params.id);
  if (!item) throw new AppError('Equipment not found.', 404, 'NOT_FOUND');
  if (req.body.branch && !(await Branch.exists({ _id: req.body.branch }))) throw new AppError('Branch not found.', 400, 'BAD_BRANCH');
  const dup = await Equipment.exists({ _id: { $ne: item._id }, branch: req.body.branch || null, name: new RegExp(`^${escapeRegex(req.body.name)}$`, 'i') });
  if (dup) throw new AppError('That equipment already exists for this branch.', 409, 'EQUIPMENT_EXISTS');
  Object.assign(item, body(req.body));
  await item.save();
  await item.populate('branch', 'name code');
  res.json({ message: 'Equipment updated.', equipment: item });
});

exports.setActive = asyncHandler(async (req, res) => {
  const item = await Equipment.findById(req.params.id);
  if (!item) throw new AppError('Equipment not found.', 404, 'NOT_FOUND');
  item.isActive = req.body.isActive;
  await item.save();
  await item.populate('branch', 'name code');
  res.json({ message: item.isActive ? 'Equipment activated.' : 'Equipment deactivated. Existing events keep it, new events cannot use it.', equipment: item });
});
