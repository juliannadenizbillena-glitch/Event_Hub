const Booking = require('../models/Booking');
const Venue = require('../models/Venue');
const VenueReservation = require('../models/VenueReservation');
const Equipment = require('../models/Equipment');
const DamageReport = require('../models/DamageReport');
const InternalCost = require('../models/InternalCost');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const ops = require('../services/operationsService');
const { UPLOAD_ROOT } = require('../middleware/upload');

const done = (message) => (req, res) => res.json({ message });

// GET /api/bookings/:id/operations/options  (Organizer of the branch)
exports.options = asyncHandler(async (req, res) => {
  const booking = await ops.loadForOrganizer(req.user, req.params.id);
  const [venues, taken, equipment] = await Promise.all([
    Venue.find({ branch: booking.branch, isActive: true }).sort('name'),
    VenueReservation.find({ date: booking.date, booking: { $ne: booking._id } }),
    Equipment.find({ isActive: true, status: 'available', $or: [{ branch: booking.branch }, { branch: null }] }).sort('name'),
  ]);
  const takenIds = new Set(taken.map((t) => String(t.venue)));
  res.json({
    venues: venues.map((v) => ({ _id: v._id, name: v.name, capacity: v.capacity, status: v.status, facilities: v.facilities, taken: takenIds.has(String(v._id)), fits: v.capacity >= booking.attendees })),
    equipment: await Promise.all(equipment.map(async (e) => ({ _id: e._id, name: e.name, category: e.category, condition: e.condition, quantity: e.quantity, free: await ops.freeEquipment(e, booking.date, booking._id) }))),
  });
});

exports.assignVenue = asyncHandler(async (req, res) => { await ops.assignVenue(req.user, req.params.id, req.body.venue); res.json({ message: 'Venue assigned.' }); });
exports.setEquipment = asyncHandler(async (req, res) => { await ops.setEquipment(req.user, req.params.id, req.body.items); res.json({ message: 'Equipment plan saved.' }); });
exports.equipmentStatus = asyncHandler(async (req, res) => { await ops.setEquipmentStatus(req.user, req.params.id, req.params.equipmentId, req.body.status); res.json({ message: 'Equipment status updated.' }); });
exports.checklist = asyncHandler(async (req, res) => { await ops.setChecklistItem(req.user, req.params.id, req.params.index, req.body.done); res.json({ message: 'Checklist updated.' }); });
exports.ready = asyncHandler(async (req, res) => { await ops.markReady(req.user, req.params.id); res.json({ message: 'Preparation marked complete. The event is ready.' }); });
exports.start = asyncHandler(async (req, res) => { await ops.startEvent(req.user, req.params.id); res.json({ message: 'Event started. It is now ongoing.' }); });
exports.complete = asyncHandler(async (req, res) => { await ops.completeEvent(req.user, req.params.id); res.json({ message: 'Event completed. You can now inspect and report any damage.' }); });
exports.finishInspection = asyncHandler(async (req, res) => { await ops.finishInspection(req.user, req.params.id, req.body.notes); res.json({ message: 'Inspection finished. Admin will review any damage reports and issue the final balance.' }); });

// POST /api/bookings/:id/damage-reports  (Organizer; multipart: item, description, quantity, details, estimatedCost, evidence[])
exports.damageReport = asyncHandler(async (req, res) => {
  try {
    const r = await ops.submitDamageReport(req.user, req.params.id, req.body, req.files || []);
    res.status(201).json({ message: 'Damage report sent to Admin. Nothing is charged until Admin approves it.', reportId: r._id });
  } catch (err) {
    const { removeFile } = require('../middleware/upload');
    (req.files || []).forEach((f) => removeFile(f.rel));
    throw err;
  }
});

// GET /api/damage-reports/:id/evidence/:index  (Admin, or the Organizer of that branch)
exports.evidence = asyncHandler(async (req, res) => {
  const report = await DamageReport.findById(req.params.id);
  if (!report) throw new AppError('Damage report not found.', 404, 'NOT_FOUND');
  const booking = await Booking.findById(report.booking);
  if (req.user.role !== 'admin' && String(booking.branch) !== String(req.user.branch?._id || req.user.branch)) throw new AppError('You do not have access to this evidence.', 403, 'FORBIDDEN_BRANCH');
  const file = report.evidence[req.params.index];
  if (!file) throw new AppError('No such evidence file.', 404, 'NOT_FOUND');
  res.type(file.mimeType).sendFile(file.path, { root: UPLOAD_ROOT });
});

// POST /api/damage-reports/:id/review  (Admin)
exports.reviewDamage = asyncHandler(async (req, res) => {
  const r = await ops.reviewDamage(req.user, req.params.id, req.body);
  res.json({ message: r.status === 'approved' ? 'Damage approved. It is added to the remaining balance.' : 'Damage rejected. It will not be charged.' });
});

// ---- internal costs (Admin only) ----
const COSTLY = ['confirmed', 'ongoing', 'completed_pending_final', 'payment_overdue', 'fully_paid', 'cancelled'];
exports.addCost = asyncHandler(async (req, res) => {
  const booking = await Booking.findById(req.params.id);
  if (!booking) throw new AppError('Booking not found.', 404, 'NOT_FOUND');
  if (!COSTLY.includes(booking.status)) throw new AppError('Costs can be recorded once a booking is confirmed.', 409, 'INVALID_STATE');
  const cost = await InternalCost.create({ booking: booking._id, category: req.body.category, amount: req.body.amount, note: req.body.note || undefined, incurredOn: req.body.incurredOn || undefined, recordedBy: req.user._id });
  res.status(201).json({ message: 'Cost recorded.', cost });
});
exports.deleteCost = asyncHandler(async (req, res) => {
  const cost = await InternalCost.findById(req.params.id);
  if (!cost) throw new AppError('Cost not found.', 404, 'NOT_FOUND');
  await cost.deleteOne();
  res.json({ message: 'Cost removed.' });
});
