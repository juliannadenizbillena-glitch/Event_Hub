const asyncHandler = require('../utils/asyncHandler');
const { buildQuote } = require('../services/pricing');

// POST /api/pricing/quote  { eventType, attendees, bundle, addOns: [ids] }
// "The system calculates this automatically": the user never types a price.
exports.quote = asyncHandler(async (req, res) => {
  const { eventType, attendees, bundle, addOns = [] } = req.body;
  const quote = await buildQuote({ eventTypeId: eventType, attendees, bundleId: bundle, addOnIds: addOns });
  res.json({ quote });
});
