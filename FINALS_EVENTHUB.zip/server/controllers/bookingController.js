const Booking = require('../models/Booking');
const Payment = require('../models/Payment');
const DamageReport = require('../models/DamageReport');
const InternalCost = require('../models/InternalCost');
const { ensureChecklist } = require('../services/operationsService');
const User = require('../models/User');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const TERMS = require('../config/terms');
const service = require('../services/bookingService');
const { availabilityForDate } = require('../services/availability');
const { presentSummary, presentBooking } = require('../services/presenters');
const { UPLOAD_ROOT, removeFile } = require('../middleware/upload');

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const PRE_CONFIRMATION = ['pending_approval', 'payment_required', 'payment_verification', 'rejected', 'payment_expired', 'cancelled'];
const EVENTS = ['confirmed', 'ongoing', 'completed_pending_final', 'payment_overdue', 'fully_paid'];

// Who may see which bookings. Anything outside this scope behaves as "not found".
function scopeFilter(user) {
  if (user.role === 'admin') return {};
  if (user.role === 'organizer') {
    const branch = user.branch?._id || user.branch;
    return branch ? { branch } : { _id: null };
  }
  return { company: user._id };
}

const populateAll = (q) => q
  .populate('eventType', 'name')
  .populate('branch', 'name code')
  .populate('company', 'companyName firstName lastName contactEmail phone')
  .populate('assignedTeams', 'name');

// GET /api/bookings/terms
exports.terms = (req, res) => res.json({ terms: TERMS });

// GET /api/bookings/summary — counts for dashboards, within the caller's scope
exports.summary = asyncHandler(async (req, res) => {
  const rows = await Booking.aggregate([{ $match: { ...scopeFilter(req.user), isArchived: { $ne: true } } }, { $group: { _id: '$status', n: { $sum: 1 } } }]);
  res.json({ counts: Object.fromEntries(rows.map((r) => [r._id, r.n])) });
});

// GET /api/bookings?scope=requests|events&status=&branch=&eventType=&search=&sort=&page=&limit=
exports.list = asyncHandler(async (req, res) => {
  const filter = { ...scopeFilter(req.user), isArchived: { $ne: true } }; // archived records only appear in the Archive
  const { scope, status, branch, eventType, search, sort } = req.query;
  if (scope === 'requests') filter.status = { $in: PRE_CONFIRMATION };
  if (scope === 'events') filter.status = { $in: EVENTS };
  if (status) filter.status = scope ? { $in: (filter.status.$in || []).filter((s) => s === status) } : status;
  if (branch && req.user.role === 'admin') filter.branch = branch;
  if (eventType) filter.eventType = eventType;
  if (search) {
    const rx = { $regex: escapeRegex(String(search).slice(0, 60)), $options: 'i' };
    const companies = req.user.role === 'user' ? [] : await User.find({ role: 'user', companyName: rx }).select('_id');
    filter.$or = [{ code: rx }, { eventName: rx }, ...(companies.length ? [{ company: { $in: companies.map((c) => c._id) } }] : [])];
  }

  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 100);
  const order = sort === 'date' ? { date: 1, startTime: 1 } : { createdAt: -1 };
  const [total, bookings] = await Promise.all([
    Booking.countDocuments(filter),
    populateAll(Booking.find(filter).sort(order).skip((page - 1) * limit).limit(limit)),
  ]);
  res.json({ bookings: bookings.map((b) => presentSummary(b, req.user.role)), total, page, pages: Math.max(Math.ceil(total / limit), 1) });
});

// 404 = no such booking. 403 = it exists but belongs to another company or another branch.
async function loadScoped(req) {
  const booking = await populateAll(Booking.findById(req.params.id));
  if (!booking) throw new AppError('Booking not found.', 404, 'NOT_FOUND');
  if (!(await Booking.exists({ _id: booking._id, ...scopeFilter(req.user) }))) {
    throw new AppError('You do not have access to this booking.', 403, 'FORBIDDEN');
  }
  return booking;
}

// GET /api/bookings/:id
exports.get = asyncHandler(async (req, res) => {
  const booking = await loadScoped(req);
  await ensureChecklist(booking); // events confirmed before checklists existed get the default one
  const fresh = await populateAll(Booking.findById(booking._id));
  const payments = req.user.role === 'organizer' ? [] : await Payment.find({ booking: booking._id }).sort('createdAt');
  const damageReports = await DamageReport.find({ booking: booking._id }).sort('createdAt');
  let costs; let revenue = 0;
  if (req.user.role === 'admin') {
    costs = await InternalCost.find({ booking: booking._id }).sort('createdAt');
    revenue = (await Payment.find({ booking: booking._id, status: 'verified' })).reduce((s, p) => s + p.amount, 0);
  }
  let teamAvailability;
  if (req.user.role === 'admin' && booking.status === 'pending_approval') {
    const { free, activeTeams } = await availabilityForDate(booking.branch._id, booking.eventType._id, booking.date);
    teamAvailability = { required: booking.teamsRequired, free: free.length, activeTeams };
  }
  res.json({ booking: presentBooking(fresh, req.user.role, { payments, teamAvailability, damageReports, costs, revenue }) });
});

// POST /api/bookings  (User)
exports.create = asyncHandler(async (req, res) => {
  const booking = await service.createBooking(req.user, req.body);
  const full = await populateAll(Booking.findById(booking._id));
  res.status(201).json({ message: 'Booking submitted. It is now pending Admin approval.', booking: presentBooking(full, 'user') });
});

// POST /api/bookings/:id/reference-image  (User, only while pending approval)
exports.uploadReference = asyncHandler(async (req, res) => {
  if (!req.file) throw new AppError('Choose an image to upload.', 400, 'BAD_FILE');
  const booking = await Booking.findById(req.params.id);
  if (!booking) { removeFile(req.file.rel); throw new AppError('Booking not found.', 404, 'NOT_FOUND'); }
  if (String(booking.company) !== String(req.user._id)) { removeFile(req.file.rel); throw new AppError('You do not have access to this booking.', 403, 'FORBIDDEN'); }
  if (booking.status !== 'pending_approval') { removeFile(req.file.rel); throw new AppError('The reference image can only be changed while the booking is pending approval.', 409, 'INVALID_STATE'); }
  removeFile(booking.referenceImage?.path);
  booking.referenceImage = { path: req.file.rel, mimeType: req.file.mimetype, originalName: req.file.originalname, size: req.file.size };
  await booking.save();
  res.json({ message: 'Reference image saved.' });
});

// GET /api/bookings/:id/reference-image  (owner, Admin, Organizer of the branch)
exports.getReferenceImage = asyncHandler(async (req, res) => {
  const booking = await Booking.findById(req.params.id);
  if (!booking) throw new AppError('Booking not found.', 404, 'NOT_FOUND');
  if (!(await Booking.exists({ _id: booking._id, ...scopeFilter(req.user) }))) throw new AppError('You do not have access to this booking.', 403, 'FORBIDDEN');
  if (!booking.referenceImage?.path) throw new AppError('No reference image.', 404, 'NOT_FOUND');
  res.type(booking.referenceImage.mimeType).sendFile(booking.referenceImage.path, { root: UPLOAD_ROOT });
});

// POST /api/bookings/:id/approve  (Admin)
exports.approve = asyncHandler(async (req, res) => {
  await service.approveBooking(req.params.id, req.user);
  res.json({ message: 'Booking approved. The required teams are held for 24 hours while the company pays the 50% down payment.' });
});

// POST /api/bookings/:id/reject  (Admin)
exports.reject = asyncHandler(async (req, res) => {
  await service.rejectBooking(req.params.id, req.user, req.body.reason);
  res.json({ message: 'Booking rejected. The company was notified.' });
});

// POST /api/bookings/:id/cancel  (the company, or Admin)
exports.cancel = asyncHandler(async (req, res) => {
  const b = await service.cancelBooking(req.user, req.params.id, req.body.reason);
  res.json({ message: b.history.at(-1).note.includes('non-refundable') ? 'Booking cancelled. The 50% down payment is non-refundable.' : 'Booking cancelled.' });
});

// POST /api/bookings/:id/archive  and  /restore  (Admin)
exports.archive = asyncHandler(async (req, res) => { await service.archiveBooking(req.params.id); res.json({ message: 'Booking archived.' }); });
exports.restore = asyncHandler(async (req, res) => { await service.restoreBooking(req.params.id); res.json({ message: 'Booking restored.' }); });
