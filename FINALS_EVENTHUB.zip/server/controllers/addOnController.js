
const AddOn = require('../models/AddOn');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

const nameTaken = (name, exceptId) =>
  AddOn.exists({
    name: { $regex: `^${escapeRegex(name)}$`, $options: 'i' },
    ...(exceptId ? { _id: { $ne: exceptId } } : {}),
  });

// GET /api/add-ons — Admin and Organizer see all (Organizer is view only).
// User sees active add-ons only.
exports.list = asyncHandler(async (req, res) => {
  const isStaff = req.user.role === 'admin' || req.user.role === 'organizer';
  const filter = isStaff ? {} : { isActive: true };

  if (isStaff && req.query.status === 'active') filter.isActive = true;
  if (isStaff && req.query.status === 'inactive') filter.isActive = false;

  const addOns = await AddOn.find(filter).sort('name');
  res.json({ addOns });
});

// POST /api/add-ons (admin)
exports.create = asyncHandler(async (req, res) => {
  const { name, description, quantity = 1, price } = req.body;

  if (typeof name !== 'string' || !name.trim()) {
    throw new AppError('Add-on name is required.', 400, 'VALIDATION_ERROR');
  }

  if (!Number.isInteger(Number(quantity)) || Number(quantity) < 1 || Number(quantity) > 10000) {
    throw new AppError('Quantity must be a whole number from 1 to 10000.', 400, 'VALIDATION_ERROR');
  }

  if (!Number.isInteger(Number(price)) || Number(price) < 1 || Number(price) > 10000000) {
    throw new AppError('Price must be a whole number of pesos from 1 to 10000000.', 400, 'VALIDATION_ERROR');
  }

  if (await nameTaken(name.trim())) {
    throw new AppError('An add-on with that name already exists.', 409, 'ADDON_EXISTS');
  }

  const addOn = await AddOn.create({
    name: name.trim(),
    description,
    quantity: Number(quantity),
    price: Number(price),
  });

  res.status(201).json({ message: 'Add-on created.', addOn });
});

// PATCH /api/add-ons/:id (admin)
exports.update = asyncHandler(async (req, res) => {
  const addOn = await AddOn.findById(req.params.id);

  if (!addOn) {
    throw new AppError('Add-on not found.', 404, 'NOT_FOUND');
  }

  const { name, description, quantity, price } = req.body;

  if (name !== undefined && (typeof name !== 'string' || !name.trim())) {
    throw new AppError('Add-on name is required.', 400, 'VALIDATION_ERROR');
  }

  if (quantity !== undefined &&
      (!Number.isInteger(Number(quantity)) || Number(quantity) < 1 || Number(quantity) > 10000)) {
    throw new AppError('Quantity must be a whole number from 1 to 10000.', 400, 'VALIDATION_ERROR');
  }

  if (price !== undefined &&
      (!Number.isInteger(Number(price)) || Number(price) < 1 || Number(price) > 10000000)) {
    throw new AppError('Price must be a whole number of pesos from 1 to 10000000.', 400, 'VALIDATION_ERROR');
  }

  if (name && await nameTaken(name.trim(), addOn._id)) {
    throw new AppError('An add-on with that name already exists.', 409, 'ADDON_EXISTS');
  }

  if (name !== undefined) addOn.name = name.trim();
  if (description !== undefined) addOn.description = description;
  if (quantity !== undefined) addOn.quantity = Number(quantity);
  if (price !== undefined) addOn.price = Number(price);

  await addOn.save();

  res.json({
    message: 'Add-on updated. Existing bookings keep their original price and quantity.',
    addOn,
  });
});

// PATCH /api/add-ons/:id/status (admin)
exports.setStatus = asyncHandler(async (req, res) => {
  const addOn = await AddOn.findById(req.params.id);

  if (!addOn) {
    throw new AppError('Add-on not found.', 404, 'NOT_FOUND');
  }

  addOn.isActive = req.body.isActive;
  await addOn.save();

  res.json({
    message: addOn.isActive
      ? 'Add-on activated.'
      : 'Add-on deactivated. Existing bookings are not affected, but new bookings cannot choose it.',
    addOn,
  });
});
