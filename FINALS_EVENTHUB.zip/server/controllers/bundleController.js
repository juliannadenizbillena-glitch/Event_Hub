
const Bundle = require('../models/Bundle');
const EventType = require('../models/EventType');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const { LEVELS } = require('../models/Bundle');

const cleanInclusions = (inc = {}) => {
  const result = {};

  for (const key of ['equipment', 'services', 'resources']) {
    const items = inc[key] ?? [];

    if (!Array.isArray(items)) {
      throw new AppError(
        `The ${key} inclusions must be a list.`,
        400,
        'VALIDATION_ERROR'
      );
    }

    result[key] = items.map((item) => {
      // Backward compatibility for existing plain-text items.
      if (typeof item === 'string') {
        const name = item.trim();

        if (!name) {
          throw new AppError('Inclusion item names cannot be empty.', 400, 'VALIDATION_ERROR');
        }

        return { name, quantity: 1 };
      }

      const name = String(item?.name ?? '').trim();
      const quantity = Number(item?.quantity ?? 1);

      if (!name || name.length > 80) {
        throw new AppError(
          'Each inclusion needs a name of 1–80 characters.',
          400,
          'VALIDATION_ERROR'
        );
      }

      if (!Number.isInteger(quantity) || quantity < 1 || quantity > 10000) {
        throw new AppError(
          'Each inclusion quantity must be a whole number from 1 to 10000.',
          400,
          'VALIDATION_ERROR'
        );
      }

      return { name, quantity };
    });
  }

  return result;
};

exports.list = asyncHandler(async (req, res) => {
  const filter = {};
  const isStaff = req.user.role === 'admin' || req.user.role === 'organizer';

  if (req.query.eventType) filter.eventType = req.query.eventType;

  if (isStaff) {
    if (req.query.status === 'active') filter.isActive = true;
    if (req.query.status === 'inactive') filter.isActive = false;
  } else {
    filter.isActive = true;
    const activeTypes = await EventType.find({ isActive: true }).select('_id');

    filter.eventType = req.query.eventType
      ? {
          $in: activeTypes
            .map((t) => t._id)
            .filter((id) => String(id) === req.query.eventType),
        }
      : { $in: activeTypes.map((t) => t._id) };
  }


  filter.level = { $in: [1, 2, 3, 4] };

const bundles = await Bundle.find(filter).populate('eventType', 'name isActive');

  bundles.sort(
    (a, b) =>
      (a.eventType?.name || '').localeCompare(b.eventType?.name || '') ||
      a.level - b.level
  );

  const attendees = Number(req.query.attendees);
  const out = bundles.map((b) => {
    const json = b.toJSON();
    if (Number.isInteger(attendees) && attendees > 0) {
      json.fits = attendees <= b.capacity;
    }
    return json;
  });

  res.json({ bundles: out });
});

exports.create = asyncHandler(async (req, res) => {
  const { eventType, level, name, description, capacity, price, inclusions } = req.body;

  if (!(await EventType.exists({ _id: eventType }))) {
    throw new AppError('Event type not found.', 404, 'NOT_FOUND');
  }

  if (!Number.isInteger(Number(level)) || Number(level) < 1 || Number(level) > 4) {
    throw new AppError('Bundle level must be from 1 to 4.', 400, 'VALIDATION_ERROR');
  }

  if (await Bundle.exists({ eventType, level })) {
    throw new AppError(
      `This event type already has its ${LEVELS[Number(level) - 1]} bundle (4 bundles per event type). Edit it instead.`,
      409,
      'BUNDLE_LEVEL_TAKEN'
    );
  }

  const bundle = await Bundle.create({
    eventType,
    level: Number(level),
    name,
    description,
    capacity,
    price,
    inclusions: cleanInclusions(inclusions),
  });

  await bundle.populate('eventType', 'name isActive');
  res.status(201).json({ message: 'Bundle created.', bundle });
});

// PATCH /api/bundles/:id (admin)
exports.update = asyncHandler(async (req, res) => {
  const bundle = await Bundle.findById(req.params.id);

  if (!bundle) {
    throw new AppError('Bundle not found.', 404, 'NOT_FOUND');
  }

  const { name, description, capacity, price, inclusions } = req.body;

  if (name !== undefined) bundle.name = name;
  if (description !== undefined) bundle.description = description;
  if (capacity !== undefined) bundle.capacity = capacity;
  if (price !== undefined) bundle.price = price;
  if (inclusions !== undefined) {
    bundle.inclusions = cleanInclusions(inclusions);
  }

  await bundle.save();
  await bundle.populate('eventType', 'name isActive');

  res.json({
    message: 'Bundle updated. Existing bookings keep the price they were booked at.',
    bundle,
  });
});

// PATCH /api/bundles/:id/status (admin)
exports.setStatus = asyncHandler(async (req, res) => {
  const bundle = await Bundle.findById(req.params.id);

  if (!bundle) {
    throw new AppError('Bundle not found.', 404, 'NOT_FOUND');
  }

  bundle.isActive = req.body.isActive;
  await bundle.save();
  await bundle.populate('eventType', 'name isActive');

  res.json({
    message: bundle.isActive
      ? 'Bundle activated.'
      : 'Bundle deactivated. Existing bookings are not affected, but new bookings cannot choose it.',
    bundle,
  });
});
