const Venue = require('../models/Venue');
const Branch = require('../models/Branch');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const branchOf = (u) => u.branch?._id || u.branch;

// GET /api/venues — Admin: all. Organizer: their branch only (another branch = 403).
exports.list = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.user.role === 'organizer') {
    const own = branchOf(req.user);
    if (!own) throw new AppError('You are not assigned to a branch yet. Contact Admin.', 403, 'NO_BRANCH');
    if (req.query.branch && String(req.query.branch) !== String(own)) throw new AppError('You can only view venues of your assigned branch.', 403, 'FORBIDDEN_BRANCH');
    filter.branch = own;
    filter.isActive = true;
  } else if (req.query.branch) filter.branch = req.query.branch;
  if (req.query.status) filter.status = req.query.status;
  if (req.query.search) filter.name = { $regex: escapeRegex(String(req.query.search).slice(0, 60)), $options: 'i' };
  const venues = await Venue.find(filter).populate('branch', 'name code').sort('name');
  res.json({ venues, total: venues.length });
});

const fields = (b) => ({ branch: b.branch, name: b.name, capacity: b.capacity, status: b.status, address: b.address || undefined, facilities: (b.facilities || []).map((f) => f.trim()).filter(Boolean), notes: b.notes || undefined });

exports.create = asyncHandler(async (req, res) => {
  if (!(await Branch.exists({ _id: req.body.branch }))) throw new AppError('Branch not found.', 400, 'BAD_BRANCH');
  if (await Venue.exists({ branch: req.body.branch, name: new RegExp(`^${escapeRegex(req.body.name)}$`, 'i') })) throw new AppError('This branch already has a venue with that name.', 409, 'VENUE_EXISTS');
  const venue = await Venue.create(fields(req.body));
  await venue.populate('branch', 'name code');
  res.status(201).json({ message: 'Venue added.', venue });
});

exports.update = asyncHandler(async (req, res) => {
  const venue = await Venue.findById(req.params.id);
  if (!venue) throw new AppError('Venue not found.', 404, 'NOT_FOUND');
  if (!(await Branch.exists({ _id: req.body.branch }))) throw new AppError('Branch not found.', 400, 'BAD_BRANCH');
  if (await Venue.exists({ _id: { $ne: venue._id }, branch: req.body.branch, name: new RegExp(`^${escapeRegex(req.body.name)}$`, 'i') })) throw new AppError('This branch already has a venue with that name.', 409, 'VENUE_EXISTS');
  Object.assign(venue, fields(req.body));
  await venue.save();
  await venue.populate('branch', 'name code');
  res.json({ message: 'Venue updated.', venue });
});

exports.setActive = asyncHandler(async (req, res) => {
  const venue = await Venue.findById(req.params.id);
  if (!venue) throw new AppError('Venue not found.', 404, 'NOT_FOUND');
  venue.isActive = req.body.isActive;
  await venue.save();
  await venue.populate('branch', 'name code');
  res.json({ message: venue.isActive ? 'Venue activated.' : 'Venue deactivated. Existing events keep it, new events cannot use it.', venue });
});
