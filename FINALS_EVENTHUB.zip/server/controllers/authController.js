const User = require('../models/User');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const { issueCode, verifyCode } = require('../utils/codes');
const { ensureAccountEmail } = require('../utils/accountEmail');
const { sendAccountReadyEmail } = require('../utils/mailer');
const {
  signAuthToken,
  setAuthCookie,
  clearAuthCookie,
  signResetToken,
  verifyResetToken,
} = require('../utils/token');

const GENERIC_CODE_MSG = 'If that email is registered, a 6-digit code has been sent.';

// Two lookups, never mixed up:
//   LOGIN       -> accountEmail only.
//   VERIFICATION -> contactEmail (the only email an unverified account has).
//   RECOVERY    -> accountEmail or contactEmail (the person may have forgotten the generated one);
//                  the code is ALWAYS sent to the contact email.
const findByContact = (contactEmail) => User.findOne({ contactEmail });
const findByEither = (email) => User.findOne({ $or: [{ accountEmail: email }, { contactEmail: email }] });

// Unknown account and cooldown cases return the same generic message so the API
// never reveals which emails are registered.
async function sendCodeQuietly(user, purpose) {
  if (!user) return;
  try {
    await issueCode(user, purpose);
  } catch (err) {
    if (err.errorCode !== 'RESEND_COOLDOWN') throw err;
  }
}

// POST /api/auth/register  — public. Role is ALWAYS 'user'; the body can't change it.
// The email entered here is the CONTACT email. The login email is generated after verification.
exports.register = asyncHandler(async (req, res) => {
  const { firstName, lastName, companyName, contactEmail, phone, password } = req.body;

  let user = await findByContact(contactEmail).select('+password');
  if (user && (user.isVerified || user.role !== 'user')) {
    throw new AppError('An account with this email already exists.', 409, 'EMAIL_TAKEN');
  }

  if (user) {
    // Registered earlier but never verified: let them start over with new details.
    Object.assign(user, { firstName, lastName, companyName, phone, password });
  } else {
    user = new User({ firstName, lastName, companyName, contactEmail, phone, password, role: 'user' });
  }
  await user.save();
  await issueCode(user, 'verify_email');

  res.status(201).json({
    message: 'Account created. We sent a 6-digit verification code to your email.',
    contactEmail: user.contactEmail,
  });
});

// POST /api/auth/verify-email  { contactEmail, code }
// On success the account email is generated and returned so the person knows what to log in with.
exports.verifyEmail = asyncHandler(async (req, res) => {
  const user = await findByContact(req.body.contactEmail);
  if (!user) throw new AppError('This code is invalid or has expired. Request a new one.', 400, 'INVALID_CODE');
  // Already verified: do not reveal the account email without a valid code.
  if (user.isVerified) return res.json({ message: 'Email already verified. Your EventHub account information was sent to your registered email address.' });

  await verifyCode(user, 'verify_email', req.body.code);
  user.isVerified = true;
  await user.save();
  const accountEmail = await ensureAccountEmail(user);
  // The generated login email is DELIVERED BY EMAIL to the contact address, never shown on the website.
  sendAccountReadyEmail({ to: user.contactEmail, name: user.firstName, accountEmail });

  res.json({ message: 'Email verified successfully. Your EventHub account information has been sent to your registered email address.' });
});

// POST /api/auth/resend-code  { contactEmail }  (verification codes only)
exports.resendCode = asyncHandler(async (req, res) => {
  const user = await findByContact(req.body.contactEmail);

  console.log('[RESEND DIAGNOSTIC]', {
    accountFound: !!user,
    isVerified: user ? user.isVerified : null,
    role: user ? user.role : null,
    gmailConfigured: !!(
      process.env.GMAIL_USER &&
      process.env.GMAIL_APP_PASSWORD
    ),
  });

  await sendCodeQuietly(
    user && !user.isVerified ? user : null,
    'verify_email'
  );

  res.json({ message: GENERIC_CODE_MSG });
});

// POST /api/auth/login  { accountEmail, password }
// One endpoint for all three roles; Organizer accounts can log in with their real contact email.
exports.login = asyncHandler(async (req, res) => {
  const { accountEmail, password } = req.body;
  const user = await User.findOne({ $or: [{ accountEmail }, { role: 'organizer', contactEmail: String(accountEmail || '').trim().toLowerCase() }] }).select('+password').populate('branch', 'name code isActive');

  if (!user || !(await user.comparePassword(password))) {
    throw new AppError('Invalid email or password.', 401, 'INVALID_CREDENTIALS');
  }
  if (!user.isVerified) {
    throw new AppError('Please verify your email before logging in.', 403, 'EMAIL_NOT_VERIFIED');
  }
  if (user.status !== 'active' || user.isArchived) {
    throw new AppError('This account is deactivated. Contact EventHub.', 403, 'ACCOUNT_DISABLED');
  }

  user.lastLoginAt = new Date();
  await user.save();
  setAuthCookie(res, signAuthToken(user));

  res.json({ message: 'Logged in.', user }); // frontend routes by user.role
});

// POST /api/auth/logout
exports.logout = (req, res) => {
  clearAuthCookie(res);
  res.json({ message: 'Logged out.' });
};

// GET /api/auth/me
exports.me = (req, res) => res.json({ user: req.user });

// POST /api/auth/forgot-password  { email }   (step 1: send code to the CONTACT email)
// `email` may be the EventHub account email or the contact email. Also how Admin-created
// Organizers set their first password.
exports.forgotPassword = asyncHandler(async (req, res) => {
  const user = await findByEither(req.body.email);
  const eligible = user && user.status === 'active' && !user.isArchived;
  await sendCodeQuietly(eligible ? user : null, 'reset_password');
  res.json({ message: GENERIC_CODE_MSG });
});

// POST /api/auth/verify-reset-code  { email, code }   (step 2)
exports.verifyResetCode = asyncHandler(async (req, res) => {
  const user = await findByEither(req.body.email);
  if (!user) {
    throw new AppError(
      'This code is invalid or has expired. Request a new one.',
      400,
      'INVALID_CODE'
    );
  }

  await verifyCode(user, 'reset_password', req.body.code);
  res.json({
    message: 'Code verified.',
    resetToken: signResetToken(user),
  });
});

// POST /api/auth/reset-password { resetToken, password, confirmPassword }
exports.resetPassword = asyncHandler(async (req, res) => {
  let decoded;

  try {
    decoded = verifyResetToken(req.body.resetToken);
  } catch {
    throw new AppError(
      'Your reset session expired. Start again.',
      400,
      'BAD_RESET_TOKEN'
    );
  }

  const user = await User.findById(decoded.id);
  const currentPwd = user?.passwordChangedAt
    ? user.passwordChangedAt.getTime()
    : 0;

  // Prevent reuse of an old reset token.
  if (!user || currentPwd !== decoded.pwd) {
    throw new AppError(
      'Your reset session expired. Start again.',
      400,
      'BAD_RESET_TOKEN'
    );
  }

  user.password = req.body.password;
  user.passwordChangedAt = new Date();
  user.isVerified = true;

  await user.save();

  clearAuthCookie(res);

  res.json({
    message: 'Password changed successfully.',
  });
});