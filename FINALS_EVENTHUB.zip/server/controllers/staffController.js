const User = require('../models/User');
const Branch = require('../models/Branch');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const { sendStaffInvite } = require('../utils/mailer');
const { ensureAccountEmail } = require('../utils/accountEmail');

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// Staff list entries tell Admin whether the person has set a password yet.
const present = (u) => ({ ...u.toJSON(), accountEmail: u.contactEmail, passwordSet: !!u.password }); // Admin-only view: includes the login email

const findStaff = async (id) => {
  const staff = await User.findOne({ _id: id, role: 'organizer', isArchived: false }).select('+password').populate('branch', 'name code isActive');
  if (!staff) throw new AppError('Staff member not found.', 404, 'NOT_FOUND');
  return staff;
};

const requireActiveBranch = async (branchId) => {
  const branch = await Branch.findById(branchId);
  if (!branch || !branch.isActive) throw new AppError('Choose an active branch.', 400, 'BAD_BRANCH');
  return branch;
};

// GET /api/admin/staff?search=&branch=&status=
exports.list = asyncHandler(async (req, res) => {
  const filter = { role: 'organizer', isArchived: false };
  if (req.query.branch) filter.branch = req.query.branch;
  if (['active', 'inactive'].includes(req.query.status)) filter.status = req.query.status;
  if (req.query.search) {
    const rx = { $regex: escapeRegex(String(req.query.search).slice(0, 60)), $options: 'i' };
    filter.$or = [{ firstName: rx }, { lastName: rx }, { accountEmail: rx }, { contactEmail: rx }, { position: rx }];
  }
  const staff = await User.find(filter).select('+password').populate('branch', 'name code isActive').sort('lastName firstName');
  res.json({ staff: staff.map(present), total: staff.length });
});

// POST /api/admin/staff — role remains organizer for access control; position stores the existing team position.
// The person's real contact email is also their login email.
exports.create = asyncHandler(async (req, res) => {
  const { firstName, lastName, contactEmail, phone, branch, position } = req.body;
  if (await User.exists({ contactEmail })) throw new AppError('An account with this email already exists.', 409, 'EMAIL_TAKEN');
  const branchDoc = await requireActiveBranch(branch);

  const staff = await User.create({
    firstName, lastName, contactEmail, phone, position,
    branch: branchDoc._id,
    role: 'organizer',
    isVerified: true, // Admin vouches for the contact email; the invite flow proves the person owns it
  });
  const accountEmail = await ensureAccountEmail(staff);

  let inviteSent = true;
  try {
    await sendStaffInvite({ to: staff.contactEmail, name: staff.firstName, branchName: branchDoc.name, accountEmail });
  } catch {
    inviteSent = false; // account exists; Admin can press "Resend invite"
  }

  const saved = await User.findById(staff._id).populate('branch', 'name code isActive');
  res.status(201).json({
    message: inviteSent
      ? `Staff account created. Login email: ${accountEmail}. An invitation was sent to ${saved.contactEmail} so they can set their password.`
      : `Staff account created (login email: ${accountEmail}), but the invitation email could not be sent. Use Resend invite.`,
    inviteSent,
    staff: { ...saved.toJSON(), accountEmail, passwordSet: false },
  });
});

// PATCH /api/admin/staff/:id — name, phone, branch, position. Neither email is editable here,
// and the account email never changes when the name does.
exports.update = asyncHandler(async (req, res) => {
  const staff = await findStaff(req.params.id);
  const { firstName, lastName, phone, branch, position } = req.body;

  if (String(staff.branch?._id) !== String(branch)) await requireActiveBranch(branch);
  Object.assign(staff, { firstName, lastName, phone, position, branch });
  await staff.save();
  await staff.populate('branch', 'name code isActive');
  res.json({ message: 'Staff updated.', staff: present(staff) });
});

// PATCH /api/admin/staff/:id/status
exports.setStatus = asyncHandler(async (req, res) => {
  const staff = await findStaff(req.params.id);
  staff.status = req.body.status;
  await staff.save();
  res.json({ message: staff.status === 'active' ? 'Staff activated.' : 'Staff deactivated. They can no longer log in.', staff: present(staff) });
});

// POST /api/admin/staff/:id/resend-invite — only until they have set a password.
exports.resendInvite = asyncHandler(async (req, res) => {
  const staff = await findStaff(req.params.id);
  if (staff.password) throw new AppError('This staff member has already set a password.', 409, 'ALREADY_SET');
  await sendStaffInvite({ to: staff.contactEmail, name: staff.firstName, branchName: staff.branch?.name || 'EventHub', accountEmail: staff.accountEmail });
  res.json({ message: 'Invitation sent again.' });
});
