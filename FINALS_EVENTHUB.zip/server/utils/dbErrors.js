// Unique-index violations: MongoDB reports code 11000. FerretDB (used for local testing) reports
// code 1 with a constraint message when the violation happens in an update. Treat both as duplicates.
const isDuplicateKey = (err) =>
  !!err && (err.code === 11000 || (err.code === 1 && /constraint|unique|duplicate/i.test(String(err.message))));

module.exports = { isDuplicateKey };
