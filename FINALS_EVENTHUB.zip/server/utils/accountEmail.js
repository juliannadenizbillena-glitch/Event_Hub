const DefaultUser = require('../models/User');
const { ACCOUNT_DOMAINS } = require('../config/accounts');
const { isDuplicateKey } = require('./dbErrors');

const MAX_LOCAL_PART = 40; // before any numbering

// "Juan" + "Dela Cruz"  ->  "juandelacruz".  Lowercase, no spaces, no accents, letters and digits only.
const TRANSLITERATE = { ł: 'l', ø: 'o', đ: 'd', ß: 'ss', æ: 'ae', œ: 'oe', ð: 'd', þ: 'th' };

function normalizeNamePart(text) {
  return String(text || '')
    .toLowerCase()
    .replace(/[łøđßæœðþ]/g, (c) => TRANSLITERATE[c])
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '');
}

function localPartFor(firstName, lastName, role = 'user') {
  const base = (normalizeNamePart(firstName) + normalizeNamePart(lastName)).slice(0, MAX_LOCAL_PART);
  return base || role; // names with no latin letters or digits fall back to the role word
}

const addressFor = (local, n, role) => `${local}${n > 1 ? n : ''}@${ACCOUNT_DOMAINS[role] || ACCOUNT_DOMAINS.user}`;

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// Gives the account its permanent EventHub login email: juandelacruz@user.eventhub.com, then
// juandelacruz2@..., juandelacruz3@... if taken. Never random. Safe to call twice (a second call
// returns the address already assigned). The unique index on accountEmail is the final authority.
async function ensureAccountEmail(user, User = DefaultUser) {
  const fresh = await User.findById(user._id).select('accountEmail firstName lastName role contactEmail');
  if (!fresh) throw new Error('Account not found.');
  if (fresh.accountEmail) return fresh.accountEmail;

  // Admin-created staff use their real contact email as their login identity.
  // This keeps the invitation and the credentials aligned with the address they actually own.
  if (fresh.role === 'organizer') {
    await User.updateOne({ _id: fresh._id, accountEmail: { $exists: false } }, { $set: { accountEmail: fresh.contactEmail } });
    return (await User.findById(fresh._id).select('accountEmail')).accountEmail;
  }

  const role = fresh.role;
  const local = localPartFor(fresh.firstName, fresh.lastName, role);
  const domain = ACCOUNT_DOMAINS[role] || ACCOUNT_DOMAINS.user;

  const taken = new Set(
    (await User.find({ accountEmail: new RegExp(`^${escapeRegex(local)}\\d*@${escapeRegex(domain)}$`) }).select('accountEmail'))
      .map((u) => u.accountEmail)
  );
  let n = 1;
  for (let attempt = 0; attempt < 200; attempt += 1) {
    while (taken.has(addressFor(local, n, role))) n += 1;
    const candidate = addressFor(local, n, role);
    try {
      const res = await User.updateOne({ _id: fresh._id, accountEmail: { $exists: false } }, { $set: { accountEmail: candidate } });
      if (res.modifiedCount === 1) return candidate;
      // Someone else assigned it first.
      return (await User.findById(fresh._id).select('accountEmail')).accountEmail;
    } catch (err) {
      if (!isDuplicateKey(err)) throw err;
      taken.add(candidate); // another account just took it: try the next number
    }
  }
  throw new Error('Could not generate a unique account email.');
}

module.exports = { normalizeNamePart, localPartFor, addressFor, ensureAccountEmail };
