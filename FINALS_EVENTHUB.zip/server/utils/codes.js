const crypto = require('crypto');
const VerificationCode = require('../models/VerificationCode');
const AppError = require('./AppError');
const { sendCodeEmail } = require('./mailer');

const CODE_TTL_MINUTES = 10; // expires after a short period
const MAX_ATTEMPTS = 5; // wrong guesses allowed
const RESEND_COOLDOWN_SECONDS = 60; // resend protection

const generateCode = () => String(crypto.randomInt(0, 1000000)).padStart(6, '0');

const hashCode = (code) =>
  crypto.createHmac('sha256', process.env.JWT_SECRET).update(String(code)).digest('hex');

// opts.to: send the code to this address instead of user.contactEmail (used for contact-email change).
async function issueCode(user, purpose, opts = {}) {
  const to = (opts.to || user.contactEmail).toLowerCase(); // codes always go to the real contact email
  const existing = await VerificationCode.findOne({ user: user._id, purpose });
  if (existing && Date.now() - existing.lastSentAt.getTime() < RESEND_COOLDOWN_SECONDS * 1000) {
    throw new AppError(
      `Please wait ${RESEND_COOLDOWN_SECONDS} seconds before requesting another code.`,
      429,
      'RESEND_COOLDOWN'
    );
  }

  const code = generateCode();
  await VerificationCode.findOneAndUpdate(
    { user: user._id, purpose },
    {
      codeHash: hashCode(code),
      target: to,
      attempts: 0,
      lastSentAt: new Date(),
      expiresAt: new Date(Date.now() + CODE_TTL_MINUTES * 60 * 1000),
    },
    { upsert: true, returnDocument: 'after', setDefaultsOnInsert: true }
  );

  await sendCodeEmail({
    to,
    name: user.firstName,
    code,
    purpose,
    ttlMinutes: CODE_TTL_MINUTES,
  });
}

// Returns true and deletes the code on success (a code can only be used once).
// `target` (optional) must match the address the code was sent to.
async function verifyCode(user, purpose, code, target) {
  const record = await VerificationCode.findOne({ user: user._id, purpose });
  if (!record || record.expiresAt < new Date() || (target && record.target !== target.toLowerCase())) {
    throw new AppError('This code is invalid or has expired. Request a new one.', 400, 'INVALID_CODE');
  }

  if (record.attempts >= MAX_ATTEMPTS) {
    await record.deleteOne();
    throw new AppError('Too many incorrect attempts. Request a new code.', 429, 'TOO_MANY_ATTEMPTS');
  }

  const a = Buffer.from(hashCode(code));
  const b = Buffer.from(record.codeHash);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    record.attempts += 1;
    await record.save();
    const left = MAX_ATTEMPTS - record.attempts;
    throw new AppError(
      left > 0 ? `Incorrect code. ${left} attempt(s) left.` : 'Too many incorrect attempts. Request a new code.',
      400,
      'INVALID_CODE'
    );
  }

  await record.deleteOne();
  return true;
}

module.exports = { issueCode, verifyCode, generateCode, hashCode };
