const jwt = require('jsonwebtoken');

const COOKIE_NAME = 'eventhub_token';
const COOKIE_MAX_AGE = 7 * 24 * 60 * 60 * 1000; // keep in sync with JWT_EXPIRES_IN (7d)

const signAuthToken = (user) =>
  jwt.sign({ id: user._id, role: user.role, iatMs: Date.now() }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  });

const setAuthCookie = (res, token) =>
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true, // JavaScript in the browser cannot read it
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: COOKIE_MAX_AGE,
  });

const clearAuthCookie = (res) =>
  res.clearCookie(COOKIE_NAME, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
  });

// Short-lived token proving the 6-digit code was verified (Forgot Password step 2 -> 3).
// It embeds the current passwordChangedAt so it stops working once the password is changed.
const signResetToken = (user) =>
  jwt.sign(
    {
      id: user._id,
      purpose: 'reset',
      pwd: user.passwordChangedAt ? user.passwordChangedAt.getTime() : 0,
    },
    process.env.JWT_SECRET,
    { expiresIn: '10m' }
  );

const verifyResetToken = (token) => {
  const decoded = jwt.verify(token, process.env.JWT_SECRET);
  if (decoded.purpose !== 'reset') throw new Error('Wrong token type');
  return decoded;
};

module.exports = {
  COOKIE_NAME,
  signAuthToken,
  setAuthCookie,
  clearAuthCookie,
  signResetToken,
  verifyResetToken,
};
