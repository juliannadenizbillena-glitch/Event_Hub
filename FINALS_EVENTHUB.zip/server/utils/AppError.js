// Error with an HTTP status and a machine-readable code the React app can switch on.
class AppError extends Error {
  constructor(message, status = 400, errorCode = 'BAD_REQUEST') {
    super(message);
    this.status = status;
    this.errorCode = errorCode;
  }
}

module.exports = AppError;
