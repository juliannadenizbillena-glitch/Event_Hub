const nodemailer = require('nodemailer');

let transporter = null;

function getTransporter() {
  if (transporter) return transporter;
  if (!process.env.GMAIL_USER || !process.env.GMAIL_APP_PASSWORD) return null;
  transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: { user: process.env.GMAIL_USER, pass: process.env.GMAIL_APP_PASSWORD },
  });
  return transporter;
}

const COPY = {
  verify_email: {
    subject: 'Verify your EventHub account',
    heading: 'Verify your email',
    intro: 'Use this code to finish creating your EventHub account.',
  },
  change_email: {
    subject: 'Confirm your new contact email',
    heading: 'Confirm your new contact email',
    intro: 'Use this code to confirm this address as the contact email on your EventHub account. The EventHub email you log in with will not change.',
  },
  reset_password: {
    subject: 'Your EventHub password reset code',
    heading: 'Reset your password',
    intro: 'Use this code to reset your EventHub password.',
  },
};

async function sendCodeEmail({ to, name, code, purpose, ttlMinutes }) {
  const copy = COPY[purpose];
  const mail = getTransporter();

  if (!mail) {
    if (process.env.NODE_ENV === 'production') {
      throw Object.assign(new Error('Email service is not configured'), { status: 500 });
    }
    // Development fallback so you can test without Gmail credentials.
    console.log(`\n[DEV EMAIL] ${copy.subject} -> ${to}\n[DEV EMAIL] Code: ${code}\n`);
    return;
  }

  const html = `
    <div style="font-family:Arial,sans-serif;max-width:480px;margin:auto;border:1px solid #BDDDFC;border-radius:12px;overflow:hidden">
      <div style="background:#384959;color:#fff;padding:20px 24px;font-size:20px;font-weight:bold">EventHub</div>
      <div style="padding:24px;color:#384959">
        <h2 style="margin:0 0 8px">${copy.heading}</h2>
        <p>Hi ${name},</p>
        <p>${copy.intro}</p>
        <div style="background:#BDDDFC;border-radius:8px;text-align:center;font-size:32px;letter-spacing:8px;font-weight:bold;padding:16px;margin:20px 0">${code}</div>
        <p style="font-size:13px;color:#6A89A7">This code expires in ${ttlMinutes} minutes. If you did not request it, you can ignore this email.</p>
      </div>
    </div>`;

  try {
    await mail.sendMail({
      from: `"EventHub" <${process.env.GMAIL_USER}>`,
      to,
      subject: copy.subject,
      html,
      text: `${copy.heading}\n\nYour code: ${code}\nIt expires in ${ttlMinutes} minutes.`,
    });
  } catch (err) {
    console.error('Mail error:', err.message);
    throw Object.assign(new Error('Could not send the email. Please try again.'), { status: 502 });
  }
}

// Security notice to the OLD address after a confirmed email change. Best effort only.
async function sendEmailChangedNotice({ to, name, newEmail }) {
  const mail = getTransporter();
  const text = `Hi ${name}, the contact email on your EventHub account was changed to ${newEmail}. Your EventHub login email did not change. If this wasn't you, contact EventHub immediately.`;
  if (!mail) {
    console.log(`\n[DEV EMAIL] Email-changed notice -> ${to}\n[DEV EMAIL] ${text}\n`);
    return;
  }
  try {
    await mail.sendMail({
      from: `"EventHub" <${process.env.GMAIL_USER}>`,
      to,
      subject: 'Your EventHub contact email was changed',
      text,
    });
  } catch (err) {
    console.error('Notice mail error:', err.message);
  }
}

// Invitation for an Admin-created Organizer/Staff account. It contains NO code and NO password:
// the staff member opens the link, asks for a code at Forgot Password, and sets their own password.
async function sendStaffInvite({ to, name, branchName, accountEmail }) {
  const appUrl = process.env.PUBLIC_APP_URL || process.env.CLIENT_URL;
  const link = appUrl ? `${appUrl.replace(/\/$/, '')}/forgot-password?email=${encodeURIComponent(accountEmail)}` : '';
  const mail = getTransporter();
  const text = `Hi ${name}, an EventHub staff account was created for you (${branchName}). Your EventHub login email is ${accountEmail}.${link ? ` Set your password here: ${link}` : ' Contact your EventHub administrator for the public password-setup URL.'}`;
  if (!mail) {
    if (process.env.NODE_ENV === 'production') {
      throw Object.assign(new Error('Email service is not configured'), { status: 500 });
    }
    console.log(`\n[DEV EMAIL] Staff invite -> ${to}\n[DEV EMAIL] ${text}\n`);
    return;
  }
  const html = `
    <div style="font-family:Arial,sans-serif;max-width:480px;margin:auto;border:1px solid #BDDDFC;border-radius:12px;overflow:hidden">
      <div style="background:#384959;color:#fff;padding:20px 24px;font-size:20px;font-weight:bold">EventHub</div>
      <div style="padding:24px;color:#384959">
        <h2 style="margin:0 0 8px">Your staff account is ready</h2>
        <p>Hi ${name},</p>
        <p>An EventHub staff account was created for you at the <strong>${branchName}</strong>.</p>
        <p>Your EventHub login email is:</p>
        <p style="background:#BDDDFC;border-radius:8px;text-align:center;font-size:17px;font-weight:bold;padding:12px;margin:12px 0">${accountEmail}</p>
        <p>Use it to log in. To start, set your password. We will send a 6-digit code to this email address to confirm it is you.</p>
        ${link ? `<p style="text-align:center;margin:24px 0"><a href="${link}" style="background:#88BDF2;color:#384959;text-decoration:none;font-weight:bold;padding:12px 24px;border-radius:10px">Set my password</a></p><p style="font-size:13px;color:#6A89A7">If the button does not work, open ${link}</p>` : '<p>Please contact your EventHub administrator for the public password-setup URL.</p>'}
      </div>
    </div>`;
  try {
    await mail.sendMail({ from: `"EventHub" <${process.env.GMAIL_USER}>`, to, subject: 'Your EventHub staff account', html, text });
  } catch (err) {
    console.error('Invite mail error:', err.message);
    throw Object.assign(new Error('Could not send the invitation email.'), { status: 502 });
  }
}

// Sent after a User verifies their contact email, so the generated login email is never lost.
async function sendAccountReadyEmail({ to, name, accountEmail }) {
  const mail = getTransporter();
  const text = `Hi ${name}, your email is verified. Your EventHub account email is ${accountEmail}. Use this email to log in to EventHub.`;
  if (!mail) {
    console.log(`\n[DEV EMAIL] Account ready -> ${to}\n[DEV EMAIL] ${text}\n`);
    return;
  }
  const html = `
    <div style="font-family:Arial,sans-serif;max-width:480px;margin:auto;border:1px solid #BDDDFC;border-radius:12px;overflow:hidden">
      <div style="background:#384959;color:#fff;padding:20px 24px;font-size:20px;font-weight:bold">EventHub</div>
      <div style="padding:24px;color:#384959">
        <h2 style="margin:0 0 8px">Email verified</h2>
        <p>Hi ${name}, your email is verified. Your EventHub account email is:</p>
        <p style="background:#BDDDFC;border-radius:8px;text-align:center;font-size:17px;font-weight:bold;padding:12px;margin:12px 0">${accountEmail}</p>
        <p>Use this email, with your password, to log in to EventHub.</p>
      </div>
    </div>`;
  try {
    await mail.sendMail({ from: `"EventHub" <${process.env.GMAIL_USER}>`, to, subject: 'Your EventHub account email', html, text });
  } catch (err) {
    console.error('Account-ready mail error:', err.message);
  }
}

module.exports = { sendCodeEmail, sendEmailChangedNotice, sendStaffInvite, sendAccountReadyEmail };
