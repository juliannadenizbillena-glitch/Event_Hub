require('dotenv').config();
const connectDB = require('./config/db');

const required = ['MONGO_URI', 'JWT_SECRET'];
const missing = required.filter((key) => !process.env[key]);
if (missing.length) {
  console.error(`Missing environment variables: ${missing.join(', ')}. Copy .env.example to .env.`);
  process.exit(1);
}

const app = require('./app');
const PORT = process.env.PORT || 5000;

const { expireOverdue } = require('./services/bookingService');

connectDB()
  .then(() => {
    // Releases team holds when the 24-hour payment window ends. Requests also expire lazily,
    // so correctness never depends on this timer; it just keeps the data tidy and notifies users.
    const sweep = () => expireOverdue().catch((err) => console.error('Expiry sweep failed:', err.message));
    sweep();
    setInterval(sweep, 60 * 1000).unref();
    app.listen(PORT, () => console.log(`EventHub API running on http://localhost:${PORT}`));
  })
  .catch((err) => {
    console.error('Database connection failed:', err.message);
    process.exit(1);
  });
