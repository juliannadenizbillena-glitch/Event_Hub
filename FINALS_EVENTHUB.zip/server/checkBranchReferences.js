
require('dotenv').config();
const mongoose = require('mongoose');

const legacyBranchIds = new Set([
  '6ad12159d5c8815883f826e7', // Cebu
  '6ad12159d5c8815883f826e8', // Davao
  '6ad12159d5c8815883f826e6', // Makati
  '6ad12158d5c8815883f826e4', // Manila
  '6ad12158d5c8815883f826e5', // Quezon City
]);

function findReferences(value, path = '') {
  const found = [];

  if (value == null) return found;

  if (value._bsontype === 'ObjectId') {
    if (legacyBranchIds.has(value.toString())) {
      found.push(path || '(root)');
    }
    return found;
  }

  if (Array.isArray(value)) {
    value.forEach((item, index) => {
      found.push(...findReferences(item, `${path}[${index}]`));
    });
    return found;
  }

  if (typeof value === 'object') {
    for (const [key, item] of Object.entries(value)) {
      found.push(...findReferences(item, path ? `${path}.${key}` : key));
    }
  }

  return found;
}

async function main() {
  await mongoose.connect(process.env.MONGO_URI);
  const db = mongoose.connection.db;

  console.log('Checking references to the five legacy branch IDs...\n');

  for (const { name } of await db.listCollections().toArray()) {
    const collection = db.collection(name);
    const cursor = collection.find({});
    let matches = 0;

    for await (const doc of cursor) {
      const paths = findReferences(doc);

      if (paths.length) {
        matches++;
        console.log({
          collection: name,
          documentId: String(doc._id),
          referencePaths: paths,
        });
      }
    }

    if (matches) {
      console.log(`Matches in ${name}: ${matches}\n`);
    }
  }

  console.log('\nRead-only reference check complete.');
  await mongoose.disconnect();
}

main().catch(async (error) => {
  console.error(error);
  await mongoose.disconnect().catch(() => {});
  process.exitCode = 1;
});
