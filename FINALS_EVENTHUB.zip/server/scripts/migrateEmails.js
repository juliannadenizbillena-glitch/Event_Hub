// npm run migrate:emails
// Converts old single-`email` accounts to accountEmail + contactEmail. The server also does this
// automatically at startup; this command just lets you run it (and read the result) on its own.
// Safe to run any number of times.
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');

(async () => {
  await connectDB(); // connecting runs the migration and prints the new login emails
  console.log('Migration check complete. Nothing left to convert.');
  await mongoose.disconnect();
})().catch((err) => { console.error(err); process.exit(1); });
