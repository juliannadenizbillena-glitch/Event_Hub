// Run once: npm run create-admin
// Admin accounts are never created from the public Register page.
//
// An Admin has the same two emails as everyone else:
//   ADMIN_CONTACT_EMAIL : the real email (recovery codes are sent here)
//   ADMIN_ACCOUNT_EMAIL : the login email, must end with @admin.eventhub.com.
//                         Leave it empty to generate it from the name (eventhubadmin@admin.eventhub.com).
// (An old ADMIN_EMAIL value is still read as the contact email.)
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const User = require('../models/User');
const { ACCOUNT_DOMAINS, isEventHubAddress } = require('../config/accounts');
const { ensureAccountEmail } = require('../utils/accountEmail');

(async () => {
  await connectDB();
  const contactEmail = (process.env.ADMIN_CONTACT_EMAIL || process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  const accountEmail = (process.env.ADMIN_ACCOUNT_EMAIL || '').trim().toLowerCase();
  if (!contactEmail || !process.env.ADMIN_PASSWORD) {
    console.error('Set ADMIN_CONTACT_EMAIL (your real email) and ADMIN_PASSWORD in .env first.');
    process.exit(1);
  }
  if (isEventHubAddress(contactEmail)) {
    console.error('ADMIN_CONTACT_EMAIL must be a real email address, not an EventHub account email.');
    process.exit(1);
  }
  if (accountEmail && !accountEmail.endsWith(`@${ACCOUNT_DOMAINS.admin}`)) {
    console.error(`ADMIN_ACCOUNT_EMAIL must end with @${ACCOUNT_DOMAINS.admin}.`);
    process.exit(1);
  }

  const existing = await User.findOne({ $or: [{ contactEmail }, ...(accountEmail ? [{ accountEmail }] : [])] });
  if (existing) {
    console.log(`An account already exists for that email (role: ${existing.role}, login: ${existing.accountEmail || 'not generated yet'}). Nothing changed.`);
  } else {
    const admin = await User.create({
      firstName: process.env.ADMIN_FIRST_NAME || 'EventHub',
      lastName: process.env.ADMIN_LAST_NAME || 'Admin',
      contactEmail,
      phone: process.env.ADMIN_PHONE,
      password: process.env.ADMIN_PASSWORD,
      role: 'admin',
      isVerified: true,
      ...(accountEmail ? { accountEmail } : {}),
    });
    const login = await ensureAccountEmail(admin);
    console.log(`Admin created.\n  Log in with: ${login}\n  Contact email: ${contactEmail}`);
  }
  await mongoose.disconnect();
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
