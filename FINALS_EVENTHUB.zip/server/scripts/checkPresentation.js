// npm run check:presentation
// Verifies that the CURRENT database is ready to present, and prints the evidence.
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const User = require('../models/User');
const Branch = require('../models/Branch');
const EventType = require('../models/EventType');
const Team = require('../models/Team');
const Bundle = require('../models/Bundle');
const AddOn = require('../models/AddOn');
const Equipment = require('../models/Equipment');
const Venue = require('../models/Venue');
const Booking = require('../models/Booking');
const Payment = require('../models/Payment');
const DamageReport = require('../models/DamageReport');
const InternalCost = require('../models/InternalCost');

const rows = [];
let failed = 0;
const check = (req, ok, evidence) => { rows.push([ok ? 'PASS' : 'FAIL', req, evidence]); if (!ok) failed += 1; };

(async () => {
  await connectDB();
  const [branches, types, teams, bundles, addOns, equipment, venues] = await Promise.all([Branch.countDocuments(), EventType.countDocuments(), Team.countDocuments(), Bundle.countDocuments(), AddOn.countDocuments(), Equipment.countDocuments(), Venue.countDocuments()]);
  check('5 branches, 11 event types, 275 teams, 44 bundles', branches >= 5 && types === 11 && teams >= 275 && bundles >= 44, `${branches} branches, ${types} event types, ${teams} teams, ${bundles} bundles`);
  check('add-ons, equipment and venues are set up', addOns >= 6 && equipment > 0 && venues > 0, `${addOns} add-ons, ${equipment} equipment items, ${venues} venues`);

  const users = await User.find({ role: 'user', isVerified: true, status: 'active' });
  const complete = users.filter((u) => u.companyName && u.firstName && u.lastName && u.contactEmail && u.accountEmail && u.phone);
  check('at least 10 realistic User/Company accounts', complete.length >= 10, `${complete.length} verified active companies with name, contact person, both emails and phone`);
  check('Admin and Organizer accounts exist (every branch has an Organizer)', (await User.countDocuments({ role: 'admin' })) >= 1 && (await User.distinct('branch', { role: 'organizer', status: 'active' })).length >= 5, `${await User.countDocuments({ role: 'admin' })} admin(s), organizers in ${(await User.distinct('branch', { role: 'organizer', status: 'active' })).length} branches`);

  const paid = await Booking.find({ status: 'fully_paid' });
  const ids = paid.map((b) => b._id);
  const payments = await Payment.find({ booking: { $in: ids }, status: 'verified' });
  const realistic = paid.filter((b) => {
    const mine = payments.filter((p) => String(p.booking) === String(b._id));
    const down = mine.find((p) => p.type === 'down'); const fin = mine.find((p) => p.type === 'final');
    const trail = ['pending_approval', 'payment_required', 'payment_verification', 'confirmed', 'ongoing', 'completed_pending_final', 'fully_paid'].every((s) => b.history.some((h) => h.status === s));
    return down && fin && down.amount === b.downPaymentAmount && Math.abs(fin.amount - (b.remainingAmount + (b.damageTotal || 0))) < 0.01 && trail && b.operations?.venueName && b.bundle?.name && b.finalPaidAt;
  });
  check('at least 20 realistic completed transactions', realistic.length >= 20, `${realistic.length} Fully Paid bookings, each with the full status trail, a verified 50% down payment, a verified final payment equal to the remaining balance + approved damage, a venue and a bundle snapshot`);
  const damage = await DamageReport.find({ booking: { $in: ids } });
  check('damage charges and internal costs are present in the completed data', damage.some((d) => d.status === 'approved') && (await InternalCost.countDocuments({ booking: { $in: ids } })) > 20, `${damage.filter((d) => d.status === 'approved').length} approved / ${damage.filter((d) => d.status === 'rejected').length} rejected damage reports, ${await InternalCost.countDocuments({ booking: { $in: ids } })} internal cost records`);
  const byStatus = {}; (await Booking.find()).forEach((b) => { byStatus[b.status] = (byStatus[b.status] || 0) + 1; });
  const needed = ['pending_approval', 'payment_required', 'payment_verification', 'confirmed', 'ongoing', 'completed_pending_final', 'fully_paid', 'rejected', 'payment_expired', 'payment_overdue', 'cancelled'];
  check('every booking status can be demonstrated', needed.every((s) => byStatus[s]), needed.map((s) => `${s}:${byStatus[s] || 0}`).join(' '));
  check('the Archive can be demonstrated', (await Booking.countDocuments({ isArchived: true })) > 0, `${await Booking.countDocuments({ isArchived: true })} archived booking(s)`);
  const months = new Set(paid.map((b) => b.date.slice(0, 7)));
  check('reports have data across several months, branches and event types', months.size >= 3 && new Set(paid.map((b) => String(b.branch))).size >= 4 && new Set(paid.map((b) => String(b.eventType))).size >= 6, `${months.size} months, ${new Set(paid.map((b) => String(b.branch))).size} branches, ${new Set(paid.map((b) => String(b.eventType))).size} event types`);
  const strays = await User.countDocuments({ role: 'user', isDemo: { $ne: true } });
  check('no development / test leftovers (customer accounts outside the demo data)', strays === 0, strays ? `${strays} extra account(s): run npm run cleanup:data` : 'none');
  const orphanless = (await Booking.countDocuments({ company: { $nin: await User.distinct('_id') } })) === 0;
  check('no orphaned booking records', orphanless, 'every booking belongs to an existing company');

  console.log('\nPRESENTATION READINESS');
  rows.forEach(([s, req, ev]) => console.log(`${s}  ${req}\n        ${ev}`));
  console.log(`\n${rows.length - failed} of ${rows.length} checks passed.`);
  await mongoose.disconnect();
  process.exit(failed ? 1 : 0);
})().catch((err) => { console.error(err); process.exit(1); });
