const mongoose = require('mongoose');
const connectDB = require('../config/db');
const { ensureBundles } = require('../services/setup');

(async () => {
  try {
    await connectDB();

    await ensureBundles();

    console.log('Bundle repair completed successfully.');
  } catch (error) {
    console.error('Bundle repair failed:', error.message);
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
})();