// npm run seed:demo            prepare the presentation database (safe to repeat; it never duplicates)
// npm run seed:demo -- --reset remove the demo data and build it again
// npm run seed:demo -- --live  refresh only the in-progress bookings (their dates and payment deadlines move to "now")
//
// Every record is produced by the REAL business logic (booking, approval, 50% payment, verification, venue and
// equipment, event day, inspection, damage review, final payment), then its dates are moved into the past so the
// history looks like months of real operation. Nothing is inserted as a shortcut "Completed" record.
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const User = require('../models/User');
const Branch = require('../models/Branch');
const EventType = require('../models/EventType');
const Bundle = require('../models/Bundle');
const AddOn = require('../models/AddOn');
const Equipment = require('../models/Equipment');
const Venue = require('../models/Venue');
const Booking = require('../models/Booking');
const Payment = require('../models/Payment');
const TeamReservation = require('../models/TeamReservation');
const VenueReservation = require('../models/VenueReservation');
const DamageReport = require('../models/DamageReport');
const InternalCost = require('../models/InternalCost');
const Notification = require('../models/Notification');
const { ensureAllSetup } = require('../services/setup');
const { ensureAccountEmail } = require('../utils/accountEmail');
const { UPLOAD_ROOT } = require('../middleware/upload');
const { todayManila, addDays } = require('../config/rules');
const B = require('../services/bookingService');
const O = require('../services/operationsService');

const args = process.argv.slice(2);
const RESET = args.includes('--reset');
const LIVE_ONLY = args.includes('--live');
const DEMO_PASSWORD = process.env.DEMO_PASSWORD || 'Demo@12345';
const TODAY = todayManila();

// ---------- tiny file generators (receipts as PDF, photos as PNG), stored privately like real uploads ----------
function crc32(buf) { let c, crc = ~0; for (let n = 0; n < buf.length; n += 1) { c = (crc ^ buf[n]) & 0xff; for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; crc = (crc >>> 8) ^ c; } return ~crc >>> 0; }
const chunk = (type, data) => { const len = Buffer.alloc(4); len.writeUInt32BE(data.length); const td = Buffer.concat([Buffer.from(type), data]); const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td)); return Buffer.concat([len, td, crc]); };
function makePng(w, h, rgb) {
  const raw = Buffer.alloc((w * 3 + 1) * h);
  for (let y = 0; y < h; y += 1) for (let x = 0; x < w; x += 1) { const [r, g, b] = rgb(x, y); const i = y * (w * 3 + 1) + 1 + x * 3; raw[i - 1] = 0; raw[i] = r; raw[i + 1] = g; raw[i + 2] = b; }
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}
function makePdf(lines) {
  const text = lines.map((l, i) => `BT /F1 14 Tf 60 ${760 - i * 24} Td (${l.replace(/[()\\]/g, '')}) Tj ET`).join('\n');
  const objs = ['<< /Type /Catalog /Pages 2 0 R >>', '<< /Type /Pages /Kids [3 0 R] /Count 1 >>', '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>', `<< /Length ${text.length} >>\nstream\n${text}\nendstream`, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>'];
  let out = '%PDF-1.4\n'; const offs = [];
  objs.forEach((o, i) => { offs.push(out.length); out += `${i + 1} 0 obj\n${o}\nendobj\n`; });
  const xref = out.length;
  out += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n${offs.map((o) => `${String(o).padStart(10, '0')} 00000 n \n`).join('')}trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return Buffer.from(out);
}
function saveFile(kind, ext, buffer, mimetype, originalname) {
  const dir = path.join(UPLOAD_ROOT, kind);
  fs.mkdirSync(dir, { recursive: true });
  const name = `${crypto.randomBytes(16).toString('hex')}${ext}`;
  fs.writeFileSync(path.join(dir, name), buffer);
  return { rel: `${kind}/${name}`, filename: name, mimetype, originalname, size: buffer.length };
}
const receipt = (method, ref, amount, label) => saveFile('receipts', '.pdf', makePdf([`EventHub - ${label}`, method === 'gcash' ? 'GCash payment receipt' : 'Bank transfer receipt', `Reference: ${ref}`, `Amount: PHP ${amount.toLocaleString('en-PH')}`, 'Status: Successful']), 'application/pdf', `${ref}.pdf`);
const photo = (seed, kind = 'references') => saveFile(kind, '.png', makePng(320, 200, (x, y) => [(seed * 37 + x / 2) % 255, (seed * 91 + y) % 255, (150 + seed * 13) % 255]), 'image/png', `photo-${seed}.png`);

// ---------- demo people ----------
const ORGANIZERS = [
  ['Juan', 'Dela Cruz', 'MNL', 'Operations Lead'], ['Maria', 'Santos', 'MKT', 'Event Organizer'], ['Jose', 'Ramirez', 'QC', 'Event Organizer'],
  ['Angela', 'Torres', 'CEB', 'Operations Lead'], ['Mark', 'Villareal', 'DVO', 'Event Organizer'],
];
const COMPANIES = [
  ['Pinnacle Logistics Inc.', 'Ramon', 'Villanueva'], ['BrightPath Learning Center', 'Angelica', 'Reyes'], ['Metro Tech Solutions', 'Carlo', 'Mendoza'],
  ['Sunrise Hospitality Group', 'Patricia', 'Lim'], ['Northstar Finance Corp.', 'Miguel', 'Tan'], ['GreenLeaf Foods Inc.', 'Isabel', 'Garcia'],
  ['Coastal Marine Services', 'Rafael', 'Aquino'], ['Summit Healthcare Partners', 'Diana', 'Cruz'], ['Horizon Real Estate Development', 'Victor', 'Ong'],
  ['BlueWave Telecom', 'Samantha', 'Bautista'], ['Heritage Bank Employees Association', 'Gloria', 'Navarro'], ['Pacific Retail Holdings', 'Anthony', 'Co'],
];
const EVENT_NAMES = {
  workshop: 'Customer Service Excellence Workshop', conference: 'Annual Company Conference', seminar: 'Financial Wellness Seminar', training: 'Workplace Safety Training',
  summit: 'Regional Leaders Summit', 'networking-event': 'Partners Networking Night', hackathon: 'Innovation Hackathon', 'career-fair': 'Campus Career Fair',
  'product-launch': 'Product Launch Showcase', 'panel-discussion': 'Industry Trends Panel Discussion', exhibition: 'Trade Exhibition',
};
const SLUGS = Object.keys(EVENT_NAMES);
const REQS = ['Need 2 additional microphones and a registration table', 'Classroom-style seating with a welcome desk near the entrance', 'Please prepare a stage backdrop with our company logo', 'Reserved seating for 10 guests of honor and a media table', 'Coffee break area and a separate breakout corner', 'Theater-style seating with a podium and lapel microphone'];
const TIMES = [['08:00', '12:00'], ['09:00', '17:00'], ['13:00', '18:00'], ['10:00', '16:00']];
const ADDON_SETS = [[], ['LED Display'], ['Photography', 'Additional Microphones'], ['LED Display', 'Photography', 'Additional Microphones'], ['Video Documentation'], ['Sound System Upgrade', 'Additional Tables & Chairs']];
const COST_PLAN = [['fuel', 0.03], ['transportation', 0.06], ['equipment', 0.09], ['utilities', 0.04], ['printing_materials', 0.03], ['staff_transport_meals', 0.07], ['venue_preparation', 0.05], ['cleaning', 0.02]];
const levelFor = (n) => (n <= 100 ? 1 : n <= 200 ? 2 : n <= 300 ? 3 : 4);

const ctx = {};

async function loadContext() {
  ctx.admin = await User.findOne({ role: 'admin', status: 'active' });
  if (!ctx.admin) {
    const contactEmail = (process.env.ADMIN_CONTACT_EMAIL || 'admin@example.com').toLowerCase();
    ctx.admin = await User.create({ firstName: process.env.ADMIN_FIRST_NAME || 'EventHub', lastName: process.env.ADMIN_LAST_NAME || 'Admin', contactEmail, phone: process.env.ADMIN_PHONE || '09170000000', password: process.env.ADMIN_PASSWORD || 'Admin@12345', role: 'admin', isVerified: true });
    await ensureAccountEmail(ctx.admin);
    console.log('  Created the default Admin (set ADMIN_* in .env and use npm run create-admin to choose your own).');
  }
  ctx.branches = Object.fromEntries((await Branch.find()).map((b) => [b.code, b]));
  ctx.types = Object.fromEntries((await EventType.find()).map((t) => [t.slug, t]));
  ctx.bundles = {};
  for (const b of await Bundle.find()) ctx.bundles[`${b.eventType}:${b.level}`] = b;
  ctx.addOns = Object.fromEntries((await AddOn.find()).map((a) => [a.name, a]));
}

async function ensurePeople() {
  ctx.organizers = {};
  for (const [first, last, code, position] of ORGANIZERS) {
    let u = await User.findOne({ role: 'organizer', branch: ctx.branches[code]._id, isDemo: true });
    if (!u) {
      u = await User.create({ firstName: first, lastName: last, contactEmail: `${first}.${last}.organizer@example.com`.toLowerCase().replace(/\s/g, ''), phone: '0917555' + (1000 + ctx.organizers.length), password: DEMO_PASSWORD, role: 'organizer', isVerified: true, branch: ctx.branches[code]._id, position, isDemo: true });
      await ensureAccountEmail(u);
    }
    ctx.organizers[code] = await User.findById(u._id).populate('branch', 'name code');
  }
  ctx.users = [];
  let n = 0;
  for (const [company, first, last] of COMPANIES) {
    let u = await User.findOne({ role: 'user', companyName: company, isDemo: true });
    if (!u) {
      u = await User.create({ firstName: first, lastName: last, companyName: company, contactEmail: `${first}.${last}@${company.toLowerCase().replace(/[^a-z]/g, '').slice(0, 14)}.example.com`.toLowerCase(), phone: `0917${String(2000000 + n * 1371).slice(0, 7)}`, password: DEMO_PASSWORD, role: 'user', isVerified: true, isDemo: true });
      await ensureAccountEmail(u);
    }
    ctx.users.push(await User.findById(u._id));
    n += 1;
  }
}

// ---------- drive one booking through the REAL workflow up to a stage ----------
const STAGES = ['pending', 'approved', 'payment_submitted', 'confirmed', 'prepared', 'ready', 'ongoing', 'completed', 'inspected', 'final_submitted', 'fully_paid'];
const at = (stage, s) => STAGES.indexOf(stage) >= STAGES.indexOf(s);

async function pickEquipment(booking, org, n) {
  const names = ['Wireless Microphones', 'Projector', 'Projection Screen', 'Banquet Tables', 'Event Chairs'];
  const items = [];
  for (const name of names) {
    const eq = await Equipment.findOne({ name, branch: booking.branch });
    if (!eq) continue;
    const want = name === 'Event Chairs' ? Math.min(n, 400) : name === 'Banquet Tables' ? Math.max(4, Math.ceil(n / 10)) : name === 'Wireless Microphones' ? 4 : 2;
    items.push({ equipment: eq._id, quantity: Math.min(want, eq.quantity) });
  }
  return items;
}

async function drive(spec, upTo) {
  const user = ctx.users[spec.company];
  const org = ctx.organizers[spec.branch];
  const type = ctx.types[spec.type];
  const bundle = ctx.bundles[`${type._id}:${spec.level || levelFor(spec.attendees)}`];
  const tempDate = spec.tempDate || addDays(TODAY, 30 + spec.i);
  const [startTime, endTime] = spec.times || TIMES[spec.i % TIMES.length];
  let b = await B.createBooking(user, {
    eventName: spec.name || `${EVENT_NAMES[spec.type]} ${spec.year || new Date().getFullYear()}`, eventType: type._id, attendees: spec.attendees, branch: ctx.branches[spec.branch]._id,
    date: tempDate, startTime, endTime, bundle: bundle._id, addOns: (spec.addOns || []).map((n) => ctx.addOns[n]._id), requirements: spec.req || REQS[spec.i % REQS.length], agreement: true,
  });
  const set = { isDemo: true };
  if (spec.photo) { const f = photo(spec.i); set.referenceImage = { path: f.rel, mimeType: f.mimetype, originalName: f.originalname, size: f.size }; }
  await Booking.updateOne({ _id: b._id }, { $set: set });
  const id = b._id;
  const method = spec.i % 2 ? 'bank_transfer' : 'gcash';
  if (!at(upTo, 'approved')) return Booking.findById(id);

  await B.approveBooking(id, ctx.admin);
  if (upTo === 'approved') return Booking.findById(id);
  b = await Booking.findById(id);
  const ref1 = `${method === 'gcash' ? 'GC' : 'BT'}${String(7000000 + spec.i * 137 + (spec.k || 0)).padStart(8, '0')}`;
  const p1 = await B.submitDownPayment(user, id, { method, referenceNumber: ref1 }, receipt(method, ref1, b.downPaymentAmount, `50% down payment ${b.code}`));
  if (upTo === 'payment_submitted') return Booking.findById(id);
  await B.verifyPayment(p1._id, ctx.admin);

  if (spec.eventDate) await shiftDate(id, spec.eventDate);
  if (!at(upTo, 'prepared')) return Booking.findById(id);

  b = await Booking.findById(id);
  const venues = (await Venue.find({ branch: b.branch, isActive: true }).sort('capacity')).filter((v) => v.capacity >= b.attendees);
  await O.assignVenue(org, id, venues[0]._id);
  if (spec.equipment !== false) await O.setEquipment(org, id, await pickEquipment(b, org, b.attendees));
  const checks = spec.checks === undefined ? 6 : spec.checks;
  for (let k = 0; k < checks; k += 1) await O.setChecklistItem(org, id, k, true);
  if (upTo === 'prepared') return Booking.findById(id);
  await O.markReady(org, id);
  if (upTo === 'ready') return Booking.findById(id);
  await O.startEvent(org, id);
  if (upTo === 'ongoing') return Booking.findById(id);
  await O.completeEvent(org, id);
  if (upTo === 'completed') {
    for (const d of spec.damage || []) await O.submitDamageReport(org, id, d.report, [photo(spec.i + 7, 'damage')].map((f) => f));
    return Booking.findById(id);
  }
  const reports = [];
  for (const d of spec.damage || []) reports.push({ d, doc: await O.submitDamageReport(org, id, d.report, [photo(spec.i + 3, 'damage'), photo(spec.i + 5, 'damage')]) });
  await O.finishInspection(org, id, spec.inspection || 'Equipment and venue inspected after the event.');
  for (const { d, doc } of reports) await O.reviewDamage(ctx.admin, doc._id, d.review);
  if (upTo === 'inspected') return Booking.findById(id);
  b = await Booking.findById(id);
  const method2 = spec.i % 3 ? 'gcash' : 'bank_transfer';
  const ref2 = `${method2 === 'gcash' ? 'GC' : 'BT'}${String(8000000 + spec.i * 211 + (spec.k || 0)).padStart(8, '0')}`;
  const p2 = await B.submitFinalPayment(user, id, { method: method2, referenceNumber: ref2 }, receipt(method2, ref2, b.finalAmountDue, `Final payment ${b.code}`));
  if (upTo === 'final_submitted') return Booking.findById(id);
  await B.verifyFinalPayment(p2._id, ctx.admin);
  return Booking.findById(id);
}

async function shiftDate(bookingId, date) {
  await Booking.updateOne({ _id: bookingId }, { date });
  await TeamReservation.updateMany({ booking: bookingId }, { date });
  await VenueReservation.updateMany({ booking: bookingId }, { date });
}

// ---------- move a finished workflow back in time so the history reads like real operation ----------
async function backdate(bookingId, eventDate) {
  const base = new Date(`${eventDate}T09:00:00+08:00`).getTime();
  const day = 86400000;
  const t = (d, h = 0) => new Date(base + d * day + h * 3600000);
  const b = await Booking.findById(bookingId);
  const n = Math.max(b.history.length, 2);
  const start = t(-21).getTime(); const end = t(3).getTime();
  const history = b.history.map((h, i) => ({ status: h.status, byRole: h.byRole, note: h.note, at: new Date(start + ((end - start) * i) / (n - 1)) }));
  await Booking.collection.updateOne({ _id: b._id }, { $set: {
    createdAt: t(-21), updatedAt: t(3), approvedAt: t(-20), confirmedAt: t(-19), paymentDeadline: t(-19), history,
    'operations.readyAt': t(-1), 'operations.startedAt': t(0, 0), 'operations.completedAt': t(0, 8), 'inspection.completedAt': t(1),
    finalPaymentDueAt: t(8), ...(b.finalPaidAt ? { finalPaidAt: t(3) } : {}),
  } });
  const pays = await Payment.find({ booking: bookingId }).sort('createdAt');
  for (const p of pays) {
    const submitted = p.type === 'down' ? t(-19.5) : t(2);
    const reviewed = p.type === 'down' ? t(-19) : t(3);
    await Payment.collection.updateOne({ _id: p._id }, { $set: { createdAt: submitted, updatedAt: reviewed, reviewedAt: reviewed } });
  }
  await DamageReport.collection.updateMany({ booking: b._id }, { $set: { createdAt: t(0, 9), reviewedAt: t(1) } });
  await Notification.deleteMany({ booking: b._id }); // seeding notifications would all be "now"
}

async function addCosts(booking, i) {
  const total = booking.total;
  const parts = COST_PLAN.filter((_, k) => (k + i) % 3 !== 0 || k < 3).slice(0, 4 + (i % 3));
  const base = new Date(`${booking.date}T09:00:00+08:00`).getTime();
  for (const [category, pct] of parts) {
    const amount = Math.round((total * pct * (0.85 + ((i * 7 + category.length) % 30) / 100)) / 50) * 50;
    const doc = await InternalCost.create({ booking: booking._id, category, amount: Math.max(amount, 500), note: category.replace(/_/g, ' '), incurredOn: booking.date, recordedBy: ctx.admin._id, isDemo: true });
    await InternalCost.collection.updateOne({ _id: doc._id }, { $set: { createdAt: new Date(base + 4 * 86400000) } });
  }
}

// ---------- the 24 completed transactions (20 are required; 24 gives the reports some depth) ----------
function completedSpecs() {
  const sizes = [60, 90, 120, 150, 180, 220, 260, 320, 80, 140, 200, 380];
  const specs = [];
  for (let i = 0; i < 24; i += 1) {
    const dmgKind = i % 4 === 1 ? 'approved' : i % 8 === 5 ? 'both' : 'none';
    const damage = [];
    if (dmgKind === 'approved' || dmgKind === 'both') damage.push({ report: { item: ['Projector', 'Banquet Table', 'Microphone', 'Stage Skirting'][i % 4], description: 'Damaged during the event', quantity: 1, details: 'Reported by the Organizer during the post-event inspection', estimatedCost: 3500 + (i % 5) * 1500 }, review: { decision: 'approve', approvedAmount: 3000 + (i % 5) * 1500, note: 'Verified against the inspection photos' } });
    if (dmgKind === 'both') damage.push({ report: { item: 'Extension Cable', description: 'Frayed cable', quantity: 2, details: 'Looks like normal wear', estimatedCost: 1200 }, review: { decision: 'reject', note: 'Normal wear and tear, not charged' } });
    specs.push({
      i, k: 0, company: i % 12, branch: ['MKT', 'MNL', 'QC', 'CEB', 'DVO'][i % 5], type: SLUGS[(i * 3) % 11], attendees: sizes[i % sizes.length],
      addOns: ADDON_SETS[i % ADDON_SETS.length], eventDate: addDays(TODAY, -(8 + i * 6)), tempDate: addDays(TODAY, 40 + i), photo: i % 3 === 0, damage,
      year: new Date(addDays(TODAY, -(8 + i * 6))).getFullYear(),
    });
  }
  return specs;
}

async function seedHistory() {
  const existing = await Booking.countDocuments({ isDemo: true, status: 'fully_paid', isArchived: { $in: [true, false] }, 'history.0': { $exists: true } });
  if (existing >= 20) { console.log(`  Completed transactions already present (${existing}). Skipping history.`); return; }
  const specs = completedSpecs();
  let done = 0;
  for (const spec of specs) {
    const b = await drive(spec, 'fully_paid');
    await backdate(b._id, spec.eventDate);
    const fresh = await Booking.findById(b._id);
    await addCosts(fresh, spec.i);
    done += 1;
    process.stdout.write(`\r  completed transactions: ${done}/${specs.length}`);
  }
  process.stdout.write('\n');
  // archive the oldest three so the Archive can be demonstrated
  const oldest = await Booking.find({ isDemo: true, status: 'fully_paid' }).sort({ date: 1 }).limit(3);
  for (const o of oldest) await B.archiveBooking(o._id);
}

// ---------- in-progress bookings, one per status, so every screen has something to show ----------
async function seedLive() {
  await clearLive();
  const S = (company, branch, type, attendees, over = {}) => ({ i: 100 + Object.keys(over).length + company * 3 + attendees, k: 1, company, branch, type, attendees, ...over });
  const live = {};
  live.pending1 = await drive(S(0, 'MKT', 'conference', 180, { name: 'Annual Logistics Conference', tempDate: addDays(TODAY, 21), addOns: ['LED Display', 'Photography'], photo: true }), 'pending');
  live.pending2 = await drive(S(1, 'MNL', 'training', 90, { name: 'Teacher Development Training', tempDate: addDays(TODAY, 30) }), 'pending');
  live.approved = await drive(S(2, 'MKT', 'product-launch', 120, { name: 'Metro Tech Product Launch', tempDate: addDays(TODAY, 40), addOns: ['LED Display', 'Video Documentation'] }), 'approved');
  live.verification = await drive(S(3, 'CEB', 'networking-event', 140, { name: 'Hospitality Partners Networking Night', tempDate: addDays(TODAY, 35), addOns: ['Photography'] }), 'payment_submitted');
  live.confirmedPartial = await drive(S(4, 'QC', 'summit', 260, { name: 'Finance Leaders Summit', tempDate: addDays(TODAY, 14), eventDate: addDays(TODAY, 14), checks: 3 }), 'prepared');
  live.confirmedFresh = await drive(S(5, 'DVO', 'exhibition', 320, { name: 'Davao Food Trade Exhibition', tempDate: addDays(TODAY, 28), eventDate: addDays(TODAY, 28) }), 'confirmed');
  live.todayNotReady = await drive(S(6, 'MNL', 'workshop', 60, { name: 'Marine Safety Workshop', tempDate: addDays(TODAY, 3), eventDate: TODAY }), 'confirmed');
  live.todayReady = await drive(S(7, 'MKT', 'seminar', 150, { name: 'Healthcare Compliance Seminar', tempDate: addDays(TODAY, 4), eventDate: TODAY, addOns: ['LED Display', 'Photography', 'Additional Microphones'] }), 'ready');
  live.ongoing = await drive(S(8, 'QC', 'panel-discussion', 100, { name: 'Real Estate Market Outlook Panel', tempDate: addDays(TODAY, 5), eventDate: TODAY }), 'ongoing');
  live.inspection = await drive(S(9, 'CEB', 'career-fair', 200, { name: 'Telecom Careers Fair', tempDate: addDays(TODAY, 6), eventDate: addDays(TODAY, -1), damage: [{ report: { item: 'LED Panel', description: 'Cracked corner', quantity: 1, details: 'Found while dismantling', estimatedCost: 9500 } }] }), 'completed');
  live.finalDue = await drive(S(10, 'DVO', 'training', 150, { name: 'Employee Banking Training', tempDate: addDays(TODAY, 7), eventDate: addDays(TODAY, -3), damage: [{ report: { item: 'Projector Lens', description: 'Scratched lens', quantity: 1, details: 'Scratch visible', estimatedCost: 4500 }, review: { decision: 'approve', approvedAmount: 4500 } }] }), 'inspected');
  live.finalSubmitted = await drive(S(11, 'MNL', 'product-launch', 220, { name: 'Retail Product Launch', tempDate: addDays(TODAY, 8), eventDate: addDays(TODAY, -4) }), 'final_submitted');
  live.rejected = await drive(S(1, 'MNL', 'conference', 300, { name: 'Education Summit Conference', tempDate: addDays(TODAY, 50) }), 'pending');
  await B.rejectBooking(live.rejected._id, ctx.admin, 'The requested hall is already reserved for another event on this date.');
  live.expired = await drive(S(2, 'MKT', 'training', 80, { name: 'Technical Onboarding Training', tempDate: addDays(TODAY, 45) }), 'approved');
  await Booking.updateOne({ _id: live.expired._id }, { paymentDeadline: new Date(Date.now() - 3600000) });
  await TeamReservation.updateMany({ booking: live.expired._id }, { heldUntil: new Date(Date.now() - 3600000) });
  live.cancelled = await drive(S(3, 'CEB', 'exhibition', 400, { name: 'Hospitality Expo', tempDate: addDays(TODAY, 60) }), 'pending');
  await B.cancelBooking(ctx.users[3], live.cancelled._id, 'The venue was changed by our management.');
  live.archivedRejected = await drive(S(11, 'DVO', 'hackathon', 120, { name: 'Retail Innovation Hackathon', tempDate: addDays(TODAY, 55) }), 'pending');
  await B.rejectBooking(live.archivedRejected._id, ctx.admin, 'The event type is not available at this branch on the requested date.');
  await B.archiveBooking(live.archivedRejected._id);
  live.overdue = await drive(S(6, 'MNL', 'seminar', 110, { name: 'Maritime Industry Seminar', tempDate: addDays(TODAY, 9), eventDate: addDays(TODAY, -20) }), 'inspected');
  await Booking.updateOne({ _id: live.overdue._id }, { finalPaymentDueAt: new Date(Date.now() - 2 * 86400000) });
  await B.expireOverdue();
  // costs for the not-yet-completed ones that are already confirmed or later
  for (const k of ['todayReady', 'ongoing', 'inspection', 'finalDue', 'finalSubmitted', 'overdue']) await addCosts(await Booking.findById(live[k]._id), 200);
  await Notification.deleteMany({ booking: { $in: [live.pending1._id] }, type: 'booking_submitted' }); // keep the Admin bell tidy
  return live;
}

async function clearLive() {
  const liveStatuses = ['pending_approval', 'payment_required', 'payment_verification', 'confirmed', 'ongoing', 'completed_pending_final', 'payment_overdue', 'rejected', 'payment_expired', 'cancelled'];
  const demoUsers = await User.find({ isDemo: true }).select('_id');
  const bookings = await Booking.find({ isDemo: true, company: { $in: demoUsers.map((u) => u._id) }, $or: [{ status: { $in: liveStatuses } }, { isArchived: true, status: { $ne: 'fully_paid' } }] }).select('_id');
  await wipeBookings(bookings.map((b) => b._id));
}

async function wipeBookings(ids) {
  await Promise.all([
    TeamReservation.deleteMany({ booking: { $in: ids } }), VenueReservation.deleteMany({ booking: { $in: ids } }), Payment.deleteMany({ booking: { $in: ids } }),
    DamageReport.deleteMany({ booking: { $in: ids } }), InternalCost.deleteMany({ booking: { $in: ids } }), Notification.deleteMany({ booking: { $in: ids } }),
  ]);
  await Booking.deleteMany({ _id: { $in: ids } });
}

async function resetDemo() {
  const users = await User.find({ isDemo: true }).select('_id');
  const bookings = await Booking.find({ $or: [{ isDemo: true }, { company: { $in: users.map((u) => u._id) } }] }).select('_id');
  await wipeBookings(bookings.map((b) => b._id));
  await Notification.deleteMany({ user: { $in: users.map((u) => u._id) } });
  await User.deleteMany({ isDemo: true });
  console.log('  Removed the previous demo data.');
}

(async () => {
  await connectDB();
  const totals = await ensureAllSetup();
  console.log(`System setup ready: ${totals.branches} branches, ${totals.eventTypes} event types, ${totals.teams} teams, ${totals.bundles} bundles, ${totals.addOns} add-ons, ${totals.equipment} equipment, ${totals.venues} venues.`);
  if (RESET) await resetDemo();
  await loadContext();
  await ensurePeople();
  console.log(`Demo people ready: ${ctx.users.length} companies, ${Object.keys(ctx.organizers).length} organizers (password for all demo accounts: ${DEMO_PASSWORD}).`);
  if (!LIVE_ONLY) { console.log('Building completed transactions through the real workflow...'); await seedHistory(); }
  console.log('Building in-progress bookings (one per status)...');
  await seedLive();

  const count = (f) => Booking.countDocuments(f);
  console.log('\nPresentation data ready:');
  console.log(`  Users/Companies: ${await User.countDocuments({ role: 'user', isVerified: true })}   Organizers: ${await User.countDocuments({ role: 'organizer' })}   Admins: ${await User.countDocuments({ role: 'admin' })}`);
  console.log(`  Completed transactions (Fully Paid): ${await count({ status: 'fully_paid' })} (${await count({ status: 'fully_paid', isArchived: true })} archived)`);
  console.log(`  Payments: ${await Payment.countDocuments({ status: 'verified' })} verified   Damage reports: ${await DamageReport.countDocuments()}   Internal cost records: ${await InternalCost.countDocuments()}`);
  console.log('\nDemo login emails (the website never displays them; this list is for the presenter):');
  for (const u of await User.find({ isDemo: true }).sort({ role: -1, companyName: 1 })) console.log(`  ${u.role.padEnd(9)} ${String(u.accountEmail).padEnd(46)} ${u.companyName || u.position}`);
  await mongoose.disconnect();
})().catch((err) => { console.error(err); process.exit(1); });
