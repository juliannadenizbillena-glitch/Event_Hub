// npm run cleanup:data                 DRY RUN: shows what would be removed
// npm run cleanup:data -- --confirm    removes it
// npm run cleanup:data -- --confirm --keep=name@example.com,other@example.com   (contact or login emails to keep)
//
// Removes development / test leftovers before a presentation:
//   * customer accounts that are not part of the prepared demo data (test registrations) and ALL their records
//   * unverified registrations, expired or leftover verification codes
//   * notifications of removed accounts, and uploaded files no record points to any more
// Keeps: Admin and Organizer accounts, branches, event types, teams, bundles, add-ons, equipment, venues, and the demo data.
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const User = require('../models/User');
const Booking = require('../models/Booking');
const Payment = require('../models/Payment');
const TeamReservation = require('../models/TeamReservation');
const VenueReservation = require('../models/VenueReservation');
const DamageReport = require('../models/DamageReport');
const InternalCost = require('../models/InternalCost');
const Notification = require('../models/Notification');
const VerificationCode = require('../models/VerificationCode');
const { UPLOAD_ROOT } = require('../middleware/upload');

const CONFIRM = process.argv.includes('--confirm');
const keepArg = (process.argv.find((a) => a.startsWith('--keep=')) || '').slice(7).toLowerCase().split(',').filter(Boolean);

(async () => {
  await connectDB();
  const customers = await User.find({ role: 'user', isDemo: { $ne: true } });
  const doomed = customers.filter((u) => !keepArg.includes(u.contactEmail) && !keepArg.includes(u.accountEmail));
  const doomedIds = doomed.map((u) => u._id);
  const bookings = await Booking.find({ company: { $in: doomedIds } }).select('_id');
  const bids = bookings.map((b) => b._id);
  const expiredCodes = await VerificationCode.countDocuments({ expiresAt: { $lt: new Date() } });
  const counts = {
    'customer accounts (not demo data)': doomed.length, 'their bookings': bids.length,
    payments: await Payment.countDocuments({ booking: { $in: bids } }), 'damage reports': await DamageReport.countDocuments({ booking: { $in: bids } }),
    'internal costs': await InternalCost.countDocuments({ booking: { $in: bids } }), 'expired verification codes': expiredCodes,
  };
  console.log(CONFIRM ? 'Removing development data:' : 'DRY RUN. Nothing is removed. Development data found:');
  Object.entries(counts).forEach(([k, v]) => console.log(`  ${String(v).padStart(5)}  ${k}`));
  doomed.slice(0, 25).forEach((u) => console.log(`         - ${u.companyName || '(no company)'} <${u.contactEmail}>${u.isVerified ? '' : ' (unverified)'}`));

  if (CONFIRM) {
    await Promise.all([
      TeamReservation.deleteMany({ booking: { $in: bids } }), VenueReservation.deleteMany({ booking: { $in: bids } }), Payment.deleteMany({ booking: { $in: bids } }),
      DamageReport.deleteMany({ booking: { $in: bids } }), InternalCost.deleteMany({ booking: { $in: bids } }),
      Notification.deleteMany({ $or: [{ booking: { $in: bids } }, { user: { $in: doomedIds } }] }),
      VerificationCode.deleteMany({ $or: [{ user: { $in: doomedIds } }, { expiresAt: { $lt: new Date() } }] }),
    ]);
    await Booking.deleteMany({ _id: { $in: bids } });
    await User.deleteMany({ _id: { $in: doomedIds } });

    // uploaded files that no record refers to any more
    const used = new Set();
    (await Booking.find({ 'referenceImage.path': { $exists: true } }).select('referenceImage')).forEach((b) => used.add(b.referenceImage.path));
    (await Payment.find().select('receipt')).forEach((p) => p.receipt?.path && used.add(p.receipt.path));
    (await DamageReport.find().select('evidence')).forEach((d) => d.evidence.forEach((e) => used.add(e.path)));
    let removedFiles = 0;
    for (const kind of fs.existsSync(UPLOAD_ROOT) ? fs.readdirSync(UPLOAD_ROOT) : []) {
      const dir = path.join(UPLOAD_ROOT, kind);
      if (!fs.statSync(dir).isDirectory()) continue;
      for (const f of fs.readdirSync(dir)) if (!used.has(`${kind}/${f}`) && f !== '.gitkeep') { fs.unlinkSync(path.join(dir, f)); removedFiles += 1; }
    }
    console.log(`  ${String(removedFiles).padStart(5)}  orphaned upload files removed`);
    console.log('Done. Admin, Organizers, system configuration and demo data were kept.');
  } else if (doomed.length || expiredCodes) {
    console.log('\nRun again with --confirm to remove them.');
  } else {
    console.log('Nothing to clean: the database only contains configuration and the prepared demo data.');
  }
  await mongoose.disconnect();
})().catch((err) => { console.error(err); process.exit(1); });
