
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const { ensureAllSetup } = require('../services/setup');

(async () => {
  await connectDB();
  const totals = await ensureAllSetup();
  console.log(`Setup ready: ${totals.branches} branches, ${totals.eventTypes} event types, ${totals.teams} teams, ${totals.bundles} bundles, ${totals.addOns} add-ons, ${totals.equipment} equipment items, ${totals.venues} venues.`);
  await mongoose.disconnect();
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
