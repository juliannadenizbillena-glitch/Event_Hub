const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const { notFound, errorHandler } = require('./middleware/error');

const app = express();

app.use(helmet());
app.use(
  cors({
    origin: process.env.CLIENT_URL || 'http://localhost:5173',
    credentials: true, // lets the browser send the httpOnly login cookie
  })
);
app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());

app.get('/api/health', (req, res) => res.json({ status: 'ok', service: 'EventHub API' }));
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/profile', require('./routes/profileRoutes'));
app.use('/api/branches', require('./routes/branchRoutes'));
app.use('/api/event-types', require('./routes/eventTypeRoutes'));
app.use('/api/teams', require('./routes/teamRoutes'));
app.use('/api/admin', require('./routes/adminRoutes'));
app.use('/api/bundles', require('./routes/bundleRoutes'));
app.use('/api/add-ons', require('./routes/addOnRoutes'));
app.use('/api/pricing', require('./routes/pricingRoutes'));
app.use('/api/availability', require('./routes/availabilityRoutes'));
app.use('/api/bookings', require('./routes/bookingRoutes'));
app.use('/api/payments', require('./routes/paymentRoutes'));
app.use('/api/notifications', require('./routes/notificationRoutes'));
app.use('/api/equipment', require('./routes/equipmentRoutes'));
app.use('/api/venues', require('./routes/venueRoutes'));
app.use('/api/damage-reports', require('./routes/damageRoutes'));
app.use('/api/dashboard', require('./routes/dashboardRoutes'));
app.use('/api/calendar', require('./routes/calendarRoutes'));

app.use(notFound);
app.use(errorHandler);

module.exports = app;
