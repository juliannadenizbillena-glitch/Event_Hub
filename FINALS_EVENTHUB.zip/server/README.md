# EventHub API

## Account model: two emails, two jobs
| | `accountEmail` | `contactEmail` |
|---|---|---|
| What it is | The generated EventHub **login** | The person's **real** email |
| Example | `juliannadenizbillena@user.eventhub.com` | `julianna@gmail.com` |
| Used for | Logging in (the only login identity) | Verification codes, setup/invitations, notices |
| Changes? | **Never** (not even if the name changes) | Yes, with password + a code sent to the new address |

- **User**: registers with a real email (stored as `contactEmail`) -> 6-digit code to that email -> after verification the login email is generated as `firstnamelastname@user.eventhub.com` (`...2@`, `...3@` if taken) and shown to the user (a copy is emailed too).
- **Organizer**: Admin enters the real email; the real contact email is also used as the Organizer login email; the invitation is sent to that address.
- **Admin**: `npm run create-admin` (login ends with `@admin.eventhub.com`).
- Normalisation: lowercase, spaces/accents/special characters removed, letters and numbers kept. Numbering, never random characters.
- A real contact email may be from any provider, but never an `@...eventhub.com` address.
- **Login** accepts only `accountEmail`. **Recovery** accepts either email and always sends the code to the contact email; after the code is verified the account email is shown.
- **Existing databases**: on startup the server migrates old single-`email` accounts automatically and safely (old email -> `contactEmail`, verified accounts get a generated login email, the old unique `email` index is dropped, passwords untouched) and prints each account's new login email. Run it by hand with `npm run migrate:emails`.


## Setup
```bash
npm install
cp .env.example .env     # then edit JWT_SECRET (and the email-sending credentials if you have them)
npm run create-admin     # creates the first Administrator
npm run seed:setup       # 5 branches, 11 event types, 275 teams, 44 bundles, 6 add-ons (safe to run again)
npm run dev              # http://localhost:5000
```
## Connect MongoDB Atlas
1. Atlas -> Database Access: create a database user (username + password).
2. Atlas -> Network Access: add your current IP address (use 0.0.0.0/0 only for short tests).
3. Atlas -> Connect -> Drivers: copy the connection string and add the database name before the `?`:
   `mongodb+srv://USER:PASSWORD@cluster0.xxxxx.mongodb.net/eventhub?retryWrites=true&w=majority`
   If the password has special characters (@ : / ? # %), URL-encode them.
4. Put it in `.env` as `MONGO_URI`.

## Test the whole auth flow against your database
```bash
npm run test:auth
```
Runs 40 checks (registration, email verification, login, profile, email change, password change,
forgot/reset password, organizer first-password, deactivated accounts). It uses throwaway
`eh.test.*@example.com` addresses, sends no real email, and deletes everything it created.
Without `GMAIL_USER` / `GMAIL_APP_PASSWORD`, codes are printed in the server console (development only).

## Endpoints
| Method | Route | Access | Purpose |
|---|---|---|---|
| POST | /api/auth/register | public | `{firstName,lastName,companyName,contactEmail,phone,password,confirmPassword}`: creates an unverified User, sends the 6-digit code to the contact email |
| POST | /api/auth/verify-email | public | `{contactEmail,code}`: verifies, generates the account email and returns `accountEmail` |
| POST | /api/auth/resend-code | public | `{contactEmail}`: resend the verification code |
| POST | /api/auth/login | public | `{accountEmail,password}` (all roles), sets the httpOnly cookie. A contact email is refused |
| POST | /api/auth/logout | public | Clears cookie |
| GET | /api/auth/me | logged in | Current user |
| POST | /api/auth/forgot-password | public | `{email}` = account OR contact email. Step 1: sends the code to the CONTACT email |
| POST | /api/auth/verify-reset-code | public | `{email,code}`. Step 2: returns `resetToken` and the `accountEmail` |
| POST | /api/auth/reset-password | public | Step 3: new password + confirm |
| GET | /api/profile | logged in | View profile |
| PATCH | /api/profile | logged in | Edit phone only |
| POST | /api/profile/email/request | logged in | Change the CONTACT email, step 1: `{newContactEmail,currentPassword}`, code sent to the NEW address |
| POST | /api/profile/email/confirm | logged in | Change the contact email, step 2: `{code}`. The account email never changes |
| DELETE | /api/profile/email/pending | logged in | Cancel a pending email change |
| PATCH | /api/profile/password | logged in | Change password |

## Rules built in
- Role is always `user` on public registration; the body cannot set it. No admin/organizer registration route exists.
- Email addresses are validated for format only (any provider); real contact emails must not be EventHub-generated addresses.
- Codes: 6 digits, stored hashed, expire in 10 minutes, 5 wrong attempts, 60-second resend cooldown, single use.
- Forgot/resend responses are identical whether or not the email exists.
- Protected routes reject unverified, deactivated, or archived accounts, and sessions issued before a password change.
- Organizers created by Admin (next step) have no password yet; they set it through Forgot Password.
- Email change: needs the current password; the new address must prove ownership with a 6-digit code; the login email only changes after the code is confirmed; each code is bound to the exact address it was sent to; the old address receives a notice.
- Use `authorize('admin')` / `authorize('organizer', 'admin')` after `protect` for role-guarded routes.

## Step 3: setup data and Admin-created staff
| Method | Route | Access | Purpose |
|---|---|---|---|
| GET | /api/branches | any role | Admin: all with team/staff counts. Others: active branches (name, code) |
| POST | /api/branches | Admin | New branch; its 55 teams are created automatically |
| PATCH | /api/branches/:id | Admin | Edit name/address (code is fixed) |
| PATCH | /api/branches/:id/status | Admin | Activate/deactivate (blocked while it has active staff) |
| GET | /api/event-types | any role | Admin: all. Others: active only (view only) |
| PATCH | /api/event-types/:id | Admin | Description, team structure, active flag (names are fixed) |
| GET | /api/teams | Admin, Organizer | Organizer is always limited to their own branch |
| PATCH | /api/teams/:id/status | Admin | Take a team out of / back into rotation |
| GET/POST | /api/admin/staff | Admin | List (search by name, either email, position) / create an Organizer: `{firstName,lastName,contactEmail,phone,branch,position}`; the real contact email is used as the login email, the role is forced |
| PATCH | /api/admin/staff/:id | Admin | Name, phone, branch, position (email is fixed) |
| PATCH | /api/admin/staff/:id/status | Admin | Activate/deactivate (deactivated staff are locked out immediately) |
| PUT | /api/teams/:id/assignments | Admin | Assign active staff from the same branch to the event type's existing position slots; each staff member can only be assigned once per team |
| POST | /api/admin/staff/:id/resend-invite | Admin | Only until the staff member has set a password |

Organizer rules enforced here: cannot edit event types, teams, branches or staff; cannot approve anything
(booking approval does not exist for them); sees only their own branch's teams.
`config/rules.js` holds `teamsRequired(attendees)` (1-100 = 1 team ... 401-500 = 5) for the Booking module.

Tests: `npm run test:rules` and `npm run test:accounts` (no database), `npm run test:auth` and `npm run test:setup` (use MONGO_URI).

## Step 4: bundles, add-ons, global pricing
| Method | Route | Access | Purpose |
|---|---|---|---|
| GET | /api/bundles?eventType=&status=&attendees= | any role | Admin/Organizer: all (Organizer view only). User: active bundles of active event types. `attendees=N` adds `fits` |
| POST | /api/bundles | Admin | Create a bundle for a free level (4 bundles per event type) |
| PATCH | /api/bundles/:id | Admin | Name, description, capacity, price, inclusions (event type and level are fixed) |
| PATCH | /api/bundles/:id/status | Admin | Activate / deactivate |
| GET | /api/add-ons | any role | Admin/Organizer: all. User: active only |
| POST, PATCH | /api/add-ons, /api/add-ons/:id | Admin | Create / edit (name, description, price) |
| PATCH | /api/add-ons/:id/status | Admin | Activate / deactivate |
| POST | /api/pricing/quote | any role | `{ eventType, attendees, bundle, addOns[] }` -> price breakdown, teamsRequired and the snapshot a Booking stores |

Rules: prices are whole pesos and global (no branch pricing); a bundle price is flat (not multiplied by
attendees or teams); capacity is the maximum attendees and is separate from the team calculation
(`teamsRequired`); Admin is the only role that can create, edit, price or deactivate; deactivated
bundles and add-ons stay valid for existing bookings but cannot be chosen for new ones.
`services/pricing.js` `buildQuote()` is what the Booking module will call: it copies names and prices
so later price changes never alter an existing booking.

Seed data is placeholder (Basic/Standard/Premium/Executive; 25,000 / 40,000 / 65,000 / 100,000; capacity
100 / 200 / 300 / 500; the six example add-ons). `seed:setup` never overwrites what Admin edited.

Tests: `npm run test:pricing` (uses MONGO_URI; temporarily edits a few Seminar bundles and add-ons and restores them).

## Booking module (availability, booking, 50% down payment, 24-hour team hold)
| Method | Route | Access | Purpose |
|---|---|---|---|
| GET | /api/availability?branch=&eventType=&attendees=&month=YYYY-MM | any role | Calendar: each day available / unavailable / past. Staff also get free-team counts. Organizer is limited to their branch |
| GET | /api/bookings/terms | any role | The booking terms shown before submitting |
| GET | /api/bookings/summary | any role | Counts by status (dashboards), within the caller's scope |
| GET | /api/bookings?scope=requests\|events&status=&search=&page= | any role | User: own. Organizer: own branch, no prices. Admin: all |
| POST | /api/bookings | User | Create a booking (status Pending Admin Approval; nothing is held yet) |
| GET | /api/bookings/:id | scoped | Booking Details (Admin also gets team availability for pending requests) |
| POST/GET | /api/bookings/:id/reference-image | User / scoped | Optional reference image (JPG, PNG, WebP, max 5 MB) |
| POST | /api/bookings/:id/approve | Admin | Re-checks availability, HOLDS the required teams for 24 hours |
| POST | /api/bookings/:id/reject | Admin | Reason required |
| GET | /api/payments/instructions | User, Admin | GCash / bank details (set in .env) |
| POST | /api/bookings/:id/payments | User | Submit the 50% down payment (method, reference number, receipt) |
| GET | /api/payments/:id/receipt | paying User, Admin | Receipts are never public and never shown to Organizers |
| POST | /api/payments/:id/verify | Admin | Booking becomes Confirmed; teams are LOCKED |
| POST | /api/payments/:id/reject | Admin | Reason required |
| GET, PATCH, POST | /api/notifications, /:id/read, /read-all | any role | In-app notifications |

Status flow: `pending_approval` -> `rejected` | `payment_required` (teams held 24h) -> `payment_verification` -> `confirmed`
(teams locked); a rejected payment returns to `payment_required` with the same deadline; no payment within 24h
-> `payment_expired` and the hold is released. `completed_pending_final`, `payment_overdue`, `fully_paid` are reserved
for the event-day and final-payment modules.

How team holding works: pending bookings never hold teams. Approval re-checks availability and reserves teams in the
`TeamReservation` collection. Its unique (team, date) index makes double booking impossible even when two Admins
approve at the same moment. A payment under review pauses the hold so it cannot lapse mid-verification; a Confirmed
booking is never expired. Expiry runs every minute AND lazily on every booking request.

Decisions to know about (change in `config/rules.js` / `services/availability.js`):
- A team is committed for the WHOLE event date (start and end time are stored, but availability is per date).
- Earliest bookable date is tomorrow; latest is 365 days ahead (Philippine dates, Asia/Manila).
- If Admin rejects a payment after the 24-hour deadline has already passed, the booking expires.
- Organizers never see prices, payments or payment notes.
- A company with a `payment_overdue` booking cannot create new bookings (the status itself arrives with the final-payment module).

Uploads go to `UPLOAD_DIR` (default `server/uploads`), are stored under random names and are served only through the API.
Tests: `npm run test:booking` (uses MONGO_URI; temporary data and files are removed afterwards).
