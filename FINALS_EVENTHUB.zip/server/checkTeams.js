
require('dotenv').config();

const mongoose = require('mongoose');
const Team = require('./models/Team');

async function main() {
  await mongoose.connect(process.env.MONGO_URI);

  console.log('Total teams:', await Team.countDocuments());
  console.log('Active teams:', await Team.countDocuments({ isActive: true }));
  console.log(
    'Teams missing branch or event type:',
    await Team.countDocuments({
      $or: [
        { branch: { $exists: false } },
        { eventType: { $exists: false } },
      ],
    })
  );

  await mongoose.disconnect();
}

main().catch(async (error) => {
  console.error(error);
  await mongoose.disconnect().catch(() => {});
  process.exitCode = 1;
});
