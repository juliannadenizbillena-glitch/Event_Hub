const DefaultUser = require('../models/User');
const { ensureAccountEmail } = require('../utils/accountEmail');

// Safe, idempotent migration from the old single `email` field to accountEmail + contactEmail.
//   * the old real email becomes contactEmail
//   * verified accounts get a generated accountEmail (their NEW login email)
//   * unverified accounts get theirs when they verify
//   * the legacy unique index on `email` is dropped (it would block new accounts)
// Nothing is deleted. Running it again changes nothing.
async function migrateLegacyEmails(User = DefaultUser) {
  const col = User.collection;
  let indexes = [];
  try { indexes = await col.indexes(); } catch { /* collection does not exist yet */ }
  for (const ix of indexes) {
    if (ix.key && Object.prototype.hasOwnProperty.call(ix.key, 'email')) {
      try { await col.dropIndex(ix.name); } catch { /* already gone */ }
    }
  }

  const legacy = await col.find({ email: { $exists: true } }).toArray();
  const mapping = [];
  for (const doc of legacy) {
    const set = {};
    const unset = { email: '' };
    if (!doc.contactEmail) set.contactEmail = String(doc.email).toLowerCase();
    if (doc.pendingEmail) { set.pendingContactEmail = String(doc.pendingEmail).toLowerCase(); unset.pendingEmail = ''; }
    const update = { $unset: unset };
    if (Object.keys(set).length) update.$set = set;
    await col.updateOne({ _id: doc._id }, update);

    if (doc.isVerified && !doc.accountEmail) {
      const accountEmail = await ensureAccountEmail(doc, User);
      mapping.push({ role: doc.role, contactEmail: String(doc.email).toLowerCase(), accountEmail });
    }
  }
  return { migrated: legacy.length, mapping };
}

// Called once after connecting: migrate, then build the indexes.
async function prepareDatabase(User = DefaultUser) {
  const result = await migrateLegacyEmails(User);
  await User.createIndexes();
  if (result.migrated) {
    console.log(`\nMigrated ${result.migrated} existing account(s) to the accountEmail / contactEmail model.`);
    result.mapping.forEach((m) => console.log(`  ${m.role.padEnd(9)} log in with: ${m.accountEmail}   (contact email: ${m.contactEmail})`));
    console.log('');
  }
  return result;
}

module.exports = { migrateLegacyEmails, prepareDatabase };
