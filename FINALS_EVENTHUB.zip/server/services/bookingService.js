const Booking = require('../models/Booking');
const Branch = require('../models/Branch');
const EventType = require('../models/EventType');
const Payment = require('../models/Payment');
const TeamReservation = require('../models/TeamReservation');
const Counter = require('../models/Counter');
const AppError = require('../utils/AppError');
const { buildQuote } = require('./pricing');
const { notify, notifyAdmins } = require('./notify');
const {
  availabilityForDate,
  availabilityForDateRange,
  reserveTeams,
  releaseReservations,
  lockReservations,
  pauseHold,
  resumeHold,
} = require('./availability');
const {
  PAYMENT_WINDOW_HOURS, isValidDate, isValidTime, isSelectableDate, bookableRange, splitPayment, todayManila,
} = require('../config/rules');
const TERMS = require('../config/terms');
const VenueReservation = require('../models/VenueReservation');
const { DEFAULT_CHECKLIST } = require('./operationsService');

const NO_TEAMS = 'No team is available for your selected schedule. Please select another date.';
const entry = (status, byRole, note) => ({ status, at: new Date(), byRole, note });


async function createBooking(user, input) {
  if (await Booking.exists({ company: user._id, status: 'payment_overdue' })) {
    throw new AppError(
      'You have an outstanding balance. Please settle it before booking another event.',
      403,
      'OUTSTANDING_BALANCE'
    );
  }

  if (input.agreement !== true) {
    throw new AppError('You must accept the booking terms.', 400, 'AGREEMENT_REQUIRED');
  }

  const { date, startTime, endTime } = input;
  const eventType = await EventType.findById(input.eventType);

  if (!eventType || !eventType.isActive) {
    throw new AppError('Choose an active event type.', 400, 'EVENT_TYPE_UNAVAILABLE');
  }

  const allowedModes = eventType.durationModes?.length
    ? eventType.durationModes
    : ['hourly'];

  const durationMode = input.durationMode || 'hourly';
  const endDate = durationMode === 'hourly' ? date : input.endDate;

  if (!allowedModes.includes(durationMode)) {
    throw new AppError(
      'This event type does not allow the selected booking duration.',
      400,
      'INVALID_DURATION_MODE'
    );
  }

  if (!isValidDate(date) || !isSelectableDate(date)) {
    const { min, max } = bookableRange();
    throw new AppError(
      `Choose an event start date between ${min} and ${max}.`,
      400,
      'DATE_NOT_SELECTABLE'
    );
  }

  if (
    !isValidDate(endDate) ||
    !isSelectableDate(endDate) ||
    endDate < date
  ) {
    throw new AppError(
      'Choose a valid event end date on or after the start date.',
      400,
      'BAD_DATE_RANGE'
    );
  }

  if (!isValidTime(startTime) || !isValidTime(endTime) || endTime <= startTime) {
    throw new AppError(
      'The end time must be after the start time.',
      400,
      'BAD_TIME'
    );
  }

  const branch = await Branch.findById(input.branch);

  if (!branch || !branch.isActive) {
    throw new AppError('Choose an active branch.', 400, 'BAD_BRANCH');
  }

  const quote = await buildQuote({
    eventTypeId: input.eventType,
    attendees: input.attendees,
    bundleId: input.bundle,
    addOnIds: input.addOns || [],
  });

  // Check availability across every date before creating the booking.
  const { free } = await availabilityForDateRange(
    branch._id,
    input.eventType,
    date,
    endDate
  );

  if (free.length < quote.teamsRequired) {
    throw new AppError(NO_TEAMS, 409, 'NO_TEAMS_AVAILABLE');
  }

  const { down, remaining } = splitPayment(quote.total);
  const year = todayManila().slice(0, 4);
  const code = `EH-${year}-${String(
    await Counter.next(`booking-${year}`)
  ).padStart(5, '0')}`;

  const booking = await Booking.create({
    code,
    company: user._id,
    eventName: input.eventName,
    eventType: input.eventType,
    branch: branch._id,

    date,
    endDate,
    durationMode,
    startTime,
    endTime,

    attendees: quote.attendees,
    teamsRequired: quote.teamsRequired,
    bundle: quote.bundle,
    addOns: quote.addOns,
    bundleTotal: quote.bundleTotal,
    addOnsTotal: quote.addOnsTotal,
    total: quote.total,
    downPaymentAmount: down,
    remainingAmount: remaining,

    requirements: input.requirements || undefined,
    agreement: {
      accepted: true,
      acceptedAt: new Date(),
      version: TERMS.version,
    },
    history: [
      entry('pending_approval', 'user', 'Booking submitted'),
    ],
  });

  await notifyAdmins({
    type: 'booking_submitted',
    title: 'New booking request',
    message: `${user.firstName} ${user.lastName} (${user.companyName || 'User/Company'}) submitted ${booking.code}: ${booking.eventName}. It is waiting for approval.`,
    booking: booking._id,
  });

  return booking;
}


// ---------- Admin: approve / reject ----------
async function approveBooking(bookingId, admin) {
  const booking = await Booking.findById(bookingId);
  if (!booking) throw new AppError('Booking not found.', 404, 'NOT_FOUND');
  if (booking.status !== 'pending_approval') throw new AppError('Only a booking that is pending approval can be approved.', 409, 'INVALID_STATE');

  const deadline = new Date(Date.now() + PAYMENT_WINDOW_HOURS * 3600 * 1000);
  let held = null;
  let chosen = null;
  // Availability is checked AGAIN here: another booking may have been approved since submission.
  for (let attempt = 0; attempt < 3 && !held; attempt += 1) {
    const { free } = await availabilityForDateRange(
  booking.branch,
  booking.eventType,
  booking.date,
  booking.endDate || booking.date
);
    if (free.length < booking.teamsRequired) {
      throw new AppError('Not enough teams are free on that date any more. Reject the request with a reason.', 409, 'NO_TEAMS_AVAILABLE');
    }
    chosen = free.slice(0, booking.teamsRequired);
    try { held = await reserveTeams(booking, chosen, deadline); }
    catch (err) { if (err.errorCode !== 'TEAM_CONFLICT' || attempt === 2) throw err; }
  }

  // Claim the booking. If someone approved/rejected it in the meantime, undo OUR reservations only.
  const updated = await Booking.findOneAndUpdate(
    { _id: booking._id, status: 'pending_approval' },
    { $set: { status: 'payment_required', approvedAt: new Date(), approvedBy: admin._id, paymentDeadline: deadline, assignedTeams: chosen.map((t) => t._id) },
      $push: { history: entry('payment_required', 'admin', 'Approved. Teams held for 24 hours.') } },
    { returnDocument: 'after' }
  );
  if (!updated) {
    await TeamReservation.deleteMany({ _id: { $in: held.map((r) => r._id) } });
    throw new AppError('This booking was already handled by someone else.', 409, 'INVALID_STATE');
  }

  await notify([booking.company], {
    type: 'booking_approved', title: 'Booking approved: payment required',
    message: `${booking.code} was approved. Pay the 50% down payment (${booking.downPaymentAmount.toLocaleString('en-PH')} PHP) within 24 hours to confirm your event.`, booking: booking._id,
  });
  return updated;
}

async function rejectBooking(bookingId, admin, reason) {
  const updated = await Booking.findOneAndUpdate(
    { _id: bookingId, status: 'pending_approval' },
    { $set: { status: 'rejected', rejectedAt: new Date(), rejectedBy: admin._id, rejectionReason: reason },
      $push: { history: entry('rejected', 'admin', reason) } },
    { returnDocument: 'after' }
  );
  if (!updated) {
    if (!(await Booking.exists({ _id: bookingId }))) throw new AppError('Booking not found.', 404, 'NOT_FOUND');
    throw new AppError('Only a booking that is pending approval can be rejected.', 409, 'INVALID_STATE');
  }
  await notify([updated.company], { type: 'booking_rejected', title: 'Booking rejected', message: `${updated.code} was rejected: ${reason}`, booking: updated._id });
  return updated;
}

// ---------- 24-hour window ----------
// Only bookings still waiting for a payment can expire. A booking whose payment is UNDER REVIEW
// keeps its hold, and a Confirmed booking is never touched.
async function expireOverdue() {
  const now = new Date();
  const overdue = await Booking.find({ status: 'payment_required', paymentDeadline: { $lt: now } }).select('_id');
  for (const { _id } of overdue) {
    const expired = await Booking.findOneAndUpdate(
      { _id, status: 'payment_required', paymentDeadline: { $lt: now } },
      { $set: { status: 'payment_expired', expiredAt: now }, $push: { history: entry('payment_expired', 'system', 'The 24-hour payment window ended. Teams released.') } },
      { returnDocument: 'after' }
    );
    if (!expired) continue;
    await releaseReservations(_id);
    await notify([expired.company], {
      type: 'booking_expired', title: 'Payment expired',
      message: `${expired.code} expired because the down payment was not received within 24 hours. You can create a new booking request.`, booking: _id,
    });
  }
  await TeamReservation.deleteMany({ status: 'held', heldUntil: { $lt: now } }); // safety net

  const lateFinal = await Booking.find({ status: 'completed_pending_final', finalPaymentDueAt: { $lt: now } }).select('_id');
  for (const { _id } of lateFinal) {
    if (await Payment.exists({ booking: _id, type: 'final', status: 'pending' })) continue;
    const late = await Booking.findOneAndUpdate(
      { _id, status: 'completed_pending_final', finalPaymentDueAt: { $lt: now } },
      { $set: { status: 'payment_overdue' }, $push: { history: entry('payment_overdue', 'system', 'The final payment was not received by its due date.') } },
      { returnDocument: 'after' }
    );
    if (!late) continue;
    await notify([late.company], { type: 'payment_overdue', title: 'Payment overdue', message: `${late.code}: the final balance of ${late.finalAmountDue.toLocaleString('en-PH')} PHP is overdue. New bookings are on hold until it is paid.`, booking: _id });
    await notifyAdmins({ type: 'payment_overdue', title: 'Payment overdue', message: `${late.code} has an overdue final balance.`, booking: _id });
  }
  return overdue.length + lateFinal.length;
}

// ---------- Down payment (50%) ----------
async function submitDownPayment(user, bookingId, { method, referenceNumber }, receipt) {
  const booking = await Booking.findById(bookingId);
  if (!booking) throw new AppError('Booking not found.', 404, 'NOT_FOUND');
  if (String(booking.company) !== String(user._id)) throw new AppError('You do not have access to this booking.', 403, 'FORBIDDEN');
  if (booking.status === 'payment_verification') throw new AppError('Your payment is already under review.', 409, 'INVALID_STATE');
  if (booking.status !== 'payment_required') throw new AppError('This booking is not waiting for a down payment.', 409, 'INVALID_STATE');
  if (booking.paymentDeadline < new Date()) throw new AppError('The 24-hour payment window has ended.', 409, 'PAYMENT_WINDOW_CLOSED');

  if (await Payment.exists({ method, referenceNumber, status: { $ne: 'rejected' } })) {
    throw new AppError('That reference number was already used for another payment.', 409, 'REFERENCE_USED');
  }

  const claimed = await Booking.findOneAndUpdate(
    { _id: booking._id, status: 'payment_required', paymentDeadline: { $gte: new Date() } },
    { $set: { status: 'payment_verification' }, $push: { history: entry('payment_verification', 'user', 'Down payment submitted') } },
    { returnDocument: 'after' }
  );
  if (!claimed) throw new AppError('This booking can no longer accept a payment.', 409, 'INVALID_STATE');

  let payment;
  try {
    payment = await Payment.create({
      booking: booking._id, type: 'down', amount: booking.downPaymentAmount, method, referenceNumber,
      receipt: { path: receipt.rel, mimeType: receipt.mimetype, originalName: receipt.originalname, size: receipt.size },
      submittedBy: user._id,
    });
  } catch (err) {
    await Booking.updateOne({ _id: booking._id }, { $set: { status: 'payment_required' }, $pop: { history: 1 } });
    throw err;
  }
  await pauseHold(booking._id); // the hold cannot lapse while Admin is reviewing
  await notifyAdmins({ type: 'payment_submitted', title: 'Payment to verify', message: `${booking.code}: a down payment was submitted.`, booking: booking._id });
  return payment;
}

async function verifyPayment(paymentId, admin) {
  const payment = await Payment.findOneAndUpdate(
    { _id: paymentId, type: 'down', status: 'pending' },
    { $set: { status: 'verified', reviewedBy: admin._id, reviewedAt: new Date() } },
    { returnDocument: 'after' }
  );
  if (!payment) {
    if (!(await Payment.exists({ _id: paymentId }))) throw new AppError('Payment not found.', 404, 'NOT_FOUND');
    throw new AppError('This payment was already reviewed.', 409, 'INVALID_STATE');
  }
  const booking = await Booking.findOneAndUpdate(
    { _id: payment.booking, status: 'payment_verification' },
    { $set: { status: 'confirmed', confirmedAt: new Date(), 'operations.checklist': DEFAULT_CHECKLIST.map((label) => ({ label, done: false })) }, $push: { history: entry('confirmed', 'admin', 'Down payment verified. Teams locked.') } },
    { returnDocument: 'after' }
  );
  if (!booking) throw new AppError('The booking is not waiting for verification.', 409, 'INVALID_STATE');
  await lockReservations(booking._id); // teams are now locked for this event
  await notify([booking.company], {
    type: 'booking_confirmed', title: 'Booking confirmed',
    message: `${booking.code} is confirmed. Your down payment was verified and your teams are reserved.`, booking: booking._id,
  });
  return { payment, booking };
}

async function rejectPayment(paymentId, admin, reason) {
  const payment = await Payment.findOneAndUpdate(
    { _id: paymentId, type: 'down', status: 'pending' },
    { $set: { status: 'rejected', rejectionReason: reason, reviewedBy: admin._id, reviewedAt: new Date() } },
    { returnDocument: 'after' }
  );
  if (!payment) {
    if (!(await Payment.exists({ _id: paymentId }))) throw new AppError('Payment not found.', 404, 'NOT_FOUND');
    throw new AppError('This payment was already reviewed.', 409, 'INVALID_STATE');
  }
  const booking = await Booking.findOne({ _id: payment.booking, status: 'payment_verification' });
  if (!booking) throw new AppError('The booking is not waiting for verification.', 409, 'INVALID_STATE');

  if (booking.paymentDeadline >= new Date()) {
    // The user may pay again, but only until the ORIGINAL deadline.
    await Booking.updateOne({ _id: booking._id }, { $set: { status: 'payment_required' }, $push: { history: entry('payment_required', 'admin', `Payment rejected: ${reason}`) } });
    await resumeHold(booking._id, booking.paymentDeadline);
    await notify([booking.company], { type: 'payment_rejected', title: 'Payment rejected', message: `${booking.code}: your payment was rejected (${reason}). You can submit it again before the original deadline.`, booking: booking._id });
  } else {
    // The window already ended while Admin was reviewing: nothing is left to pay into.
    await Booking.updateOne({ _id: booking._id }, { $set: { status: 'payment_expired', expiredAt: new Date() }, $push: { history: entry('payment_expired', 'admin', `Payment rejected after the deadline: ${reason}`) } });
    await releaseReservations(booking._id);
    await notify([booking.company], { type: 'booking_expired', title: 'Payment expired', message: `${booking.code}: your payment was rejected (${reason}) and the 24-hour window has ended. You can create a new booking request.`, booking: booking._id });
  }
  return { payment, booking: await Booking.findById(booking._id) };
}

// ---------- Final payment (remaining 50% + approved damage) ----------
async function submitFinalPayment(user, bookingId, { method, referenceNumber }, receipt) {
  const booking = await Booking.findById(bookingId);
  if (!booking) throw new AppError('Booking not found.', 404, 'NOT_FOUND');
  if (String(booking.company) !== String(user._id)) throw new AppError('You do not have access to this booking.', 403, 'FORBIDDEN');
  if (!['completed_pending_final', 'payment_overdue'].includes(booking.status)) throw new AppError('This booking is not waiting for a final payment.', 409, 'INVALID_STATE');
  if (booking.finalAmountDue === undefined || booking.finalAmountDue === null) {
    throw new AppError('Your final balance is still being prepared. The event inspection is not finished yet.', 409, 'FINAL_NOT_READY');
  }
  if (await Payment.exists({ booking: booking._id, type: 'final', status: 'pending' })) throw new AppError('Your payment is already under review.', 409, 'INVALID_STATE');
  if (await Payment.exists({ method, referenceNumber, status: { $ne: 'rejected' } })) throw new AppError('That reference number was already used for another payment.', 409, 'REFERENCE_USED');

  const payment = await Payment.create({
    booking: booking._id, type: 'final', amount: booking.finalAmountDue, method, referenceNumber,
    receipt: { path: receipt.rel, mimeType: receipt.mimetype, originalName: receipt.originalname, size: receipt.size }, submittedBy: user._id,
  });
  await Booking.updateOne({ _id: booking._id }, { $push: { history: entry(booking.status, 'user', 'Final payment submitted') } });
  await notifyAdmins({ type: 'payment_submitted', title: 'Final payment to verify', message: `${booking.code}: a final payment was submitted.`, booking: booking._id });
  return payment;
}

async function verifyFinalPayment(paymentId, admin) {
  const payment = await Payment.findOneAndUpdate({ _id: paymentId, type: 'final', status: 'pending' }, { $set: { status: 'verified', reviewedBy: admin._id, reviewedAt: new Date() } }, { returnDocument: 'after' });
  if (!payment) throw new AppError('This payment was already reviewed.', 409, 'INVALID_STATE');
  const booking = await Booking.findOneAndUpdate(
    { _id: payment.booking, status: { $in: ['completed_pending_final', 'payment_overdue'] } },
    { $set: { status: 'fully_paid', finalPaidAt: new Date() }, $push: { history: entry('fully_paid', 'admin', 'Final payment verified. Event fully paid.') } },
    { returnDocument: 'after' }
  );
  if (!booking) throw new AppError('The booking is not waiting for a final payment.', 409, 'INVALID_STATE');
  await notify([booking.company], { type: 'booking_completed', title: 'Event completed', message: `${booking.code} is fully paid. Thank you for choosing EventHub.`, booking: booking._id });
  return { payment, booking };
}

async function rejectFinalPayment(paymentId, admin, reason) {
  const payment = await Payment.findOneAndUpdate({ _id: paymentId, type: 'final', status: 'pending' }, { $set: { status: 'rejected', rejectionReason: reason, reviewedBy: admin._id, reviewedAt: new Date() } }, { returnDocument: 'after' });
  if (!payment) throw new AppError('This payment was already reviewed.', 409, 'INVALID_STATE');
  const booking = await Booking.findById(payment.booking);
  await notify([booking.company], { type: 'payment_rejected', title: 'Final payment rejected', message: `${booking.code}: your final payment was rejected (${reason}). You can submit it again.`, booking: booking._id });
  return { payment, booking };
}

// ---------- Cancellation ----------
// The 50% down payment is NON-REFUNDABLE once the booking is confirmed (kept as revenue).
async function cancelBooking(actor, bookingId, reason) {
  const booking = await Booking.findById(bookingId);
  if (!booking) throw new AppError('Booking not found.', 404, 'NOT_FOUND');
  const isAdmin = actor.role === 'admin';
  if (!isAdmin && String(booking.company) !== String(actor._id)) throw new AppError('You do not have access to this booking.', 403, 'FORBIDDEN');
  if (booking.status === 'payment_verification') throw new AppError('A payment is under review. It must be verified or rejected first.', 409, 'INVALID_STATE');
  if (!['pending_approval', 'payment_required', 'confirmed'].includes(booking.status)) throw new AppError('This booking can no longer be cancelled.', 409, 'INVALID_STATE');
  if (booking.status === 'confirmed' && !isAdmin && todayManila() >= booking.date) throw new AppError('A confirmed event can only be cancelled before its date.', 409, 'INVALID_STATE');
  if (isAdmin && (!reason || reason.trim().length < 3)) throw new AppError('Give a reason for cancelling this booking.', 422, 'REASON_REQUIRED');

  const note = booking.status === 'confirmed' ? `Cancelled${reason ? `: ${reason}` : ''}. The 50% down payment is non-refundable.` : `Cancelled${reason ? `: ${reason}` : ''}`;
  const updated = await Booking.findOneAndUpdate(
    { _id: booking._id, status: booking.status },
    { $set: { status: 'cancelled', cancelledAt: new Date(), cancelledByRole: isAdmin ? 'admin' : 'user', cancellationReason: reason || undefined, 'operations.equipment': [], 'operations.ready': false },
      $unset: { 'operations.venue': '', 'operations.venueName': '' }, $push: { history: entry('cancelled', isAdmin ? 'admin' : 'user', note) } },
    { returnDocument: 'after' }
  );
  if (!updated) throw new AppError('This booking was changed by someone else. Reload and try again.', 409, 'INVALID_STATE');
  await releaseReservations(booking._id); // teams
  await VenueReservation.deleteMany({ booking: booking._id });
  if (isAdmin) await notify([booking.company], { type: 'booking_cancelled', title: 'Booking cancelled', message: `${booking.code} was cancelled by EventHub: ${reason}`, booking: booking._id });
  else await notifyAdmins({ type: 'booking_cancelled', title: 'Booking cancelled', message: `${booking.code} was cancelled by the company.`, booking: booking._id });
  return updated;
}

// ---------- Archive (historical records; NOT the same as deactivating configuration) ----------
const ARCHIVABLE = ['fully_paid', 'rejected', 'payment_expired', 'cancelled'];

async function archiveBooking(bookingId) {
  const booking = await Booking.findById(bookingId);
  if (!booking) throw new AppError('Booking not found.', 404, 'NOT_FOUND');
  if (booking.isArchived) throw new AppError('This booking is already archived.', 409, 'INVALID_STATE');
  if (!ARCHIVABLE.includes(booking.status)) throw new AppError('Only completed (fully paid), rejected, expired or cancelled bookings can be archived.', 409, 'NOT_ARCHIVABLE');
  booking.isArchived = true;
  booking.archivedAt = new Date();
  await booking.save();
  return booking;
}

async function restoreBooking(bookingId) {
  const booking = await Booking.findById(bookingId);
  if (!booking) throw new AppError('Booking not found.', 404, 'NOT_FOUND');
  if (!booking.isArchived) throw new AppError('This booking is not archived.', 409, 'INVALID_STATE');
  booking.isArchived = false;
  booking.archivedAt = undefined;
  await booking.save();
  return booking;
}

module.exports = {
  createBooking, approveBooking, rejectBooking, expireOverdue, submitDownPayment, verifyPayment, rejectPayment, NO_TEAMS,
  submitFinalPayment, verifyFinalPayment, rejectFinalPayment, cancelBooking, archiveBooking, restoreBooking, ARCHIVABLE,
};
