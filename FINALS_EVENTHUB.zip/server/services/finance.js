const round2 = (n) => Math.round(n * 100) / 100;

// What a booking still owes (or will owe after the event).
//   due: true  = payable now      due: false = a balance that is not due yet
function owed(b) {
  if (b.status === 'payment_required') return { amount: b.downPaymentAmount, reason: 'Down payment (50%)', dueAt: b.paymentDeadline, due: true };
  if (['completed_pending_final', 'payment_overdue'].includes(b.status)) {
    const ready = b.finalAmountDue !== undefined && b.finalAmountDue !== null;
    return { amount: ready ? b.finalAmountDue : round2(b.remainingAmount + (b.damageTotal || 0)), reason: ready ? 'Final balance' : 'Final balance (being prepared)', dueAt: b.finalPaymentDueAt, due: ready };
  }
  if (['confirmed', 'ongoing'].includes(b.status)) return { amount: b.remainingAmount, reason: 'Balance after the event', dueAt: null, due: false };
  return null;
}

module.exports = { owed, round2 };
