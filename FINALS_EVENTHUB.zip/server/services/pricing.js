
const EventType = require('../models/EventType');
const Bundle = require('../models/Bundle');
const AddOn = require('../models/AddOn');
const AppError = require('../utils/AppError');
const { teamsRequired } = require('../config/rules');


function snapshotInclusions(inclusions = {}) {
  const result = {};

  for (const key of ['equipment', 'services', 'resources']) {
    result[key] = (inclusions[key] || []).map((item) => {
      if (typeof item === 'string') {
        return { name: item, quantity: 1 };
      }

      return {
        name: item.name,
        quantity: Number(item.quantity ?? 1),
      };
    });
  }

  return result;
}


async function buildQuote({ eventTypeId, attendees, bundleId, addOnIds = [] }) {
  let teams;

  try {
    teams = teamsRequired(attendees);
  } catch (e) {
    throw new AppError(e.message, 400, 'BAD_ATTENDEES');
  }

  const count = Number(attendees);

  const eventType = await EventType.findById(eventTypeId);

  if (!eventType || !eventType.isActive) {
    throw new AppError(
      'That event type is not available.',
      400,
      'EVENT_TYPE_UNAVAILABLE'
    );
  }

  const bundle = await Bundle.findById(bundleId);

  if (!bundle || String(bundle.eventType) !== String(eventType._id)) {
    throw new AppError(
      'That bundle does not belong to the selected event type.',
      400,
      'BUNDLE_MISMATCH'
    );
  }

  if (!bundle.isActive) {
    throw new AppError(
      'That bundle is no longer available.',
      400,
      'BUNDLE_INACTIVE'
    );
  }

  if (count > bundle.capacity) {
    throw new AppError(
      `${bundle.name} allows up to ${bundle.capacity} attendees. Choose a larger bundle.`,
      400,
      'BUNDLE_CAPACITY'
    );
  }

  const ids = addOnIds.map(String);

  if (new Set(ids).size !== ids.length) {
    throw new AppError(
      'An add-on was selected more than once.',
      400,
      'DUPLICATE_ADDON'
    );
  }

  const found = ids.length
    ? await AddOn.find({ _id: { $in: ids } })
    : [];

  if (found.length !== ids.length) {
    throw new AppError(
      'One of the add-ons does not exist.',
      400,
      'ADDON_NOT_FOUND'
    );
  }

  if (found.some((addOn) => !addOn.isActive)) {
    throw new AppError(
      'One of the add-ons is no longer available.',
      400,
      'ADDON_INACTIVE'
    );
  }

  const byId = new Map(found.map((addOn) => [String(addOn._id), addOn]));

  const addOns = ids.map((id) => {
    const addOn = byId.get(id);

    return {
      addOn: id,
      name: addOn.name,
      quantity: Number(addOn.quantity ?? 1),
      price: addOn.price,
    };
  });

  const addOnsTotal = addOns.reduce((sum, addOn) => sum + addOn.price, 0);

  return {
    eventType: {
      id: String(eventType._id),
      name: eventType.name,
    },
    attendees: count,
    teamsRequired: teams,
    bundle: {
      bundle: String(bundle._id),
      name: bundle.name,
      level: bundle.level,
      capacity: bundle.capacity,
      price: bundle.price,
      inclusions: snapshotInclusions(bundle.inclusions?.toObject?.() || bundle.inclusions),
    },
    addOns,
    bundleTotal: bundle.price,
    addOnsTotal,
    total: bundle.price + addOnsTotal,
  };
}

module.exports = { buildQuote };
