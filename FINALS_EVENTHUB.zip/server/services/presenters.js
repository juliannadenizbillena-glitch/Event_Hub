// What each role is allowed to see of a booking.
//   User:      own bookings, with prices and their payments.
//   Admin:     everything.
//   Organizer: event details for their branch, WITHOUT prices or payments (not needed to run an event).

const idName = (x) => (x && x._id ? { _id: x._id, name: x.name, ...(x.code ? { code: x.code } : {}) } : x);

// The Organizer does not handle money, so payment steps and payment notes are removed from the timeline.
// Only the booking's own milestones remain (and the reason a booking was rejected).
function organizerHistory(history = []) {
  let seenApproval = false;
  return history
    .filter((h) => {
      if (h.status === 'payment_verification') return false;
      if (h.status === 'payment_required') { if (seenApproval) return false; seenApproval = true; }
      return true;
    })
    .map((h) => ({ status: h.status, at: h.at, byRole: h.byRole, note: h.status === 'rejected' ? h.note : undefined }));
}

function presentSummary(b, role) {
  const out = {
    _id: b._id, code: b.code, eventName: b.eventName, status: b.status,
    eventType: idName(b.eventType), branch: idName(b.branch),  
    date: b.date, endDate: b.endDate, durationMode: b.durationMode || 'hourly',
    startTime: b.startTime, endTime: b.endTime, attendees: b.attendees, teamsRequired: b.teamsRequired,
    bundleName: b.bundle?.name, paymentDeadline: b.paymentDeadline, createdAt: b.createdAt,
  };
  if (b.company && b.company._id) out.company = { _id: b.company._id, companyName: b.company.companyName };
  if (role !== 'organizer') out.total = b.total;
  return out;
}

function presentBooking(b, role, { payments = [], teamAvailability, damageReports = [], costs, revenue } = {}) {
  const out = {
    ...presentSummary(b, role),
    company: b.company?._id
      ? { _id: b.company._id, companyName: b.company.companyName, contactName: `${b.company.firstName} ${b.company.lastName}`, contactEmail: b.company.contactEmail, phone: b.company.phone }
      : undefined,
  
bundle: {
  name: b.bundle?.name,
  level: b.bundle?.level,
  capacity: b.bundle?.capacity,
  inclusions: {
    equipment: (b.bundle?.inclusions?.equipment || []).map((item) => ({
      name: typeof item === 'string' ? item : item.name,
      quantity: typeof item === 'string' ? 1 : (item.quantity ?? 1),
    })),
    services: (b.bundle?.inclusions?.services || []).map((item) => ({
      name: typeof item === 'string' ? item : item.name,
      quantity: typeof item === 'string' ? 1 : (item.quantity ?? 1),
    })),
    resources: (b.bundle?.inclusions?.resources || []).map((item) => ({
      name: typeof item === 'string' ? item : item.name,
      quantity: typeof item === 'string' ? 1 : (item.quantity ?? 1),
    })),
  },
},
addOns: (b.addOns || []).map((a) => ({
  name: a.name,
  quantity: a.quantity ?? 1,
})),

    requirements: b.requirements,
    hasReferenceImage: !!b.referenceImage?.path,
    approvedAt: b.approvedAt, confirmedAt: b.confirmedAt, expiredAt: b.expiredAt,
    rejectionReason: b.rejectionReason,
    assignedTeams: (b.assignedTeams || []).map((t) => ({ _id: t._id, name: t.name })),
    history: role === 'organizer' ? organizerHistory(b.history) : b.history,
    isArchived: !!b.isArchived,
    cancelledAt: b.cancelledAt, cancellationReason: b.cancellationReason,
  };

  // ---- event operations ----
  const ops = b.operations || {};
  if (role === 'user') {
    out.operations = { venueName: ops.venueName, ready: !!ops.ready, startedAt: ops.startedAt, completedAt: ops.completedAt };
  } else {
    out.operations = {
      venue: ops.venue ? { _id: ops.venue, name: ops.venueName } : null,
      equipment: (ops.equipment || []).map((e) => ({ equipment: e.equipment, name: e.name, quantity: e.quantity, status: e.status })),
      checklist: (ops.checklist || []).map((c, index) => ({ index, label: c.label, done: c.done })),
      notes: ops.notes, ready: !!ops.ready, readyAt: ops.readyAt, startedAt: ops.startedAt, completedAt: ops.completedAt,
    };
  }
  out.inspection = { status: b.inspection?.status, completedAt: b.inspection?.completedAt, ...(role === 'user' ? {} : { notes: b.inspection?.notes }) };

  if (role === 'admin') {
    out.damageReports = damageReports.map((d) => ({ _id: d._id, item: d.item, description: d.description, quantity: d.quantity, details: d.details, estimatedCost: d.estimatedCost, status: d.status, approvedAmount: d.approvedAmount, reviewNote: d.reviewNote, evidenceCount: (d.evidence || []).length, createdAt: d.createdAt }));
  } else if (role === 'organizer') {
    out.damageReports = damageReports.map((d) => ({ _id: d._id, item: d.item, description: d.description, quantity: d.quantity, details: d.details, estimatedCost: d.estimatedCost, status: d.status, reviewNote: d.reviewNote, evidenceCount: (d.evidence || []).length, createdAt: d.createdAt }));
  } else {
    out.damageCharges = damageReports.filter((d) => d.status === 'approved').map((d) => ({ item: d.item, description: d.description, quantity: d.quantity, approvedAmount: d.approvedAmount }));
  }
  if (role !== 'organizer') {
    out.bundle.price = b.bundle?.price;

    out.addOns = (b.addOns || []).map((a) => ({
  name: a.name,
  quantity: a.quantity ?? 1,
  price: a.price,
}));

    Object.assign(out, {
      bundleTotal: b.bundleTotal, addOnsTotal: b.addOnsTotal, total: b.total,
      downPaymentAmount: b.downPaymentAmount, remainingAmount: b.remainingAmount,
      damageTotal: b.damageTotal || 0, finalAmountDue: b.finalAmountDue, finalPaymentDueAt: b.finalPaymentDueAt, finalPaidAt: b.finalPaidAt,
      payments: payments.map((p) => ({
        _id: p._id, type: p.type, amount: p.amount, method: p.method, referenceNumber: p.referenceNumber,
        status: p.status, rejectionReason: p.rejectionReason, submittedAt: p.createdAt, reviewedAt: p.reviewedAt,
        hasReceipt: !!p.receipt?.path,
      })),
    });
  }
  if (teamAvailability) out.teamAvailability = teamAvailability;
  // Internal costs and profit are Admin-only.
  if (role === 'admin' && costs) {
    const costTotal = costs.reduce((s, c) => s + c.amount, 0);
    out.internalCosts = { items: costs.map((c) => ({ _id: c._id, category: c.category, amount: c.amount, note: c.note, incurredOn: c.incurredOn })), total: costTotal, revenue: revenue || 0, profit: (revenue || 0) - costTotal };
  }
  return out;
}

module.exports = { presentSummary, presentBooking };
