const Notification = require('../models/Notification');
const User = require('../models/User');

// Notifications must never break the action that triggered them.
async function notify(userIds, { type, title, message, booking }) {
  try {
    const ids = [...new Set(userIds.map(String))];
    if (ids.length) await Notification.insertMany(ids.map((user) => ({ user, type, title, message, booking })));
  } catch (err) {
    console.error('Notification error:', err.message);
  }
}

async function notifyAdmins(payload) {
  try {
    const admins = await User.find({ role: 'admin', status: 'active', isArchived: false }).select('_id');
    await notify(admins.map((a) => a._id), payload);
  } catch (err) {
    console.error('Notification error:', err.message);
  }
}

module.exports = { notify, notifyAdmins };
