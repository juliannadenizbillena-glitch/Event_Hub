const Team = require('../models/Team');
const TeamReservation = require('../models/TeamReservation');
const AppError = require('../utils/AppError');
const { todayManila, addDays, bookableRange, TEAMS_PER_EVENT_TYPE } = require('../config/rules');

// A reservation blocks its team unless it is a HELD one whose payment window has lapsed
// (it is about to be released by the expiry job, so it must not block anyone).
const isStale = (r, now = new Date()) => r.status === 'held' && r.heldUntil && r.heldUntil < now;

// Teams of one branch + event type that are free on one date.
// Pending (not yet approved) bookings never hold teams; only held/locked reservations do.
async function availabilityForDate(branchId, eventTypeId, date) {
  const [teams, reservations] = await Promise.all([
    Team.find({ branch: branchId, eventType: eventTypeId, isActive: true }).sort('number'),
    TeamReservation.find({ branch: branchId, eventType: eventTypeId, date }),
  ]);
  const now = new Date();
  const busy = new Set(reservations.filter((r) => !isStale(r, now)).map((r) => String(r.team)));
  return { activeTeams: teams.length, free: teams.filter((t) => !busy.has(String(t._id))) };
}


/**
 * Returns teams that are available for EVERY date in an inclusive range.
 * A team must remain free throughout the entire event.
 */
async function availabilityForDateRange(branchId, eventTypeId, startDate, endDate) {
  const teams = await Team.find({
    branch: branchId,
    eventType: eventTypeId,
    isActive: true,
  }).sort('number');

  const dates = [];
  for (let date = startDate; date <= endDate; date = addDays(date, 1)) {
    dates.push(date);
  }

  if (dates.length === 0) {
    return { activeTeams: teams.length, free: [] };
  }

  const reservations = await TeamReservation.find({
    branch: branchId,
    eventType: eventTypeId,
    date: { $in: dates },
  });

  const now = new Date();
  const busyByDate = new Map();

  for (const reservation of reservations) {
    if (isStale(reservation, now)) continue;

    if (!busyByDate.has(reservation.date)) {
      busyByDate.set(reservation.date, new Set());
    }

    busyByDate.get(reservation.date).add(String(reservation.team));
  }

  const free = teams.filter((team) =>
    dates.every((date) =>
      !busyByDate.get(date)?.has(String(team._id))
    )
  );

  return { activeTeams: teams.length, free };
}



// Calendar for one month: available / unavailable / past (not selectable), per the flow.
async function monthAvailability({ branchId, eventTypeId, attendees, month, required }) {
  const first = `${month}-01`;
  const [y, m] = month.split('-').map(Number);
  const last = addDays(new Date(Date.UTC(y, m, 1)).toISOString().slice(0, 10), -1);
  const [teams, reservations] = await Promise.all([
    Team.countDocuments({ branch: branchId, eventType: eventTypeId, isActive: true }),
    TeamReservation.find({ branch: branchId, eventType: eventTypeId, date: { $gte: first, $lte: last } }),
  ]);
  const now = new Date();
  const busyByDate = {};
  for (const r of reservations) if (!isStale(r, now)) busyByDate[r.date] = (busyByDate[r.date] || 0) + 1;

  const { min, max } = bookableRange();
  const days = [];
  for (let date = first; date <= last; date = addDays(date, 1)) {
    if (date < min || date > max) { days.push({ date, status: 'past' }); continue; }
    const freeTeams = Math.max(teams - (busyByDate[date] || 0), 0);
    days.push({ date, status: freeTeams >= required ? 'available' : 'unavailable', freeTeams });
  }
  return { month, requiredTeams: required, activeTeams: teams, teamsPerType: TEAMS_PER_EVENT_TYPE, today: todayManila(), days };
}

// Reserve teams one by one. The unique (team, date) index rejects a team someone else just took;
// in that case everything inserted by THIS call is rolled back.

async function reserveTeams(booking, teams, heldUntil) {
  const ids = teams.map((team) => team._id);
  const startDate = booking.date;
  const endDate = booking.endDate || booking.date;

  const dates = [];
  for (let date = startDate; date <= endDate; date = addDays(date, 1)) {
    dates.push(date);
  }

  if (dates.length === 0) {
    throw new AppError('Choose a valid event date range.', 400, 'BAD_DATE_RANGE');
  }

  await TeamReservation.deleteMany({
    team: { $in: ids },
    date: { $in: dates },
    status: 'held',
    heldUntil: { $lt: new Date() },
  });

  const inserted = [];

  try {
    for (const date of dates) {
      for (const team of teams) {
        inserted.push(
          await TeamReservation.create({
            team: team._id,
            booking: booking._id,
            branch: booking.branch,
            eventType: booking.eventType,
            date,
            status: 'held',
            heldUntil,
          })
        );
      }
    }

    return inserted;
  } catch (err) {
    // Roll back every reservation inserted by this attempt.
    await TeamReservation.deleteMany({
      _id: { $in: inserted.map((reservation) => reservation._id) },
    });

    if (err.code === 11000) {
      throw new AppError(
        'Those teams were just taken by another booking. Please try again.',
        409,
        'TEAM_CONFLICT'
      );
    }

    throw err;
  }
}


const releaseReservations = (bookingId) => TeamReservation.deleteMany({ booking: bookingId });
const lockReservations = (bookingId) =>
  TeamReservation.updateMany({ booking: bookingId }, { $set: { status: 'locked' }, $unset: { heldUntil: 1 } });
const pauseHold = (bookingId) => TeamReservation.updateMany({ booking: bookingId }, { $unset: { heldUntil: 1 } });
const resumeHold = (bookingId, heldUntil) => TeamReservation.updateMany({ booking: bookingId, status: 'held' }, { $set: { heldUntil } });

module.exports = {
  availabilityForDate,
  availabilityForDateRange,
  monthAvailability,
  reserveTeams,
  releaseReservations,
  lockReservations,
  pauseHold,
  resumeHold,
};