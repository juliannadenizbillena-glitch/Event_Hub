const Branch = require('../models/Branch');
const EventType = require('../models/EventType');
const Team = require('../models/Team');
const Bundle = require('../models/Bundle');
const AddOn = require('../models/AddOn');
const Equipment = require('../models/Equipment');
const Venue = require('../models/Venue');
const { TEAMS_PER_EVENT_TYPE } = require('../config/rules');

const BRANCHES = [
  { name: 'Manila Branch', code: 'MNL' },
  { name: 'Makati Branch', code: 'MKT' },
  { name: 'Quezon City Branch', code: 'QC' },
  { name: 'Cebu Branch', code: 'CEB' },
  { name: 'Davao Branch', code: 'DVO' },
];

// Default structure for a 15-member team. Admin can edit it per event type.
const DEFAULT_STAFFING = [
  { role: 'Team Lead', count: 1 },
  { role: 'Setup Crew', count: 3 },
  { role: 'Registration Staff', count: 2 },
  { role: 'Technical Support', count: 2 },
  { role: 'Logistics', count: 2 },
  { role: 'Participant Support', count: 2 },
  { role: 'Safety Officer', count: 1 },
  { role: 'Documentation', count: 2 },
];

const EVENT_TYPES = [
  ['Workshop', 'Hands-on, practical sessions where participants learn by doing.'],
  ['Conference', 'Multi-session gatherings with speakers, tracks and large audiences.'],
  ['Seminar', 'Focused, instructor-led sessions for learning and discussion.'],
  ['Training', 'Structured skills training for teams and organizations.'],
  ['Summit', 'High-level gatherings for leaders and decision makers.'],
  ['Networking Event', 'Events designed for meeting people and building connections.'],
  ['Hackathon', 'Time-boxed build events with teams, mentors and demos.'],
  ['Career Fair', 'Employer booths and candidate meetups.'],
  ['Product Launch', 'Showcases and announcements for new products.'],
  ['Panel Discussion', 'Moderated discussions between several speakers.'],
  ['Exhibition', 'Booth and display based events open to visitors.'],
];

const BASE_INCLUSIONS = {
  equipment: [
    { name: 'Basic sound system', quantity: 1 },
    { name: 'Projector and screen', quantity: 1 },
    { name: 'Tables', quantity: 5 },
    { name: 'Chairs', quantity: 100 },
  ],
  services: [
    { name: 'Event coordination', quantity: 1 },
    { name: 'On-site registration desk', quantity: 1 },
  ],
  resources: [
    { name: 'Venue setup and teardown', quantity: 1 },
  ],
};

const BUNDLE_TEMPLATES = [
  {
    level: 1,
    tier: 'Basic',
    capacity: 100,
    price: 25000,
    blurb: 'Essential setup for events of up to 100 attendees.',
    inclusions: BASE_INCLUSIONS,
  },
  {
    level: 2,
    tier: 'Standard',
    capacity: 200,
    price: 40000,
    blurb: 'Expanded equipment and support for up to 200 attendees.',
    inclusions: {
      equipment: [
        { name: 'Basic sound system', quantity: 1 },
        { name: 'Projector and screen', quantity: 1 },
        { name: 'Tables', quantity: 10 },
        { name: 'Chairs', quantity: 200 },
        { name: 'Standard lighting', quantity: 2 },
        { name: 'Wireless microphones', quantity: 4 },
      ],
      services: [
        { name: 'Event coordination', quantity: 1 },
        { name: 'On-site registration desks', quantity: 2 },
        { name: 'Technical support staff', quantity: 2 },
      ],
      resources: [
        { name: 'Venue setup and teardown', quantity: 1 },
        { name: 'Printed signage', quantity: 4 },
      ],
    },
  },
  {
    level: 3,
    tier: 'Premium',
    capacity: 300,
    price: 65000,
    blurb: 'Professional production and expanded support for up to 300 attendees.',
    inclusions: {
      equipment: [
        { name: 'Basic sound system', quantity: 2 },
        { name: 'Projector and screen', quantity: 2 },
        { name: 'Tables', quantity: 15 },
        { name: 'Chairs', quantity: 300 },
        { name: 'Professional lighting', quantity: 4 },
        { name: 'Wireless microphones', quantity: 6 },
        { name: 'Stage platform', quantity: 1 },
      ],
      services: [
        { name: 'Event coordination', quantity: 1 },
        { name: 'On-site registration desks', quantity: 3 },
        { name: 'Technical support staff', quantity: 4 },
        { name: 'Guest assistance staff', quantity: 3 },
      ],
      resources: [
        { name: 'Venue setup and teardown', quantity: 1 },
        { name: 'Printed signage', quantity: 6 },
        { name: 'Branded backdrop', quantity: 1 },
      ],
    },
  },
  {
    level: 4,
    tier: 'Executive',
    capacity: 500,
    price: 100000,
    blurb: 'Full-scale event production and guest support for up to 500 attendees.',
    inclusions: {
      equipment: [
        { name: 'Basic sound system', quantity: 2 },
        { name: 'Projector and screen', quantity: 3 },
        { name: 'Tables', quantity: 25 },
        { name: 'Chairs', quantity: 500 },
        { name: 'Professional lighting', quantity: 6 },
        { name: 'Wireless microphones', quantity: 8 },
        { name: 'Stage platform', quantity: 2 },
        { name: 'Backup power', quantity: 1 },
      ],
      services: [
        { name: 'Event coordination', quantity: 2 },
        { name: 'On-site registration desks', quantity: 5 },
        { name: 'Technical support staff', quantity: 6 },
        { name: 'Guest assistance staff', quantity: 8 },
      ],
      resources: [
        { name: 'Venue setup and teardown', quantity: 1 },
        { name: 'Printed signage', quantity: 10 },
        { name: 'Branded backdrop', quantity: 2 },
        { name: 'VIP lounge setup', quantity: 1 },
      ],
    },
  },
];


const ADD_ONS = [
  { name: 'LED Display', quantity: 1, price: 8000 },
  { name: 'Photography', quantity: 1, price: 6000 },
  { name: 'Video Documentation', quantity: 1, price: 8000 },
  { name: 'Additional Microphones', quantity: 2, price: 1500 },
  { name: 'Sound System Upgrade', quantity: 1, price: 5000 },
  { name: 'Additional Tables & Chairs', quantity: 1, price: 2500 },
];


// ---- Equipment and venues (starter inventory per branch; Admin edits everything) ----
const EQUIPMENT = [
  ['Wireless Microphones', 'audio', 24], ['PA Sound System', 'audio', 6], ['Projector', 'video', 8], ['Projection Screen', 'video', 8],
  ['LED Display Wall', 'video', 2], ['Event Camera', 'video', 3], ['Lighting Rig', 'lighting', 4], ['Stage Platform Set', 'staging', 3],
  ['Banquet Tables', 'furniture', 60], ['Event Chairs', 'furniture', 500], ['Registration Counter', 'furniture', 6],
  ['Wi-Fi Router Kit', 'networking', 4], ['Backdrop Frame', 'signage', 6], ['First-Aid Kit', 'safety', 6],
];
const VENUE_TEMPLATES = [
  ['Grand Ballroom', 500, ['Stage', 'Sound system', 'Air conditioning', 'Backup power', 'Registration lobby']],
  ['Conference Hall', 300, ['Projector and screen', 'Air conditioning', 'Breakout area']],
  ['Function Room', 150, ['Projector and screen', 'Air conditioning', 'Pantry']],
  ['Training Room', 100, ['Whiteboards', 'Air conditioning', 'Wi-Fi']],
];

async function ensureEquipment() {
  const branches = await Branch.find({ code: { $in: BRANCHES.map((b) => b.code) } });
  const ops = [];
  for (const b of branches) {
    for (const [name, category, quantity] of EQUIPMENT) {
      ops.push({ updateOne: { filter: { branch: b._id, name }, update: { $setOnInsert: { branch: b._id, name, category, quantity, condition: 'good', status: 'available', isActive: true } }, upsert: true } });
    }
  }
  if (ops.length) await Equipment.bulkWrite(ops);
}

async function ensureVenues() {
  const branches = await Branch.find({ code: { $in: BRANCHES.map((b) => b.code) } });
  const ops = [];
  for (const b of branches) {
    const city = b.name.replace(/ Branch$/, '');
    for (const [suffix, capacity, facilities] of VENUE_TEMPLATES) {
      const name = `${city} ${suffix}`;
      ops.push({ updateOne: { filter: { branch: b._id, name }, update: { $setOnInsert: { branch: b._id, name, capacity, facilities, status: 'available', address: `${city}, Philippines`, isActive: true } }, upsert: true } });
    }
  }
  if (ops.length) await Venue.bulkWrite(ops);
}

const slugify = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

// All ensure* functions are idempotent: running them twice changes nothing.
async function ensureBranches() {
  await Branch.bulkWrite(
    BRANCHES.map((b) => ({
      updateOne: { filter: { code: b.code }, update: { $setOnInsert: { ...b, isActive: true } }, upsert: true },
    }))
  );
}



async function ensureEventTypes() {
  for (const [name, description] of EVENT_TYPES) {
    const slug = slugify(name);

    // Match by name OR slug so existing records are reused.
    const existing = await EventType.findOne({
      $or: [{ name }, { slug }],
    });

    if (existing) {
      existing.name = name;
      existing.slug = slug;
      existing.description = description;
if (!Array.isArray(existing.staffing) || existing.staffing.length === 0) {
  existing.staffing = DEFAULT_STAFFING;
}
      existing.durationModes = ['hourly', 'multi_day'];

      if (existing.isActive === undefined) {
        existing.isActive = true;
      }

      await existing.save();
    } else {
      await EventType.create({
        name,
        slug,
        description,
        staffing: DEFAULT_STAFFING,
        durationModes: ['hourly', 'multi_day'],
        isActive: true,
      });
    }
  }
}


async function ensureTeamsForBranch(branch, eventTypes) {
  const types = eventTypes || (await EventType.find());

  for (const type of types) {
    for (let n = 1; n <= TEAMS_PER_EVENT_TYPE; n += 1) {
      const name = `${type.name} Team ${n}`;

      const existing = await Team.findOne({
        name,
        branch: branch._id,
        eventType: type._id,
      });

      if (existing) {
        existing.number = n;
        existing.isActive = true;
        await existing.save();
      } else {
        await Team.create({
          branch: branch._id,
          eventType: type._id,
          number: n,
          name,
          isActive: true,
        });
      }
    }
  }
}


async function ensureBundles() {
  const types = await EventType.find();
  const ops = [];

  const toQuantityItems = (items = []) =>
    items.map((item) => ({
      name: typeof item === 'string' ? item.trim() : item.name,
      quantity: Number(
        typeof item === 'string' ? 1 : (item.quantity ?? 1)
      ),
    }));

  for (const type of types) {
    for (const template of BUNDLE_TEMPLATES) {
      const inclusions = {
        equipment: toQuantityItems(template.inclusions?.equipment),
        services: toQuantityItems(template.inclusions?.services),
        resources: toQuantityItems(template.inclusions?.resources),
      };

      ops.push({
        updateOne: {
          filter: {
            eventType: type._id,
            level: template.level,
          },
          update: {
            $set: {
              name: `${template.tier} ${type.name}`,
              description: template.blurb,
              capacity: template.capacity,
              price: template.price,
              inclusions,
            },
            $setOnInsert: {
  isActive: true,
},
            
          },
          upsert: true,
        },
      });
    }
  }

  if (ops.length) {
    await Bundle.bulkWrite(ops);
  }

  
}


async function ensureAddOns() {
  await AddOn.bulkWrite(
    ADD_ONS.map((a) => ({
      updateOne: {
        filter: { name: a.name },
        update: {
          $setOnInsert: {
            ...a,
            isActive: true,
          },
        },
        upsert: true,
      },
    }))
  );

  
  await AddOn.updateMany(
    { quantity: { $exists: false } },
    { $set: { quantity: 1 } }
  );
}


async function ensureAllSetup() {
  await ensureBranches();
  await ensureEventTypes();
  const [branches, types] = await Promise.all([Branch.find(), EventType.find()]);
  for (const branch of branches) await ensureTeamsForBranch(branch, types);
  await ensureBundles();
  await ensureAddOns();
  await ensureEquipment();
  await ensureVenues();
  return {
    branches: await Branch.countDocuments(),
    eventTypes: await EventType.countDocuments(),
    teams: await Team.countDocuments(),
    bundles: await Bundle.countDocuments(),
    addOns: await AddOn.countDocuments(),
    equipment: await Equipment.countDocuments(),
    venues: await Venue.countDocuments(),
  };
}

module.exports = { BRANCHES, EVENT_TYPES, DEFAULT_STAFFING, BUNDLE_TEMPLATES, ADD_ONS, ensureBranches, ensureEventTypes, ensureTeamsForBranch, ensureBundles, ensureAddOns, ensureEquipment, ensureVenues, ensureAllSetup };
