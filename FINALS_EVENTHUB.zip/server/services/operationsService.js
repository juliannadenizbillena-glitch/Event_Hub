const Booking = require('../models/Booking');
const Venue = require('../models/Venue');
const VenueReservation = require('../models/VenueReservation');
const Equipment = require('../models/Equipment');
const DamageReport = require('../models/DamageReport');
const AppError = require('../utils/AppError');
const { isDuplicateKey } = require('../utils/dbErrors');
const { notify, notifyAdmins } = require('./notify');
const { todayManila, FINAL_PAYMENT_DUE_DAYS } = require('../config/rules');

const entry = (status, byRole, note) => ({ status, at: new Date(), byRole, note });
const round2 = (n) => Math.round(n * 100) / 100;
const branchOf = (user) => user.branch?._id || user.branch;

const DEFAULT_CHECKLIST = [
  'Team briefing completed', 'Venue setup completed', 'Equipment checked and loaded',
  'Registration area ready', 'Technical test completed', 'Safety check completed',
];

// Organizers operate ONLY the events of their own branch. Anything else is 403.
async function loadForOrganizer(user, bookingId) {
  const booking = await Booking.findById(bookingId);
  if (!booking) throw new AppError('Booking not found.', 404, 'NOT_FOUND');
  if (user.role !== 'organizer') throw new AppError('Only the Organizer of this branch can do that.', 403, 'FORBIDDEN');
  if (String(booking.branch) !== String(branchOf(user))) throw new AppError('This event belongs to another branch.', 403, 'FORBIDDEN_BRANCH');
  return booking;
}

const need = (booking, statuses, message) => {
  if (!statuses.includes(booking.status)) throw new AppError(message, 409, 'INVALID_STATE');
};

async function ensureChecklist(booking) {
  if (booking.operations?.checklist?.length) return booking;
  await Booking.updateOne({ _id: booking._id, 'operations.checklist.0': { $exists: false } },
    { $set: { 'operations.checklist': DEFAULT_CHECKLIST.map((label) => ({ label, done: false })) } });
  return Booking.findById(booking._id);
}

// ---------- Venue ----------
async function assignVenue(user, bookingId, venueId) {
  const booking = await loadForOrganizer(user, bookingId);
  need(booking, ['confirmed'], 'A venue can only be assigned to a confirmed event that has not started.');
  const venue = await Venue.findById(venueId);
  if (!venue || !venue.isActive) throw new AppError('That venue is not available.', 400, 'BAD_VENUE');
  if (String(venue.branch) !== String(booking.branch)) throw new AppError('Choose a venue of this event\'s branch.', 400, 'BAD_VENUE');
  if (venue.status !== 'available') throw new AppError('That venue is under maintenance.', 409, 'VENUE_UNAVAILABLE');
  if (venue.capacity < booking.attendees) {
    throw new AppError(`${venue.name} holds ${venue.capacity} people, but this event has ${booking.attendees} attendees.`, 400, 'VENUE_TOO_SMALL');
  }
  if (String(booking.operations?.venue) === String(venue._id)) return booking;

  try {
    await VenueReservation.create({ venue: venue._id, booking: booking._id, date: booking.date });
  } catch (err) {
    if (isDuplicateKey(err)) throw new AppError(`${venue.name} is already used by another event on ${booking.date}.`, 409, 'VENUE_TAKEN');
    throw err;
  }
  await VenueReservation.deleteMany({ booking: booking._id, venue: { $ne: venue._id } }); // release the previous venue
  await Booking.updateOne({ _id: booking._id }, { $set: { 'operations.venue': venue._id, 'operations.venueName': venue.name, 'operations.ready': false } });
  return Booking.findById(booking._id);
}

// ---------- Equipment ----------
// How many of an item are free on a date = quantity owned - quantity allocated to OTHER active events that day.
async function freeEquipment(equipment, date, excludeBookingId) {
  const others = await Booking.find({
    date, status: { $in: ['confirmed', 'ongoing'] }, ...(excludeBookingId ? { _id: { $ne: excludeBookingId } } : {}),
    'operations.equipment.equipment': equipment._id,
  }).select('operations.equipment');
  const used = others.reduce((sum, b) => sum + b.operations.equipment.filter((e) => String(e.equipment) === String(equipment._id)).reduce((s, e) => s + e.quantity, 0), 0);
  return Math.max(equipment.quantity - used, 0);
}

async function setEquipment(user, bookingId, items) {
  const booking = await loadForOrganizer(user, bookingId);
  need(booking, ['confirmed'], 'Equipment can only be planned for a confirmed event that has not started.');
  const seen = new Set();
  const list = [];
  for (const it of items) {
    if (seen.has(String(it.equipment))) throw new AppError('An equipment item was listed twice.', 400, 'DUPLICATE_EQUIPMENT');
    seen.add(String(it.equipment));
    const eq = await Equipment.findById(it.equipment);
    if (!eq || !eq.isActive || eq.status !== 'available') throw new AppError('One of the equipment items is not available.', 400, 'BAD_EQUIPMENT');
    if (eq.branch && String(eq.branch) !== String(booking.branch)) throw new AppError(`${eq.name} belongs to another branch.`, 403, 'FORBIDDEN_BRANCH');
    const free = await freeEquipment(eq, booking.date, booking._id);
    if (it.quantity > free) throw new AppError(`Only ${free} of ${eq.name} ${free === 1 ? 'is' : 'are'} free on ${booking.date}.`, 409, 'EQUIPMENT_SHORTAGE');
    const prior = (booking.operations?.equipment || []).find((e) => String(e.equipment) === String(eq._id));
    list.push({ equipment: eq._id, name: eq.name, quantity: it.quantity, status: prior?.status || 'planned' });
  }
  await Booking.updateOne({ _id: booking._id }, { $set: { 'operations.equipment': list, 'operations.ready': false } });
  return Booking.findById(booking._id);
}

async function setEquipmentStatus(user, bookingId, equipmentId, status) {
  const booking = await loadForOrganizer(user, bookingId);
  need(booking, ['confirmed', 'ongoing', 'completed_pending_final'], 'Equipment usage can be recorded once the event is confirmed.');
  const list = (booking.operations?.equipment || []).map((e) => e.toObject());
  const item = list.find((e) => String(e.equipment) === String(equipmentId));
  if (!item) throw new AppError('That equipment is not planned for this event.', 404, 'NOT_FOUND');
  item.status = status;
  await Booking.updateOne({ _id: booking._id }, { $set: { 'operations.equipment': list } });
  return Booking.findById(booking._id);
}

// ---------- Preparation checklist ----------
async function setChecklistItem(user, bookingId, index, done) {
  let booking = await loadForOrganizer(user, bookingId);
  need(booking, ['confirmed'], 'The checklist can only be changed before the event starts.');
  booking = await ensureChecklist(booking);
  if (!Number.isInteger(index) || index < 0 || index >= booking.operations.checklist.length) throw new AppError('Unknown checklist item.', 404, 'NOT_FOUND');
  const set = { [`operations.checklist.${index}.done`]: !!done };
  if (!done) set['operations.ready'] = false;
  await Booking.updateOne({ _id: booking._id }, { $set: set });
  return Booking.findById(booking._id);
}

async function markReady(user, bookingId) {
  let booking = await loadForOrganizer(user, bookingId);
  need(booking, ['confirmed'], 'Only a confirmed event can be marked ready.');
  booking = await ensureChecklist(booking);
  const missing = [];
  if (!booking.operations.venue) missing.push('assign a venue');
  if (booking.operations.checklist.some((c) => !c.done)) missing.push('finish the preparation checklist');
  if (missing.length) throw new AppError(`Before marking the event ready, ${missing.join(' and ')}.`, 409, 'NOT_READY');
  await Booking.updateOne({ _id: booking._id }, { $set: { 'operations.ready': true, 'operations.readyAt': new Date() }, $push: { history: entry('confirmed', 'organizer', 'Event preparation completed') } });
  return Booking.findById(booking._id);
}

// ---------- Event day ----------
async function startEvent(user, bookingId) {
  const booking = await loadForOrganizer(user, bookingId);
  need(booking, ['confirmed'], 'Only a confirmed event can be started.');
  if (!booking.operations?.ready) throw new AppError('Mark the preparation as complete before starting the event.', 409, 'NOT_READY');
  if (todayManila() < booking.date) throw new AppError(`The event can only be started on or after its date (${booking.date}).`, 409, 'EVENT_NOT_TODAY');
  const updated = await Booking.findOneAndUpdate(
    { _id: booking._id, status: 'confirmed' },
    { $set: { status: 'ongoing', 'operations.startedAt': new Date() }, $push: { history: entry('ongoing', 'organizer', 'Event started') } },
    { returnDocument: 'after' }
  );
  if (!updated) throw new AppError('The event was already started.', 409, 'INVALID_STATE');
  await notify([booking.company], { type: 'event_started', title: 'Your event has started', message: `${booking.code}: ${booking.eventName} is now ongoing.`, booking: booking._id });
  return updated;
}

async function completeEvent(user, bookingId) {
  const booking = await loadForOrganizer(user, bookingId);
  need(booking, ['ongoing'], 'Only an ongoing event can be completed.');
  const updated = await Booking.findOneAndUpdate(
    { _id: booking._id, status: 'ongoing' },
    { $set: { status: 'completed_pending_final', 'operations.completedAt': new Date(), 'inspection.status': 'pending' },
      $push: { history: entry('completed_pending_final', 'organizer', 'Event completed. Inspection started.') } },
    { returnDocument: 'after' }
  );
  if (!updated) throw new AppError('The event was already completed.', 409, 'INVALID_STATE');
  await notify([booking.company], { type: 'event_completed', title: 'Your event is complete', message: `${booking.code}: the event is complete. EventHub is inspecting equipment and property before the final balance is issued.`, booking: booking._id });
  return updated;
}

// ---------- Damage ----------
async function submitDamageReport(user, bookingId, body, files = []) {
  const booking = await loadForOrganizer(user, bookingId);
  if (booking.status !== 'completed_pending_final' || booking.inspection?.status !== 'pending') {
    throw new AppError('Damage can only be reported after the event is completed and before the inspection is finished.', 409, 'INVALID_STATE');
  }
  const report = await DamageReport.create({
    booking: booking._id, reportedBy: user._id, item: body.item, description: body.description, quantity: body.quantity,
    details: body.details || undefined, estimatedCost: body.estimatedCost,
    evidence: files.map((f) => ({ path: f.rel, mimeType: f.mimetype, originalName: f.originalname, size: f.size })),
  });
  await notifyAdmins({ type: 'damage_reported', title: 'Damage report to review', message: `${booking.code}: ${report.item} (est. ${report.estimatedCost.toLocaleString('en-PH')} PHP).`, booking: booking._id });
  return report;
}

// The final balance is issued once the inspection is finished AND every damage report has been reviewed.
async function refreshFinalBalance(bookingId) {
  const booking = await Booking.findById(bookingId);
  if (!booking || booking.status !== 'completed_pending_final' || booking.inspection?.status !== 'completed') return booking;
  if (await DamageReport.countDocuments({ booking: booking._id, status: 'pending' })) return booking;
  const approved = await DamageReport.find({ booking: booking._id, status: 'approved' });
  const damageTotal = round2(approved.reduce((s, r) => s + r.approvedAmount, 0));
  const firstTime = booking.finalAmountDue === undefined || booking.finalAmountDue === null;
  const due = booking.finalPaymentDueAt || new Date(Date.now() + FINAL_PAYMENT_DUE_DAYS * 86400000);
  const updated = await Booking.findOneAndUpdate({ _id: booking._id }, { $set: { damageTotal, finalAmountDue: round2(booking.remainingAmount + damageTotal), finalPaymentDueAt: due } }, { returnDocument: 'after' });
  if (firstTime) {
    await notify([booking.company], {
      type: 'final_payment_required', title: 'Final payment required',
      message: `${booking.code}: remaining balance ${booking.remainingAmount.toLocaleString('en-PH')} PHP${damageTotal ? ` + approved damage ${damageTotal.toLocaleString('en-PH')} PHP` : ''} = ${updated.finalAmountDue.toLocaleString('en-PH')} PHP. Please pay before ${due.toISOString().slice(0, 10)}.`,
      booking: booking._id,
    });
  }
  return updated;
}

async function finishInspection(user, bookingId, notes) {
  const booking = await loadForOrganizer(user, bookingId);
  need(booking, ['completed_pending_final'], 'The inspection can only be finished after the event is completed.');
  if (booking.inspection?.status === 'completed') throw new AppError('The inspection was already finished.', 409, 'INVALID_STATE');
  await Booking.updateOne({ _id: booking._id }, { $set: { 'inspection.status': 'completed', 'inspection.completedAt': new Date(), 'inspection.notes': notes || undefined }, $push: { history: entry('completed_pending_final', 'organizer', 'Inspection finished') } });
  const pending = await DamageReport.countDocuments({ booking: booking._id, status: 'pending' });
  if (pending) await notifyAdmins({ type: 'damage_review', title: 'Damage reports waiting', message: `${booking.code}: ${pending} damage report(s) must be reviewed before the final balance can be issued.`, booking: booking._id });
  return refreshFinalBalance(booking._id);
}

async function reviewDamage(admin, reportId, { decision, approvedAmount, note }) {
  const report = await DamageReport.findById(reportId);
  if (!report) throw new AppError('Damage report not found.', 404, 'NOT_FOUND');
  if (report.status !== 'pending') throw new AppError('This damage report was already reviewed.', 409, 'INVALID_STATE');
  const booking = await Booking.findById(report.booking);
  if (!booking || booking.status !== 'completed_pending_final') throw new AppError('The booking is no longer open for damage review.', 409, 'INVALID_STATE');

  const set = { reviewedBy: admin._id, reviewedAt: new Date() };
  if (decision === 'approve') {
    const amount = approvedAmount === undefined || approvedAmount === null ? report.estimatedCost : Number(approvedAmount);
    if (!(amount > 0) || amount > 10000000) throw new AppError('Enter an approved amount between 1 and 10,000,000.', 422, 'BAD_AMOUNT');
    Object.assign(set, { status: 'approved', approvedAmount: round2(amount), reviewNote: note || undefined });
  } else {
    if (!note || note.trim().length < 3) throw new AppError('Give a reason for rejecting this damage report.', 422, 'REASON_REQUIRED');
    Object.assign(set, { status: 'rejected', reviewNote: note.trim() });
  }
  const updated = await DamageReport.findOneAndUpdate({ _id: report._id, status: 'pending' }, { $set: set }, { returnDocument: 'after' });
  if (!updated) throw new AppError('This damage report was already reviewed.', 409, 'INVALID_STATE');
  await notify([report.reportedBy], { type: `damage_${updated.status}`, title: `Damage report ${updated.status}`, message: `${booking.code}: ${updated.item} was ${updated.status}${updated.reviewNote ? ` (${updated.reviewNote})` : ''}.`, booking: booking._id });
  await refreshFinalBalance(booking._id);
  return updated;
}

module.exports = {
  DEFAULT_CHECKLIST, loadForOrganizer, ensureChecklist, freeEquipment, assignVenue, setEquipment, setEquipmentStatus,
  setChecklistItem, markReady, startEvent, completeEvent, submitDamageReport, finishInspection, reviewDamage, refreshFinalBalance,
};
