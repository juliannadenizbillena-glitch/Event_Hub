const Booking = require('../models/Booking');
const Payment = require('../models/Payment');
const InternalCost = require('../models/InternalCost');
const DamageReport = require('../models/DamageReport');
const { owed, round2 } = require('./finance');

const EVENT = ['confirmed', 'ongoing', 'completed_pending_final', 'payment_overdue', 'fully_paid'];

const bump = (map, key, label, add) => {
  const row = (map[key] ||= { key, label, events: 0, attendees: 0, revenue: 0, costs: 0 });
  Object.entries(add).forEach(([k, v]) => { row[k] += v; });
};

// Admin report. Filters: event date range, branch, event type, status. Archived bookings are INCLUDED:
// archiving hides a record from daily lists, it never removes it from the books.
async function buildReport({ from, to, branch, eventType, status }) {
  const filter = {};
  if (from || to) filter.date = { ...(from ? { $gte: from } : {}), ...(to ? { $lte: to } : {}) };
  if (branch) filter.branch = branch;
  if (eventType) filter.eventType = eventType;
  if (status) filter.status = status;

  const bookings = await Booking.find(filter).populate('eventType', 'name').populate('branch', 'name').populate('company', 'companyName').sort({ date: 1 });
  const ids = bookings.map((b) => b._id);
  const [payments, costs, damage] = await Promise.all([
    Payment.find({ booking: { $in: ids }, status: 'verified' }),
    InternalCost.find({ booking: { $in: ids } }),
    DamageReport.find({ booking: { $in: ids }, status: 'approved' }),
  ]);
  const paidBy = {}; const costBy = {};
  payments.forEach((p) => { paidBy[p.booking] = (paidBy[p.booking] || 0) + p.amount; });
  costs.forEach((c) => { costBy[c.booking] = (costBy[c.booking] || 0) + c.amount; });

  const byStatus = {};
  const byType = {}; const byBranch = {}; const byMonth = {}; const teams = {};
  let attendees = 0; let outstandingDue = 0; let outstandingUpcoming = 0; let overdueAmount = 0; let overdueCount = 0;
  const rows = [];

  for (const b of bookings) {
    byStatus[b.status] = (byStatus[b.status] || 0) + 1;
    const revenue = paidBy[b._id] || 0;
    const cost = costBy[b._id] || 0;
    const o = owed(b);
    if (o) { if (o.due) outstandingDue += o.amount; else outstandingUpcoming += o.amount; }
    if (b.status === 'payment_overdue') { overdueCount += 1; overdueAmount += o.amount; }

    const isEvent = EVENT.includes(b.status);
    if (isEvent) {
      attendees += b.attendees;
      const add = { events: 1, attendees: b.attendees, revenue, costs: cost };
      bump(byType, b.eventType?.name, b.eventType?.name, add);
      bump(byBranch, b.branch?.name, b.branch?.name, add);
      bump(byMonth, b.date.slice(0, 7), b.date.slice(0, 7), add);
      const tk = `${b.branch?.name} | ${b.eventType?.name}`;
      (teams[tk] ||= { branch: b.branch?.name, eventType: b.eventType?.name, events: 0, teamsUsed: 0 });
      teams[tk].events += 1; teams[tk].teamsUsed += b.teamsRequired;
      rows.push({ code: b.code, eventName: b.eventName, company: b.company?.companyName, branch: b.branch?.name, eventType: b.eventType?.name, date: b.date, attendees: b.attendees, status: b.status, total: b.total, damage: b.damageTotal || 0, collected: round2(revenue), costs: round2(cost), profit: round2(revenue - cost) });
    }
  }

  const sum = (list, pick) => round2(list.reduce((s, x) => s + pick(x), 0));
  const costByCategory = {};
  costs.forEach((c) => { costByCategory[c.category] = (costByCategory[c.category] || 0) + c.amount; });
  const collected = sum(payments, (p) => p.amount);
  const costTotal = sum(costs, (c) => c.amount);

  return {
    filters: { from: from || null, to: to || null, branch: branch || null, eventType: eventType || null, status: status || null },
    totals: { bookings: bookings.length, events: rows.length, attendees, byStatus },
    revenue: {
      collected, downPayments: sum(payments.filter((p) => p.type === 'down'), (p) => p.amount), finalPayments: sum(payments.filter((p) => p.type === 'final'), (p) => p.amount),
      damageCharges: sum(damage, (d) => d.approvedAmount), eventRevenue: sum(rows, (r) => r.total + r.damage),
    },
    outstanding: { dueNow: round2(outstandingDue), upcoming: round2(outstandingUpcoming), total: round2(outstandingDue + outstandingUpcoming), overdue: { count: overdueCount, amount: round2(overdueAmount) } },
    events: {
      byType: Object.values(byType).sort((a, b) => b.events - a.events), byBranch: Object.values(byBranch).sort((a, b) => b.events - a.events),
      byMonth: Object.values(byMonth).sort((a, b) => a.key.localeCompare(b.key)),
    },
    teamUsage: { totalTeamAssignments: Object.values(teams).reduce((s, t) => s + t.teamsUsed, 0), rows: Object.values(teams).sort((a, b) => b.teamsUsed - a.teamsUsed) },
    costs: { total: costTotal, byCategory: Object.entries(costByCategory).map(([category, amount]) => ({ category, amount: round2(amount) })).sort((a, b) => b.amount - a.amount) },
    profit: { revenue: collected, costs: costTotal, profit: round2(collected - costTotal) }, // Revenue - Internal costs = Profit
    rows: rows.slice(0, 300),
  };
}

module.exports = { buildReport };
