const router = require('express').Router();
const rateLimit = require('express-rate-limit');
const profile = require('../controllers/profileController');
const { protect } = require('../middleware/auth');
const v = require('../middleware/validators');

router.use(protect); // every role can manage their own profile

const sensitiveLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: process.env.NODE_ENV === 'production' ? 15 : 200,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Too many attempts. Please try again later.', code: 'RATE_LIMITED' },
});

router.get('/', profile.getProfile);
router.patch('/', v.updateProfileRules, v.validate, profile.updateProfile); // phone only
router.patch('/password', sensitiveLimiter, v.changePasswordRules, v.validate, profile.changePassword);

// Email change: password re-check -> code to the NEW address -> confirm.
router.post('/email/request', sensitiveLimiter, v.emailChangeRequestRules, v.validate, profile.requestEmailChange);
router.post('/email/confirm', sensitiveLimiter, v.emailChangeConfirmRules, v.validate, profile.confirmEmailChange);
router.delete('/email/pending', profile.cancelEmailChange);
router.post('/account-email/resend', sensitiveLimiter, profile.resendAccountEmail);

module.exports = router;
