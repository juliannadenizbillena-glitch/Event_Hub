const router = require('express').Router();
const c = require('../controllers/teamController');
const { protect, authorize } = require('../middleware/auth');
const v = require('../middleware/validators');

router.use(protect);
router.get('/', authorize('admin', 'organizer'), c.list); // organizer: own branch only
router.patch('/:id/status', authorize('admin'), v.idParam, v.activeRules, v.validate, c.setStatus);
router.put('/:id/assignments', authorize('admin'), v.idParam, v.validate, c.setAssignments);

module.exports = router;
