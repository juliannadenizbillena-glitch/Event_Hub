const router = require('express').Router();
const { dashboard } = require('../controllers/dashboardController');
const { protect } = require('../middleware/auth');
const lazyExpire = require('../middleware/lazyExpire');

router.use(protect, lazyExpire);
router.get('/', dashboard);

module.exports = router;
