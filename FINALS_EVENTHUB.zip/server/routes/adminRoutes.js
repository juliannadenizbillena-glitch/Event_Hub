const router = require('express').Router();
const staff = require('../controllers/staffController');
const companies = require('../controllers/companyController');
const reports = require('../controllers/reportController');
const archive = require('../controllers/archiveController');
const op = require('../controllers/operationsController');
const lazyExpire = require('../middleware/lazyExpire');
const { protect, authorize } = require('../middleware/auth');
const v = require('../middleware/validators');

router.use(protect, authorize('admin'), lazyExpire); // everything under /api/admin is Admin-only

router.get('/staff', staff.list);
router.post('/staff', v.staffCreateRules, v.validate, staff.create);
router.patch('/staff/:id', v.idParam, v.staffUpdateRules, v.validate, staff.update);
router.patch('/staff/:id/status', v.idParam, v.staffStatusRules, v.validate, staff.setStatus);
router.post('/staff/:id/resend-invite', v.idParam, v.validate, staff.resendInvite);

// Customer companies = User accounts (view, contact details, history, deactivate/reactivate)
router.get('/companies', companies.list);
router.get('/companies/:id', v.idParam, v.validate, companies.get);
router.patch('/companies/:id/status', v.idParam, v.staffStatusRules, v.validate, companies.setStatus);

router.get('/reports', reports.report);
router.get('/archive', archive.list);
router.delete('/costs/:id', v.idParam, v.validate, op.deleteCost);

module.exports = router;
