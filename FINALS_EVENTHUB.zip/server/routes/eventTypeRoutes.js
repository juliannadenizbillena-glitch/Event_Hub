const router = require('express').Router();
const c = require('../controllers/eventTypeController');
const { protect, authorize } = require('../middleware/auth');
const v = require('../middleware/validators');

router.use(protect);
router.get('/', c.list); // read-only for Organizer and User
router.patch('/:id', authorize('admin'), v.idParam, v.eventTypeUpdateRules, v.validate, c.update);

module.exports = router;
