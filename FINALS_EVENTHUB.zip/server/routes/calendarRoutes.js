const router = require('express').Router();
const { events } = require('../controllers/calendarController');
const { protect } = require('../middleware/auth');
const lazyExpire = require('../middleware/lazyExpire');

router.use(protect, lazyExpire);
router.get('/', events);

module.exports = router;
