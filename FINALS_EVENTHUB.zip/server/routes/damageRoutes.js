const router = require('express').Router();
const op = require('../controllers/operationsController');
const { protect, authorize } = require('../middleware/auth');
const lazyExpire = require('../middleware/lazyExpire');
const v = require('../middleware/validators');

router.use(protect, lazyExpire);
router.get('/:id/evidence/:index', authorize('admin', 'organizer'), v.idParam, v.indexParam, v.validate, op.evidence);
router.post('/:id/review', authorize('admin'), v.idParam, v.damageReviewRules, v.validate, op.reviewDamage);

module.exports = router;
