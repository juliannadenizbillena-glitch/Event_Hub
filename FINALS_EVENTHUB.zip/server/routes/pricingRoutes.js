const router = require('express').Router();
const c = require('../controllers/pricingController');
const { protect } = require('../middleware/auth');
const v = require('../middleware/validators');

router.use(protect);
router.post('/quote', v.quoteRules, v.validate, c.quote);

module.exports = router;
