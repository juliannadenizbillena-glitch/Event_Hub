const router = require('express').Router();
const c = require('../controllers/bundleController');
const { protect, authorize } = require('../middleware/auth');
const v = require('../middleware/validators');

router.use(protect);
router.get('/', c.list); // Admin + Organizer: all (Organizer view only). User: active only.
router.post('/', authorize('admin'), v.bundleCreateRules, v.validate, c.create);
router.patch('/:id', authorize('admin'), v.idParam, v.bundleUpdateRules, v.validate, c.update);
router.patch('/:id/status', authorize('admin'), v.idParam, v.activeRules, v.validate, c.setStatus);

module.exports = router;
