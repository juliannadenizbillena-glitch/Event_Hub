const router = require('express').Router();
const c = require('../controllers/venueController');
const { protect, authorize } = require('../middleware/auth');
const v = require('../middleware/validators');

router.use(protect);
router.get('/', authorize('admin', 'organizer'), c.list); // Organizer: own branch only
router.post('/', authorize('admin'), v.venueRules, v.validate, c.create);
router.patch('/:id', authorize('admin'), v.idParam, v.venueRules, v.validate, c.update);
router.patch('/:id/status', authorize('admin'), v.idParam, v.activeRules, v.validate, c.setActive);

module.exports = router;
