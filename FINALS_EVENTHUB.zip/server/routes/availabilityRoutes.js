
const router = require('express').Router();
const c = require('../controllers/availabilityController');
const { protect } = require('../middleware/auth');
const lazyExpire = require('../middleware/lazyExpire');
const v = require('../middleware/validators');

router.use(protect, lazyExpire);

router.get('/', v.availabilityRules, v.validate, c.month);

module.exports = router;
