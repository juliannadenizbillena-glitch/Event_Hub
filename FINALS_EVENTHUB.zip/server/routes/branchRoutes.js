const router = require('express').Router();
const c = require('../controllers/branchController');
const { protect, authorize } = require('../middleware/auth');
const v = require('../middleware/validators');

router.use(protect);
router.get('/', c.list); // every role; non-admins get active branches only
router.post('/', authorize('admin'), v.branchCreateRules, v.validate, c.create);
router.patch('/:id', authorize('admin'), v.idParam, v.branchUpdateRules, v.validate, c.update);
router.patch('/:id/status', authorize('admin'), v.idParam, v.activeRules, v.validate, c.setStatus);

module.exports = router;
