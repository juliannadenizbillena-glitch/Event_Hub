const router = require('express').Router();
const rateLimit = require('express-rate-limit');
const auth = require('../controllers/authController');
const { protect } = require('../middleware/auth');
const v = require('../middleware/validators');

// Brute-force / spam protection on every auth endpoint.
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: process.env.NODE_ENV === 'production' ? 30 : 300,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Too many requests. Please try again later.', code: 'RATE_LIMITED' },
});
router.use(limiter);

router.post('/register', v.registerRules, v.validate, auth.register);
router.post('/verify-email', v.verifyEmailRules, v.validate, auth.verifyEmail);
router.post('/resend-code', v.resendRules, v.validate, auth.resendCode);
router.post('/login', v.loginRules, v.validate, auth.login);
router.post('/logout', auth.logout);
router.get('/me', protect, auth.me);

router.post('/forgot-password', v.emailRules, v.validate, auth.forgotPassword);
router.post('/verify-reset-code', v.verifyResetCodeRules, v.validate, auth.verifyResetCode);
router.post('/reset-password', v.resetPasswordRules, v.validate, auth.resetPassword);

module.exports = router;
