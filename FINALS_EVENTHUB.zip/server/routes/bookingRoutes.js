const router = require('express').Router();
const rateLimit = require('express-rate-limit');
const c = require('../controllers/bookingController');
const pay = require('../controllers/paymentController');
const { protect, authorize } = require('../middleware/auth');
const lazyExpire = require('../middleware/lazyExpire');
const { uploadReference, uploadReceipt, uploadDamage, verifyUpload, verifyUploads } = require('../middleware/upload');
const op = require('../controllers/operationsController');
const v = require('../middleware/validators');

const uploadLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: process.env.NODE_ENV === 'production' ? 30 : 500, standardHeaders: true, legacyHeaders: false,
  message: { message: 'Too many uploads. Please try again later.', code: 'RATE_LIMITED' },
});

router.use(protect, lazyExpire);

router.get('/terms', c.terms);
router.get('/summary', c.summary);
router.get('/', c.list); // scoped by role: User own, Organizer own branch, Admin all
router.post('/', authorize('user'), v.bookingCreateRules, v.validate, c.create);

router.get('/:id', v.idParam, v.validate, c.get);
router.post('/:id/reference-image', authorize('user'), uploadLimiter, v.idParam, uploadReference.single('referenceImage'), verifyUpload, v.validate, c.uploadReference);
router.get('/:id/reference-image', v.idParam, v.validate, c.getReferenceImage);

router.post('/:id/approve', authorize('admin'), v.idParam, v.validate, c.approve);
router.post('/:id/reject', authorize('admin'), v.idParam, v.reasonRules, v.validate, c.reject);

router.post('/:id/payments', authorize('user'), uploadLimiter, v.idParam, uploadReceipt.single('receipt'), verifyUpload, v.paymentSubmitRules, v.validate, pay.submit);

// ---- final payment (remaining balance + approved damage) ----
router.post('/:id/final-payment', authorize('user'), uploadLimiter, v.idParam, uploadReceipt.single('receipt'), verifyUpload, v.paymentSubmitRules, v.validate, pay.submitFinal);

// ---- cancellation, archive ----
router.post('/:id/cancel', authorize('user', 'admin'), v.idParam, v.cancelRules, v.validate, c.cancel);
router.post('/:id/archive', authorize('admin'), v.idParam, v.validate, c.archive);
router.post('/:id/restore', authorize('admin'), v.idParam, v.validate, c.restore);

// ---- event operations (Organizer of the booking's branch only) ----
const organizer = authorize('organizer');
router.get('/:id/operations/options', organizer, v.idParam, v.validate, op.options);
router.put('/:id/operations/venue', organizer, v.idParam, v.venueAssignRules, v.validate, op.assignVenue);
router.put('/:id/operations/equipment', organizer, v.idParam, v.equipmentPlanRules, v.validate, op.setEquipment);
router.patch('/:id/operations/equipment/:equipmentId', organizer, v.idParam, v.equipmentIdParam, v.equipmentStatusRules, v.validate, op.equipmentStatus);
router.patch('/:id/operations/checklist/:index', organizer, v.idParam, v.indexParam, v.checklistRules, v.validate, op.checklist);
router.post('/:id/operations/ready', organizer, v.idParam, v.validate, op.ready);
router.post('/:id/operations/start', organizer, v.idParam, v.validate, op.start);
router.post('/:id/operations/complete', organizer, v.idParam, v.validate, op.complete);
router.post('/:id/inspection/finish', organizer, v.idParam, v.inspectionRules, v.validate, op.finishInspection);
router.post('/:id/damage-reports', organizer, uploadLimiter, v.idParam, uploadDamage.array('evidence', 5), verifyUploads, v.damageReportRules, v.validate, op.damageReport);

// ---- internal costs (Admin only) ----
router.post('/:id/costs', authorize('admin'), v.idParam, v.costRules, v.validate, op.addCost);

module.exports = router;
