const router = require('express').Router();
const pay = require('../controllers/paymentController');
const { protect, authorize } = require('../middleware/auth');
const lazyExpire = require('../middleware/lazyExpire');
const v = require('../middleware/validators');

router.use(protect, lazyExpire);

router.get('/instructions', authorize('user', 'admin'), pay.instructions);
router.get('/:id/receipt', authorize('user', 'admin'), v.idParam, v.validate, pay.getReceipt);
router.post('/:id/verify', authorize('admin'), v.idParam, v.validate, pay.verify);
router.post('/:id/reject', authorize('admin'), v.idParam, v.reasonRules, v.validate, pay.reject);

module.exports = router;
