const router = require('express').Router();
const c = require('../controllers/equipmentController');
const { protect, authorize } = require('../middleware/auth');
const v = require('../middleware/validators');

router.use(protect);
router.get('/', authorize('admin', 'organizer'), c.list); // Organizer: own branch + shared items only
router.post('/', authorize('admin'), v.equipmentRules, v.validate, c.create);
router.patch('/:id', authorize('admin'), v.idParam, v.equipmentRules, v.validate, c.update);
router.patch('/:id/status', authorize('admin'), v.idParam, v.activeRules, v.validate, c.setActive);

module.exports = router;
