const router = require('express').Router();
const c = require('../controllers/addOnController');
const { protect, authorize } = require('../middleware/auth');
const v = require('../middleware/validators');

router.use(protect);
router.get('/', c.list);
router.post('/', authorize('admin'), v.addOnRules, v.validate, c.create);
router.patch('/:id', authorize('admin'), v.idParam, v.addOnRules, v.validate, c.update);
router.patch('/:id/status', authorize('admin'), v.idParam, v.activeRules, v.validate, c.setStatus);

module.exports = router;
