const router = require('express').Router();
const c = require('../controllers/notificationController');
const { protect } = require('../middleware/auth');
const v = require('../middleware/validators');

router.use(protect);
router.get('/', c.list);
router.post('/read-all', c.markAllRead);
router.patch('/:id/read', v.idParam, v.validate, c.markRead);

module.exports = router;
