const { isDuplicateKey } = require('../utils/dbErrors');

exports.notFound = (req, res) => {
  res.status(404).json({ message: `Route not found: ${req.method} ${req.originalUrl}`, code: 'NOT_FOUND' });
};

// eslint-disable-next-line no-unused-vars
exports.errorHandler = (err, req, res, next) => {
  let status = err.status || 500;
  let message = err.message;
  let code = err.errorCode || 'SERVER_ERROR';

  if (isDuplicateKey(err)) {
    status = 409;
    message = 'That value is already in use.';
    code = 'DUPLICATE';
  } else if (err.name === 'ValidationError' && err.errors) {
    status = 422;
    message = Object.values(err.errors).map((e) => e.message).join(', ');
    code = 'VALIDATION_ERROR';
  } else if (err.name === 'CastError') {
    status = 400;
    message = 'Invalid ID format.';
    code = 'BAD_ID';
  } else if (err.name === 'MulterError') {
    status = 400;
    message = err.code === 'LIMIT_FILE_SIZE' ? 'That file is too large (maximum 5 MB).' : 'Upload failed. Send one file in the expected field.';
    code = 'BAD_FILE';
  } else if (err.type === 'entity.parse.failed') {
    status = 400;
    message = 'Invalid JSON body.';
  }

  if (status >= 500) {
    console.error(err);
    if (process.env.NODE_ENV === 'production') message = 'Something went wrong.';
  }

  res.status(status).json({ message, code });
};
