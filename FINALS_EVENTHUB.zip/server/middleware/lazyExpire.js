const { expireOverdue } = require('../services/bookingService');

// Expire any lapsed 24-hour windows before a booking request is handled, so nobody ever sees
// stale data between runs of the background job.
module.exports = async (req, res, next) => {
  try { await expireOverdue(); } catch (err) { return next(err); }
  next();
};
