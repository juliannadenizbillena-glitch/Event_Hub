const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');
const AppError = require('../utils/AppError');

const UPLOAD_ROOT = path.resolve(process.env.UPLOAD_DIR || path.join(__dirname, '..', 'uploads'));
const MAX_BYTES = 5 * 1024 * 1024;
const EXT = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp', 'application/pdf': '.pdf' };
const IMAGES = ['image/jpeg', 'image/png', 'image/webp'];

// Files are saved under random names (never the user's file name) and are NOT served statically:
// they can only be fetched through authorised API routes.
function uploader(kind, allowed, maxFiles = 1) {
  const dir = path.join(UPLOAD_ROOT, kind);
  fs.mkdirSync(dir, { recursive: true });
  return multer({
    storage: multer.diskStorage({
      destination: dir,
      filename: (req, file, cb) => cb(null, crypto.randomBytes(16).toString('hex') + EXT[file.mimetype]),
    }),
    limits: { fileSize: MAX_BYTES, files: maxFiles },
    fileFilter: (req, file, cb) =>
      allowed.includes(file.mimetype)
        ? cb(null, true)
        : cb(new AppError(`Unsupported file type. Allowed: ${allowed.map((m) => EXT[m].slice(1).toUpperCase()).join(', ')}.`, 400, 'BAD_FILE')),
  });
}

const looksLike = (buf, mime) => {
  if (mime === 'image/jpeg') return buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
  if (mime === 'image/png') return buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
  if (mime === 'image/webp') return buf.subarray(0, 4).toString() === 'RIFF' && buf.subarray(8, 12).toString() === 'WEBP';
  if (mime === 'application/pdf') return buf.subarray(0, 4).toString() === '%PDF';
  return false;
};

// The browser-declared type is not trusted: the first bytes must match it.
const verifyUpload = (req, res, next) => {
  if (!req.file) return next();
  const fd = fs.openSync(req.file.path, 'r');
  const buf = Buffer.alloc(12);
  fs.readSync(fd, buf, 0, 12, 0);
  fs.closeSync(fd);
  if (!looksLike(buf, req.file.mimetype)) {
    fs.unlink(req.file.path, () => {});
    return next(new AppError('That file is not a valid image or PDF.', 400, 'BAD_FILE'));
  }
  req.file.rel = `${path.basename(path.dirname(req.file.path))}/${req.file.filename}`;
  next();
};

// Same signature check for a list of files (damage evidence). One bad file rejects the whole request.
const verifyUploads = (req, res, next) => {
  const files = req.files || [];
  for (const file of files) {
    const fd = fs.openSync(file.path, 'r');
    const buf = Buffer.alloc(12);
    fs.readSync(fd, buf, 0, 12, 0);
    fs.closeSync(fd);
    if (!looksLike(buf, file.mimetype)) {
      files.forEach((f) => fs.unlink(f.path, () => {}));
      return next(new AppError('One of the files is not a valid image.', 400, 'BAD_FILE'));
    }
    file.rel = `${path.basename(path.dirname(file.path))}/${file.filename}`;
  }
  next();
};

const removeFile = (rel) => { if (rel) fs.unlink(path.join(UPLOAD_ROOT, rel), () => {}); };

module.exports = {
  UPLOAD_ROOT, IMAGES, verifyUpload, verifyUploads, removeFile,
  uploadDamage: uploader('damage', IMAGES, 5),
  uploadReference: uploader('references', IMAGES),
  uploadReceipt: uploader('receipts', [...IMAGES, 'application/pdf']),
};
