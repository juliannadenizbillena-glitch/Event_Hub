const jwt = require('jsonwebtoken');
const User = require('../models/User');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const { COOKIE_NAME } = require('../utils/token');

// Requires a logged-in, verified, active account. Sets req.user.
exports.protect = asyncHandler(async (req, res, next) => {
  const header = req.headers.authorization;
  const token =
    req.cookies?.[COOKIE_NAME] || (header?.startsWith('Bearer ') ? header.slice(7) : null);

  if (!token) throw new AppError('Please log in to continue.', 401, 'NO_TOKEN');

  let decoded;
  try {
    decoded = jwt.verify(token, process.env.JWT_SECRET);
  } catch {
    throw new AppError('Your session has expired. Please log in again.', 401, 'BAD_TOKEN');
  }
  if (decoded.purpose) throw new AppError('Invalid session.', 401, 'BAD_TOKEN'); // reset tokens are not login tokens

  const user = await User.findById(decoded.id).populate('branch', 'name code isActive');
  if (!user) throw new AppError('Account no longer exists.', 401, 'NO_USER');
  if (!user.isVerified) throw new AppError('Please verify your email first.', 403, 'EMAIL_NOT_VERIFIED');
  if (user.status !== 'active' || user.isArchived) {
    throw new AppError('This account is deactivated. Contact EventHub.', 403, 'ACCOUNT_DISABLED');
  }
  // Password changed after this token was issued -> force a fresh login.
  // (millisecond precision: a session started in the same second as the change must still be refused)
  if (user.passwordChangedAt && (decoded.iatMs ?? decoded.iat * 1000) < user.passwordChangedAt.getTime()) {
    throw new AppError('Password was changed. Please log in again.', 401, 'BAD_TOKEN');
  }

  req.user = user;
  next();
});

// Role guard: router.get('/x', protect, authorize('admin'), handler)
exports.authorize = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role)) {
    return next(new AppError('You do not have permission to perform this action.', 403, 'FORBIDDEN'));
  }
  next();
};
