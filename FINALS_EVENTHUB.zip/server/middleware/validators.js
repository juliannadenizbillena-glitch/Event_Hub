const { body, param, validationResult } = require('express-validator');

const validate = (req, res, next) => {
  const result = validationResult(req);
  if (result.isEmpty()) return next();
  if (req.file) require('fs').unlink(req.file.path, () => {}); // do not keep files from rejected requests
  (req.files || []).forEach((f) => require('fs').unlink(f.path, () => {}));
  return res.status(422).json({
    message: 'Please fix the highlighted fields.',
    code: 'VALIDATION_ERROR',
    errors: result.array().map((e) => ({ field: e.path, message: e.msg })),
  });
};

const { isEventHubAddress } = require('../config/accounts');

// Email format only (any provider). `contact: true` also refuses EventHub-generated addresses:
// the real contact email must be a real inbox, never an @...eventhub.com account email.
const emailField = (field, { contact = false } = {}) => {
  let chain = body(field).trim().toLowerCase()
    .isLength({ min: 1, max: 254 }).withMessage('This field is required.').bail()
    .isEmail().withMessage('Enter a valid email address.').bail();
  if (contact) chain = chain.custom((v) => !isEventHubAddress(v)).withMessage('Use your real email address, not an EventHub account email.');
  return chain;
};

const NAME_PATTERN = /^[\p{L}\p{M}][\p{L}\p{M}\s'.-]*$/u;
const name = (field, label) =>
  body(field).trim().notEmpty().withMessage('This field is required.').bail()
    .isLength({ max: 50 }).withMessage(`${label} is too long.`).bail()
    .matches(NAME_PATTERN).withMessage(`Enter a valid ${label.toLowerCase()}.`);

const phone = () =>
  body('phone').trim()
    .notEmpty().withMessage('This field is required.').bail()
    .matches(/^09\d{9}$/)
    .withMessage('Enter exactly 11 digits starting with 09, e.g. 09XXXXXXXXX.');

const password = (field = 'password') =>
  body(field)
    .isLength({ min: 8 }).withMessage('Password must be at least 8 characters.')
    .isLength({ max: 72 }).withMessage('Password must be 72 characters or fewer.')
    .matches(/[a-z]/).withMessage('Password needs a lowercase letter.')
    .matches(/[A-Z]/).withMessage('Password needs an uppercase letter.')
    .matches(/\d/).withMessage('Password needs a number.');

const confirm = (field = 'confirmPassword', against = 'password') =>
  body(field)
    .custom((value, { req }) => typeof value === 'string' && value === req.body[against])
    .withMessage('Passwords do not match.');

const code = () =>
  body('code').trim().matches(/^\d{6}$/).withMessage('Enter the 6-digit code.');

exports.validate = validate;

exports.registerRules = [
  name('firstName', 'First name'),
  name('lastName', 'Last name'),
  body('companyName').trim().notEmpty().withMessage('This field is required.')
    .isLength({ max: 100 }).withMessage('Company name is too long.'),
  emailField('contactEmail', { contact: true }), // the REAL email: used for verification and contact only
  phone(),
  password(),
  confirm(),
];

// Login uses the generated EventHub account email. A contact email is never a login.
exports.loginRules = [
  emailField('accountEmail'),
  body('password').notEmpty().withMessage('This field is required.'),
];

exports.verifyEmailRules = [emailField('contactEmail'), code()];
exports.resendRules = [emailField('contactEmail')];
// Recovery accepts the account email OR the contact email; the code always goes to the contact email.
exports.emailRules = [emailField('email')];
exports.verifyResetCodeRules = [emailField('email'), code()];
exports.resetPasswordRules = [
  body('resetToken').notEmpty().withMessage('Reset token is required.'),
  password(),
  confirm(),
];

// Email is NOT editable here; it has its own verified flow (see emailChange rules).
exports.updateProfileRules = [
  body('phone').trim()
    .matches(/^09\d{9}$/).withMessage('Enter exactly 11 digits starting with 09, e.g. 09XXXXXXXXX.'),
];

exports.emailChangeRequestRules = [
  emailField('newContactEmail', { contact: true }),
  body('currentPassword').notEmpty().withMessage('This field is required.'),
];

exports.emailChangeConfirmRules = [code()];

exports.changePasswordRules = [
  body('currentPassword').notEmpty().withMessage('This field is required.'),
  password('newPassword'),
  confirm('confirmPassword', 'newPassword'),
];

// ---------- Step 3: branches, event types, teams, staff ----------
exports.idParam = [param('id').isMongoId().withMessage('Invalid ID.')];

exports.branchCreateRules = [
  body('name').trim().notEmpty().withMessage('Branch name is required.').isLength({ max: 60 }).withMessage('Branch name is too long.'),
  body('code').trim().toUpperCase().matches(/^[A-Z]{2,6}$/).withMessage('Code must be 2-6 letters (e.g. MNL).'),
  body('address').optional({ values: 'falsy' }).trim().isLength({ max: 200 }).withMessage('Address is too long.'),
];
exports.branchUpdateRules = [
  body('name').trim().notEmpty().withMessage('Branch name is required.').isLength({ max: 60 }).withMessage('Branch name is too long.'),
  body('address').optional({ values: 'falsy' }).trim().isLength({ max: 200 }).withMessage('Address is too long.'),
];
exports.activeRules = [body('isActive').isBoolean().withMessage('isActive must be true or false.').toBoolean()];

exports.eventTypeUpdateRules = [
  body('description').optional({ values: 'falsy' }).trim().isLength({ max: 400 }).withMessage('Description is too long.'),
  body('isActive').optional().isBoolean().withMessage('isActive must be true or false.').toBoolean(),
  body('staffing').optional().isArray({ min: 1, max: 12 }).withMessage('Add 1 to 12 team roles.'),
  body('staffing.*.role').optional().trim().notEmpty().withMessage('Every role needs a name.').isLength({ max: 40 }).withMessage('Role name is too long.'),
  body('staffing.*.count').optional().isInt({ min: 1, max: 50 }).withMessage('Each role needs 1 to 50 members.').toInt(),
  body('staffing').optional().custom((list) => {
    const names = list.map((r) => String(r.role || '').trim().toLowerCase());
    if (new Set(names).size !== names.length) throw new Error('Each role can only appear once.');
    const total = list.reduce((sum, r) => sum + Number(r.count || 0), 0);
    if (total < 1 || total > 100) throw new Error('A team must have between 1 and 100 members in total.');
    return true;
  }),
];

exports.staffCreateRules = [
  name('firstName', 'First name'),
  name('lastName', 'Last name'),
  emailField('contactEmail', { contact: true }), // the organizer's REAL email; the login email is generated
  phone(),
  body('branch').isMongoId().withMessage('Choose a branch.'),
  body('position').trim().notEmpty().withMessage('Position / role is required.').isLength({ max: 60 }).withMessage('Position is too long.'),
];
exports.staffUpdateRules = [
  name('firstName', 'First name'),
  name('lastName', 'Last name'),
  phone(),
  body('branch').isMongoId().withMessage('Choose a branch.'),
  body('position').trim().notEmpty().withMessage('Position / role is required.').isLength({ max: 60 }).withMessage('Position is too long.'),
];
exports.staffStatusRules = [body('status').isIn(['active', 'inactive']).withMessage('Status must be active or inactive.')];

// ---------- Step 4: bundles, add-ons, pricing ----------
const MAX_PRICE = 10000000;
const priceRule = () => body('price').isInt({ min: 1, max: MAX_PRICE }).withMessage(`Price must be a whole number of pesos from 1 to ${MAX_PRICE.toLocaleString('en-US')}.`).toInt();

const inclusionsRule = () => body('inclusions').custom((inc) => {
  if (inc === undefined) return true;
  if (typeof inc !== 'object' || inc === null || Array.isArray(inc)) throw new Error('Inclusions are invalid.');
  for (const key of ['equipment', 'services', 'resources']) {
    const list = inc[key] ?? [];
    if (!Array.isArray(list) || list.length > 20) throw new Error(`Add up to 20 items for ${key}.`);
    if (list.some((item) => typeof item !== 'string' || item.trim().length > 80)) throw new Error('Each included item must be text of 80 characters or less.');
  }
  return true;
});

const bundleFields = () => [
  body('name').trim().notEmpty().withMessage('Bundle name is required.').isLength({ max: 80 }).withMessage('Bundle name is too long.'),
  body('description').optional({ values: 'falsy' }).trim().isLength({ max: 400 }).withMessage('Description is too long.'),
  body('capacity').isInt({ min: 100, max: 500 }).withMessage('Capacity must be a whole number from 100 to 500 attendees.').toInt(),
  priceRule(),
  inclusionsRule(),
];

exports.bundleCreateRules = [
  body('eventType').isMongoId().withMessage('Choose an event type.'),
  body('level').isInt({ min: 1, max: 4 }).withMessage('Level must be 1 to 4.').toInt(),
  ...bundleFields(),
];
exports.bundleUpdateRules = bundleFields();

exports.addOnRules = [
  body('name').trim().notEmpty().withMessage('Add-on name is required.').isLength({ max: 80 }).withMessage('Add-on name is too long.'),
  body('description').optional({ values: 'falsy' }).trim().isLength({ max: 300 }).withMessage('Description is too long.'),
  priceRule(),
];

exports.quoteRules = [
  body('eventType').isMongoId().withMessage('Choose an event type.'),
  body('attendees').isInt({ min: 1, max: 500 }).withMessage('Attendees must be a whole number from 1 to 500.').toInt(),
  body('bundle').isMongoId().withMessage('Choose a bundle.'),
  body('addOns').optional().isArray({ max: 50 }).withMessage('Add-ons must be a list.'),
  body('addOns.*').optional().isMongoId().withMessage('Invalid add-on.'),
];

// ---------- Step 5: bookings, payments, availability ----------
const { isValidDate, isValidTime } = require('../config/rules');
const { query } = require('express-validator');

exports.bookingCreateRules = [
  body('eventName').trim().isLength({ min: 3, max: 100 }).withMessage('Event name must be 3 to 100 characters.'),
  body('eventType').isMongoId().withMessage('Choose an event type.'),
  body('attendees').isInt({ min: 1, max: 500 }).withMessage('Attendees must be a whole number from 1 to 500.').toInt(),
  body('branch').isMongoId().withMessage('Choose a branch.'),
  
  body('date')
    .custom((v) => isValidDate(v))
    .withMessage('Choose a valid event date.'),

  body('durationMode')
    .optional()
    .isIn(['hourly', 'multi_day'])
    .withMessage('Choose a valid booking duration.'),

  body('endDate')
    .optional({ values: 'falsy' })
    .custom((v, { req }) => {
      if (req.body.durationMode !== 'multi_day') return true;
      if (!isValidDate(v)) return false;
      if (!isValidDate(req.body.date)) return false;
      return v >= req.body.date;
    })
    .withMessage('Choose a valid end date on or after the start date.'),

  body('startTime')
    .custom((v) => isValidTime(v))
    .withMessage('Choose a valid start time.'),

  body('endTime').custom((v) => isValidTime(v)).withMessage('Choose a valid end time.'),
  body('bundle').isMongoId().withMessage('Choose a bundle.'),
  body('addOns').optional().isArray({ max: 50 }).withMessage('Add-ons must be a list.'),
  body('addOns.*').optional().isMongoId().withMessage('Invalid add-on.'),
  body('requirements').optional({ values: 'falsy' }).trim().isLength({ max: 1000 }).withMessage('Requirements must be 1000 characters or fewer.'),
  body('agreement').custom((v) => v === true).withMessage('You must accept the booking terms.'),
];

exports.reasonRules = [
  body('reason').trim().isLength({ min: 3, max: 300 }).withMessage('Give a reason of 3 to 300 characters.'),
];

exports.paymentSubmitRules = [
  body('method').isIn(['gcash', 'bank_transfer']).withMessage('Choose GCash or Bank Transfer.'),
  body('referenceNumber').trim().matches(/^[A-Za-z0-9-]{4,40}$/).withMessage('Enter the payment reference number (4 to 40 letters, numbers or dashes).'),
];

exports.availabilityRules = [
  query('branch').optional().isMongoId().withMessage('Choose a branch.'),
  query('eventType').isMongoId().withMessage('Choose an event type.'),
  query('attendees').isInt({ min: 1, max: 500 }).withMessage('Attendees must be a whole number from 1 to 500.'),
  query('month').matches(/^\d{4}-(0[1-9]|1[0-2])$/).withMessage('Month must look like 2026-11.'),
];

// ---------- Equipment, venues, operations, damage, costs, cancellation ----------
const { CATEGORIES: EQUIPMENT_CATEGORIES, CONDITIONS, STATUSES: EQUIPMENT_STATUSES } = require('../models/Equipment');
const { CATEGORIES: COST_CATEGORIES } = require('../models/InternalCost');
const required = 'This field is required.';

exports.equipmentRules = [
  body('name').trim().notEmpty().withMessage(required).isLength({ max: 80 }).withMessage('Name is too long.'),
  body('category').isIn(EQUIPMENT_CATEGORIES).withMessage('Select a category.'),
  body('quantity').isInt({ min: 0, max: 100000 }).withMessage('Enter a whole number of 0 or more.').toInt(),
  body('condition').isIn(CONDITIONS).withMessage('Select a condition.'),
  body('status').isIn(EQUIPMENT_STATUSES).withMessage('Select a status.'),
  body('branch').optional({ values: 'falsy' }).isMongoId().withMessage('Select a branch.'),
  body('notes').optional({ values: 'falsy' }).trim().isLength({ max: 300 }).withMessage('Notes are too long.'),
];

exports.venueRules = [
  body('branch').isMongoId().withMessage('Select a branch.'),
  body('name').trim().notEmpty().withMessage(required).isLength({ max: 80 }).withMessage('Name is too long.'),
  body('capacity').isInt({ min: 1, max: 5000 }).withMessage('Enter a whole number from 1 to 5000.').toInt(),
  body('status').isIn(['available', 'maintenance']).withMessage('Select a status.'),
  body('address').optional({ values: 'falsy' }).trim().isLength({ max: 200 }).withMessage('Address is too long.'),
  body('facilities').optional().isArray({ max: 20 }).withMessage('Facilities must be a list.'),
  body('facilities.*').optional().trim().isLength({ min: 1, max: 60 }).withMessage('Each facility must be 1 to 60 characters.'),
  body('notes').optional({ values: 'falsy' }).trim().isLength({ max: 300 }).withMessage('Notes are too long.'),
];

exports.venueAssignRules = [body('venue').isMongoId().withMessage('Select a venue.')];
exports.equipmentPlanRules = [
  body('items').isArray({ max: 40 }).withMessage('Items must be a list.'),
  body('items.*.equipment').isMongoId().withMessage('Select an equipment item.'),
  body('items.*.quantity').isInt({ min: 1, max: 100000 }).withMessage('Enter a whole number of 1 or more.').toInt(),
];
exports.equipmentStatusRules = [body('status').isIn(['planned', 'prepared', 'returned']).withMessage('Select a status.')];
exports.checklistRules = [body('done').isBoolean().withMessage('done must be true or false.').toBoolean()];
exports.inspectionRules = [body('notes').optional({ values: 'falsy' }).trim().isLength({ max: 500 }).withMessage('Notes are too long.')];

exports.damageReportRules = [
  body('item').trim().notEmpty().withMessage(required).isLength({ max: 80 }).withMessage('Item name is too long.'),
  body('description').trim().notEmpty().withMessage(required).isLength({ max: 500 }).withMessage('Description is too long.'),
  body('quantity').isInt({ min: 1, max: 10000 }).withMessage('Enter a whole number of 1 or more.').toInt(),
  body('details').optional({ values: 'falsy' }).trim().isLength({ max: 500 }).withMessage('Details are too long.'),
  body('estimatedCost').isInt({ min: 1, max: 10000000 }).withMessage('Enter a whole number of pesos (1 or more).').toInt(),
];
exports.damageReviewRules = [
  body('decision').isIn(['approve', 'reject']).withMessage('Choose approve or reject.'),
  body('approvedAmount').optional({ values: 'falsy' }).isFloat({ min: 1, max: 10000000 }).withMessage('Enter an amount between 1 and 10,000,000.').toFloat(),
  body('note').optional({ values: 'falsy' }).trim().isLength({ max: 300 }).withMessage('Note is too long.'),
];
exports.costRules = [
  body('category').isIn(COST_CATEGORIES).withMessage('Select a category.'),
  body('amount').isFloat({ min: 1, max: 100000000 }).withMessage('Enter an amount of 1 or more.').toFloat(),
  body('note').optional({ values: 'falsy' }).trim().isLength({ max: 200 }).withMessage('Note is too long.'),
  body('incurredOn').optional({ values: 'falsy' }).custom((v) => isValidDate(v)).withMessage('Enter a valid date.'),
];
exports.cancelRules = [body('reason').optional({ values: 'falsy' }).trim().isLength({ min: 3, max: 300 }).withMessage('Give a reason of 3 to 300 characters.')];
exports.indexParam = [param('index').isInt({ min: 0, max: 50 }).withMessage('Invalid item.').toInt()];
exports.equipmentIdParam = [param('equipmentId').isMongoId().withMessage('Invalid equipment.')];
