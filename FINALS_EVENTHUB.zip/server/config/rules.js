// Business rules from the EventHub flow, in one place.

const MAX_ATTENDEES = 500;
const ATTENDEES_PER_TEAM = 100;
const TEAMS_PER_EVENT_TYPE = 5; // every branch has 5 teams for every event type

// Attendees -> teams required:  1-100 = 1, 101-200 = 2, 201-300 = 3, 301-400 = 4, 401-500 = 5
function teamsRequired(attendees) {
  const n = Number(attendees);
  if (!Number.isInteger(n) || n < 1 || n > MAX_ATTENDEES) {
    throw new RangeError(`Attendees must be a whole number from 1 to ${MAX_ATTENDEES}.`);
  }
  return Math.ceil(n / ATTENDEES_PER_TEAM);
}

// ---------- Booking rules ----------
const PAYMENT_WINDOW_HOURS = 24; // after Admin approval, to pay the 50% down payment
const MIN_LEAD_DAYS = 1; // earliest bookable date = tomorrow (today and earlier are "past / not selectable")
const MAX_ADVANCE_DAYS = 365; // latest bookable date
const FINAL_PAYMENT_DUE_DAYS = 7; // after the event is completed, to pay the remaining balance (+ approved damage)
const TZ = 'Asia/Manila'; // event dates are Philippine local dates

const todayManila = () => new Date().toLocaleDateString('en-CA', { timeZone: TZ }); // YYYY-MM-DD
const addDays = (dateStr, n) => {
  const [y, m, d] = dateStr.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10);
};
const isValidDate = (s) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && addDays(s, 0) === s;
const isValidTime = (s) => typeof s === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(s);
const bookableRange = () => ({ min: addDays(todayManila(), MIN_LEAD_DAYS), max: addDays(todayManila(), MAX_ADVANCE_DAYS) });
const isSelectableDate = (s) => { const { min, max } = bookableRange(); return s >= min && s <= max; };

// 50% down payment now, the rest after the event. Works in whole cents so odd totals stay exact.
const splitPayment = (total) => {
  const cents = Math.round(Number(total) * 100);
  const down = Math.round(cents / 2);
  return { down: down / 100, remaining: (cents - down) / 100 };
};

module.exports = {
  MAX_ATTENDEES, ATTENDEES_PER_TEAM, TEAMS_PER_EVENT_TYPE, teamsRequired,
  PAYMENT_WINDOW_HOURS, FINAL_PAYMENT_DUE_DAYS, MIN_LEAD_DAYS, MAX_ADVANCE_DAYS, TZ,
  todayManila, addDays, isValidDate, isValidTime, bookableRange, isSelectableDate, splitPayment,
};
