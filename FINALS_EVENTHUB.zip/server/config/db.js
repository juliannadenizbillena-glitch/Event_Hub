const mongoose = require('mongoose');
const { prepareDatabase } = require('../services/emailMigration');
require('dotenv').config({ path: require('path').resolve(__dirname, '../.env') });


module.exports = async function connectDB() {
  await mongoose.connect(process.env.MONGO_URI);
  console.log(`MongoDB connected: ${mongoose.connection.host}/${mongoose.connection.name}`);
  await prepareDatabase(); 
};
