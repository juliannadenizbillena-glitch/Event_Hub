// Two different emails per account:
//   accountEmail : the generated EventHub LOGIN identity (e.g. juandelacruz@user.eventhub.com). Permanent.
//   contactEmail : the person's REAL email. Used only for verification, setup and notifications.
const ACCOUNT_DOMAINS = {
  user: 'user.eventhub.com',
  organizer: 'organizer.eventhub.com',
  admin: 'admin.eventhub.com',
};

// A real contact email can never be an EventHub-generated address (those cannot receive mail).
const isEventHubAddress = (email) => /@([a-z0-9-]+\.)*eventhub\.com$/i.test(String(email || '').trim());

module.exports = { ACCOUNT_DOMAINS, isEventHubAddress };
