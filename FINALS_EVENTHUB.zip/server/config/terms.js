// EventHub Booking Terms shown before a booking can be submitted (flow section 23).
module.exports = {
  version: '2026-10',
  items: [
    { title: 'Cancellation', text: 'Once the booking is confirmed, the 50% down payment is non-refundable if you cancel the event.' },
    { title: 'Damage', text: 'You are responsible for verified damage to EventHub equipment, EventHub property, venue facilities and other provided resources.' },
    { title: 'Damage fee', text: 'Approved damage charges are added to the remaining balance after the event.' },
    { title: 'Payment', text: 'You must pay the required amounts on the EventHub schedule: 50% within 24 hours of approval, and the remaining balance after the event.' },
  ],
};
