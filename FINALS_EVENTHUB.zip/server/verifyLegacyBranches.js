﻿require('dotenv').config();
const mongoose = require('mongoose');

async function main() {
  await mongoose.connect(process.env.MONGO_URI);

  const ids = [
    '6ad12159d5c8815883f826e7',
    '6ad12159d5c8815883f826e8',
    '6ad12159d5c8815883f826e6',
    '6ad12158d5c8815883f826e4',
    '6ad12158d5c8815883f826e5'
  ].map(id => new mongoose.Types.ObjectId(id));

  const rows = await mongoose.connection.db
    .collection('branches')
    .find({ _id: { $in: ids } })
    .project({ _id: 1, name: 1, code: 1, isActive: 1 })
    .toArray();

  console.log(JSON.stringify(rows, null, 2));
  console.log('Legacy branch records found:', rows.length);

  await mongoose.disconnect();
}

main().catch(async error => {
  console.error(error.message);
  await mongoose.disconnect().catch(() => {});
  process.exitCode = 1;
});
