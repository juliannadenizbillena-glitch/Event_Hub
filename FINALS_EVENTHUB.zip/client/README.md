
## Forms and validation
- Every form uses `src/hooks/useForm.js` and the rules in `src/utils/validators.js`: nothing is shown before a field is touched, a field is checked when it is left and re-checked as the person types, errors vanish the moment the value is valid, and a subtle check mark confirms valid fields. The API repeats every rule and stays authoritative.
- Password requirements are a compact live row that only appears while it helps.
- Fields carry realistic examples as placeholders (`e.g. Juan`, `e.g. 09171234567`, ...); placeholders are never saved as values.
- Messages are temporary and contextual: one-time notices (e.g. after verification) are removed from history so a refresh never replays them, success notices fade, and "Invalid email or password." appears only after a real failed login and clears as soon as the person edits a field.

## Account emails
`Login` uses the generated EventHub **account email**. The email typed at registration is the **contact email** (verification and notices only). After verification the screen shows the account email prominently (with a copy button) and it is also emailed.
