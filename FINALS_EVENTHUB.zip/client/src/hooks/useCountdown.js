import { useCallback, useEffect, useState } from 'react';

// Resend-code timer. start() restarts it; `left` counts down to 0.
export default function useCountdown(initial = 0) {
  const [left, setLeft] = useState(initial);

  useEffect(() => {
    if (left <= 0) return undefined;
    const t = setTimeout(() => setLeft((n) => n - 1), 1000);
    return () => clearTimeout(t);
  }, [left]);

  const start = useCallback((seconds = 60) => setLeft(seconds), []);
  return [left, start];
}
