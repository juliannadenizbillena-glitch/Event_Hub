import { useState } from 'react';

// Mainstream-website form behaviour:
//  - nothing is shown before the person interacts with a field (unless they try to submit)
//  - a field is checked when they leave it (blur); after that it re-checks as they type,
//    so an error disappears the moment the value becomes valid
//  - server messages stay on their field until that field is edited
export default function useForm(initial, rules = {}) {
  const [values, setValues] = useState(initial);
  const [touched, setTouched] = useState({});
  const [focused, setFocused] = useState({});
  const [serverErrors, setServerErrors] = useState({});

  const ruleError = (name, vals = values) => (rules[name] ? rules[name](vals[name], vals) || '' : '');
  const errorOf = (name) => serverErrors[name] || (touched[name] ? ruleError(name) : '');

  const setValue = (name, value) => {
    setValues((v) => ({ ...v, [name]: value }));
    setServerErrors((e) => (e[name] ? { ...e, [name]: '' } : e));
  };

  const field = (name) => {
    const error = errorOf(name);
    const value = values[name] ?? '';
    return {
      name,
      value,
      error,
      valid: !!rules[name] && !!touched[name] && !error && String(value).trim() !== '',
      onChange: (e) => setValue(name, e.target.value),
      onFocus: () => setFocused((f) => ({ ...f, [name]: true })),
      onBlur: () => { setTouched((t) => ({ ...t, [name]: true })); setFocused((f) => ({ ...f, [name]: false })); },
    };
  };

  const focusFirstError = () => requestAnimationFrame(() => document.querySelector('[aria-invalid="true"]')?.focus());

  // Marks the fields as touched (so their errors show) and returns true when all are valid.
  const validateFields = (names) => {
    setTouched((t) => ({ ...t, ...Object.fromEntries(names.map((n) => [n, true])) }));
    const ok = names.every((n) => !ruleError(n));
    if (!ok) focusFirstError();
    return ok;
  };
  const validateAll = () => validateFields(Object.keys(rules));

  return {
    values, field, setValue, validateFields, validateAll,
    isFocused: (n) => !!focused[n],
    isTouched: (n) => !!touched[n],
    setServerErrors: (errs) => setServerErrors(errs || {}),
    reset: (next = initial) => { setValues(next); setTouched({}); setFocused({}); setServerErrors({}); },
  };
}
