import { useCallback, useEffect, useState } from 'react';
import { errorMessage } from '../api/client';

// Loads data when `deps` change. reload() fetches again (e.g. after an edit).
export default function useLoad(fetcher, deps = []) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try { setData(await fetcher()); }
    catch (err) { setError(errorMessage(err)); }
    finally { setLoading(false); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  useEffect(() => { load(); }, [load]);
  return { data, loading, error, reload: load };
}
