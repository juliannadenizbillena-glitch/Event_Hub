// Client-side checks for a good form experience. The API repeats every one of them and stays authoritative.
// Messages are short on purpose.
export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
export const PHONE_RE = /^09\d{9}$/;
export const NAME_RE = /^[\p{L}\p{M}][\p{L}\p{M}\s'.-]*$/u;
const EVENTHUB_RE = /@([a-z0-9-]+\.)*eventhub\.com$/i;

export const isEventHubAddress = (v = '') => EVENTHUB_RE.test(v.trim());

export const passwordChecks = (pw = '') => [
  { label: '8+ characters', ok: pw.length >= 8 },
  { label: 'Lowercase', ok: /[a-z]/.test(pw) },
  { label: 'Uppercase', ok: /[A-Z]/.test(pw) },
  { label: 'Number', ok: /\d/.test(pw) },
];
export const passwordValid = (pw) => passwordChecks(pw).every((c) => c.ok);

const REQUIRED = 'This field is required.';
const empty = (v) => v === undefined || v === null || String(v).trim() === '';

export const rules = {
  required: (message) => (v) => (empty(v) ? message : ''),
  name: (label) => (v) => {
    if (empty(v)) return 'This field is required.';
    if (v.trim().length > 50) return `${label[0].toUpperCase()}${label.slice(1)} is too long.`;
    return NAME_RE.test(v.trim()) ? '' : `Enter a valid ${label}.`;
  },
  email: () => (v) => {
    if (empty(v)) return REQUIRED;
    return EMAIL_RE.test(v.trim()) && v.trim().length <= 254 ? '' : 'Enter a valid email address.';
  },
  // The REAL email: never an EventHub-generated address.
  contactEmail: () => (v) => {
    if (empty(v)) return REQUIRED;
    if (!EMAIL_RE.test(v.trim()) || v.trim().length > 254) return 'Enter a valid email address.';
    return isEventHubAddress(v) ? 'Use your real email address, not an EventHub account email.' : '';
  },
  phone: (v) => {
    if (empty(v)) return REQUIRED;
    return PHONE_RE.test(v.trim()) ? '' : 'Enter exactly 11 digits starting with 09, e.g. 09XXXXXXXXX.';
  },
  password: (v) => {
    if (!v) return REQUIRED;
    if (v.length > 72) return 'Use 72 characters or fewer.';
    return passwordValid(v) ? '' : 'Password does not meet the requirements.';
  },
  confirm: (against = 'password') => (v, values) => {
    if (!v) return REQUIRED;
    return v === values[against] ? '' : 'Passwords do not match.';
  },
  whole: (label, min, max) => (v) => {
    const n = Number(v);
    if (empty(v)) return REQUIRED;
    return Number.isInteger(n) && n >= min && n <= max ? '' : `Enter a whole number from ${min} to ${max}.`;
  },
};
