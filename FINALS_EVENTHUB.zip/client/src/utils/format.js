// Whole-peso amounts, e.g. 55500 -> "₱55,500"
export const peso = (n) => `₱${Number(n).toLocaleString('en-PH')}`;

// "2026-11-20" -> "Fri, Nov 20, 2026" (dates are plain Philippine calendar dates, no time zone shifts)
export const formatDate = (s) =>
  s ? new Date(`${s}T00:00:00`).toLocaleDateString('en-PH', { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' }) : '—';

// "09:00" -> "9:00 AM"
export const formatTime = (t) => {
  if (!t) return '—';
  const [h, m] = t.split(':').map(Number);
  return `${((h + 11) % 12) + 1}:${String(m).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`;
};

export const formatDateTime = (iso) =>
  iso ? new Date(iso).toLocaleString('en-PH', { dateStyle: 'medium', timeStyle: 'short' }) : '—';
