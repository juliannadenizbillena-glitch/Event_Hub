import { Eye } from 'lucide-react';

export default function PageHeader({ title, subtitle, action, viewOnly = false }) {
  return (
    <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
      <div>
        <div className="flex flex-wrap items-center gap-3">
          <h1 className="text-2xl font-extrabold text-navy sm:text-[1.7rem]">{title}</h1>
          {viewOnly && <span className="inline-flex items-center gap-1.5 rounded-full bg-mist px-3 py-1 text-xs font-semibold text-navy"><Eye size={14} /> View only</span>}
        </div>
        {subtitle && <p className="mt-1.5 max-w-2xl text-sm leading-6 text-steel">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}
