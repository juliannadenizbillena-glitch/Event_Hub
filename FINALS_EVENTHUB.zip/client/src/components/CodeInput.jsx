import { useRef } from 'react';

// Six boxes for the 6-digit code. Supports typing, backspace, arrow keys, and pasting.
export default function CodeInput({ value, onChange, disabled = false, error = false }) {
  const refs = useRef([]);
  const digits = Array.from({ length: 6 }, (_, i) => value[i] || '');

  const set = (next) => onChange(next.replace(/\D/g, '').slice(0, 6));

  const handleChange = (i, e) => {
    const d = e.target.value.replace(/\D/g, '');
    if (!d) return;
    const chars = digits.slice();
    chars[i] = d[d.length - 1];
    set(chars.join(''));
    refs.current[Math.min(i + 1, 5)]?.focus();
  };

  const handleKeyDown = (i, e) => {
    if (e.key === 'Backspace') {
      e.preventDefault();
      const chars = digits.slice();
      if (chars[i]) chars[i] = '';
      else if (i > 0) { chars[i - 1] = ''; refs.current[i - 1]?.focus(); }
      set(chars.join(''));
    } else if (e.key === 'ArrowLeft') refs.current[Math.max(i - 1, 0)]?.focus();
    else if (e.key === 'ArrowRight') refs.current[Math.min(i + 1, 5)]?.focus();
  };

  const handlePaste = (e) => {
    e.preventDefault();
    const text = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    set(text);
    refs.current[Math.min(text.length, 5)]?.focus();
  };

  return (
    <div className="flex justify-between gap-2 sm:gap-3" onPaste={handlePaste}>
      {digits.map((d, i) => (
        <input
          key={i}
          ref={(el) => (refs.current[i] = el)}
          value={d}
          inputMode="numeric"
          autoComplete={i === 0 ? 'one-time-code' : 'off'}
          maxLength={1}
          disabled={disabled}
          aria-label={`Digit ${i + 1}`}
          onChange={(e) => handleChange(i, e)}
          onKeyDown={(e) => handleKeyDown(i, e)}
          onFocus={(e) => e.target.select()}
          className={`h-14 w-full min-w-0 rounded-xl border bg-white text-center text-2xl font-semibold text-navy transition focus:border-sky focus:outline-none focus:ring-2 focus:ring-sky/40 ${error ? 'border-red-400' : d ? 'border-sky bg-mist/30' : 'border-steel/40'}`}
        />
      ))}
    </div>
  );
}
