
import { Link } from 'react-router-dom';
import { CalendarCheck } from 'lucide-react';

export default function Logo({ light = false, className = '' }) {
  return (
    <Link
      to="/"
      aria-label="EventHub home"
      className={`flex items-center gap-2.5 ${className}`}
    >
      <span className={`flex h-9 w-9 items-center justify-center rounded-xl bg-sky text-white`}>
        <CalendarCheck size={20} />
      </span>
      <span className={`text-xl font-extrabold tracking-tight ${light ? 'text-white' : 'text-navy'}`}>
        EventHub
      </span>
    </Link>
  );
}
