import { useEffect, useState } from 'react';
import { Clock } from 'lucide-react';

// Live countdown to a deadline (the 24-hour payment window). Calls onExpire once when it reaches zero.
export default function Countdown({ until, onExpire }) {
  const [left, setLeft] = useState(() => new Date(until) - Date.now());

  useEffect(() => {
    const tick = () => setLeft(new Date(until) - Date.now());
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, [until]);

  useEffect(() => { if (left <= 0) onExpire?.(); }, [left <= 0]); // eslint-disable-line react-hooks/exhaustive-deps

  if (left <= 0) return <span className="font-semibold text-red-700">Deadline passed</span>;
  const s = Math.floor(left / 1000);
  const hh = String(Math.floor(s / 3600)).padStart(2, '0');
  const mm = String(Math.floor((s % 3600) / 60)).padStart(2, '0');
  const ss = String(s % 60).padStart(2, '0');
  return <span className="inline-flex items-center gap-1.5 font-mono font-semibold text-navy"><Clock size={16} />{hh}:{mm}:{ss}</span>;
}
