import { useEffect, useRef, useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import {
  CalendarCheck,
  ChevronDown,
  LogOut,
  Menu,
  UserRound,
  X,
} from 'lucide-react';
import Logo from './Logo';
import NotificationBell from './NotificationBell';
import Footer from './Footer';
import { useAuth } from '../context/AuthContext';
import { NAV, ROLE_LABEL } from '../config/navigation';

export default function AppShell() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const profileRef = useRef(null);

  const initials =
    `${user.firstName?.[0] || ''}${user.lastName?.[0] || ''}`.toUpperCase() || 'U';

  useEffect(() => {
    const closeProfile = (event) => {
      if (profileRef.current && !profileRef.current.contains(event.target)) {
        setProfileOpen(false);
      }
    };

    document.addEventListener('mousedown', closeProfile);
    return () => document.removeEventListener('mousedown', closeProfile);
  }, []);

  const handleLogout = async () => {
    setProfileOpen(false);
    setOpen(false);
    await logout();
    navigate('/login', { replace: true });
  };

  const navigationItems = NAV[user.role].flatMap((group) => group.items);

  return (
    <div className="flex min-h-screen flex-col">
      <div className="flex flex-1">
        {open && (
          <div
            className="fixed inset-0 z-30 bg-navy/40 backdrop-blur-sm lg:hidden"
            onClick={() => setOpen(false)}
          />
        )}

        <div className="eh-shell flex min-w-0 flex-1">
          <aside
            className={`fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-mist bg-white p-4 text-navy transition-transform lg:static lg:translate-x-0 ${
              open ? 'translate-x-0' : '-translate-x-full'
            }`}
          >
            <div className="flex items-center justify-between px-2 pb-6 pt-2">
              <Logo />
              <button
                className="text-steel lg:hidden"
                onClick={() => setOpen(false)}
                aria-label="Close menu"
              >
                <X size={20} />
              </button>
            </div>

            <nav className="flex-1 overflow-y-auto">
              <ul className="space-y-1">
                {navigationItems.map(({ label, to, icon: Icon, home }) => (
                  <li key={to}>
                    <NavLink
                      to={to}
                      end={!!home}
                      onClick={() => setOpen(false)}
                      className={({ isActive }) =>
                        `eh-nav-link flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm transition ${
                          isActive
                            ? 'bg-[#F0EEFB] font-bold text-sky'
                            : 'font-medium text-steel hover:bg-mist/60 hover:text-navy'
                        }`
                      }
                    >
                      <Icon size={18} />
                      {label}
                    </NavLink>
                  </li>
                ))}
              </ul>
            </nav>

            <div className="mt-4 rounded-2xl bg-[#F4F3FC] p-4">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-white text-sky shadow-sm">
                <CalendarCheck size={18} />
              </span>
              <p className="mt-3 text-sm font-bold text-navy">EventHub</p>
              <p className="text-xs text-steel">{ROLE_LABEL[user.role]}</p>
            </div>
          </aside>

          <div className="flex min-w-0 flex-1 flex-col">
            <header className="relative z-20 flex items-center justify-between border-b border-mist bg-white px-4 py-3 sm:px-8">
              <button
                className="text-navy lg:hidden"
                onClick={() => setOpen(true)}
                aria-label="Open menu"
              >
                <Menu size={22} />
              </button>

              <p className="hidden text-sm font-medium text-steel lg:block">
                Hello, <span className="font-bold text-navy">{user.firstName}</span>
              </p>

              <div className="ml-auto flex items-center gap-3">
                <NotificationBell />

                <div className="relative" ref={profileRef}>
                  <button
                    type="button"
                    aria-label="Open profile menu"
                    aria-expanded={profileOpen}
                    onClick={() => setProfileOpen((value) => !value)}
                    className="flex items-center gap-2 rounded-full p-1.5 transition hover:bg-mist/60 sm:gap-3 sm:rounded-2xl sm:px-3"
                  >
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-sky text-sm font-bold text-white">
                      {initials}
                    </span>

                    <span className="hidden text-left leading-tight sm:block">
                      <span className="block max-w-40 truncate text-sm font-bold text-navy">
                        {user.firstName} {user.lastName}
                      </span>
                      <span className="block text-xs text-steel">
                        {ROLE_LABEL[user.role]}
                      </span>
                    </span>

                    <ChevronDown
                      size={16}
                      className={`hidden text-steel transition-transform sm:block ${
                        profileOpen ? 'rotate-180' : ''
                      }`}
                    />
                  </button>

                  {profileOpen && (
                    <div className="absolute right-0 top-full z-50 mt-2 w-52 overflow-hidden rounded-2xl border border-mist bg-white py-1 text-navy shadow-[0_20px_50px_rgba(35,35,58,0.18)]">
                      <NavLink
                        to="/profile"
                        onClick={() => setProfileOpen(false)}
                        className="flex items-center gap-3 px-4 py-3 text-sm font-medium hover:bg-mist/50"
                      >
                        <UserRound size={17} />
                        Profile
                      </NavLink>

                      <button
                        type="button"
                        onClick={handleLogout}
                        className="flex w-full items-center gap-3 px-4 py-3 text-left text-sm font-medium hover:bg-mist/50"
                      >
                        <LogOut size={17} />
                        Logout
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </header>

            <main className="eh-main flex-1 px-4 py-8 sm:px-8">
              <Outlet />
            </main>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
