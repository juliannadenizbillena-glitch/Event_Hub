import { Loader2 } from 'lucide-react';
import Alert from './Alert';

// Shows a spinner or the error; renders children once data is ready.
export default function LoadState({ loading, error, hasData, children }) {
  if (error) return <Alert type="error">{error}</Alert>;
  if (loading && !hasData) return <div className="flex justify-center py-16 text-steel"><Loader2 className="animate-spin" /></div>;
  return children;
}
