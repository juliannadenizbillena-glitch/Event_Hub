export default function Card({ title, description, icon: Icon, children, className = '' }) {
  return (
    <section className={`rounded-3xl border border-mist/70 bg-white p-6 shadow-sm ${className}`}>
      {(title || description) && (
        <header className="mb-5 flex items-start gap-3">
          {Icon && <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-mist text-sky"><Icon size={18} /></span>}
          <div>
            <h2 className="text-base font-bold text-navy">{title}</h2>
            {description && <p className="text-sm text-steel">{description}</p>}
          </div>
        </header>
      )}
      {children}
    </section>
  );
}
