
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { Bell, ChevronDown, LayoutDashboard, LogOut, Menu, UserRound, X } from 'lucide-react';
import Logo from './Logo';
import Footer from './Footer';
import Button from './Button';
import NotificationBell from './NotificationBell';
import { useAuth } from '../context/AuthContext';
import { ROLE_HOME, ROLE_LABEL } from '../config/navigation';

export default function PublicLayout({ children }) {
  const { pathname } = useLocation();
  const hideFooter = ['/login', '/register'].includes(pathname.replace(/\/+$/, ''));
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [profileOpen, setProfileOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const initials = `${user?.firstName?.[0] || ''}${user?.lastName?.[0] || ''}`.toUpperCase();

  const handleLogout = async () => {
    await logout();
    setProfileOpen(false);
    navigate('/login', { replace: true });
  };

  return (
    <div className="flex min-h-screen flex-col text-navy">
      <header className="sticky top-0 z-40 border-b border-mist bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 py-3 sm:px-8">
          <Link to="/" aria-label="EventHub home" onClick={() => setMobileOpen(false)}>
            <Logo />
          </Link>

          <nav className="absolute left-1/2 hidden -translate-x-1/2 items-center gap-5 whitespace-nowrap lg:flex">
            <Link to="/" className="text-sm font-medium text-navy hover:text-steel">Home</Link>
            <Link to="/about" className="text-sm font-medium text-navy hover:text-steel">About</Link>
            <a href="/#services" className="text-sm font-medium text-navy hover:text-steel">Services</a>
            <a href="/#how-it-works" className="text-sm font-medium text-navy hover:text-steel">How it works</a>
            <a href="/#branches" className="text-sm font-medium text-navy hover:text-steel">Branches</a>
            <Link to="/contact" className="text-sm font-medium text-navy hover:text-steel">Contact</Link>
          </nav>

          <div className="ml-auto flex items-center gap-2 sm:gap-3">
            {user ? (
              <>
                <NotificationBell />
                <div className="relative">
                  <button
                    type="button"
                    aria-label="Open profile menu"
                    aria-expanded={profileOpen}
                    onClick={() => setProfileOpen((value) => !value)}
                    className="flex items-center gap-2 rounded-full border border-mist p-1.5 pr-2 transition hover:bg-mist/30"
                  >
                    <span className="flex h-9 w-9 items-center justify-center rounded-full bg-sky text-sm font-bold text-white">
                      {initials || <UserRound size={18} />}
                    </span>
                    <span className="hidden max-w-28 text-left sm:block">
                      <span className="block truncate text-xs font-semibold text-navy">
                        {user.firstName} {user.lastName}
                      </span>
                      <span className="block text-[10px] text-steel">
                        {ROLE_LABEL[user.role]}
                      </span>
                    </span>
                    <ChevronDown size={15} className="hidden text-steel sm:block" />
                  </button>

                  {profileOpen && (
                    <>
                      <button
                        type="button"
                        aria-label="Close profile menu"
                        className="fixed inset-0 z-40 cursor-default"
                        onClick={() => setProfileOpen(false)}
                      />
                      <div className="absolute right-0 z-50 mt-2 w-56 overflow-hidden rounded-xl border border-mist bg-white py-2 shadow-xl">
                        <Link
                          to="/profile"
                          onClick={() => setProfileOpen(false)}
                          className="flex items-center gap-3 px-4 py-3 text-sm font-medium text-navy hover:bg-mist/30"
                        >
                          <UserRound size={17} /> Profile
                        </Link>
                        <Link
                          to={ROLE_HOME[user.role] || '/'}
                          onClick={() => setProfileOpen(false)}
                          className="flex items-center gap-3 px-4 py-3 text-sm font-medium text-navy hover:bg-mist/30"
                        >
                          <LayoutDashboard size={17} /> Go to dashboard
                        </Link>
                        <button
                          type="button"
                          onClick={handleLogout}
                          className="flex w-full items-center gap-3 px-4 py-3 text-left text-sm font-medium text-red-600 hover:bg-red-50"
                        >
                          <LogOut size={17} /> Logout
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </>
            ) : (
              <>
                <Link to="/login" className="hidden px-2 text-sm font-semibold text-navy hover:underline sm:inline">
                  Log in
                </Link>
                <Link to="/register" className="hidden sm:inline-flex">
                  <Button>Create account</Button>
                </Link>
                <Link to="/login" className="sm:hidden">
                  <Button>Log in</Button>
                </Link>
              </>
            )}

            <button
              type="button"
              aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
              aria-expanded={mobileOpen}
              onClick={() => setMobileOpen((value) => !value)}
              className="rounded-lg p-2 text-navy hover:bg-mist/40 lg:hidden"
            >
              {mobileOpen ? <X size={21} /> : <Menu size={21} />}
            </button>
          </div>
        </div>

        {mobileOpen && (
          <nav className="border-t border-mist bg-white px-5 py-3 lg:hidden">
            <div className="mx-auto flex max-w-7xl flex-col">
              {[
                ['Home', '/'],
                ['About', '/about'],
                ['Services', '/#services'],
                ['How it works', '/#how-it-works'],
                ['Branches', '/#branches'],
                ['Contact', '/contact'],
              ].map(([label, to]) => (
                <Link
                  key={label}
                  to={to}
                  onClick={() => setMobileOpen(false)}
                  className="rounded-lg px-3 py-3 text-sm font-medium text-navy hover:bg-mist/30"
                >
                  {label}
                </Link>
              ))}
              {user && (
                <Link
                  to={ROLE_HOME[user.role] || '/'}
                  onClick={() => setMobileOpen(false)}
                  className="mt-2 flex items-center gap-2 rounded-lg bg-mist/30 px-3 py-3 text-sm font-semibold text-navy"
                >
                  <LayoutDashboard size={17} /> Go to dashboard
                </Link>
              )}
            </div>
          </nav>
        )}
      </header>

      <main className="flex-1">{children}</main>
      {!hideFooter && <Footer />}
    </div>
  );
}
