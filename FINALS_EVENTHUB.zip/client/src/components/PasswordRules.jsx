import { Check, Circle } from 'lucide-react';
import { passwordChecks, passwordValid } from '../utils/validators';

export { passwordChecks, passwordValid };

// Compact, live requirements. Only shown while they help (field focused or not yet satisfied after
// typing) and gone once every requirement is met.
export default function PasswordRules({ password, visible }) {
  if (!visible || passwordValid(password)) return null;
  return (
    <ul className="-mt-1 flex flex-wrap gap-1.5" aria-label="Password requirements">
      {passwordChecks(password).map((c) => (
        <li key={c.label} className={`flex items-center gap-1 rounded-full px-2 py-0.5 text-xs ${c.ok ? 'bg-emerald-50 text-emerald-700' : 'bg-gray-100 text-steel'}`}>
          {c.ok ? <Check size={11} /> : <Circle size={8} />} {c.label}
        </li>
      ))}
    </ul>
  );
}
