import { useState } from 'react';
import Modal from './Modal';
import Button from './Button';
import Alert from './Alert';

// Admin must always give a reason when rejecting a booking or a payment.
export default function ReasonModal({ title, label, confirmLabel, placeholder, onClose, onConfirm }) {
  const [reason, setReason] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    if (reason.trim().length < 3) return setError('Give a reason of at least 3 characters.');
    setLoading(true); setError('');
    try { await onConfirm(reason.trim()); }
    catch (err) { setError(err.message || 'Something went wrong.'); setLoading(false); }
  };

  return (
    <Modal title={title} onClose={onClose}>
      <form onSubmit={submit} className="space-y-4" noValidate>
        <Alert type="error">{error}</Alert>
        <div>
          <label htmlFor="reason" className="mb-1.5 block text-sm font-medium text-navy">{label}</label>
          <textarea id="reason" rows={4} maxLength={300} value={reason} onChange={(e) => setReason(e.target.value)} placeholder={placeholder}
            className="w-full rounded-xl border border-steel/40 px-4 py-2.5 text-sm text-navy placeholder:text-steel/70 focus:border-sky focus:outline-none focus:ring-2 focus:ring-sky/40" />
        </div>
        <div className="flex justify-end gap-3">
          <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
          <Button type="submit" variant="dark" loading={loading}>{confirmLabel}</Button>
        </div>
      </form>
    </Modal>
  );
}
