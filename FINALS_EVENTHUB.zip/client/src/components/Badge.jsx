const TONES = {
  active: 'bg-mist text-navy',
  inactive: 'bg-steel/15 text-steel',
  pending: 'border border-sky bg-white text-navy',
  info: 'bg-mist/50 text-navy',
  // booking statuses (functional colours: waiting, action needed, in review, done, problem)
  yellow: 'bg-amber-100 text-amber-800',
  orange: 'bg-orange-100 text-orange-800',
  sky: 'bg-sky/30 text-navy',
  green: 'bg-emerald-100 text-emerald-800',
  red: 'bg-red-100 text-red-800',
  purple: 'bg-violet-100 text-violet-800',
  blue: 'bg-blue-100 text-blue-800',
  gray: 'bg-gray-200 text-gray-700',
};

export default function Badge({ tone = 'info', children }) {
  return <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${TONES[tone]}`}>{children}</span>;
}
