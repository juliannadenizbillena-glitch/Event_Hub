import { useId, useState } from 'react';
import { Check, Eye, EyeOff } from 'lucide-react';

// `error` shows a short message under the field; `valid` shows a subtle check mark.
export default function Field({ label, error, hint, valid = false, type = 'text', className = '', ...props }) {
  const id = useId();
  const [show, setShow] = useState(false);
  const isPassword = type === 'password';
  const showCheck = valid && !error;

  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1.5 block text-sm font-medium text-navy">{label}</label>
      <div className="relative">
        <input
          id={id}
          type={isPassword && show ? 'text' : type}
          aria-invalid={!!error}
          aria-describedby={error ? `${id}-error` : undefined}
          className={`w-full rounded-xl border bg-white px-4 py-2.5 text-sm text-navy placeholder:text-steel/60 transition focus:outline-none focus:ring-2 read-only:bg-mist/30 ${error ? 'border-red-400 focus:border-red-400 focus:ring-red-200' : 'border-steel/40 focus:border-sky focus:ring-sky/40'} ${isPassword ? (showCheck ? 'pr-20' : 'pr-11') : showCheck ? 'pr-10' : ''}`}
          {...props}
        />
        {showCheck && (
          <span className={`pointer-events-none absolute inset-y-0 flex items-center text-emerald-600 ${isPassword ? 'right-11' : 'right-3'}`} aria-hidden="true">
            <Check size={16} />
          </span>
        )}
        {isPassword && (
          <button
            type="button"
            onClick={() => setShow((s) => !s)}
            aria-label={show ? 'Hide password' : 'Show password'}
            className="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-steel hover:text-navy"
          >
            {show ? <EyeOff size={18} /> : <Eye size={18} />}
          </button>
        )}
      </div>
      {error ? <p id={`${id}-error`} className="mt-1 text-xs text-red-600">{error}</p> : hint && <p className="mt-1 text-xs text-steel">{hint}</p>}
    </div>
  );
}
