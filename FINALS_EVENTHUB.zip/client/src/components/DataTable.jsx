// Responsive table. columns: [{ key, label, render?(row), className? }]
// Wide screens: a table. Narrow screens: one card per row (label: value), so nothing is clipped.
export default function DataTable({ columns, rows, empty = 'Nothing to show yet.', rowKey = '_id' }) {
  const cell = (c, row) => (c.render ? c.render(row) : row[c.key]);
  return (
    <>
      <div className="hidden overflow-x-auto rounded-2xl border border-mist bg-white shadow-sm md:block">
        <table className="w-full text-left text-sm">
          <thead className="bg-mist/30 text-xs uppercase tracking-wide text-steel">
            <tr>{columns.map((c) => <th key={c.key} className={`px-4 py-3 font-semibold ${c.className || ''}`}>{c.label}</th>)}</tr>
          </thead>
          <tbody>
            {rows.length === 0 && <tr><td colSpan={columns.length} className="px-4 py-10 text-center text-steel">{empty}</td></tr>}
            {rows.map((row) => (
              <tr key={row[rowKey]} className="border-t border-mist/60 text-navy">
                {columns.map((c) => <td key={c.key} className={`px-4 py-3 align-middle ${c.className || ''}`}>{cell(c, row)}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="space-y-3 md:hidden" data-testid="table-cards">
        {rows.length === 0 && <p className="rounded-2xl border border-mist bg-white px-4 py-10 text-center text-sm text-steel">{empty}</p>}
        {rows.map((row) => (
          <div key={row[rowKey]} className="rounded-2xl border border-mist bg-white p-4 text-sm text-navy shadow-sm">
            {columns.filter((c) => c.label).map((c, i) => (
              <div key={c.key} className={`flex items-start justify-between gap-4 py-1.5 ${i ? 'border-t border-mist/50' : ''}`}>
                <span className="shrink-0 text-xs font-semibold uppercase tracking-wide text-steel">{c.label}</span>
                <span className="min-w-0 break-words text-right">{cell(c, row)}</span>
              </div>
            ))}
            {columns.filter((c) => !c.label).map((c) => <div key={c.key} className="mt-3 flex flex-wrap justify-end gap-2">{cell(c, row)}</div>)}
          </div>
        ))}
      </div>
    </>
  );
}
