import Logo from './Logo';


// Authentication shell: soft pastel brand panel on the left, the form on a clean white page on the right.
export default function AuthLayout({ title, subtitle, children, footer }) {
  return (
    <div className="flex min-h-screen flex-col">
    <div className="grid flex-1 lg:grid-cols-[minmax(0,5fr)_minmax(0,6fr)]">
      <aside className="eh-hero-grad relative hidden overflow-hidden p-12 text-navy lg:flex lg:flex-col lg:justify-between">
        <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 400 600" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
          <circle cx="360" cy="60" r="170" fill="#F9D7EA" opacity="0.55" />
          <circle cx="40" cy="560" r="210" fill="#D3E4FF" opacity="0.6" />
          <rect x="70" y="230" width="190" height="130" rx="28" fill="#FFFFFF" opacity="0.7" />
          <rect x="130" y="290" width="190" height="130" rx="28" fill="#CBEFF5" opacity="0.8" />
          <rect x="190" y="350" width="150" height="100" rx="28" fill="#DFD5FD" opacity="0.8" />
        </svg>
        <Logo className="relative" />
        <div className="relative max-w-sm">
          <h2 className="text-3xl font-extrabold leading-tight">Events, planned and delivered.</h2>
          <p className="mt-3 text-steel">One place to book, manage and run your events.</p>
        </div>
        <p className="relative text-xs text-steel">© {new Date().getFullYear()} EventHub</p>
      </aside>

      <main className="flex items-center justify-center bg-white px-5 py-10 sm:px-10">
        <div className="w-full max-w-md">
          <Logo className="mb-8 lg:hidden" />
          <h1 className="text-2xl font-extrabold text-navy">{title}</h1>
          {subtitle && <p className="mt-1.5 text-sm text-steel">{subtitle}</p>}
          <div className="mt-7">{children}</div>
          {footer && <div className="mt-6 text-center text-sm text-steel">{footer}</div>}
        </div>
      </main>
    </div>
  
    </div>
  );
}
