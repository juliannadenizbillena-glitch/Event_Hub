import { Link } from 'react-router-dom';
import Logo from './Logo';

export const LINKS = [
  { to: '/about', label: 'About' },
  { to: '/contact', label: 'Contact' },
  { to: '/privacy', label: 'Privacy Policy' },
];

export default function Footer() {
  return (
    <footer
      data-testid="global-footer"
      className="mt-auto w-full border-t border-mist bg-white"
    >
      <div className="mx-auto w-full max-w-7xl px-5 py-6 sm:px-8">
        <div className="grid gap-7 sm:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-3"><Logo /><p className="max-w-sm text-sm leading-6 text-steel">EventHub helps companies plan and manage workshops, conferences, seminars, training sessions, and other professional events through our branch-based event management service.</p></div>

          <div><h2 className="mb-3 text-sm font-bold text-navy">Explore EventHub</h2><nav aria-label="Footer">
            <ul className="flex flex-wrap gap-x-6 gap-y-2 sm:justify-end">
              {LINKS.map((link) => (
                <li key={link.to}>
                  <Link
                    to={link.to}
                    className="text-sm font-medium text-navy hover:underline"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav></div>
          <div><h2 className="mb-3 text-sm font-bold text-navy">Our service</h2><p className="text-sm leading-6 text-steel">Browse event services, compare available packages and add-ons, select a branch, and submit your event request. Our team reviews requests and coordinates the next steps.</p></div>
          <div><h2 className="mb-3 text-sm font-bold text-navy">Need help?</h2><p className="text-sm leading-6 text-steel">Sign in to manage your booking, review event updates, and check payment status. For assistance, use the Contact page to reach EventHub.</p><Link to="/contact" className="mt-2 inline-block text-sm font-semibold text-navy hover:underline">Contact EventHub</Link></div>
        </div>

        <p className="mt-6 border-t border-mist pt-4 text-left text-xs text-steel">
          © 2026 EventHub Event Management Services. All rights reserved. Event details and availability are confirmed by the EventHub team.
        </p>
      </div>
    </footer>
  );
}