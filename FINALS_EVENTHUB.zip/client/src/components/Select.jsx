import { useId } from 'react';

export default function Select({ label, error, children, className = '', ...props }) {
  const id = useId();
  return (
    <div className={className}>
      {label && <label htmlFor={id} className="mb-1.5 block text-sm font-medium text-navy">{label}</label>}
      <select
        id={id}
        aria-invalid={!!error}
        className={`w-full rounded-xl border bg-white px-3 py-2.5 text-sm text-navy transition focus:border-sky focus:outline-none focus:ring-2 focus:ring-sky/40 ${error ? 'border-red-400' : 'border-steel/40'}`}
        {...props}
      >
        {children}
      </select>
      {error && <p className="mt-1 text-xs text-red-600">{error}</p>}
    </div>
  );
}
