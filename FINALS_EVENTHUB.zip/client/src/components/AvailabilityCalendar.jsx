import { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';
import api, { errorMessage } from '../api/client';
import Alert from './Alert';

const DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const NO_TEAMS = 'No team is available for your selected schedule. Please select another date.';
const monthLabel = (m) => new Date(`${m}-01T00:00:00`).toLocaleDateString('en-PH', { month: 'long', year: 'numeric' });
const shift = (m, n) => { const [y, mo] = m.split('-').map(Number); const d = new Date(y, mo - 1 + n, 1); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; };

// Available (green) / Unavailable (red) / Past or not selectable (grey). No "limited" state.
// Staff (showCounts) also see how many teams are free.


export default function AvailabilityCalendar({
  branchId,
  branchOptional = false,
  eventTypeId,
  attendees,
  selectedDate,
  onSelect,
  showCounts = false,
  minDate,
  selectionLabel,
}) {

  const [month, setMonth] = useState(() => new Date().toISOString().slice(0, 7));
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [notice, setNotice] = useState('');

  useEffect(() => {
    if (!eventTypeId || !attendees || (!branchId && !branchOptional)) return;
    let cancelled = false;
    setLoading(true); setError('');
    api.get('/availability', { params: { branch: branchId || undefined, eventType: eventTypeId, attendees, month } })
      .then((res) => { if (!cancelled) setData(res.data); })
      .catch((err) => { if (!cancelled) { setData(null); setError(errorMessage(err)); } })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [branchId, branchOptional, eventTypeId, attendees, month]);

  useEffect(() => { setNotice(''); }, [branchId, eventTypeId, attendees, month]);

  const days = data?.days || [];
  const lead = days.length ? new Date(`${days[0].date}T00:00:00`).getDay() : 0;
  const thisMonth = new Date().toISOString().slice(0, 7);
  const lastMonth = shift(thisMonth, 12);

  return (
    <div className="rounded-2xl border border-mist bg-white p-5">
      <div className="mb-4 flex items-center justify-between">
        <button type="button" aria-label="Previous month" disabled={month <= thisMonth} onClick={() => setMonth(shift(month, -1))} className="rounded-lg p-2 text-navy hover:bg-mist/50 disabled:opacity-30"><ChevronLeft size={18} /></button>
        <p className="flex items-center gap-2 text-sm font-semibold text-navy">{monthLabel(month)} {loading && <Loader2 size={14} className="animate-spin text-steel" />}</p>
        <button type="button" aria-label="Next month" disabled={month >= lastMonth} onClick={() => setMonth(shift(month, 1))} className="rounded-lg p-2 text-navy hover:bg-mist/50 disabled:opacity-30"><ChevronRight size={18} /></button>
      </div>

      {error ? <Alert type="error">{error}</Alert> : (
        <>
          <div className="grid grid-cols-7 gap-1.5 text-center text-xs font-semibold text-steel">{DOW.map((d) => <div key={d}>{d}</div>)}</div>
          <div className="mt-1.5 grid grid-cols-7 gap-1.5">
            {Array.from({ length: lead }).map((_, i) => <div key={`b${i}`} />)}
            {days.map((d) => {
              const num = Number(d.date.slice(8));
              const selected = d.date === selectedDate;
              const beforeMinDate = minDate && d.date < minDate;
              const base = 'flex h-11 flex-col items-center justify-center rounded-lg text-sm transition';

if (d.status === 'past' || beforeMinDate) {
  return (
    <div
      key={d.date}
      className={`${base} bg-gray-100 text-gray-400`}
      title={beforeMinDate ? 'Before the event start date' : 'Not selectable'}
    >
      {num}
    </div>
  );
}

              const tone = selected ? 'bg-navy text-white' : d.status === 'available' ? 'bg-emerald-100 text-emerald-900 hover:bg-emerald-200' : 'bg-red-100 text-red-800 hover:bg-red-200';
              return (
                <button
                  key={d.date} type="button" data-date={d.date} data-status={d.status}
                  aria-label={`${d.date} ${d.status}`}
                  onClick={() => {
                    if (d.status === 'unavailable') { setNotice(NO_TEAMS); return; }
                    setNotice(''); onSelect?.(d.date);
                  }}
                  className={`${base} ${tone} ${onSelect || d.status === 'unavailable' ? 'cursor-pointer' : 'cursor-default'}`}
                >
                  <span className="font-semibold">{num}</span>
                  {showCounts && d.freeTeams !== undefined && <span className="text-[10px] leading-none opacity-80">{d.freeTeams}/{data.activeTeams}</span>}
                </button>
              );
            })}
          </div>
          <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-1 text-xs text-steel">
            <span className="flex items-center gap-1.5"><span className="h-3 w-3 rounded bg-emerald-200" /> Available</span>
            <span className="flex items-center gap-1.5"><span className="h-3 w-3 rounded bg-red-200" /> Unavailable</span>
            <span className="flex items-center gap-1.5"><span className="h-3 w-3 rounded bg-gray-200" /> Past / not selectable</span>
            {data && <span className="ml-auto">Needs {data.requiredTeams} {data.requiredTeams === 1 ? 'team' : 'teams'}</span>}
          </div>
          {notice && <div className="mt-3"><Alert type="error">{notice}</Alert></div>}
        </>
      )}
    </div>
  );
}
