import Badge from './Badge';
import { STATUS } from '../config/bookingStatus';

export default function BookingStatusBadge({ status }) {
  const s = STATUS[status] || { label: status, tone: 'info' };
  return <Badge tone={s.tone}>{s.label}</Badge>;
}
