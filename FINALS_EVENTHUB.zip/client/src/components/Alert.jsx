import { AlertCircle, CheckCircle2, Info } from 'lucide-react';

const STYLES = {
  error: { box: 'border-red-200 bg-red-50 text-red-800', Icon: AlertCircle },
  success: { box: 'border-emerald-200 bg-emerald-50 text-emerald-800', Icon: CheckCircle2 },
  info: { box: 'border-mist bg-mist/40 text-navy', Icon: Info },
};

export default function Alert({ type = 'info', children, action }) {
  if (!children) return null;
  const { box, Icon } = STYLES[type];
  return (
    <div role={type === 'error' ? 'alert' : 'status'} className={`flex items-start gap-3 rounded-xl border px-4 py-3 text-sm ${box}`}>
      <Icon size={18} className="mt-0.5 shrink-0" />
      <div className="flex-1">
        <p>{children}</p>
        {action && <div className="mt-2">{action}</div>}
      </div>
    </div>
  );
}
