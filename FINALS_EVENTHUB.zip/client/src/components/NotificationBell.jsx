
import { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell } from 'lucide-react';
import api from '../api/client';
import { formatDateTime } from '../utils/format';
import { bookingPath } from '../config/bookingStatus';
import { useAuth } from '../context/AuthContext';

export default function NotificationBell() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [data, setData] = useState({ notifications: [], unread: 0 });
  const box = useRef(null);

  const load = useCallback(
    () => api.get('/notifications').then((r) => setData(r.data)).catch(() => {}),
    []
  );

  useEffect(() => {
    load();
    const t = setInterval(load, 30000);
    return () => clearInterval(t);
  }, [load]);

  useEffect(() => {
    const close = (e) => {
      if (box.current && !box.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, []);

  const openItem = async (n) => {
    if (!n.readAt) await api.patch(`/notifications/${n._id}/read`).catch(() => {});
    setOpen(false);
    load();

    if (n.booking) {
      try {
        const r = await api.get(`/bookings/${n.booking}`);
        navigate(bookingPath(user.role, r.data.booking));
      } catch {
        // Booking may no longer be visible.
      }
    }
  };

  return (
    <div className="relative" ref={box}>
      <button
        aria-label={`Notifications${data.unread ? `, ${data.unread} unread` : ''}`}
        onClick={() => {
          setOpen((o) => !o);
          load();
        }}
        className="relative rounded-full border border-mist bg-white p-2.5 text-navy shadow-sm hover:bg-mist/60"
      >
        <Bell size={20} />

        {data.unread > 0 && (
          <span className="absolute -right-0.5 -top-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-red-600 px-1 text-[11px] font-bold text-white">
            {data.unread > 9 ? '9+' : data.unread}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 z-40 mt-2 w-80 max-w-[90vw] overflow-hidden rounded-2xl border border-mist bg-white shadow-[0_16px_40px_rgba(35,35,58,0.12)]">
          <div className="flex items-center justify-between border-b border-mist px-4 py-3">
            <p className="text-sm font-semibold text-navy">Notifications</p>

            {data.unread > 0 && (
              <button
                onClick={async () => {
                  await api.post('/notifications/read-all');
                  load();
                }}
                className="text-xs font-semibold text-steel hover:text-navy"
              >
                Mark all read
              </button>
            )}
          </div>

          <ul className="max-h-96 overflow-y-auto">
            {data.notifications.length === 0 && (
              <li className="px-4 py-8 text-center text-sm text-steel">
                You are all caught up.
              </li>
            )}

            {data.notifications.map((n) => (
              <li key={n._id}>
                <button
                  onClick={() => openItem(n)}
                  className={`flex w-full gap-3 border-b border-mist/60 px-4 py-3 text-left hover:bg-mist/30 ${
                    n.readAt ? '' : 'bg-mist/20'
                  }`}
                >
                  <span
                    className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${
                      n.readAt ? 'bg-transparent' : 'bg-red-600'
                    }`}
                  />

                  <span>
                    <span className="block text-sm font-semibold text-navy">{n.title}</span>
                    <span className="block text-xs text-navy">{n.message}</span>
                    <span className="mt-1 block text-[11px] text-steel">
                      {formatDateTime(n.createdAt)}
                    </span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
