import Select from './Select';

// Half-hour slots, e.g. "6:00 AM" ... "11:30 PM". Value is "HH:MM".
const SLOTS = Array.from({ length: 36 }, (_, i) => {
  const mins = 6 * 60 + i * 30;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  const value = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
  return { value, label: `${((h + 11) % 12) + 1}:${String(m).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}` };
});

export default function TimeSelect({ placeholder, after, ...props }) {
  return (
    <Select {...props}>
      <option value="">{placeholder}</option>
      {SLOTS.filter((s) => !after || s.value > after).map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
    </Select>
  );
}
