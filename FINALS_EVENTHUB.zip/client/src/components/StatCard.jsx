import { Link } from 'react-router-dom';

export default function StatCard({ label, value, hint, to, attention = false, testId }) {
  const body = (
    <div className={`h-full rounded-2xl border p-5 shadow-sm transition ${to ? 'hover:-translate-y-0.5 hover:shadow-md' : ''} ${attention ? 'ring-attn border-sky bg-mist/40' : 'border-mist bg-white'}`}>
      <p data-testid={testId} className="text-2xl font-extrabold text-navy sm:text-3xl">{value}</p>
      <p className="mt-1 text-sm font-medium text-navy/70">{label}</p>
      {hint && <p className="mt-1 text-xs text-steel/80">{hint}</p>}
    </div>
  );
  return to ? <Link to={to} className="block h-full">{body}</Link> : body;
}
