import { Loader2 } from 'lucide-react';

// primary: brand violet with white text
const VARIANTS = {
  primary: 'bg-sky text-white shadow-[0_6px_16px_rgba(91,82,185,0.28)] hover:bg-sky/90 disabled:hover:bg-sky',
  secondary: 'border border-mist bg-white text-navy hover:bg-mist/60',
  dark: 'bg-navy text-white hover:bg-navy/90',
};

export default function Button({ variant = 'primary', loading = false, full = false, className = '', children, disabled, ...props }) {
  return (
    <button
      disabled={disabled || loading}
      className={`inline-flex items-center justify-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-60 ${VARIANTS[variant]} ${full ? 'w-full' : ''} ${className}`}
      {...props}
    >
      {loading && <Loader2 size={16} className="animate-spin" />}
      {children}
    </button>
  );
}
