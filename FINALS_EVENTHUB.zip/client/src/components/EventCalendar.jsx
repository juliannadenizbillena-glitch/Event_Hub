import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';
import api, { errorMessage } from '../api/client';
import Alert from './Alert';
import { STATUS, bookingPath } from '../config/bookingStatus';
import { useAuth } from '../context/AuthContext';

const DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const TONE = { yellow: 'bg-amber-100 text-amber-900', orange: 'bg-orange-100 text-orange-900', sky: 'bg-sky/30 text-navy', green: 'bg-emerald-100 text-emerald-900', red: 'bg-red-100 text-red-800', purple: 'bg-violet-100 text-violet-900', blue: 'bg-blue-100 text-blue-900', gray: 'bg-gray-200 text-gray-700' };
const pad = (n) => String(n).padStart(2, '0');
const monthLabel = (m) => new Date(`${m}-01T00:00:00`).toLocaleDateString('en-PH', { month: 'long', year: 'numeric' });
const shift = (m, n) => { const [y, mo] = m.split('-').map(Number); const d = new Date(y, mo - 1 + n, 1); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}`; };

// A month of events. User: their own bookings. Organizer: their branch's events. Admin: the whole system.
export default function EventCalendar({ branch = '' }) {
  const { user } = useAuth();
  const [month, setMonth] = useState(() => new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Manila' }).slice(0, 7));
  const [events, setEvents] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const [y, m] = month.split('-').map(Number);
    const last = new Date(y, m, 0).getDate();
    let live = true;
    setLoading(true); setError('');
    api.get('/calendar', { params: { from: `${month}-01`, to: `${month}-${pad(last)}`, branch: branch || undefined } })
      .then((r) => live && setEvents(r.data.events)).catch((e) => live && setError(errorMessage(e))).finally(() => live && setLoading(false));
    return () => { live = false; };
  }, [month, branch]);

  const [y, m] = month.split('-').map(Number);
  const days = new Date(y, m, 0).getDate();
  const lead = new Date(y, m - 1, 1).getDay();
  const byDate = {};
  events.forEach((e) => { (byDate[e.date] ||= []).push(e); });

  return (
    <div className="rounded-2xl border border-mist bg-white p-4 sm:p-5" data-testid="event-calendar">
      <div className="mb-4 flex items-center justify-between">
        <button type="button" aria-label="Previous month" onClick={() => setMonth(shift(month, -1))} className="rounded-lg p-2 text-navy hover:bg-mist/50"><ChevronLeft size={18} /></button>
        <p className="flex items-center gap-2 text-sm font-semibold text-navy">{monthLabel(month)} {loading && <Loader2 size={14} className="animate-spin text-steel" />}</p>
        <button type="button" aria-label="Next month" onClick={() => setMonth(shift(month, 1))} className="rounded-lg p-2 text-navy hover:bg-mist/50"><ChevronRight size={18} /></button>
      </div>
      {error ? <Alert type="error">{error}</Alert> : (
        <>
          <div className="grid grid-cols-7 gap-1 text-center text-xs font-semibold text-steel">{DOW.map((d) => <div key={d}>{d}</div>)}</div>
          <div className="mt-1 grid grid-cols-7 gap-1">
            {Array.from({ length: lead }).map((_, i) => <div key={`b${i}`} className="min-h-16 sm:min-h-24" />)}
            {Array.from({ length: days }, (_, i) => i + 1).map((d) => {
              const date = `${month}-${pad(d)}`;
              const list = byDate[date] || [];
              return (
                <div key={date} data-date={date} className={`min-h-16 rounded-lg border p-1 sm:min-h-24 ${list.length ? 'border-sky/60 bg-mist/20' : 'border-mist/50'}`}>
                  <p className="text-xs font-semibold text-navy">{d}</p>
                  <div className="mt-0.5 space-y-0.5">
                    {list.slice(0, 2).map((e) => (
                      <Link key={e._id} to={bookingPath(user.role, e)} title={`${e.eventName} · ${STATUS[e.status]?.label}${e.company ? ` · ${e.company}` : ''}`} className={`block truncate rounded px-1 py-0.5 text-[10px] font-medium leading-tight sm:text-xs ${TONE[STATUS[e.status]?.tone || 'gray']}`}>{e.eventName}</Link>
                    ))}
                    {list.length > 2 && <p className="px-1 text-[10px] text-steel">+{list.length - 2} more</p>}
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mt-4 flex flex-wrap gap-x-4 gap-y-1 text-xs text-steel">
            {Object.entries(STATUS).filter(([s]) => events.some((e) => e.status === s)).map(([s, v]) => <span key={s} className="flex items-center gap-1.5"><span className={`h-3 w-3 rounded ${TONE[v.tone].split(' ')[0]}`} />{v.label}</span>)}
            {events.length === 0 && !loading && <span>No events this month.</span>}
          </div>
        </>
      )}
    </div>
  );
}
