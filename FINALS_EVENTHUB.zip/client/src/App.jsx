import { Navigate, Route, Routes } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { useAuth } from './context/AuthContext';
import { NAV, ROLE_HOME } from './config/navigation';
import { ProtectedRoute, PublicOnlyRoute } from './routes/guards';
import AppShell from './components/AppShell';
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import VerifyEmail from './pages/auth/VerifyEmail';
import ForgotPassword from './pages/auth/ForgotPassword';
import ResetPassword from './pages/auth/ResetPassword';
import DashboardHome from './pages/app/DashboardHome';
import ComingSoon from './pages/app/ComingSoon';
import Profile from './pages/app/Profile';
import Landing from './pages/public/Landing';
import { About, Contact, Privacy, Terms } from './pages/public/Static';
import Branches from './pages/admin/Branches';
import EventTypes from './pages/admin/EventTypes';
import Teams from './pages/admin/Teams';
import Staff from './pages/admin/Staff';
import Pricing from './pages/admin/Pricing';
import EventSetup from './pages/app/EventSetup';
import BookEvent from './pages/bookings/BookEvent';
import BookingList from './pages/bookings/BookingList';
import BookingDetails from './pages/bookings/BookingDetails';
import CalendarPage from './pages/bookings/CalendarPage';
import { LISTS } from './pages/bookings/lists';
import AdminEvents from './pages/bookings/AdminEvents';
import Equipment from './pages/admin/Equipment';
import Venues from './pages/admin/Venues';
import Companies, { CompanyDetails } from './pages/admin/Companies';
import Archive from './pages/admin/Archive';
import Reports from './pages/admin/Reports';

// Pages that exist, by path. Everything else in config/navigation.js still shows its placeholder.
// Teams, Calendar and the booking pages adapt to the role (Organizer: own branch only; no prices).
const BUILT = {
  '/admin/branches': <Branches />,
  '/admin/event-types': <EventTypes />,
  '/admin/teams': <Teams />,
  '/admin/staff': <Staff />,
  '/admin/bundles': <Pricing />,
  '/admin/booking-requests': <BookingList config={LISTS.adminRequests} />,
  '/admin/events': <AdminEvents />,
  '/admin/equipment': <Equipment />,
  '/admin/venues': <Venues />,
  '/admin/companies': <Companies />,
  '/admin/archive': <Archive />,
  '/admin/reports': <Reports />,
  '/organizer/teams': <Teams />,
  '/organizer/event-setup': <EventSetup />,
  '/organizer/booking-requests': <BookingList config={LISTS.organizerRequests} />,
  '/organizer/my-events': <BookingList config={LISTS.organizerEvents} />,
  '/organizer/calendar': <CalendarPage />,
  '/organizer/equipment': <Equipment />,
  '/organizer/venues': <Venues />,
  '/book-event': <BookEvent />,
  '/my-events': <BookingList config={LISTS.user} />,
  '/calendar': <CalendarPage />,
};

// Booking Details pages. One page handles every status; the panel changes with status and role.
const DETAILS = {
  user: [['/my-events/:id', { to: '/my-events', label: 'My Events' }]],
  organizer: [
    ['/organizer/booking-requests/:id', { to: '/organizer/booking-requests', label: 'Booking Requests' }],
    ['/organizer/my-events/:id', { to: '/organizer/my-events', label: 'My Events' }],
  ],
  admin: [
    ['/admin/booking-requests/:id', { to: '/admin/booking-requests', label: 'Booking Requests' }],
    ['/admin/events/:id', { to: '/admin/events', label: 'Events' }],
    ['/admin/archive/:id', { to: '/admin/archive', label: 'Archive' }],
  ],
};

const ROLES = ['user', 'organizer', 'admin'];

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/about" element={<About />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/privacy" element={<Privacy />} />
      <Route path="/terms" element={<Terms />} />

      {/* Logged-out only */}
      <Route element={<PublicOnlyRoute />}>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/verify-email" element={<VerifyEmail />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />
      </Route>

      {/* Logged-in: one shell, pages generated per role from config/navigation.js */}
      <Route element={<ProtectedRoute />}>
        <Route element={<AppShell />}>
          <Route path="/profile" element={<Profile />} />
          {ROLES.map((role) => (
            <Route key={role} element={<ProtectedRoute roles={[role]} />}>
              {NAV[role].flatMap((g) => g.items).filter((i) => i.to !== '/profile').map((item) => {
                return <Route key={item.to} path={item.to} element={item.home ? <DashboardHome /> : BUILT[item.to] || <ComingSoon />} />;
              })}
              {role === 'admin' && <Route path="/admin/companies/:id" element={<CompanyDetails />} />}
              {DETAILS[role].map(([path, back]) => <Route key={path} path={path} element={<BookingDetails back={back} />} />)}
            </Route>
          ))}
        </Route>
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
