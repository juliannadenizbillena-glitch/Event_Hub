import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { ROLE_HOME } from '../config/navigation';

const Splash = () => (
  <div className="flex min-h-screen items-center justify-center bg-white text-steel">
    <Loader2 className="animate-spin" />
  </div>
);

// Login / Register / Forgot password are for logged-out visitors only.
export function PublicOnlyRoute() {
  const { user, loading } = useAuth();
  if (loading) return <Splash />;
  return user ? <Navigate to={ROLE_HOME[user.role]} replace /> : <Outlet />;
}

// Requires a login, and (optionally) one of the given roles. Wrong role -> own dashboard.
export function ProtectedRoute({ roles }) {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading) return <Splash />;
  if (!user) return <Navigate to="/login" replace state={{ from: location }} />;
  if (roles && !roles.includes(user.role)) return <Navigate to={ROLE_HOME[user.role]} replace />;
  return <Outlet />;
}
