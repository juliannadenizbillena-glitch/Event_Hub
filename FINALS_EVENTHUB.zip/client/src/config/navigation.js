
import {
  LayoutDashboard, CalendarPlus, CalendarDays, ClipboardList, Users, Building2, Layers,
  Package, MapPin, BarChart3, Archive, Wrench, Settings2, ListChecks, Briefcase,
} from 'lucide-react';

// SINGLE SOURCE OF TRUTH for navigation.
// Menu items and permissions remain specific to each role.

export const ROLE_HOME = {
  user: '/dashboard',
  organizer: '/organizer',
  admin: '/admin',
};

export const ROLE_LABEL = {
  user: 'User / Company',
  organizer: 'Organizer / Staff',
  admin: 'Administrator',
};

export const ROLE_PERMISSIONS = {
  user: [
    'Create your own event booking (type, branch, date and time, bundle, add-ons, requirements).',
    'Pay the 50% down payment within 24 hours of approval, and the remaining balance after the event.',
    'Follow every booking and event status from one Booking Details page.',
  ],
  organizer: [
    'Prepare and run confirmed events for your assigned branch with your assigned teams.',
    'Inspect equipment and property after the event and file damage reports.',
    'View booking requests and event setup. Approving bookings and changing prices belong to Admin.',
  ],
  admin: [
    'Review, approve or reject booking requests and verify payments.',
    'Approve or reject damage fees, and manage branches, teams, staff, companies and pricing.',
    'Oversee reports and keep records organised through the Archive.',
  ],
};

export const NAV = {
  user: [
    {
      section: 'Main',
      items: [
        { label: 'Dashboard', to: '/dashboard', icon: LayoutDashboard, home: true },
        {
          label: 'Book an Event',
          to: '/book-event',
          icon: CalendarPlus,
          module: 'Booking',
          description: 'Create your own event booking: event details, branch, date and time, team availability, bundle, add-ons, requirements, optional reference image, then review the booking details and submit.',
        },
        {
          label: 'My Events',
          to: '/my-events',
          icon: ClipboardList,
          module: 'Booking and Payments',
          description: 'All your bookings. Open one to see its status, pay the 50% down payment within 24 hours of approval, upload payment proof, and pay the final balance after the event.',
        },
        {
          label: 'Calendar',
          to: '/calendar',
          icon: CalendarDays,
          module: 'Availability',
          description: 'Branch availability by date: available, unavailable, or past (not selectable).',
        },
      ],
    },
  ],

  organizer: [
    {
      section: 'Main',
      items: [
        { label: 'Dashboard', to: '/organizer', icon: LayoutDashboard, home: true },
        {
          label: 'My Events',
          to: '/organizer/my-events',
          icon: ClipboardList,
          module: 'Event Operations',
          description: 'Confirmed events for your branch: company, schedule, attendees, bundle, add-ons, requirements, reference image and assigned teams. Prepare the event, then run the damage inspection afterwards.',
        },
        {
          label: 'Booking Requests',
          to: '/organizer/booking-requests',
          icon: ListChecks,
          module: 'Booking',
          readOnly: true,
          description: 'Incoming requests for your branch. View only: approving or rejecting bookings and verifying payments belong to Admin.',
        },
        {
          label: 'Calendar',
          to: '/organizer/calendar',
          icon: CalendarDays,
          module: 'Availability',
          description: 'Your branch schedule and which teams are reserved on each date.',
        },
        {
          label: 'Teams',
          to: '/organizer/teams',
          icon: Users,
          module: 'Teams',
          description: 'The event teams of your branch, their staffing, and the events they are reserved for.',
        },
      ],
    },
    {
      section: 'Management',
      items: [
        {
          label: 'Event Setup',
          to: '/organizer/event-setup',
          icon: Settings2,
          module: 'Event Setup',
          readOnly: true,
          description: 'View event types, bundles, add-ons and prices set by Admin, for event preparation. Official prices cannot be edited here.',
        },
        {
          label: 'Equipment',
          to: '/organizer/equipment',
          icon: Wrench,
          module: 'Resources',
          description: 'Equipment used for your branch events.',
        },
        {
          label: 'Venues',
          to: '/organizer/venues',
          icon: MapPin,
          module: 'Resources',
          description: 'Venues used for your branch events.',
        },
      ],
    },
  ],

  admin: [
    {
      section: 'Main',
      items: [
        { label: 'Dashboard', to: '/admin', icon: LayoutDashboard, home: true },
        {
          label: 'Booking Requests',
          to: '/admin/booking-requests',
          icon: ListChecks,
          module: 'Booking',
          description: 'Review complete requests with team availability, then approve or reject. Payment verification and damage-fee review also happen inside each booking.',
        },
        {
          label: 'Events',
          to: '/admin/events',
          icon: CalendarDays,
          module: 'Booking',
          description: 'All confirmed and completed events across branches.',
        },
        {
          label: 'Branches',
          to: '/admin/branches',
          icon: Building2,
          module: 'Admin Setup',
          description: 'Manila, Makati, Quezon City, Cebu and Davao.',
        },
        {
          label: 'Teams',
          to: '/admin/teams',
          icon: Users,
          module: 'Admin Setup',
          description: '275 teams: 5 per event type in each branch, with fixed staffing.',
        },
        {
          label: 'Staff / Organizers',
          to: '/admin/staff',
          icon: Briefcase,
          module: 'Admin Setup',
          description: 'Create Organizer/Staff accounts and assign them to a branch. They set their own password with an emailed code.',
        },
        {
          label: 'Companies',
          to: '/admin/companies',
          icon: Building2,
          module: 'Admin Setup',
          description: 'Registered User/Company accounts and their outstanding balances.',
        },
      ],
    },
    {
      section: 'Management',
      items: [
        {
          label: 'Event Types',
          to: '/admin/event-types',
          icon: Layers,
          module: 'Pricing',
          description: 'The 11 event types and their operational setup.',
        },
        {
          label: 'Bundles & Pricing',
          to: '/admin/bundles',
          icon: Package,
          module: 'Pricing',
          description: 'Official bundles and add-ons with global prices. Only Admin edits these.',
        },
        {
          label: 'Equipment',
          to: '/admin/equipment',
          icon: Wrench,
          module: 'Resources',
          description: 'Equipment inventory.',
        },
        {
          label: 'Venues',
          to: '/admin/venues',
          icon: MapPin,
          module: 'Resources',
          description: 'Venue records.',
        },
        {
          label: 'Archive',
          to: '/admin/archive',
          icon: Archive,
          module: 'Archive',
          description: 'Search and filter archived bookings, companies, staff and bundles. Restore records where appropriate.',
        },
      ],
    },
    {
      section: 'Reports',
      items: [
        {
          label: 'Reports',
          to: '/admin/reports',
          icon: BarChart3,
          module: 'Reports',
          description: 'Bookings, revenue, events, teams and financial reports including internal costs and estimated profit.',
        },
      ],
    },
  ],
};

export const flatItems = (role) =>
  NAV[role].flatMap((section) => section.items);
