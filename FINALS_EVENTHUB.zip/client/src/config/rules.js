// Mirrors the business rules in the API (server/config/rules.js).
// Attendees -> teams required.
export const TEAM_TIERS = [
  { attendees: '1 – 100', teams: 1 },
  { attendees: '101 – 200', teams: 2 },
  { attendees: '201 – 300', teams: 3 },
  { attendees: '301 – 400', teams: 4 },
  { attendees: '401 – 500', teams: 5 },
];
