// Booking statuses from the EventHub flow. A status is shown as a badge and as different actions
// inside Booking Details; it is never its own page.
export const STATUS = {
  pending_approval: { label: 'Pending Approval', tone: 'yellow' },
  payment_required: { label: 'Approved — Payment Required', tone: 'orange' },
  payment_verification: { label: 'Payment Verification', tone: 'sky' },
  confirmed: { label: 'Confirmed', tone: 'green' },
  ongoing: { label: 'Ongoing', tone: 'blue' },
  completed_pending_final: { label: 'Completed — Final Payment Due', tone: 'purple' },
  fully_paid: { label: 'Completed / Fully Paid', tone: 'green' },
  rejected: { label: 'Rejected', tone: 'red' },
  cancelled: { label: 'Cancelled', tone: 'gray' },
  payment_expired: { label: 'Payment Expired', tone: 'red' },
  payment_overdue: { label: 'Payment Overdue', tone: 'red' },
};

export const REQUEST_STATUSES = ['pending_approval', 'payment_required', 'payment_verification', 'rejected', 'payment_expired', 'cancelled'];
export const EVENT_STATUSES = ['confirmed', 'ongoing', 'completed_pending_final', 'payment_overdue', 'fully_paid'];
export const ARCHIVABLE = ['fully_paid', 'rejected', 'payment_expired', 'cancelled'];

// Where a booking's detail page lives for each role.
export const bookingPath = (role, b) => {
  if (role === 'user') return `/my-events/${b._id}`;
  const isEvent = EVENT_STATUSES.includes(b.status);
  if (role === 'admin') return b.isArchived ? `/admin/archive/${b._id}` : isEvent ? `/admin/events/${b._id}` : `/admin/booking-requests/${b._id}`;
  return isEvent ? `/organizer/my-events/${b._id}` : `/organizer/booking-requests/${b._id}`;
};
