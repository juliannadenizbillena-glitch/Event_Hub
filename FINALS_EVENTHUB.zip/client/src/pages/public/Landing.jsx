import { Link } from 'react-router-dom';
import {
  ArrowRight,
  CalendarDays,
  CheckCircle2,
  MapPin,
  PackageCheck,
  ShieldCheck,
  Users,
} from 'lucide-react';
import PublicLayout from '../../components/PublicLayout';
import { useAuth } from '../../context/AuthContext';
import { ROLE_HOME } from '../../config/navigation';

const EVENT_TYPES = [
  'Workshop',
  'Conference',
  'Seminar',
  'Training',
  'Summit',
  'Networking Event',
  'Hackathon',
  'Career Fair',
  'Product Launch',
  'Panel Discussion',
  'Exhibition',
];

const BRANCHES = [
  'Manila Branch',
  'Makati Branch',
  'Quezon City Branch',
  'Cebu Branch',
  'Davao Branch',
];

const BUNDLES = [
  {
    name: 'Basic',
    description: 'Essential arrangements for straightforward events.',
    features: ['Venue and basic setup', 'Essential event equipment', 'Assigned event team'],
  },
  {
    name: 'Standard',
    description: 'Additional support for more involved gatherings.',
    features: ['Venue and event setup', 'Additional equipment options', 'Event team coordination'],
  },
  {
    name: 'Premium',
    description: 'A more comprehensive setup for larger productions.',
    features: ['Enhanced venue arrangement', 'Expanded equipment options', 'Production support'],
  },
  {
    name: 'Executive',
    description: 'Comprehensive arrangements for high-touch events.',
    features: ['Premium event arrangement', 'Expanded service options', 'Coordinated event support'],
  },
];

const SERVICES = [
  {
    title: 'Conferences & summits',
    description: 'Venue arrangements and presentation support for professional gatherings.',
    image: 'https://images.unsplash.com/photo-1505373877841-8d25f7d46678?auto=format&fit=crop&w=1000&q=85',
    alt: 'Audience attending a professional conference',
  },
  {
    title: 'Seminars & workshops',
    description: 'Purposeful spaces for training, discussion and collaborative learning.',
    image: 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1000&q=85',
    alt: 'Seminar event space',
  },
  {
    title: 'Product launches',
    description: 'Event layouts and production support for important brand moments.',
    image: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=1000&q=85',
    alt: 'Live event with stage lighting',
  },
  {
    title: 'Corporate functions',
    description: 'Considered venue setups for company gatherings and celebrations.',
    image: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1000&q=85',
    alt: 'Prepared event venue with banquet tables',
  },
];

const STEPS = [
  {
    number: '01',
    title: 'Submit your event details',
    description: 'Choose an event type, branch, date, time and attendee count.',
  },
  {
    number: '02',
    title: 'Select your setup',
    description: 'Review available bundles, add-ons and the requirements for your event.',
  },
  {
    number: '03',
    title: 'Track your booking',
    description: 'Follow the approval, payment and event status from your account.',
  },
];

export default function Landing() {
  const { user } = useAuth();

  // Visitors must sign in before starting a booking. Registration remains available
  // from the public header for visitors who need an account.
  const primaryLink = !user
    ? '/login'
    : user.role === 'user'
      ? '/book-event'
      : ROLE_HOME[user.role] || '/';

  const primaryLabel = !user
    ? 'Log in to book'
    : user.role === 'user'
      ? 'Book an event'
      : 'Go to dashboard';

  return (
    <PublicLayout>
      <main className="overflow-hidden bg-white text-[#23233A]">
        {/* Hero */}
        <section className="relative isolate min-h-[590px] overflow-hidden bg-[#23233A] lg:min-h-[660px]">
          <img
            src="https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=2200&q=90"
            alt="Professionally prepared event venue"
            className="absolute inset-0 -z-20 h-full w-full object-cover"
          />
          <div className="absolute inset-0 -z-10 bg-gradient-to-r from-[#14142B]/95 via-[#23233A]/80 to-[#23233A]/20" />

          <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 py-24 sm:px-8 lg:min-h-[660px] lg:grid-cols-[1.15fr_0.85fr] lg:py-28">
            <div className="max-w-2xl text-white">
              <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[#DAD7F5]">
                EVENT MANAGEMENT · EVENTHUB
              </p>
              <h1 className="mt-6 max-w-2xl text-4xl font-semibold leading-[1.12] tracking-tight sm:text-5xl lg:text-6xl">
                A better setting for
                <span className="mt-2 block text-[#DAD7F5]">your next event.</span>
              </h1>
              <p className="mt-6 max-w-xl text-base leading-7 text-white/80 sm:text-lg sm:leading-8">
                Plan conferences, seminars and corporate gatherings with coordinated
                venues, event setups and booking support in one place.
              </p>
              <div className="mt-9 flex flex-wrap gap-3">
                <Link
                  to={primaryLink}
                  className="inline-flex min-h-12 items-center rounded-xl justify-center gap-2 bg-[#DAD7F5] px-6 py-3 text-sm font-semibold text-[#23233A] transition hover:bg-white"
                >
                  {primaryLabel}
                  <ArrowRight size={18} />
                </Link>
                <a
                  href="#services"
                  className="inline-flex min-h-12 items-center rounded-xl justify-center border border-white/50 px-6 py-3 text-sm font-semibold text-white transition hover:bg-white/10"
                >
                  Explore event services
                </a>
              </div>
              <div className="mt-10 flex flex-wrap gap-x-7 gap-y-3 text-sm text-white/80">
                <span className="flex items-center gap-2">
                  <CheckCircle2 size={17} className="text-[#DAD7F5]" />
                  Coordinated event teams
                </span>
                <span className="flex items-center gap-2">
                  <CheckCircle2 size={17} className="text-[#DAD7F5]" />
                  Five branch locations
                </span>
              </div>
            </div>

          </div>
        </section>

        {/* Service overview */}
        <section id="services" className="scroll-mt-24 bg-[#F7F7FB]">
          <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 lg:py-24">
            <div className="grid gap-8 lg:grid-cols-[0.85fr_1.15fr] lg:items-end">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#5B52B9]">
                  Event services
                </p>
                <h2 className="mt-4 text-3xl font-semibold leading-tight tracking-tight text-[#23233A] sm:text-4xl">
                  Well planned, from venue to setup.
                </h2>
              </div>
              <div className="max-w-2xl lg:justify-self-end">
                <p className="leading-7 text-[#6B6B85]">
                  EventHub brings key planning details together so your team can review
                  the event requirements, available arrangements and booking progress
                  in one organized workflow.
                </p>
                <Link
                  to={primaryLink}
                  className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-[#23233A] underline decoration-[#5B52B9] decoration-2 underline-offset-4 hover:text-[#5B52B9]"
                >
                  {user?.role === 'user' ? 'Start a booking' : !user ? 'Log in to book' : 'Go to dashboard'}
                  <ArrowRight size={16} />
                </Link>
              </div>
            </div>

            <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {SERVICES.map((service, index) => (
                <article key={service.title} className="group bg-white">
                  <div className="aspect-[4/3] overflow-hidden rounded-2xl bg-[#E7E7F1]">
                    <img
                      src={service.image}
                      alt={service.alt}
                      loading="lazy"
                      className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.03]"
                    />
                  </div>
                  <div className="border-b border-[#E7E7F1] px-1 py-5">
                    <p className="text-xs font-semibold tracking-[0.16em] text-[#5B52B9]">
                      0{index + 1}
                    </p>
                    <h3 className="mt-2 text-lg font-semibold text-[#23233A]">{service.title}</h3>
                    <p className="mt-2 text-sm leading-6 text-[#6B6B85]">{service.description}</p>
                    <Link
                      to={primaryLink}
                      className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-[#23233A] hover:text-[#5B52B9]"
                    >
                      View booking options <ArrowRight size={15} />
                    </Link>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* Event types */}
        <section className="bg-white">
          <div className="mx-auto grid max-w-7xl gap-8 px-5 py-20 sm:px-8 lg:grid-cols-[0.8fr_1.2fr] lg:gap-16 lg:py-24">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#5B52B9]">
                Event formats
              </p>
              <h2 className="mt-4 text-3xl font-semibold leading-tight tracking-tight text-[#23233A] sm:text-4xl">
                Space for different ideas and audiences.
              </h2>
              <p className="mt-5 leading-7 text-[#6B6B85]">
                Select the event format that best matches your objectives, audience and
                programme when you submit a booking request.
              </p>
            </div>
            <div className="grid content-start sm:grid-cols-2">
              {EVENT_TYPES.map((type, index) => (
                <div key={type} className="flex items-center gap-4 border-b border-[#E7E7F1] py-4">
                  <span className="w-7 shrink-0 text-xs font-semibold text-[#5B52B9]">
                    {String(index + 1).padStart(2, '0')}
                  </span>
                  <span className="text-sm font-medium text-[#23233A]">{type}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Booking steps */}
        <section id="how-it-works" className="scroll-mt-24 bg-[#F1F1F8]">
          <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 lg:py-24">
            <div className="max-w-2xl">
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#5B52B9]">
                Booking process
              </p>
              <h2 className="mt-4 text-3xl font-semibold leading-tight tracking-tight text-[#23233A] sm:text-4xl">
                Three steps to get started.
              </h2>
            </div>
            <div className="mt-10 grid gap-8 md:grid-cols-3">
              {STEPS.map((step) => (
                <article key={step.number} className="border-t-2 border-[#5B52B9] pt-5">
                  <p className="text-sm font-semibold tracking-[0.16em] text-[#5B52B9]">
                    {step.number}
                  </p>
                  <h3 className="mt-4 text-xl font-semibold text-[#23233A]">{step.title}</h3>
                  <p className="mt-3 text-sm leading-7 text-[#6B6B85]">{step.description}</p>
                </article>
              ))}
            </div>
            <Link
              to={primaryLink}
              className="mt-10 inline-flex items-center gap-2 rounded-xl bg-[#23233A] px-6 py-3.5 text-sm font-semibold text-white transition hover:bg-[#4A4296]"
            >
              {primaryLabel} <ArrowRight size={17} />
            </Link>
          </div>
        </section>

        {/* Bundles */}
        <section id="bundles" className="scroll-mt-24 bg-white">
          <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 lg:py-24">
            <div className="grid gap-6 lg:grid-cols-[0.8fr_1.2fr] lg:items-end">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#5B52B9]">
                  Event bundles
                </p>
                <h2 className="mt-4 text-3xl font-semibold leading-tight tracking-tight text-[#23233A] sm:text-4xl">
                  Choose the level of support.
                </h2>
              </div>
              <p className="max-w-2xl leading-7 text-[#6B6B85] lg:justify-self-end">
                Basic, Standard, Premium and Executive options provide a starting point
                for planning. Confirm the actual inclusions and prices in the booking
                options, where current configured details are displayed.
              </p>
            </div>

            <div className="mt-10 grid gap-0 border-y border-[#E7E7F1] sm:grid-cols-2 lg:grid-cols-4 lg:divide-x lg:divide-[#E7E7F1]">
              {BUNDLES.map((bundle, index) => (
                <article key={bundle.name} className="flex flex-col px-5 py-7 first:pl-0 last:pr-0">
                  <p className="text-xs font-semibold tracking-[0.18em] text-[#5B52B9]">
                    PACKAGE 0{index + 1}
                  </p>
                  <h3 className="mt-3 text-xl font-semibold text-[#23233A]">{bundle.name}</h3>
                  <p className="mt-3 min-h-[4.5rem] text-sm leading-6 text-[#6B6B85]">
                    {bundle.description}
                  </p>
                  <ul className="mt-4 flex-1 space-y-3">
                    {bundle.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-2 text-sm leading-6 text-[#23233A]">
                        <CheckCircle2 size={16} className="mt-1 shrink-0 text-[#5B52B9]" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Link
                    to={primaryLink}
                    className="mt-7 inline-flex items-center gap-2 border-t border-[#E7E7F1] pt-4 text-sm font-semibold text-[#23233A] hover:text-[#5B52B9]"
                  >
                    View options <ArrowRight size={15} />
                  </Link>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* Branches */}
        <section id="branches" className="scroll-mt-24 bg-[#F7F7FB]">
          <div className="mx-auto grid max-w-7xl gap-10 px-5 py-20 sm:px-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-center lg:py-24">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#5B52B9]">
                Our locations
              </p>
              <h2 className="mt-4 text-3xl font-semibold leading-tight tracking-tight text-[#23233A] sm:text-4xl">
                Five branches. One booking process.
              </h2>
              <p className="mt-5 max-w-lg leading-7 text-[#6B6B85]">
                Choose your preferred branch when submitting a request. Dates and team
                availability are checked as part of the booking process.
              </p>
              <Link
                to={primaryLink}
                className="mt-7 inline-flex items-center gap-2 text-sm font-semibold text-[#23233A] underline decoration-[#5B52B9] decoration-2 underline-offset-4 hover:text-[#5B52B9]"
              >
                Check booking options <ArrowRight size={16} />
              </Link>
            </div>
            <div className="grid border-t border-[#E3E3EE] sm:grid-cols-2 sm:border-l">
              {BRANCHES.map((branch, index) => (
                <div key={branch} className="flex items-center gap-4 border-b border-[#E3E3EE] px-4 py-5 sm:border-l">
                  <MapPin size={19} className="shrink-0 text-[#5B52B9]" />
                  <div>
                    <p className="text-xs font-semibold tracking-[0.16em] text-[#5B52B9]">
                      LOCATION 0{index + 1}
                    </p>
                    <p className="mt-1 font-medium text-[#23233A]">{branch}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Closing call to action */}
        <section className="bg-[#23233A] text-white">
          <div className="mx-auto grid max-w-7xl gap-8 px-5 py-16 sm:px-8 md:grid-cols-[1fr_auto] md:items-center lg:py-20">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#DAD7F5]">
                EventHub
              </p>
              <h2 className="mt-4 max-w-2xl text-3xl font-semibold leading-tight tracking-tight sm:text-4xl">
                Start planning your next event.
              </h2>
              <p className="mt-4 max-w-2xl leading-7 text-white/75">
                Submit your requirements and follow your booking through approval,
                payment and event preparation.
              </p>
            </div>
            <div className="flex flex-wrap gap-3 md:flex-col">
              <Link
                to={primaryLink}
                className="inline-flex min-h-12 items-center rounded-xl justify-center gap-2 bg-[#DAD7F5] px-6 py-3 text-sm font-semibold text-[#23233A] transition hover:bg-white"
              >
                {primaryLabel} <ArrowRight size={17} />
              </Link>
              {!user && (
                <Link
                  to="/register"
                  className="inline-flex min-h-12 items-center rounded-xl justify-center border border-white/40 px-6 py-3 text-sm font-semibold text-white transition hover:bg-white/10"
                >
                  Create account
                </Link>
              )}
            </div>
          </div>
        </section>

        {/* Brief service details */}
        <section className="border-t border-[#E7E7F1] bg-white">
          <div className="mx-auto grid max-w-7xl gap-5 px-5 py-7 text-sm text-[#6B6B85] sm:grid-cols-3 sm:px-8">
            <p className="flex items-center gap-3">
              <CalendarDays size={18} className="shrink-0 text-[#5B52B9]" />
              Booking and schedule tracking
            </p>
            <p className="flex items-center gap-3">
              <Users size={18} className="shrink-0 text-[#5B52B9]" />
              Assigned event teams
            </p>
            <p className="flex items-center gap-3">
              <ShieldCheck size={18} className="shrink-0 text-[#5B52B9]" />
              Booking status visibility
            </p>
          </div>
        </section>
      </main>
    </PublicLayout>
  );
}
