import PublicLayout from '../../components/PublicLayout';

const Page = ({ title, intro, children }) => (
  <PublicLayout>
    <div className="mx-auto max-w-3xl px-5 py-14 sm:px-8">
      <h1 className="text-3xl font-bold text-navy">{title}</h1>
      {intro && <p className="mt-3 text-steel">{intro}</p>}
      <div className="mt-8 space-y-6 text-sm leading-relaxed text-navy">{children}</div>
    </div>
  </PublicLayout>
);
const H = ({ children }) => <h2 className="text-lg font-semibold text-navy">{children}</h2>;

export function About() {
  return (
    <Page title="About EventHub" intro="EventHub Event Management Services helps companies and organizations run their own events.">
      <section><H>What we do</H><p>EventHub is an event management service, not an event marketplace. A company creates its own booking, chooses a branch, date, bundle and add-ons, and EventHub provides the venue, equipment, staff and teams to deliver it.</p></section>
      <section><H>How it works</H><p>A company books an event and EventHub reviews the request. After approval the company pays a 50% down payment to confirm the date. EventHub's organizers then prepare and run the event. After the event the remaining balance, plus any verified damage, is settled and the event is completed.</p></section>
      <section><H>Where we operate</H><p>Manila, Makati, Quezon City, Cebu and Davao, with trained teams for 11 event types: workshops, conferences, seminars, training, summits, networking events, hackathons, career fairs, product launches, panel discussions and exhibitions.</p></section>
    </Page>
  );
}

export function Contact() {
  return (
    <Page title="Contact" intro="Questions about a booking or an event? Reach EventHub through any of these.">
      <section><H>General inquiries</H><p>Email: hello@eventhub.example<br />Phone: +63 2 8000 0000<br />Hours: Monday to Saturday, 8:00 AM to 6:00 PM (Philippine Time)</p></section>
      <section><H>Branches</H><ul className="list-disc space-y-1 pl-5"><li>Manila Branch</li><li>Makati Branch</li><li>Quezon City Branch</li><li>Cebu Branch</li><li>Davao Branch</li></ul></section>
      <section><H>Existing customers</H><p>Log in to see the status of your bookings, payments and events. Account and booking questions are answered fastest through your booking page.</p></section>
    </Page>
  );
}

export function Privacy() {
  return (
    <Page title="Privacy Policy" intro="How EventHub handles your information.">
      <section><H>Information we collect</H><p>Your name, company, contact email, phone number, event details and payment references. We never store passwords in readable form.</p></section>
      <section><H>How we use it</H><p>To verify your account, process bookings and payments, run your events, and send important notices to your registered contact email, including your EventHub account information.</p></section>
      <section><H>Who can see it</H><p>Only the EventHub staff who need it. Organizers see the event details they need to run an event, not prices or payments. Receipts and uploaded photos are private and are available only to authorised users.</p></section>
      <section><H>Security</H><p>Sessions are protected, sensitive codes are stored hashed and expire, and every action is checked on the server against your role.</p></section>
    </Page>
  );
}

export function Terms() {
  return (
    <Page title="Terms & Conditions" intro="By submitting a booking you agree to the following.">
      <section><H>Cancellation</H><p>Once a booking is confirmed, the 50% down payment is non-refundable if you cancel the event.</p></section>
      <section><H>Damage</H><p>You are responsible for verified damage to EventHub equipment, EventHub property, the venue and other provided resources.</p></section>
      <section><H>Damage fee</H><p>Approved damage charges are added to the remaining balance after the event. Only damage approved by EventHub Admin is charged.</p></section>
      <section><H>Payment</H><p>After your booking is approved you have 24 hours to pay the 50% down payment. The remaining balance, plus any approved damage, is paid after the event. Bookings are blocked while a final balance is overdue.</p></section>
    </Page>
  );
}
