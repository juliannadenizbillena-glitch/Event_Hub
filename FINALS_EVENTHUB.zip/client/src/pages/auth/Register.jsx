import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import AuthLayout from '../../components/AuthLayout';
import Field from '../../components/Field';
import Button from '../../components/Button';
import Alert from '../../components/Alert';
import PasswordRules from '../../components/PasswordRules';
import useForm from '../../hooks/useForm';
import { rules } from '../../utils/validators';
import api, { errorCode, errorMessage, fieldErrors } from '../../api/client';

const RULES = {
  firstName: rules.name('first name'),
  lastName: rules.name('last name'),
  companyName: rules.required('This field is required.'),
  contactEmail: rules.contactEmail(),
  phone: rules.phone,
  password: rules.password,
  confirmPassword: rules.confirm('password'),
};

// The email entered here is only your CONTACT email (verification and notices). Your EventHub
// login email is generated after you verify it.
export default function Register() {
  const navigate = useNavigate();
  const form = useForm({ firstName: '', lastName: '', companyName: '', contactEmail: '', phone: '', password: '', confirmPassword: '' }, RULES);
  const [formError, setFormError] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setFormError('');
    if (!form.validateAll()) return;
    setLoading(true);
    try {
      const v = form.values;
      const contactEmail = v.contactEmail.trim().toLowerCase();
      await api.post('/auth/register', {
        firstName: v.firstName.trim(), lastName: v.lastName.trim(), companyName: v.companyName.trim(),
        contactEmail, phone: v.phone.trim(), password: v.password, confirmPassword: v.confirmPassword,
      });
      sessionStorage.setItem('eh_verify_email', contactEmail);
      navigate('/verify-email', { state: { contactEmail, fromRegister: true } });
    } catch (err) {
      const fe = fieldErrors(err);
      if (errorCode(err) === 'EMAIL_TAKEN') fe.contactEmail = 'An account with this email already exists.';
      form.setServerErrors(fe);
      if (!Object.keys(fe).length) setFormError(errorMessage(err));
      else form.validateFields([]); // keep focus behaviour consistent
    } finally { setLoading(false); }
  };

  const pw = form.field('password');
  return (
    <AuthLayout
      title="Create your account"
      subtitle="Register your company to start booking events."
      footer={<>Already have an account? <Link to="/login" className="font-semibold text-navy hover:underline">Log in</Link></>}
    >
      <form onSubmit={submit} noValidate className="space-y-4">
        <Alert type="error">{formError}</Alert>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="First name" placeholder="e.g. Juan" autoComplete="given-name" {...form.field('firstName')} />
          <Field label="Last name" placeholder="e.g. Dela Cruz" autoComplete="family-name" {...form.field('lastName')} />
        </div>
        <Field label="Company / organization name" placeholder="e.g. ABC Corporation" autoComplete="organization" {...form.field('companyName')} />
        <Field label="Email address" type="email" placeholder="e.g. juan.delacruz@gmail.com" autoComplete="email" {...form.field('contactEmail')} />
        <Field label="Phone number" type="tel" placeholder="09XXXXXXXXX" autoComplete="tel" {...form.field('phone')} />
        <Field label="Password" type="password" placeholder="Enter your password" autoComplete="new-password" {...pw} />
        <PasswordRules password={form.values.password} visible={form.isFocused('password') || (form.isTouched('password') && !!pw.error)} />
        <Field label="Confirm password" type="password" placeholder="Re-enter your password" autoComplete="new-password" {...form.field('confirmPassword')} />
        <Button type="submit" full loading={loading} className="mt-2">Create account</Button>
      </form>
    </AuthLayout>
  );
}
