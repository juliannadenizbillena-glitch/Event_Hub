import { useState } from 'react';
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import AuthLayout from '../../components/AuthLayout';
import CodeInput from '../../components/CodeInput';
import Field from '../../components/Field';
import Button from '../../components/Button';
import Alert from '../../components/Alert';
import PasswordRules from '../../components/PasswordRules';
import useForm from '../../hooks/useForm';
import useCountdown from '../../hooks/useCountdown';
import { rules } from '../../utils/validators';
import api, { errorCode, errorMessage, fieldErrors } from '../../api/client';

// Steps 2 and 3 of 3: verify the code, then choose a new password.
export default function ResetPassword() {
  const navigate = useNavigate();
  const { state } = useLocation();
  const email = state?.email || sessionStorage.getItem('eh_reset_email');

  const [step, setStep] = useState('code'); // 'code' | 'password'
  const [code, setCode] = useState('');
  const [resetToken, setResetToken] = useState('');
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [loading, setLoading] = useState(false);
  const [left, startCountdown] = useCountdown(state?.justSent ? 60 : 0);
  const form = useForm({ password: '', confirmPassword: '' }, { password: rules.password, confirmPassword: rules.confirm('password') });

  if (!email) return <Navigate to="/forgot-password" replace />;

  const resend = async () => {
    setError(''); setInfo('');
    try {
      await api.post('/auth/forgot-password', { email });
      setInfo('If that email is registered, a new code has been sent.');
      startCountdown(60);
    } catch (err) { setError(errorMessage(err)); }
  };

  const verifyCode = async (e) => {
    e.preventDefault();
    setError(''); setInfo(''); setLoading(true);
    try {
      const res = await api.post('/auth/verify-reset-code', { email, code });
      setResetToken(res.data.resetToken);
      setStep('password');
    } catch (err) {
      setError(errorMessage(err));
      if (errorCode(err) !== 'INVALID_CODE') setCode('');
    } finally { setLoading(false); }
  };

  const changePassword = async (e) => {
    e.preventDefault();
    setError('');
    if (!form.validateAll()) return;
    setLoading(true);
    try {
      const res = await api.post('/auth/reset-password', { resetToken, password: form.values.password, confirmPassword: form.values.confirmPassword });
      sessionStorage.removeItem('eh_reset_email');
      navigate('/login', { replace: true, state: { flash: res.data.message } });
    } catch (err) {
      form.setServerErrors(fieldErrors(err));
      setError(errorMessage(err));
      if (errorCode(err) === 'BAD_RESET_TOKEN') { setStep('code'); setCode(''); setResetToken(''); }
    } finally { setLoading(false); }
  };

  if (step === 'password') {
    const pw = form.field('password');
    return (
      <AuthLayout title="Choose a new password">
        <form onSubmit={changePassword} noValidate className="space-y-4">
          <Alert type="error">{error}</Alert>
          <Field label="New password" type="password" placeholder="Enter your new password" autoComplete="new-password" {...pw} />
          <PasswordRules password={form.values.password} visible={form.isFocused('password') || (form.isTouched('password') && !!pw.error)} />
          <Field label="Confirm password" type="password" placeholder="Re-enter your new password" autoComplete="new-password" {...form.field('confirmPassword')} />
          <Button type="submit" full loading={loading}>Change password</Button>
        </form>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout
      title="Enter your code"
      subtitle="Enter the 6-digit code we sent to the contact email on your account."
      footer={<Link to="/forgot-password" className="font-semibold text-navy hover:underline">Use a different email</Link>}
    >
      <form onSubmit={verifyCode} className="space-y-5">
        <CodeInput value={code} onChange={(v) => { setCode(v); setError(''); }} error={!!error} disabled={loading} />
        <Alert type="error">{error}</Alert>
        <Alert type="success">{info}</Alert>
        <Button type="submit" full loading={loading} disabled={code.length !== 6}>Verify code</Button>
        <p className="text-center text-sm text-steel">
          Did not get it?{' '}
          {left > 0
            ? <span>Resend in {left}s</span>
            : <button type="button" onClick={resend} className="font-semibold text-navy hover:underline">Resend code</button>}
        </p>
      </form>
    </AuthLayout>
  );
}
