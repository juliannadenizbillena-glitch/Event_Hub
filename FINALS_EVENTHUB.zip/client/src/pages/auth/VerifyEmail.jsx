import { useEffect, useRef, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { CheckCircle2 } from 'lucide-react';
import AuthLayout from '../../components/AuthLayout';
import CodeInput from '../../components/CodeInput';
import Field from '../../components/Field';
import Button from '../../components/Button';
import Alert from '../../components/Alert';
import useForm from '../../hooks/useForm';
import useCountdown from '../../hooks/useCountdown';
import { rules } from '../../utils/validators';
import api, { errorCode, errorMessage } from '../../api/client';

const VERIFIED_KEY = 'eh_verified_account';
const readVerified = () => { try { return JSON.parse(sessionStorage.getItem(VERIFIED_KEY) || 'null'); } catch { return null; } };

export default function VerifyEmail() {
  const navigate = useNavigate();
  const { state } = useLocation();
  const [contactEmail, setContactEmail] = useState(state?.contactEmail || sessionStorage.getItem('eh_verify_email') || '');
  const [verified, setVerified] = useState(readVerified); // { accountEmail } once verification succeeded
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [loading, setLoading] = useState(false);
  const [left, startCountdown] = useCountdown(state?.fromRegister ? 60 : 0);
  const emailForm = useForm({ email: '' }, { email: rules.email() });
  const cleared = useRef(false);

  // One-time navigation state is dropped from history, so a refresh never replays old messages.
  useEffect(() => { if (state && !cleared.current) { cleared.current = true; navigate('/verify-email', { replace: true, state: null }); } }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const resend = async (target = contactEmail) => {
    setError(''); setInfo('');
    try {
      await api.post('/auth/resend-code', { contactEmail: target });
      setInfo('A new code was sent.');
      startCountdown(60);
    } catch (err) { setError(errorMessage(err)); }
  };

  const submit = async (e) => {
    e.preventDefault();
    setError(''); setInfo('');
    setLoading(true);
    try {
      const res = await api.post('/auth/verify-email', { contactEmail, code });
      sessionStorage.removeItem('eh_verify_email');
      sessionStorage.setItem(VERIFIED_KEY, JSON.stringify({ verified: true })); // so a refresh keeps the confirmation
      setVerified({ verified: true });
    } catch (err) {
      setError(errorMessage(err));
      if (errorCode(err) !== 'INVALID_CODE') setCode('');
    } finally { setLoading(false); }
  };

  // ---------- Verified: the account information was SENT BY EMAIL; it is never shown on the website ----------
  if (verified) {
    const goToLogin = () => {
      sessionStorage.removeItem(VERIFIED_KEY);
      navigate('/login', { state: { flash: 'Email verified. You can now log in.' } });
    };
    return (
      <AuthLayout title="Email verified successfully.">
        <div className="space-y-6">
          <div className="flex items-start gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-4 text-sm text-emerald-900">
            <CheckCircle2 size={22} className="mt-0.5 shrink-0" />
            <p data-testid="verified-message">Your EventHub account information has been sent to your registered email address.</p>
          </div>
          <Button full onClick={goToLogin}>Continue to Login</Button>
        </div>
      </AuthLayout>
    );
  }

  // ---------- No email known (opened directly): ask for the contact email ----------
  if (!contactEmail) {
    return (
      <AuthLayout title="Verify your email" subtitle="Enter the email address you registered with." footer={<Link to="/login" className="font-semibold text-navy hover:underline">Back to login</Link>}>
        <form
          className="space-y-4" noValidate
          onSubmit={(e) => {
            e.preventDefault();
            if (!emailForm.validateAll()) return;
            const value = emailForm.values.email.trim().toLowerCase();
            sessionStorage.setItem('eh_verify_email', value); setContactEmail(value); resend(value);
          }}
        >
          <Alert type="error">{error}</Alert>
          <Field label="Email address" type="email" placeholder="e.g. juan.delacruz@gmail.com" autoComplete="email" {...emailForm.field('email')} />
          <Button type="submit" full>Send code</Button>
        </form>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout
      title="Verify your email"
      subtitle={<>Enter the 6-digit code sent to <span className="font-semibold text-navy">{contactEmail}</span>.</>}
      footer={<>Wrong email? <Link to="/register" className="font-semibold text-navy hover:underline">Register again</Link></>}
    >
      <form onSubmit={submit} className="space-y-5">
        <CodeInput value={code} onChange={(v) => { setCode(v); setError(''); }} error={!!error} disabled={loading} />
        <Alert type="error">{error}</Alert>
        <Alert type="success">{info}</Alert>
        <Button type="submit" full loading={loading} disabled={code.length !== 6}>Verify email</Button>
        <p className="text-center text-sm text-steel">
          Did not get it?{' '}
          {left > 0
            ? <span>Resend in {left}s</span>
            : <button type="button" onClick={() => resend()} className="font-semibold text-navy hover:underline">Resend code</button>}
        </p>
      </form>
    </AuthLayout>
  );
}
