import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import AuthLayout from '../../components/AuthLayout';
import Field from '../../components/Field';
import Button from '../../components/Button';
import Alert from '../../components/Alert';
import useForm from '../../hooks/useForm';
import { rules } from '../../utils/validators';
import api, { errorMessage, fieldErrors } from '../../api/client';


export default function ForgotPassword() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const form = useForm({ email: params.get('email') || '' }, { email: rules.email() });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (!form.validateAll()) return;
    const email = form.values.email.trim().toLowerCase();
    setLoading(true);
    try {
      await api.post('/auth/forgot-password', { email });
      sessionStorage.setItem('eh_reset_email', email);
      navigate('/reset-password', { state: { email, justSent: true } });
    } catch (err) {
      const fe = fieldErrors(err);
      form.setServerErrors(fe);
      if (!Object.keys(fe).length) setError(errorMessage(err));
    } finally { setLoading(false); }
  };

  return (
    <AuthLayout
      title="Forgot your password?"
      footer={<Link to="/login" className="font-semibold text-navy hover:underline">Back to login</Link>}
    >
      <form onSubmit={submit} noValidate className="space-y-4">
        <Alert type="error">{error}</Alert>
        <Field
         label="Email Address"
         type="email"
         placeholder="e.g. juandelacruz@gmail.com"
         autoComplete="username"
        {...form.field('email')}
/>
        <Button type="submit" full loading={loading}>Send code</Button>
      </form>
    </AuthLayout>
  );
}
