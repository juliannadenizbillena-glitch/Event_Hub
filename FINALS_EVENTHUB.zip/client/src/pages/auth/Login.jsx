import { useEffect, useRef, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import AuthLayout from '../../components/AuthLayout';
import Field from '../../components/Field';
import Button from '../../components/Button';
import Alert from '../../components/Alert';
import useForm from '../../hooks/useForm';
import { useAuth } from '../../context/AuthContext';
import { ROLE_HOME } from '../../config/navigation';
import { rules } from '../../utils/validators';
import { errorMessage } from '../../api/client';

// Login always uses the generated EventHub ACCOUNT email, never the real contact email.
export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { state } = location;
  const [flash, setFlash] = useState(state?.flash || ''); // one-time message (e.g. after verification)
  const [error, setError] = useState('');                  // only after a real failed login
  const [loading, setLoading] = useState(false);
  const form = useForm({ accountEmail: '', password: '' }, {
    accountEmail: rules.email(),
    password: rules.required('This field is required.'),
  });
  const cleared = useRef(false);

  // The message and prefilled email are one-time: drop them from history so a refresh starts clean.
  useEffect(() => { if (state && !cleared.current) { cleared.current = true; navigate(location.pathname, { replace: true, state: null }); } }, []); // eslint-disable-line react-hooks/exhaustive-deps
  // Success messages are temporary.
  useEffect(() => { if (!flash) return undefined; const t = setTimeout(() => setFlash(''), 8000); return () => clearTimeout(t); }, [flash]);

  const field = (name) => {
    const f = form.field(name);
    return { ...f, onChange: (e) => { f.onChange(e); setError(''); setFlash(''); } }; // stale messages clear as soon as the person edits
  };

  const submit = async (e) => {
    e.preventDefault();
    setError(''); setFlash('');
    if (!form.validateAll()) return;
    setLoading(true);
    try {
      const user = await login(form.values.accountEmail.trim().toLowerCase(), form.values.password);
      navigate(state?.from?.pathname && state.from.pathname !== '/' ? state.from.pathname : ROLE_HOME[user.role], { replace: true });
    } catch (err) {
      setError(errorMessage(err)); // "Invalid email or password." appears only after a real failed attempt
      setLoading(false);
    }
  };

  return (
    <AuthLayout
      title="Welcome back"
      subtitle="Log in to manage your events."
      footer={<>New to EventHub? <Link to="/register" className="font-semibold text-navy hover:underline">Create an account</Link></>}
    >
      <form onSubmit={submit} noValidate className="space-y-4">
        {flash && !error && <Alert type="success">{flash}</Alert>}
        {error && <Alert type="error">{error}</Alert>}


        <Field label="Email Address" type="email" placeholder="Enter your email address" autoComplete="username" {...field('accountEmail')} />
        <div>
          <Field label="Password" type="password" placeholder="Enter your password" autoComplete="current-password" {...field('password')} />
          <div className="mt-2 text-right">
            <Link to="/forgot-password" className="text-sm font-medium text-steel hover:text-navy hover:underline">Forgot password?</Link>
          </div>
        </div>
        <Button type="submit" full loading={loading}>Log in</Button>
      </form>
    </AuthLayout>
  );
}
