import { useState } from 'react';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import LoadState from '../../components/LoadState';
import Select from '../../components/Select';
import Field from '../../components/Field';
import Card from '../../components/Card';
import StatCard from '../../components/StatCard';
import Button from '../../components/Button';
import Alert from '../../components/Alert';
import useLoad from '../../hooks/useLoad';
import { STATUS } from '../../config/bookingStatus';
import { formatDate, peso } from '../../utils/format';
import api, { errorMessage } from '../../api/client';

const COST_LABEL = { fuel: 'Fuel', transportation: 'Transportation', equipment: 'Equipment', utilities: 'Utilities', printing_materials: 'Printing / materials', cleaning: 'Cleaning', staff_transport_meals: 'Staff transport / meals', venue_preparation: 'Venue preparation', other: 'Other' };
const Bar = ({ value, max }) => <div className="h-2 w-full rounded-full bg-mist/40"><div className="h-2 rounded-full bg-sky" style={{ width: `${max ? Math.max((value / max) * 100, 2) : 0}%` }} /></div>;

export default function Reports() {
  const [filters, setFilters] = useState({ from: '', to: '', branch: '', eventType: '', status: '' });
  const [applied, setApplied] = useState(filters);
  const [dateError, setDateError] = useState('');
  const set = (k) => (e) => setFilters((f) => ({ ...f, [k]: e.target.value }));
  const lists = useLoad(async () => { const [b, t] = await Promise.all([api.get('/branches'), api.get('/event-types')]); return { branches: b.data.branches, types: t.data.eventTypes }; });
  const rep = useLoad(async () => (await api.get('/admin/reports', { params: Object.fromEntries(Object.entries(applied).filter(([, v]) => v)) })).data.report, [applied]);
  const apply = () => { if (filters.from && filters.to && filters.from > filters.to) return setDateError('The start date must not be after the end date.'); setDateError(''); setApplied(filters); };
  const reset = () => { const empty = { from: '', to: '', branch: '', eventType: '', status: '' }; setFilters(empty); setApplied(empty); setDateError(''); };
  const r = rep.data;
  const maxMonth = r ? Math.max(...r.events.byMonth.map((m) => m.revenue), 1) : 1;
  const maxType = r ? Math.max(...r.events.byType.map((m) => m.events), 1) : 1;

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <PageHeader title="Reports" subtitle="Bookings, revenue, outstanding payments, events, team usage, internal costs and profit. Archived bookings are included." />
      <Card>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <Field label="Event date from" type="date" value={filters.from} onChange={set('from')} />
          <Field label="Event date to" type="date" value={filters.to} onChange={set('to')} />
          <Select label="Branch" value={filters.branch} onChange={set('branch')}><option value="">All branches</option>{lists.data?.branches.map((b) => <option key={b._id} value={b._id}>{b.name}</option>)}</Select>
          <Select label="Event type" value={filters.eventType} onChange={set('eventType')}><option value="">All event types</option>{lists.data?.types.map((t) => <option key={t._id} value={t._id}>{t.name}</option>)}</Select>
          <Select label="Status" value={filters.status} onChange={set('status')}><option value="">All statuses</option>{Object.entries(STATUS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</Select>
        </div>
        <div className="mt-4 flex gap-3"><Button onClick={apply}>Apply filters</Button><Button variant="secondary" onClick={reset}>Reset</Button></div>
        {dateError && <div className="mt-3"><Alert type="error">{dateError}</Alert></div>}
      </Card>

      <LoadState loading={rep.loading} error={rep.error} hasData={!!r}>
        {r && (
          <>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <StatCard label="Total bookings" value={r.totals.bookings} testId="rep-bookings" /><StatCard label="Events held / scheduled" value={r.totals.events} hint={`${r.totals.attendees.toLocaleString('en-PH')} attendees`} />
              <StatCard label="Revenue collected" value={peso(r.revenue.collected)} testId="rep-revenue" hint={`Down ${peso(r.revenue.downPayments)} · Final ${peso(r.revenue.finalPayments)}`} />
              <StatCard label="Outstanding payments" value={peso(r.outstanding.total)} hint={`Due now ${peso(r.outstanding.dueNow)} · overdue ${r.outstanding.overdue.count}`} attention={r.outstanding.overdue.count > 0} />
              <StatCard label="Damage charges (approved)" value={peso(r.revenue.damageCharges)} /><StatCard label="Internal costs" value={peso(r.costs.total)} testId="rep-costs" />
              <StatCard label="Profit (revenue − costs)" value={peso(r.profit.profit)} testId="rep-profit" attention /><StatCard label="Team assignments" value={r.teamUsage.totalTeamAssignments} hint="Teams used across events" />
            </div>

            <div className="grid gap-6 lg:grid-cols-2">
              <Card title="Bookings by status">
                <ul className="space-y-2.5 text-sm text-navy">{Object.entries(r.totals.byStatus).map(([s, n]) => <li key={s}><div className="mb-1 flex justify-between"><span>{STATUS[s]?.label || s}</span><span className="font-semibold">{n}</span></div><Bar value={n} max={r.totals.bookings} /></li>)}</ul>
              </Card>
              <Card title="Events by event type">
                <ul className="space-y-2.5 text-sm text-navy">{r.events.byType.length === 0 && <li className="text-steel">No events in this selection.</li>}{r.events.byType.map((t) => <li key={t.key}><div className="mb-1 flex justify-between"><span>{t.label}</span><span className="font-semibold">{t.events} · {peso(t.revenue)}</span></div><Bar value={t.events} max={maxType} /></li>)}</ul>
              </Card>
              <Card title="Events and revenue by month">
                <ul className="space-y-2.5 text-sm text-navy">{r.events.byMonth.length === 0 && <li className="text-steel">No events in this selection.</li>}{r.events.byMonth.map((m) => <li key={m.key}><div className="mb-1 flex justify-between"><span>{m.label}</span><span className="font-semibold">{m.events} events · {peso(m.revenue)}</span></div><Bar value={m.revenue} max={maxMonth} /></li>)}</ul>
              </Card>
              <Card title="Internal costs by category">
                <ul className="space-y-2.5 text-sm text-navy">{r.costs.byCategory.length === 0 && <li className="text-steel">No costs recorded.</li>}{r.costs.byCategory.map((c) => <li key={c.category}><div className="mb-1 flex justify-between"><span>{COST_LABEL[c.category]}</span><span className="font-semibold">{peso(c.amount)}</span></div><Bar value={c.amount} max={r.costs.byCategory[0]?.amount} /></li>)}</ul>
              </Card>
            </div>

            <Card title="Events by branch">
              <DataTable rowKey="key" empty="No events in this selection." rows={r.events.byBranch} columns={[{ key: 'label', label: 'Branch' }, { key: 'events', label: 'Events' }, { key: 'attendees', label: 'Attendees' }, { key: 'revenue', label: 'Revenue', render: (x) => peso(x.revenue) }, { key: 'costs', label: 'Costs', render: (x) => peso(x.costs) }, { key: 'p', label: 'Profit', render: (x) => peso(x.revenue - x.costs) }]} />
            </Card>
            <Card title="Team usage">
              <DataTable rowKey="k" empty="No team usage." rows={r.teamUsage.rows.map((t) => ({ ...t, k: `${t.branch}${t.eventType}` }))} columns={[{ key: 'branch', label: 'Branch' }, { key: 'eventType', label: 'Event type' }, { key: 'events', label: 'Events' }, { key: 'teamsUsed', label: 'Teams used' }]} />
            </Card>
            <Card title="Event revenue, costs and profit">
              <DataTable rowKey="code" empty="No events in this selection." rows={r.rows} columns={[
                { key: 'code', label: 'Booking', render: (x) => <div><p className="font-semibold">{x.eventName}</p><p className="text-xs text-steel">{x.code} · {x.company}</p></div> }, { key: 'date', label: 'Date', render: (x) => formatDate(x.date) },
                { key: 'branch', label: 'Branch' }, { key: 'attendees', label: 'Guests' }, { key: 'collected', label: 'Collected', render: (x) => peso(x.collected) }, { key: 'damage', label: 'Damage', render: (x) => peso(x.damage) },
                { key: 'costs', label: 'Costs', render: (x) => peso(x.costs) }, { key: 'profit', label: 'Profit', render: (x) => peso(x.profit) }]} />
            </Card>
          </>
        )}
      </LoadState>
    </div>
  );
}
