import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArchiveRestore } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import LoadState from '../../components/LoadState';
import BookingStatusBadge from '../../components/BookingStatusBadge';
import Button from '../../components/Button';
import Select from '../../components/Select';
import Field from '../../components/Field';
import Alert from '../../components/Alert';
import useLoad from '../../hooks/useLoad';
import { ARCHIVABLE, STATUS } from '../../config/bookingStatus';
import { formatDate, formatDateTime, peso } from '../../utils/format';
import api, { errorMessage } from '../../api/client';

// The Archive holds finished HISTORICAL records (fully paid, rejected, expired, cancelled bookings).
// It is not the same as deactivating configuration, which stays in each module.
export default function Archive() {
  const [filters, setFilters] = useState({ search: '', status: '', branch: '', eventType: '', from: '', to: '' });
  const [debounced, setDebounced] = useState(filters);
  const [page, setPage] = useState(1);
  const [notice, setNotice] = useState({ type: '', text: '' });
  useEffect(() => { const t = setTimeout(() => { setDebounced(filters); setPage(1); }, 300); return () => clearTimeout(t); }, [filters]);
  const set = (k) => (e) => setFilters((f) => ({ ...f, [k]: e.target.value }));
  const lists = useLoad(async () => { const [b, t] = await Promise.all([api.get('/branches'), api.get('/event-types')]); return { branches: b.data.branches, types: t.data.eventTypes }; });
  const list = useLoad(async () => (await api.get('/admin/archive', { params: { page, limit: 15, ...Object.fromEntries(Object.entries(debounced).filter(([, v]) => v)) } })).data, [debounced, page]);

  const restore = async (b) => {
    try { const res = await api.post(`/bookings/${b._id}/restore`); setNotice({ type: 'success', text: `${b.code}: ${res.data.message}` }); list.reload(); }
    catch (err) { setNotice({ type: 'error', text: errorMessage(err) }); }
  };
  const columns = [
    { key: 'b', label: 'Booking', render: (b) => <div><Link to={`/admin/archive/${b._id}`} className="font-semibold text-navy hover:underline">{b.eventName}</Link><p className="text-xs text-steel">{b.code}</p></div> },
    { key: 'company', label: 'Company', render: (b) => b.company?.companyName }, { key: 'type', label: 'Type', render: (b) => b.eventType?.name },
    { key: 'branch', label: 'Branch', render: (b) => b.branch?.name }, { key: 'date', label: 'Event date', render: (b) => formatDate(b.date) },
    { key: 'total', label: 'Total', render: (b) => peso(b.total) }, { key: 'status', label: 'Status', render: (b) => <BookingStatusBadge status={b.status} /> },
    { key: 'archivedAt', label: 'Archived', render: (b) => formatDateTime(b.archivedAt) },
    { key: 'actions', label: '', className: 'text-right', render: (b) => <Button variant="secondary" className="!px-3 !py-1.5" onClick={() => restore(b)}><ArchiveRestore size={14} /> Restore</Button> },
  ];
  const data = list.data;
  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader title="Archive" subtitle="Completed, rejected, expired and cancelled bookings you archived. Restore a record to bring it back to the daily lists." />
      <div className="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <div className="lg:col-span-3 sm:col-span-2"><label htmlFor="ar-search" className="mb-1.5 block text-sm font-medium text-navy">Search</label><input id="ar-search" value={filters.search} onChange={set('search')} placeholder="Event, booking code or company" className="w-full rounded-xl border border-steel/40 px-3 py-2.5 text-sm text-navy placeholder:text-steel/60 focus:border-sky focus:outline-none focus:ring-2 focus:ring-sky/40" /></div>
        <Select label="Status" value={filters.status} onChange={set('status')}><option value="">All archived statuses</option>{ARCHIVABLE.map((s) => <option key={s} value={s}>{STATUS[s].label}</option>)}</Select>
        <Select label="Branch" value={filters.branch} onChange={set('branch')}><option value="">All branches</option>{lists.data?.branches.map((b) => <option key={b._id} value={b._id}>{b.name}</option>)}</Select>
        <Select label="Event type" value={filters.eventType} onChange={set('eventType')}><option value="">All event types</option>{lists.data?.types.map((t) => <option key={t._id} value={t._id}>{t.name}</option>)}</Select>
        <Field label="Event date from" type="date" value={filters.from} onChange={set('from')} />
        <Field label="Event date to" type="date" value={filters.to} onChange={set('to')} />
      </div>
      <div className="mb-4"><Alert type={notice.type || 'info'}>{notice.text}</Alert></div>
      <LoadState loading={list.loading} error={list.error} hasData={!!data}>
        <DataTable columns={columns} rows={data?.bookings || []} empty="Nothing archived yet. Archive finished bookings from their details page." />
        {data && data.pages > 1 && (
          <div className="mt-4 flex items-center justify-between text-sm text-steel"><span>{data.total} archived · page {data.page} of {data.pages}</span>
            <div className="flex gap-2"><Button variant="secondary" className="!px-3 !py-1.5" disabled={page <= 1} onClick={() => setPage(page - 1)}>Previous</Button><Button variant="secondary" className="!px-3 !py-1.5" disabled={page >= data.pages} onClick={() => setPage(page + 1)}>Next</Button></div></div>
        )}
      </LoadState>
    </div>
  );
}
