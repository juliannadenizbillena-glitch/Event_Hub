import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, Power } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import LoadState from '../../components/LoadState';
import Badge from '../../components/Badge';
import Button from '../../components/Button';
import Select from '../../components/Select';
import Alert from '../../components/Alert';
import Card from '../../components/Card';
import StatCard from '../../components/StatCard';
import BookingStatusBadge from '../../components/BookingStatusBadge';
import useLoad from '../../hooks/useLoad';
import { formatDate, formatDateTime, peso } from '../../utils/format';
import { bookingPath } from '../../config/bookingStatus';
import api, { errorMessage } from '../../api/client';

// Companies = the User accounts. A User IS a customer company/organization (there is no separate Company role).
export default function Companies() {
  const [filters, setFilters] = useState({ search: '', status: '' });
  const [debounced, setDebounced] = useState(filters);
  const [page, setPage] = useState(1);
  const [notice, setNotice] = useState({ type: '', text: '' });
  useEffect(() => { const t = setTimeout(() => { setDebounced(filters); setPage(1); }, 300); return () => clearTimeout(t); }, [filters]);
  const set = (k) => (e) => setFilters((f) => ({ ...f, [k]: e.target.value }));
  const list = useLoad(async () => (await api.get('/admin/companies', { params: { page, limit: 15, ...Object.fromEntries(Object.entries(debounced).filter(([, v]) => v)) } })).data, [debounced, page]);

  const toggle = async (c) => {
    try { const res = await api.patch(`/admin/companies/${c._id}/status`, { status: c.status === 'active' ? 'inactive' : 'active' }); setNotice({ type: 'success', text: res.data.message }); list.reload(); }
    catch (err) { setNotice({ type: 'error', text: errorMessage(err) }); }
  };
  const columns = [
    { key: 'company', label: 'Company', render: (c) => <div><Link to={`/admin/companies/${c._id}`} className="font-semibold text-navy hover:underline">{c.companyName}</Link><p className="text-xs text-steel">Role: User / Company</p></div> },
    { key: 'contact', label: 'Contact person', render: (c) => <div><p>{c.firstName} {c.lastName}</p><p className="text-xs text-steel">{c.phone}</p></div> },
    { key: 'emails', label: 'Emails', render: (c) => <div className="text-xs"><p>Contact: {c.contactEmail}</p><p className="text-steel">Login: {c.accountEmail}</p></div> },
    { key: 'bookings', label: 'Bookings', render: (c) => `${c.bookings} (${c.activeBookings} active, ${c.completedEvents} completed)` },
    { key: 'outstanding', label: 'Outstanding', render: (c) => <span className={c.hasOverdue ? 'font-semibold text-red-700' : ''}>{peso(c.outstanding)}{c.hasOverdue ? ' · overdue' : ''}</span> },
    { key: 'status', label: 'Status', render: (c) => <Badge tone={c.status === 'active' ? 'active' : 'inactive'}>{c.status === 'active' ? 'Active' : 'Inactive'}</Badge> },
    { key: 'actions', label: '', className: 'text-right', render: (c) => (
      <div className="flex justify-end gap-2">
        <Link to={`/admin/companies/${c._id}`}><Button variant="secondary" className="!px-3 !py-1.5">View</Button></Link>
        <Button variant="secondary" className="!px-3 !py-1.5" onClick={() => toggle(c)}><Power size={14} /> {c.status === 'active' ? 'Deactivate' : 'Reactivate'}</Button>
      </div>
    ) },
  ];
  const data = list.data;
  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader title="Companies" subtitle="Registered customer companies (User accounts): contact details, booking history, outstanding payments, and account access." />
      <div className="mb-4 grid gap-3 sm:grid-cols-3">
        <div className="sm:col-span-2">
          <label htmlFor="co-search" className="mb-1.5 block text-sm font-medium text-navy">Search</label>
          <input id="co-search" value={filters.search} onChange={set('search')} placeholder="Company, contact person or email" className="w-full rounded-xl border border-steel/40 px-3 py-2.5 text-sm text-navy placeholder:text-steel/60 focus:border-sky focus:outline-none focus:ring-2 focus:ring-sky/40" />
        </div>
        <Select label="Status" value={filters.status} onChange={set('status')}><option value="">All</option><option value="active">Active</option><option value="inactive">Inactive</option></Select>
      </div>
      <div className="mb-4"><Alert type={notice.type || 'info'}>{notice.text}</Alert></div>
      <LoadState loading={list.loading} error={list.error} hasData={!!data}>
        <DataTable columns={columns} rows={data?.companies || []} empty="No companies match." />
        {data && data.pages > 1 && (
          <div className="mt-4 flex items-center justify-between text-sm text-steel">
            <span>{data.total} companies · page {data.page} of {data.pages}</span>
            <div className="flex gap-2"><Button variant="secondary" className="!px-3 !py-1.5" disabled={page <= 1} onClick={() => setPage(page - 1)}>Previous</Button><Button variant="secondary" className="!px-3 !py-1.5" disabled={page >= data.pages} onClick={() => setPage(page + 1)}>Next</Button></div>
          </div>
        )}
      </LoadState>
    </div>
  );
}

export function CompanyDetails() {
  const { id } = useParams();
  const { data, loading, error, reload } = useLoad(async () => (await api.get(`/admin/companies/${id}`)).data, [id]);
  const [notice, setNotice] = useState({ type: '', text: '' });
  const toggle = async () => {
    try { const res = await api.patch(`/admin/companies/${id}/status`, { status: data.company.status === 'active' ? 'inactive' : 'active' }); setNotice({ type: 'success', text: res.data.message }); reload(); }
    catch (err) { setNotice({ type: 'error', text: errorMessage(err) }); }
  };
  const c = data?.company;
  return (
    <div className="mx-auto max-w-5xl space-y-5">
      <Link to="/admin/companies" className="inline-flex items-center gap-1.5 text-sm font-semibold text-steel hover:text-navy"><ArrowLeft size={16} /> Companies</Link>
      <LoadState loading={loading} error={error} hasData={!!data}>
        {data && (
          <>
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div><h1 className="text-2xl font-bold text-navy">{c.companyName}</h1><p className="mt-1 text-sm text-steel">{c.firstName} {c.lastName} · {c.phone}</p></div>
              <div className="flex items-center gap-3"><Badge tone={c.status === 'active' ? 'active' : 'inactive'}>{c.status === 'active' ? 'Active' : 'Inactive'}</Badge><Button variant="secondary" onClick={toggle}><Power size={14} /> {c.status === 'active' ? 'Deactivate account' : 'Reactivate account'}</Button></div>
            </div>
            <Alert type={notice.type || 'info'}>{notice.text}</Alert>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <StatCard label="Bookings" value={data.stats.bookings} /><StatCard label="Active bookings" value={data.stats.active} /><StatCard label="Completed events" value={data.stats.completed} />
              <StatCard label="Outstanding now" value={peso(data.stats.outstandingNow)} attention={data.stats.outstandingNow > 0} />
            </div>
            <Card title="Account"><dl className="grid gap-4 text-sm sm:grid-cols-2">
              {[['Role', 'User / Company'], ['Contact email', c.contactEmail], ['Login (account) email', c.accountEmail], ['Registered', formatDateTime(c.createdAt)], ['Last login', c.lastLoginAt ? formatDateTime(c.lastLoginAt) : 'Never']].map(([k, v]) => <div key={k}><dt className="text-xs font-semibold uppercase tracking-wide text-steel">{k}</dt><dd className="mt-0.5 break-all font-medium text-navy">{v}</dd></div>)}
            </dl></Card>
            <Card title="Outstanding payments">
              {data.outstanding.length === 0 ? <p className="text-sm text-steel">Nothing outstanding.</p> : (
                <ul className="divide-y divide-mist/60 text-sm text-navy">{data.outstanding.map((o) => <li key={o.bookingId} className="flex flex-wrap items-center justify-between gap-2 py-2"><span><Link className="font-semibold hover:underline" to={`/admin/${['confirmed', 'ongoing', 'completed_pending_final', 'payment_overdue'].includes(o.status) ? 'events' : 'booking-requests'}/${o.bookingId}`}>{o.code}</Link> · {o.eventName}<span className="block text-xs text-steel">{o.reason}{o.dueAt ? ` · due ${formatDateTime(o.dueAt)}` : ''}</span></span><span className="font-semibold">{peso(o.amount)}</span></li>)}</ul>
              )}
            </Card>
            <Card title="Booking history">
              <DataTable rowKey="_id" empty="No bookings." rows={data.bookingHistory} columns={[
                { key: 'b', label: 'Booking', render: (b) => <div><Link to={bookingPath('admin', b)} className="font-semibold hover:underline">{b.eventName}</Link><p className="text-xs text-steel">{b.code}</p></div> },
                { key: 'type', label: 'Type', render: (b) => b.eventType?.name }, { key: 'branch', label: 'Branch', render: (b) => b.branch?.name },
                { key: 'date', label: 'Date', render: (b) => formatDate(b.date) }, { key: 'total', label: 'Total', render: (b) => peso(b.total) },
                { key: 'status', label: 'Status', render: (b) => <div className="flex gap-1.5"><BookingStatusBadge status={b.status} />{b.isArchived && <Badge tone="gray">Archived</Badge>}</div> },
              ]} />
            </Card>
            <Card title="Payment history">
              <DataTable rowKey="_id" empty="No payments." rows={data.payments} columns={[
                { key: 'code', label: 'Booking', render: (p) => p.bookingCode }, { key: 'type', label: 'Type', render: (p) => (p.type === 'down' ? '50% down payment' : 'Final payment') },
                { key: 'amount', label: 'Amount', render: (p) => peso(p.amount) }, { key: 'method', label: 'Method', render: (p) => (p.method === 'gcash' ? 'GCash' : 'Bank transfer') },
                { key: 'ref', label: 'Reference', render: (p) => p.referenceNumber },
                { key: 'status', label: 'Status', render: (p) => <Badge tone={{ pending: 'sky', verified: 'green', rejected: 'red' }[p.status]}>{p.status}</Badge> },
              ]} />
            </Card>
            {data.damageCharges.length > 0 && (
              <Card title="Damage charges"><ul className="divide-y divide-mist/60 text-sm text-navy">{data.damageCharges.map((d, i) => <li key={i} className="flex justify-between gap-3 py-2"><span>{d.bookingCode} · {d.item} × {d.quantity}<span className="block text-xs text-steel">{d.description}</span></span><span className="font-semibold">{peso(d.approvedAmount)}</span></li>)}</ul></Card>
            )}
          </>
        )}
      </LoadState>
    </div>
  );
}
