import { useEffect, useState } from 'react';
import { Power, Users } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import LoadState from '../../components/LoadState';
import Badge from '../../components/Badge';
import Button from '../../components/Button';
import Select from '../../components/Select';
import Alert from '../../components/Alert';
import Modal from '../../components/Modal';
import useLoad from '../../hooks/useLoad';
import { useAuth } from '../../context/AuthContext';
import api, { errorMessage } from '../../api/client';

// Admin: all 275 teams with filters, and can take a team out of rotation.
// Organizer: only the teams of their own branch, view only.
export default function Teams() {
  const { user } = useAuth();
  const isAdmin = user.role === 'admin';
  const [filters, setFilters] = useState({ branch: '', eventType: '', status: '', search: '' });
  const [notice, setNotice] = useState({ type: '', text: '' });
  const [assigning, setAssigning] = useState(null);
  const set = (k) => (e) => setFilters((f) => ({ ...f, [k]: e.target.value }));

  const lists = useLoad(async () => {
    const [b, t] = await Promise.all([api.get('/branches'), api.get('/event-types')]);
    return { branches: b.data.branches, eventTypes: t.data.eventTypes };
  });
  const teams = useLoad(async () => (await api.get('/teams', { params: Object.fromEntries(Object.entries(filters).filter(([, v]) => v)) })).data.teams, [filters]);

  const toggle = async (t) => {
    setNotice({ type: '', text: '' });
    try {
      await api.patch(`/teams/${t._id}/status`, { isActive: !t.isActive });
      setNotice({ type: 'success', text: `${t.name} (${t.branch.name}) ${t.isActive ? 'deactivated' : 'activated'}.` });
      teams.reload();
    } catch (err) { setNotice({ type: 'error', text: errorMessage(err) }); }
  };

  const rows = teams.data || [];
  const columns = [
    { key: 'name', label: 'Team', render: (t) => <span className="font-semibold">{t.name}</span> },
    { key: 'eventType', label: 'Event type', render: (t) => t.eventType?.name },
    ...(isAdmin ? [{ key: 'branch', label: 'Branch', render: (t) => t.branch?.name }] : []),
    { key: 'size', label: 'Members', render: (t) => t.eventType ? t.eventType.teamSize : '—' },
    { key: 'assignedStaff', label: 'Assigned staff', render: (t) => {
      const assigned = (t.assignments || []).filter((a) => a.staff).map((a) => `${a.staff.firstName} ${a.staff.lastName} — ${a.position}`);
      return assigned.length ? <div className="space-y-1">{assigned.map((name, i) => <p key={`${name}-${i}`} className="text-xs">{name}</p>)}</div> : <span className="text-xs text-steel">No staff assigned</span>;
    } },
    { key: 'isActive', label: 'Status', render: (t) => <Badge tone={t.isActive ? 'active' : 'inactive'}>{t.isActive ? 'Active' : 'Inactive'}</Badge> },
    ...(isAdmin ? [{ key: 'actions', label: '', className: 'text-right', render: (t) => (
      <div className="flex flex-wrap justify-end gap-2">
        <Button variant="secondary" className="!px-3 !py-1.5" onClick={() => setAssigning(t)}><Users size={14} /> Assign staff</Button>
        <Button variant="secondary" className="!px-3 !py-1.5" onClick={() => toggle(t)}><Power size={14} /> {t.isActive ? 'Deactivate' : 'Activate'}</Button>
      </div>
    ) }] : []),
  ];

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader
        title="Teams"
        viewOnly={!isAdmin}
        subtitle={isAdmin
          ? 'Every branch has 5 teams for each of the 11 event types (275 in total). Team structure comes from the event type.'
          : 'The event teams of your branch and their structure. Reservations for confirmed events will show here when the Booking module is ready.'}
      />

      <div className="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {isAdmin && (
          <Select label="Branch" value={filters.branch} onChange={set('branch')}>
            <option value="">All branches</option>
            {lists.data?.branches.map((b) => <option key={b._id} value={b._id}>{b.name}</option>)}
          </Select>
        )}
        <Select label="Event type" value={filters.eventType} onChange={set('eventType')}>
          <option value="">All event types</option>
          {lists.data?.eventTypes.map((t) => <option key={t._id} value={t._id}>{t.name}</option>)}
        </Select>
        <Select label="Status" value={filters.status} onChange={set('status')}>
          <option value="">All</option><option value="active">Active</option><option value="inactive">Inactive</option>
        </Select>
        <div>
          <label htmlFor="team-search" className="mb-1.5 block text-sm font-medium text-navy">Search</label>
          <input id="team-search" value={filters.search} onChange={set('search')} placeholder="e.g. Seminar Team 2"
            className="w-full rounded-xl border border-steel/40 px-3 py-2.5 text-sm text-navy placeholder:text-steel/70 focus:border-sky focus:outline-none focus:ring-2 focus:ring-sky/40" />
        </div>
      </div>

      <div className="mb-4"><Alert type={notice.type || 'info'}>{notice.text}</Alert></div>
      <LoadState loading={teams.loading} error={teams.error} hasData={!!teams.data}>
        <p className="mb-2 text-sm text-steel">{rows.length} team{rows.length === 1 ? '' : 's'} shown{!isAdmin && user.branch?.name ? ` · ${user.branch.name}` : ''}</p>
        <DataTable columns={columns} rows={rows} empty="No teams match these filters." />
      </LoadState>
      {isAdmin && assigning && <TeamAssignments team={assigning} onClose={() => setAssigning(null)} onSaved={(message) => { setAssigning(null); setNotice({ type: 'success', text: message }); teams.reload(); }} />}
    </div>
  );
}


function TeamAssignments({ team, onClose, onSaved }) {
  const [staff, setStaff] = useState([]);
  const [slots, setSlots] = useState(() => {
    const existing = team.assignments || [];
    const result = [];
    (team.eventType?.staffing || []).forEach((position) => {
      for (let i = 0; i < position.count; i += 1) {
        const match = existing.filter((a) => a.position === position.role)[i];
        result.push({ position: position.role, staff: match?.staff?._id || match?.staff || '' });
      }
    });
    return result;
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let active = true;
    api.get('/admin/staff', { params: { branch: team.branch?._id || team.branch, status: 'active' } })
      .then((res) => { if (active) setStaff((res.data.staff || []).filter((person) => !person.isArchived)); })
      .catch((err) => { if (active) setError(errorMessage(err)); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [team.branch]);

  const change = (index, value) => setSlots((current) => current.map((slot, i) => i === index ? { ...slot, staff: value } : slot));
  const submit = async (e) => {
    e.preventDefault(); setSaving(true); setError('');
    try {
      const assignments = slots.map(({ position, staff: staffId }) => ({ position, staff: staffId || null }));
      const res = await api.put(`/teams/${team._id}/assignments`, { assignments });
      onSaved(res.data.message || 'Team staff assignments saved.');
    } catch (err) { setError(errorMessage(err)); }
    finally { setSaving(false); }
  };

  const usedByOthers = (index) => new Set(slots.filter((_, i) => i !== index).map((slot) => slot.staff).filter(Boolean));
  return (
    <Modal title={`Assign staff — ${team.name}`} onClose={onClose} wide>
      <form onSubmit={submit} className="space-y-4">
        <p className="text-sm text-steel">Only active staff from {team.branch?.name || 'this team’s branch'} can be assigned. Leave a position unassigned if needed.</p>
        {error && <Alert type="error">{error}</Alert>}
        {loading ? <p className="text-sm text-steel">Loading staff…</p> : (
          <div className="max-h-[55vh] space-y-3 overflow-y-auto pr-1">
            {slots.map((slot, index) => {
              const used = usedByOthers(index);
              return <div key={`${slot.position}-${index}`} className="grid gap-2 sm:grid-cols-[minmax(120px,0.8fr)_minmax(180px,1.2fr)] sm:items-center">
                <label htmlFor={`team-slot-${index}`} className="text-sm font-medium text-navy">{slot.position} <span className="text-steel">#{slots.slice(0, index + 1).filter((s) => s.position === slot.position).length}</span></label>
                <select id={`team-slot-${index}`} value={slot.staff} onChange={(e) => change(index, e.target.value)} className="w-full rounded-xl border border-steel/40 bg-white px-3 py-2.5 text-sm text-navy focus:border-sky focus:outline-none focus:ring-2 focus:ring-sky/40">
                  <option value="">Unassigned</option>
                  {staff.filter((person) => !used.has(person._id) || person._id === slot.staff).map((person) => <option key={person._id} value={person._id}>{person.firstName} {person.lastName}{person.position ? ` (${person.position})` : ''}</option>)}
                </select>
              </div>;
            })}
            {!slots.length && <p className="text-sm text-steel">This event type has no positions configured.</p>}
            {!staff.length && <p className="text-sm text-steel">No active staff accounts were found for this branch. Add staff first on the Staff / Organizers page.</p>}
          </div>
        )}
        <div className="flex justify-end gap-3 border-t border-mist pt-4">
          <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
          <Button type="submit" loading={saving} disabled={loading}>Save assignments</Button>
        </div>
      </form>
    </Modal>
  );
}
