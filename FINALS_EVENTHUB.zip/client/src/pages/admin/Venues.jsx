import { useState } from 'react';
import { Pencil, Plus, Power } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import LoadState from '../../components/LoadState';
import Badge from '../../components/Badge';
import Button from '../../components/Button';
import Modal from '../../components/Modal';
import Field from '../../components/Field';
import Select from '../../components/Select';
import Alert from '../../components/Alert';
import useLoad from '../../hooks/useLoad';
import useForm from '../../hooks/useForm';
import { useAuth } from '../../context/AuthContext';
import { rules } from '../../utils/validators';
import api, { errorMessage, fieldErrors } from '../../api/client';

// Admin manages venues. The Organizer sees their own branch's venues and assigns one to an event inside
// Booking Details (the system refuses a venue that is too small or already used that day).
export default function Venues() {
  const { user } = useAuth();
  const isAdmin = user.role === 'admin';
  const [filters, setFilters] = useState({ branch: '', status: '', search: '' });
  const [editing, setEditing] = useState(null);
  const [notice, setNotice] = useState({ type: '', text: '' });
  const set = (k) => (e) => setFilters((f) => ({ ...f, [k]: e.target.value }));
  const branches = useLoad(async () => (await api.get('/branches')).data.branches);
  const list = useLoad(async () => (await api.get('/venues', { params: Object.fromEntries(Object.entries(filters).filter(([, v]) => v)) })).data.venues, [filters]);
  const toggle = async (v) => {
    try { const res = await api.patch(`/venues/${v._id}/status`, { isActive: !v.isActive }); setNotice({ type: 'success', text: res.data.message }); list.reload(); }
    catch (err) { setNotice({ type: 'error', text: errorMessage(err) }); }
  };
  const columns = [
    { key: 'name', label: 'Venue', render: (v) => <div><p className="font-semibold">{v.name}</p>{v.address && <p className="text-xs text-steel">{v.address}</p>}</div> },
    { key: 'branch', label: 'Branch', render: (v) => v.branch?.name },
    { key: 'capacity', label: 'Capacity', render: (v) => `${v.capacity} pax` },
    { key: 'facilities', label: 'Facilities', render: (v) => <div className="flex flex-wrap gap-1">{v.facilities?.map((f) => <span key={f} className="rounded-full bg-mist/50 px-2 py-0.5 text-xs">{f}</span>)}</div> },
    { key: 'status', label: 'Status', render: (v) => <div className="flex flex-wrap gap-1.5"><Badge tone={v.status === 'available' ? 'active' : 'orange'}>{v.status === 'available' ? 'Available' : 'Maintenance'}</Badge>{!v.isActive && <Badge tone="inactive">Deactivated</Badge>}</div> },
    ...(isAdmin ? [{ key: 'actions', label: '', className: 'text-right', render: (v) => (
      <div className="flex justify-end gap-2">
        <Button variant="secondary" className="!px-3 !py-1.5" onClick={() => setEditing(v)}><Pencil size={14} /> Edit</Button>
        <Button variant="secondary" className="!px-3 !py-1.5" onClick={() => toggle(v)}><Power size={14} /> {v.isActive ? 'Deactivate' : 'Activate'}</Button>
      </div>
    ) }] : []),
  ];
  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader title="Venues" viewOnly={!isAdmin}
        subtitle={isAdmin ? 'Venues for every branch. A venue can host one event per date and must fit the attendee count.' : 'Venues of your branch. Assign one to an event inside its Booking Details.'}
        action={isAdmin && <Button onClick={() => setEditing('new')}><Plus size={16} /> Add venue</Button>} />
      <div className="mb-4 grid gap-3 sm:grid-cols-3">
        {isAdmin && <Select label="Branch" value={filters.branch} onChange={set('branch')}><option value="">All branches</option>{branches.data?.map((b) => <option key={b._id} value={b._id}>{b.name}</option>)}</Select>}
        <Select label="Status" value={filters.status} onChange={set('status')}><option value="">All</option><option value="available">Available</option><option value="maintenance">Maintenance</option></Select>
        <div>
          <label htmlFor="v-search" className="mb-1.5 block text-sm font-medium text-navy">Search</label>
          <input id="v-search" value={filters.search} onChange={set('search')} placeholder="e.g. Grand Ballroom" className="w-full rounded-xl border border-steel/40 px-3 py-2.5 text-sm text-navy placeholder:text-steel/60 focus:border-sky focus:outline-none focus:ring-2 focus:ring-sky/40" />
        </div>
      </div>
      <div className="mb-4"><Alert type={notice.type || 'info'}>{notice.text}</Alert></div>
      <LoadState loading={list.loading} error={list.error} hasData={!!list.data}>
        <DataTable columns={columns} rows={list.data || []} empty="No venues match these filters." />
      </LoadState>
      {editing && <VenueForm venue={editing === 'new' ? null : editing} branches={branches.data || []} onClose={() => setEditing(null)} onSaved={(text) => { setEditing(null); setNotice({ type: 'success', text }); list.reload(); }} />}
    </div>
  );
}

function VenueForm({ venue, branches, onClose, onSaved }) {
  const form = useForm({ branch: venue?.branch?._id || '', name: venue?.name || '', capacity: venue?.capacity ?? '', status: venue?.status || '', address: venue?.address || '', facilities: (venue?.facilities || []).join(', '), notes: venue?.notes || '' }, {
    branch: rules.required('Select a branch.'), name: rules.required('This field is required.'), capacity: rules.whole('the capacity', 1, 5000), status: rules.required('Select a status.'),
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const submit = async (e) => {
    e.preventDefault(); setError('');
    if (!form.validateAll()) return;
    setLoading(true);
    try {
      const v = form.values;
      const payload = { ...v, capacity: Number(v.capacity), facilities: v.facilities.split(',').map((s) => s.trim()).filter(Boolean) };
      if (venue) await api.patch(`/venues/${venue._id}`, payload); else await api.post('/venues', payload);
      onSaved(venue ? 'Venue updated.' : 'Venue added.');
    } catch (err) { const fe = fieldErrors(err); form.setServerErrors(fe); if (!Object.keys(fe).length) setError(errorMessage(err)); }
    finally { setLoading(false); }
  };
  return (
    <Modal title={venue ? 'Edit venue' : 'Add venue'} onClose={onClose}>
      <form onSubmit={submit} noValidate className="space-y-4">
        <Alert type="error">{error}</Alert>
        <Select label="Branch" {...form.field('branch')}><option value="">Select branch</option>{branches.map((b) => <option key={b._id} value={b._id}>{b.name}</option>)}</Select>
        <Field label="Venue name" placeholder="e.g. Makati Grand Ballroom" {...form.field('name')} />
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Capacity (pax)" type="number" min={1} placeholder="e.g. 500" {...form.field('capacity')} />
          <Select label="Status" {...form.field('status')}><option value="">Select status</option><option value="available">Available</option><option value="maintenance">Maintenance</option></Select>
        </div>
        <Field label="Address (optional)" placeholder="e.g. 123 Ayala Avenue, Makati City" {...form.field('address')} />
        <Field label="Facilities (comma separated)" placeholder="e.g. Stage, Sound system, Air conditioning" {...form.field('facilities')} />
        <Field label="Notes (optional)" placeholder="e.g. Loading dock at the rear" {...form.field('notes')} />
        <div className="flex justify-end gap-3 pt-2"><Button type="button" variant="secondary" onClick={onClose}>Cancel</Button><Button type="submit" loading={loading}>{venue ? 'Save changes' : 'Add venue'}</Button></div>
      </form>
    </Modal>
  );
}
