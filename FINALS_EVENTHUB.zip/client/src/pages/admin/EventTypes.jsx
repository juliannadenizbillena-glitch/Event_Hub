import { useState } from 'react';
import { Pencil, Plus, Trash2, Users } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import LoadState from '../../components/LoadState';
import Badge from '../../components/Badge';
import Button from '../../components/Button';
import Modal from '../../components/Modal';
import Field from '../../components/Field';
import Alert from '../../components/Alert';
import Card from '../../components/Card';
import useLoad from '../../hooks/useLoad';
import { useAuth } from '../../context/AuthContext';
import { TEAM_TIERS } from '../../config/rules';
import api, { errorMessage, fieldErrors } from '../../api/client';

// Admin: edits event types and their team structure.
// Organizer: the same page, view only (official configuration belongs to Admin).
export default function EventTypes({ embedded = false }) {
  const { user } = useAuth();
  const isAdmin = user.role === 'admin';
  const { data, loading, error, reload } = useLoad(async () => (await api.get('/event-types')).data.eventTypes);
  const [editing, setEditing] = useState(null);
  const [notice, setNotice] = useState('');

  return (
    <div className={embedded ? 'space-y-6' : 'mx-auto max-w-5xl space-y-6'}>
      {!embedded && (
        <PageHeader
          title={isAdmin ? 'Event Types' : 'Event Setup'}
          viewOnly={!isAdmin}
          subtitle="The 11 event types EventHub offers. Every branch has 5 teams per type, and all of them follow the team structure set here."
        />
      )}
      <Alert type="success">{notice}</Alert>

      <Card title="Teams needed per event" description="The system picks the number of teams from the attendee count." icon={Users}>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
          {TEAM_TIERS.map((t) => (
            <div key={t.teams} className="rounded-xl bg-mist/40 px-4 py-3 text-center">
              <p className="text-xs text-steel">{t.attendees} attendees</p>
              <p className="mt-1 text-lg font-bold text-navy">{t.teams} {t.teams === 1 ? 'team' : 'teams'}</p>
            </div>
          ))}
        </div>
      </Card>

      <LoadState loading={loading} error={error} hasData={!!data}>
        <div className="grid gap-4 sm:grid-cols-2">
          {(data || []).map((t) => (
            <section key={t._id} className="flex flex-col rounded-2xl border border-mist bg-white p-5 shadow-sm">
              <div className="flex items-start justify-between gap-3">
                <h2 className="text-base font-semibold text-navy">{t.name}</h2>
                <Badge tone={t.isActive ? 'active' : 'inactive'}>{t.isActive ? 'Active' : 'Inactive'}</Badge>
              </div>
              <p className="mt-1 text-sm text-steel">{t.description}</p>
              <p className="mt-4 text-sm font-semibold text-navy">{t.teamSize}-member team</p>
              <ul className="mt-2 flex flex-wrap gap-1.5">
                {t.staffing.map((s) => <li key={s.role} className="rounded-full bg-mist/50 px-2.5 py-1 text-xs text-navy">{s.role} × {s.count}</li>)}
              </ul>
              {isAdmin && <div className="mt-4 pt-1"><Button variant="secondary" className="!px-3 !py-1.5" onClick={() => setEditing(t)}><Pencil size={14} /> Edit</Button></div>}
            </section>
          ))}
        </div>
      </LoadState>

      {editing && <EventTypeForm eventType={editing} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); setNotice('Event type updated. Its teams now follow the new structure.'); reload(); }} />}
    </div>
  );
}

function EventTypeForm({ eventType, onClose, onSaved }) {
  const [description, setDescription] = useState(eventType.description || '');
  const [durationModes, setDurationModes] = useState(
  eventType.durationModes?.length ? eventType.durationModes : ['hourly']
);

  const [isActive, setIsActive] = useState(eventType.isActive);
  const [rows, setRows] = useState(eventType.staffing.map((s) => ({ ...s })));
  const [errors, setErrors] = useState({});
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const total = rows.reduce((n, r) => n + (Number(r.count) || 0), 0);

  const setRow = (i, key, value) => setRows((rs) => rs.map((r, idx) => (idx === i ? { ...r, [key]: value } : r)));

  const submit = async (e) => {
    e.preventDefault();
    setError(''); setErrors({});
    if (rows.length === 0) return setError('Add at least one team role.');
    if (rows.some((r) => !r.role.trim())) return setError('Every role needs a name.');
    if (rows.some((r) => !(Number(r.count) >= 1))) return setError('Every role needs at least 1 member.');
    setLoading(true);
    try {
await api.patch(`/event-types/${eventType._id}`, {
  description,
  isActive,
  durationModes,
  staffing: rows.map((r) => ({
    role: r.role.trim(),
    count: Number(r.count),
  })),
});
      onSaved();
    } catch (err) {
      const fe = fieldErrors(err);
      setErrors(fe);
      // The team structure has no single field to highlight, so show the specific reason here.
      setError(fe.staffing || Object.values(fe)[0] || errorMessage(err));
    } finally { setLoading(false); }
  };

  return (
    <Modal title={`Edit ${eventType.name}`} onClose={onClose} wide>
      <form onSubmit={submit} noValidate className="space-y-5">
        <Alert type="error">{error}</Alert>
        <div>
          <label htmlFor="et-desc" className="mb-1.5 block text-sm font-medium text-navy">Description</label>
          <textarea id="et-desc" rows={3} placeholder="e.g. Focused, instructor-led sessions for learning and discussion." value={description} onChange={(e) => setDescription(e.target.value)}
            className="w-full rounded-xl border border-steel/40 px-4 py-2.5 text-sm text-navy focus:border-sky focus:outline-none focus:ring-2 focus:ring-sky/40" />
          {errors.description && <p className="mt-1 text-xs text-red-600">{errors.description}</p>}
        </div>

        <div>
  <p className="mb-2 text-sm font-medium text-navy">Booking duration options</p>

  <div className="space-y-2">
    <label className="flex items-center gap-3 text-sm text-navy">
      <input
        type="checkbox"
        checked={durationModes.includes('hourly')}
        onChange={(e) =>
          setDurationModes((current) =>
            e.target.checked
              ? [...new Set([...current, 'hourly'])]
              : current.filter((mode) => mode !== 'hourly')
          )
        }
        className="h-4 w-4 accent-[#5B52B9]"
      />
      Hourly / single-day booking
    </label>

    <label className="flex items-center gap-3 text-sm text-navy">
      <input
        type="checkbox"
        checked={durationModes.includes('multi_day')}
        onChange={(e) =>
          setDurationModes((current) =>
            e.target.checked
              ? [...new Set([...current, 'multi_day'])]
              : current.filter((mode) => mode !== 'multi_day')
          )
        }
        className="h-4 w-4 accent-[#5B52B9]"
      />
      Multi-day booking
    </label>
  </div>

  {durationModes.length === 0 && (
    <p className="mt-1 text-xs text-red-600">
      Select at least one booking duration option.
    </p>
  )}
</div>

        <div>
          <div className="mb-2 flex items-center justify-between">
            <p className="text-sm font-medium text-navy">Team structure</p>
            <p className="text-sm font-semibold text-navy">{total} members per team</p>
          </div>
          <div className="space-y-2">
            {rows.map((r, i) => (
              <div key={i} className="flex items-center gap-2">
                <input aria-label={`Role ${i + 1}`} value={r.role} onChange={(e) => setRow(i, 'role', e.target.value)} placeholder="e.g. Team Lead"
                  className="min-w-0 flex-1 rounded-xl border border-steel/40 px-3 py-2 text-sm text-navy focus:border-sky focus:outline-none focus:ring-2 focus:ring-sky/40" />
                <input aria-label={`Members for role ${i + 1}`} type="number" min={1} max={50} placeholder="e.g. 2" value={r.count} onChange={(e) => setRow(i, 'count', e.target.value)}
                  className="w-20 rounded-xl border border-steel/40 px-3 py-2 text-sm text-navy focus:border-sky focus:outline-none focus:ring-2 focus:ring-sky/40" />
                <button type="button" aria-label={`Remove role ${i + 1}`} onClick={() => setRows((rs) => rs.filter((_, idx) => idx !== i))} className="rounded-lg p-2 text-steel hover:bg-mist/50 hover:text-navy"><Trash2 size={16} /></button>
              </div>
            ))}
          </div>
          <Button type="button" variant="secondary" className="mt-3 !px-3 !py-1.5" onClick={() => setRows((rs) => [...rs, { role: '', count: 1 }])}><Plus size={14} /> Add role</Button>
          <p className="mt-2 text-xs text-steel">All 5 teams of this type, in every branch, use this structure.</p>
        </div>

        <label className="flex items-center gap-3 text-sm text-navy">
          <input type="checkbox" checked={isActive} onChange={(e) => setIsActive(e.target.checked)} className="h-4 w-4 accent-[#5B52B9]" />
          Active (customers can book this event type)
        </label>

        <div className="flex justify-end gap-3 pt-2">
          <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
          <Button type="submit" loading={loading}>Save changes</Button>
        </div>
      </form>
    </Modal>
  );
}
