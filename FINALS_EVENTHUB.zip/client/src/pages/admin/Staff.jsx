import { useEffect, useState } from 'react';
import { Mail, Pencil, Plus, Power } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import LoadState from '../../components/LoadState';
import Badge from '../../components/Badge';
import Button from '../../components/Button';
import Modal from '../../components/Modal';
import Field from '../../components/Field';
import Select from '../../components/Select';
import Alert from '../../components/Alert';
import useLoad from '../../hooks/useLoad';
import useForm from '../../hooks/useForm';
import { rules } from '../../utils/validators';
import api, { errorMessage, fieldErrors } from '../../api/client';

// Admin creates Organizer/Staff accounts here. They never use the public Register page.
export default function Staff() {
  const [filters, setFilters] = useState({ search: '', branch: '', status: '' });
  const [debounced, setDebounced] = useState(filters);
  const [editing, setEditing] = useState(null); // null | 'new' | staff
  const [notice, setNotice] = useState({ type: '', text: '' });
  const set = (k) => (e) => setFilters((f) => ({ ...f, [k]: e.target.value }));

  useEffect(() => { const t = setTimeout(() => setDebounced(filters), 300); return () => clearTimeout(t); }, [filters]);

  const branches = useLoad(async () => (await api.get('/branches')).data.branches);
  const staff = useLoad(async () => (await api.get('/admin/staff', { params: Object.fromEntries(Object.entries(debounced).filter(([, v]) => v)) })).data.staff, [debounced]);

  const act = async (fn, success) => {
    setNotice({ type: '', text: '' });
    try { await fn(); setNotice({ type: 'success', text: success }); staff.reload(); }
    catch (err) { setNotice({ type: 'error', text: errorMessage(err) }); }
  };

  const columns = [
    { key: 'name', label: 'Name', render: (s) => (
      <div>
        <p className="font-semibold">{s.firstName} {s.lastName}</p>
        <p className="text-xs text-navy">Login: {s.accountEmail}</p>
        <p className="text-xs text-steel">Contact: {s.contactEmail}</p>
      </div>
    ) },
    { key: 'phone', label: 'Phone' },
    { key: 'branch', label: 'Branch', render: (s) => s.branch?.name || '—' },
    { key: 'position', label: 'Position' },
    { key: 'status', label: 'Status', render: (s) => (
      <div className="flex flex-wrap gap-1.5">
        <Badge tone={s.status === 'active' ? 'active' : 'inactive'}>{s.status === 'active' ? 'Active' : 'Inactive'}</Badge>
        {!s.passwordSet && <Badge tone="pending">Invite pending</Badge>}
      </div>
    ) },
    { key: 'actions', label: '', className: 'text-right', render: (s) => (
      <div className="flex flex-wrap justify-end gap-2">
        <Button variant="secondary" className="!px-3 !py-1.5" onClick={() => setEditing(s)}><Pencil size={14} /> Edit</Button>
        {!s.passwordSet && <Button variant="secondary" className="!px-3 !py-1.5" onClick={() => act(() => api.post(`/admin/staff/${s._id}/resend-invite`), 'Invitation sent again.')}><Mail size={14} /> Resend invite</Button>}
        <Button variant="secondary" className="!px-3 !py-1.5" onClick={() => act(() => api.patch(`/admin/staff/${s._id}/status`, { status: s.status === 'active' ? 'inactive' : 'active' }), s.status === 'active' ? 'Staff deactivated. They can no longer log in.' : 'Staff activated.')}><Power size={14} /> {s.status === 'active' ? 'Deactivate' : 'Activate'}</Button>
      </div>
    ) },
  ];

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader
        title="Staff / Organizers"
        subtitle="View and manage all staff and Organizers across every branch. Assign each person to their existing team position."
        action={<Button onClick={() => setEditing('new')}><Plus size={16} /> Add staff</Button>}
      />

      <div className="mb-4 grid gap-3 sm:grid-cols-3">
        <div>
          <label htmlFor="staff-search" className="mb-1.5 block text-sm font-medium text-navy">Search</label>
          <input id="staff-search" value={filters.search} onChange={set('search')} placeholder="Search by name, email or position"
            className="w-full rounded-xl border border-steel/40 px-3 py-2.5 text-sm text-navy placeholder:text-steel/70 focus:border-sky focus:outline-none focus:ring-2 focus:ring-sky/40" />
        </div>
        <Select label="Branch" value={filters.branch} onChange={set('branch')}>
          <option value="">All branches</option>
          {branches.data?.map((b) => <option key={b._id} value={b._id}>{b.name}</option>)}
        </Select>
        <Select label="Status" value={filters.status} onChange={set('status')}>
          <option value="">All</option><option value="active">Active</option><option value="inactive">Inactive</option>
        </Select>
      </div>

      <div className="mb-4"><Alert type={notice.type || 'info'}>{notice.text}</Alert></div>
      <LoadState loading={staff.loading} error={staff.error} hasData={!!staff.data}>
        <DataTable columns={columns} rows={staff.data || []} empty="No staff found. Use Add staff to create a staff or Organizer account." />
      </LoadState>

      {editing && (
        <StaffForm
          staff={editing === 'new' ? null : editing}
          branches={(branches.data || []).filter((b) => b.isActive || b._id === editing?.branch?._id)}
          onClose={() => setEditing(null)}
          onSaved={(type, text) => { setEditing(null); setNotice({ type, text }); staff.reload(); branches.reload(); }}
        />
      )}
    </div>
  );
}

function StaffForm({ staff, branches, onClose, onSaved }) {
  const form = useForm(
    {
      firstName: staff?.firstName || '', lastName: staff?.lastName || '', contactEmail: staff?.contactEmail || '',
      phone: staff?.phone || '', branch: staff?.branch?._id || '', position: staff?.position || '',
    },
    {
      firstName: rules.name('first name'),
      lastName: rules.name('last name'),
      contactEmail: staff ? undefined : rules.contactEmail(),
      phone: rules.phone,
      branch: rules.required('Select a branch.'),
      position: rules.required('This field is required.'),
    }
  );
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const v = form.values;
  // A preview of the generated login email. The server decides the final one (it adds a number if the name is taken).
  const local = (normalizeName(v.firstName) + normalizeName(v.lastName)).slice(0, 40);
  const preview = staff ? (staff.contactEmail || staff.accountEmail) : v.contactEmail.trim().toLowerCase();

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (!form.validateAll()) return;
    setLoading(true);
    try {
      const payload = { ...v, contactEmail: v.contactEmail.trim().toLowerCase() };
      if (staff) {
        await api.patch(`/admin/staff/${staff._id}`, payload);
        onSaved('success', 'Staff updated.');
      } else {
        const res = await api.post('/admin/staff', payload);
        onSaved(res.data.inviteSent ? 'success' : 'error', res.data.message);
      }
    } catch (err) {
      const fe = fieldErrors(err);
      form.setServerErrors(fe);
      if (!Object.keys(fe).length) setError(errorMessage(err));
    } finally { setLoading(false); }
  };

  return (
    <Modal title={staff ? 'Edit staff' : 'Add staff'} onClose={onClose}>
      <form onSubmit={submit} noValidate className="space-y-4">
        <Alert type="error">{error}</Alert>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="First name" placeholder="e.g. Juan" {...form.field('firstName')} />
          <Field label="Last name" placeholder="e.g. Dela Cruz" {...form.field('lastName')} />
        </div>
        <Field label="Email address" type="email" placeholder="e.g. juan.delacruz@gmail.com"
          {...(staff ? { value: staff.contactEmail, readOnly: true, onChange: () => {} } : form.field('contactEmail'))}
          hint={staff ? 'The contact email cannot be changed here.' : undefined} />
        {preview && (
          <p className="-mt-1 rounded-xl bg-mist/40 px-4 py-2.5 text-xs text-navy">
            Account / login email: <span data-testid="login-preview" className="font-semibold">{preview}</span>
          </p>
        )}
        <Field label="Phone number" type="tel" placeholder="09XXXXXXXXX" {...form.field('phone')} />
        <Select label="Branch" {...form.field('branch')}>
          <option value="">Select branch</option>
          {branches.map((b) => <option key={b._id} value={b._id}>{b.name}</option>)}
        </Select>
        <Field label="Position / role" placeholder="e.g. Organizer" {...form.field('position')} />
        <div className="flex justify-end gap-3 pt-2">
          <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
          <Button type="submit" loading={loading}>{staff ? 'Save changes' : 'Create account'}</Button>
        </div>
      </form>
    </Modal>
  );
}

// Same normalisation as the server (accents and special characters removed, lowercase).
const normalizeName = (t) => String(t || '').toLowerCase().replace(/[łøđßæœðþ]/g, (c) => ({ ł: 'l', ø: 'o', đ: 'd', ß: 'ss', æ: 'ae', œ: 'oe', ð: 'd', þ: 'th' }[c])).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');
