import { useState } from 'react';
import { Pencil, Plus, Power } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import LoadState from '../../components/LoadState';
import Badge from '../../components/Badge';
import Button from '../../components/Button';
import Modal from '../../components/Modal';
import Field from '../../components/Field';
import Select from '../../components/Select';
import Alert from '../../components/Alert';
import useLoad from '../../hooks/useLoad';
import useForm from '../../hooks/useForm';
import { useAuth } from '../../context/AuthContext';
import { rules } from '../../utils/validators';
import api, { errorMessage, fieldErrors } from '../../api/client';

const CATEGORIES = ['audio', 'video', 'lighting', 'furniture', 'staging', 'networking', 'signage', 'safety', 'other'];
const CONDITIONS = { good: 'Good', fair: 'Fair', needs_repair: 'Needs repair', out_of_service: 'Out of service' };
const COND_TONE = { good: 'green', fair: 'yellow', needs_repair: 'orange', out_of_service: 'red' };
const label = (s) => s[0].toUpperCase() + s.slice(1);

// Admin manages the inventory. The Organizer sees their branch's items (plus shared ones) and uses them
// when planning an event (inside Booking Details), so this page is view only for them.
export default function Equipment() {
  const { user } = useAuth();
  const isAdmin = user.role === 'admin';
  const [filters, setFilters] = useState({ branch: '', category: '', status: '', search: '' });
  const [editing, setEditing] = useState(null);
  const [notice, setNotice] = useState({ type: '', text: '' });
  const set = (k) => (e) => setFilters((f) => ({ ...f, [k]: e.target.value }));
  const branches = useLoad(async () => (await api.get('/branches')).data.branches);
  const list = useLoad(async () => (await api.get('/equipment', { params: Object.fromEntries(Object.entries(filters).filter(([, v]) => v)) })).data.equipment, [filters]);

  const toggle = async (e) => {
    try { const res = await api.patch(`/equipment/${e._id}/status`, { isActive: !e.isActive }); setNotice({ type: 'success', text: res.data.message }); list.reload(); }
    catch (err) { setNotice({ type: 'error', text: errorMessage(err) }); }
  };
  const columns = [
    { key: 'name', label: 'Item', render: (e) => <div><p className="font-semibold">{e.name}</p>{e.notes && <p className="text-xs text-steel">{e.notes}</p>}</div> },
    { key: 'category', label: 'Category', render: (e) => label(e.category) },
    { key: 'quantity', label: 'Quantity' },
    { key: 'condition', label: 'Condition', render: (e) => <Badge tone={COND_TONE[e.condition]}>{CONDITIONS[e.condition]}</Badge> },
    { key: 'status', label: 'Status', render: (e) => <div className="flex flex-wrap gap-1.5"><Badge tone={e.status === 'available' ? 'active' : 'inactive'}>{label(e.status)}</Badge>{!e.isActive && <Badge tone="inactive">Deactivated</Badge>}</div> },
    { key: 'branch', label: 'Branch', render: (e) => e.branch?.name || 'Shared' },
    ...(isAdmin ? [{ key: 'actions', label: '', className: 'text-right', render: (e) => (
      <div className="flex justify-end gap-2">
        <Button variant="secondary" className="!px-3 !py-1.5" onClick={() => setEditing(e)}><Pencil size={14} /> Edit</Button>
        <Button variant="secondary" className="!px-3 !py-1.5" onClick={() => toggle(e)}><Power size={14} /> {e.isActive ? 'Deactivate' : 'Activate'}</Button>
      </div>
    ) }] : []),
  ];

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader title="Equipment" viewOnly={!isAdmin}
        subtitle={isAdmin ? 'Inventory used to run events. Organizers pick what each event needs, and the system stops over-allocation on a date.' : 'Equipment available to your branch, including shared items. Plan what an event needs inside its Booking Details.'}
        action={isAdmin && <Button onClick={() => setEditing('new')}><Plus size={16} /> Add equipment</Button>} />
      <div className="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {isAdmin && (
          <Select label="Branch" value={filters.branch} onChange={set('branch')}>
            <option value="">All branches</option><option value="shared">Shared (all branches)</option>
            {branches.data?.map((b) => <option key={b._id} value={b._id}>{b.name}</option>)}
          </Select>
        )}
        <Select label="Category" value={filters.category} onChange={set('category')}><option value="">All categories</option>{CATEGORIES.map((c) => <option key={c} value={c}>{label(c)}</option>)}</Select>
        <Select label="Status" value={filters.status} onChange={set('status')}><option value="">All</option><option value="available">Available</option><option value="maintenance">Maintenance</option><option value="retired">Retired</option></Select>
        <div>
          <label htmlFor="eq-search" className="mb-1.5 block text-sm font-medium text-navy">Search</label>
          <input id="eq-search" value={filters.search} onChange={set('search')} placeholder="e.g. Projector" className="w-full rounded-xl border border-steel/40 px-3 py-2.5 text-sm text-navy placeholder:text-steel/60 focus:border-sky focus:outline-none focus:ring-2 focus:ring-sky/40" />
        </div>
      </div>
      <div className="mb-4"><Alert type={notice.type || 'info'}>{notice.text}</Alert></div>
      <LoadState loading={list.loading} error={list.error} hasData={!!list.data}>
        <p className="mb-2 text-sm text-steel">{list.data?.length} item{list.data?.length === 1 ? '' : 's'}</p>
        <DataTable columns={columns} rows={list.data || []} empty="No equipment matches these filters." />
      </LoadState>
      {editing && <EquipmentForm item={editing === 'new' ? null : editing} branches={branches.data || []} onClose={() => setEditing(null)} onSaved={(text) => { setEditing(null); setNotice({ type: 'success', text }); list.reload(); }} />}
    </div>
  );
}

function EquipmentForm({ item, branches, onClose, onSaved }) {
  const form = useForm({ name: item?.name || '', category: item?.category || '', quantity: item?.quantity ?? '', condition: item?.condition || '', status: item?.status || '', branch: item?.branch?._id || '', notes: item?.notes || '' }, {
    name: rules.required('This field is required.'), category: rules.required('Select a category.'), quantity: rules.whole('the quantity', 0, 100000),
    condition: rules.required('Select a condition.'), status: rules.required('Select a status.'),
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const submit = async (e) => {
    e.preventDefault(); setError('');
    if (!form.validateAll()) return;
    setLoading(true);
    try {
      const payload = { ...form.values, quantity: Number(form.values.quantity), branch: form.values.branch || undefined };
      if (item) await api.patch(`/equipment/${item._id}`, payload); else await api.post('/equipment', payload);
      onSaved(item ? 'Equipment updated.' : 'Equipment added.');
    } catch (err) { const fe = fieldErrors(err); form.setServerErrors(fe); if (!Object.keys(fe).length) setError(errorMessage(err)); }
    finally { setLoading(false); }
  };
  return (
    <Modal title={item ? 'Edit equipment' : 'Add equipment'} onClose={onClose}>
      <form onSubmit={submit} noValidate className="space-y-4">
        <Alert type="error">{error}</Alert>
        <Field label="Name" placeholder="e.g. Wireless Microphones" {...form.field('name')} />
        <div className="grid gap-4 sm:grid-cols-2">
          <Select label="Category" {...form.field('category')}><option value="">Select category</option>{CATEGORIES.map((c) => <option key={c} value={c}>{label(c)}</option>)}</Select>
          <Field label="Quantity owned" type="number" min={0} placeholder="e.g. 24" {...form.field('quantity')} />
          <Select label="Condition" {...form.field('condition')}><option value="">Select condition</option>{Object.entries(CONDITIONS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select>
          <Select label="Status" {...form.field('status')}><option value="">Select status</option><option value="available">Available</option><option value="maintenance">Maintenance</option><option value="retired">Retired</option></Select>
        </div>
        <Select label="Branch" {...form.field('branch')}><option value="">Shared (all branches)</option>{branches.map((b) => <option key={b._id} value={b._id}>{b.name}</option>)}</Select>
        <Field label="Notes (optional)" placeholder="e.g. Includes carrying cases" {...form.field('notes')} />
        <div className="flex justify-end gap-3 pt-2"><Button type="button" variant="secondary" onClick={onClose}>Cancel</Button><Button type="submit" loading={loading}>{item ? 'Save changes' : 'Add equipment'}</Button></div>
      </form>
    </Modal>
  );
}
