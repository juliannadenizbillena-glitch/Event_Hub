import { useState } from 'react';
import { Info, Pencil, Plus, Power } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import LoadState from '../../components/LoadState';
import Badge from '../../components/Badge';
import Button from '../../components/Button';
import Modal from '../../components/Modal';
import Field from '../../components/Field';
import Select from '../../components/Select';
import Alert from '../../components/Alert';
import useLoad from '../../hooks/useLoad';
import { peso } from '../../utils/format';
import api, { errorMessage, fieldErrors } from '../../api/client';

const LEVELS = ['Basic', 'Standard', 'Premium', 'Executive']; // placeholder names until finalized
const GROUPS = [['equipment', 'Equipment'], ['services', 'Services'], ['resources', 'Resources']];

// Admin: creates, edits, prices and deactivates official bundles and add-ons.
// Organizer (readOnly): sees the same list with no controls.
// Prices are global (no branch-specific pricing).
export default function Pricing({ readOnly = false, embedded = false }) {
  const [tab, setTab] = useState('bundles');
  const [notice, setNotice] = useState({ type: '', text: '' });

  return (
    <div className={embedded ? 'space-y-5' : 'mx-auto max-w-6xl space-y-5'}>
      {!embedded && (
        <PageHeader
          title="Bundles & Pricing"
          subtitle="Official bundles, add-ons and prices. They are global: every branch uses the same list, and only Admin can change it."
        />
      )}
      <div className="flex items-start gap-3 rounded-xl bg-mist/40 px-4 py-3 text-sm text-navy">
        <Info size={18} className="mt-0.5 shrink-0 text-steel" />
        <p>A bundle price is flat. It does not change with the number of attendees. The number of teams is worked out separately from the attendee count, and a bundle's capacity is the most attendees it allows.</p>
      </div>

      <div className="flex gap-2 border-b border-mist">
        {[['bundles', 'Bundles'], ['addons', 'Add-ons']].map(([key, label]) => (
          <button key={key} onClick={() => { setTab(key); setNotice({ type: '', text: '' }); }}
            className={`-mb-px border-b-2 px-4 py-2.5 text-sm font-semibold transition ${tab === key ? 'border-sky text-navy' : 'border-transparent text-steel hover:text-navy'}`}>
            {label}
          </button>
        ))}
      </div>

      <Alert type={notice.type || 'info'}>{notice.text}</Alert>
      {tab === 'bundles' ? <BundlesTab readOnly={readOnly} setNotice={setNotice} /> : <AddOnsTab readOnly={readOnly} setNotice={setNotice} />}
    </div>
  );
}

/* ----------------------------- Bundles ----------------------------- */

function BundlesTab({ readOnly, setNotice }) {
  const types = useLoad(async () => (await api.get('/event-types')).data.eventTypes);
  const [typeId, setTypeId] = useState('');
  const selected = typeId || types.data?.[0]?._id || '';
  const bundles = useLoad(async () => (selected ? (await api.get('/bundles', { params: { eventType: selected } })).data.bundles : []), [selected]);
  const [editing, setEditing] = useState(null); // null | 'new' | bundle

  const toggle = async (b) => {
    try {
      const res = await api.patch(`/bundles/${b._id}/status`, { isActive: !b.isActive });
      setNotice({ type: 'success', text: res.data.message });
      bundles.reload();
    } catch (err) { setNotice({ type: 'error', text: errorMessage(err) }); }
  };

  const list = bundles.data || [];
  const freeLevels = [1, 2, 3, 4].filter((l) => !list.some((b) => b.level === l));

  return (
    <LoadState loading={types.loading} error={types.error} hasData={!!types.data}>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <Select label="Event type" value={selected} onChange={(e) => setTypeId(e.target.value)} className="w-full sm:w-72">
          {types.data?.map((t) => <option key={t._id} value={t._id}>{t.name}{t.isActive ? '' : ' (inactive)'}</option>)}
        </Select>
        {!readOnly && freeLevels.length > 0 && <Button onClick={() => setEditing('new')}><Plus size={16} /> Add bundle</Button>}
        {!readOnly && freeLevels.length === 0 && list.length > 0 && <p className="text-sm text-steel">4 of 4 bundles. Edit a bundle to change it.</p>}
      </div>

      <LoadState loading={bundles.loading} error={bundles.error} hasData={!!bundles.data}>
        <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {list.map((b) => (
            <section key={b._id} className={`flex flex-col rounded-2xl border border-mist bg-white p-5 shadow-sm ${b.isActive ? '' : 'opacity-70'}`}>
              <div className="flex items-start justify-between gap-2">
                <p className="text-xs font-semibold uppercase tracking-wide text-steel">Level {b.level}</p>
                <Badge tone={b.isActive ? 'active' : 'inactive'}>{b.isActive ? 'Active' : 'Inactive'}</Badge>
              </div>
              <h3 className="mt-1 text-base font-semibold text-navy">{b.name}</h3>
              <p className="mt-2 text-2xl font-bold text-navy">{peso(b.price)}</p>
              <p className="text-xs text-steel">Up to {b.capacity} attendees</p>
              {b.description && <p className="mt-3 text-sm text-steel">{b.description}</p>}
              <div className="mt-4 flex-1 space-y-3">
                {GROUPS.map(([key, label]) => b.inclusions?.[key]?.length > 0 && (
                  <div key={key}>
                    <p className="text-xs font-semibold text-navy">{label}</p>
                    <ul className="mt-1 space-y-1 text-xs text-navy">
                      {b.inclusions[key].map((item, index) => {
                        const name = typeof item === 'string' ? item : item.name;
                         const quantity = typeof item === 'string' ? 1 : (item.quantity ?? 1);

                           return (
                            <li key={`${name}-${index}`} className="flex gap-2">
                             <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-sky" />
                             <span>{name} × {quantity}</span>
                               </li>
                                  );
                                 })}
                    </ul>
                  </div>
                ))}
              </div>
              {!readOnly && (
                <div className="mt-5 flex flex-wrap gap-2">
                  <Button variant="secondary" className="!px-3 !py-1.5" onClick={() => setEditing(b)}><Pencil size={14} /> Edit</Button>
                  <Button variant="secondary" className="!px-3 !py-1.5" onClick={() => toggle(b)}><Power size={14} /> {b.isActive ? 'Deactivate' : 'Activate'}</Button>
                </div>
              )}
            </section>
          ))}
          {list.length === 0 && <p className="col-span-full rounded-2xl border border-mist bg-white px-4 py-10 text-center text-sm text-steel">No bundles for this event type yet.</p>}
        </div>
      </LoadState>

      {editing && (
        <BundleForm
          bundle={editing === 'new' ? null : editing}
          eventTypeId={selected}
          eventTypeName={types.data?.find((t) => t._id === selected)?.name}
          freeLevels={freeLevels}
          onClose={() => setEditing(null)}
          onSaved={(text) => { setEditing(null); setNotice({ type: 'success', text }); bundles.reload(); }}
        />
      )}
    </LoadState>
  );
}



const toLines = (arr = []) =>
  arr
    .map((item) => {
      if (typeof item === 'string') return item;

      const name = item?.name || '';
      const quantity = Number(item?.quantity ?? 1);

      return name ? `${name} x${quantity}` : '';
    })
    .filter(Boolean)
    .join('\n');

const fromLines = (text) =>
  text
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const match = line.match(/^(.+?)\s+[x×]\s*(\d+)$/i);

      if (!match) {
        return { name: line, quantity: 1 };
      }

      return {
        name: match[1].trim(),
        quantity: Number(match[2]),
      };
    });


    
function BundleForm({ bundle, eventTypeId, eventTypeName, freeLevels, onClose, onSaved }) {
  const [form, setForm] = useState({
    level: bundle?.level || freeLevels[0],
    name: bundle?.name || '',
    description: bundle?.description || '',
    capacity: bundle?.capacity ?? '',
    price: bundle?.price ?? '',
    equipment: toLines(bundle?.inclusions?.equipment),
    services: toLines(bundle?.inclusions?.services),
    resources: toLines(bundle?.inclusions?.resources),
  });

  const [errors, setErrors] = useState({});
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const set = (key) => (e) =>
    setForm((current) => ({ ...current, [key]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setErrors({});

    const found = {};

    if (!form.name.trim()) {
      found.name = 'Bundle name is required.';
    }

    const capacity = Number(form.capacity);
    const price = Number(form.price);

    if (!Number.isInteger(capacity) || capacity < 100 || capacity > 500) {
      found.capacity = 'Capacity must be a whole number from 100 to 500.';
    }

    if (!Number.isInteger(price) || price < 1 || price > 10000000) {
      found.price = 'Enter a whole number of pesos (1 or more).';
    }

    const inclusionGroups = ['equipment', 'services', 'resources'];



    
for (const key of inclusionGroups) {
  const lines = form[key]
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean);

  for (const line of lines) {
    const quantityEntry = line.match(/^(.+?)\s+[x×]\s*(.*?)$/i);

    if (quantityEntry) {
      const itemName = quantityEntry[1].trim();
      const quantityText = quantityEntry[2].trim();
      const quantity = Number(quantityText);

      if (
        !itemName ||
        !/^\d+$/.test(quantityText) ||
        !Number.isInteger(quantity) ||
        quantity < 1 ||
        quantity > 10000
      ) {
        found[key] =
          'Use the format Item name xQuantity, with a whole quantity from 1 to 10000.';
        break;
      }
    }
  }
}


    if (Object.keys(found).length) {
      setErrors(found);
      return;
    }

    const payload = {
      name: form.name.trim(),
      description: form.description.trim(),
      capacity,
      price,
      inclusions: {
        equipment: fromLines(form.equipment),
        services: fromLines(form.services),
        resources: fromLines(form.resources),
      },
    };

    setLoading(true);

    try {
      if (bundle) {
        await api.patch(`/bundles/${bundle._id}`, payload);
      } else {
        await api.post('/bundles', {
          ...payload,
          eventType: eventTypeId,
          level: Number(form.level),
        });
      }

      onSaved(
        bundle
          ? 'Bundle updated. Existing bookings keep their original booked price and quantities.'
          : 'Bundle created.'
      );
    } catch (err) {
      const fieldErrs = fieldErrors(err);
      setErrors(fieldErrs);
      setError(fieldErrs.inclusions || errorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      title={bundle ? `Edit ${bundle.name}` : `Add bundle for ${eventTypeName}`}
      onClose={onClose}
      wide
    >
      <form onSubmit={submit} noValidate className="space-y-4">
        <Alert type="error">{error}</Alert>

        {!bundle && (
          <Select label="Level" value={form.level} onChange={set('level')}>
            {freeLevels.map((level) => (
              <option key={level} value={level}>
                Level {level} ({LEVELS[level - 1]})
              </option>
            ))}
          </Select>
        )}

        <Field
          label="Bundle name"
          placeholder={`e.g. ${LEVELS[(form.level || 1) - 1]} ${eventTypeName || 'Seminar'}`}
          value={form.name}
          onChange={set('name')}
          error={errors.name}
        />

        <div>
          <label htmlFor="b-desc" className="mb-1.5 block text-sm font-medium text-navy">
            Description
          </label>
          <textarea
            id="b-desc"
            rows={2}
            value={form.description}
            onChange={set('description')}
            placeholder="Describe what this bundle includes."
            className="w-full rounded-xl border border-steel/40 px-4 py-2.5 text-sm text-navy focus:border-sky focus:outline-none focus:ring-2 focus:ring-sky/40"
          />
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field
            label="Capacity (max attendees)"
            type="number"
            min={100}
            max={500}
            value={form.capacity}
            onChange={set('capacity')}
            error={errors.capacity}
          />
          <Field
            label="Price (₱, flat, all branches)"
            type="number"
            min={1}
            value={form.price}
            onChange={set('price')}
            error={errors.price}
          />
        </div>

        <p className="text-sm text-steel">
          Enter one item per line, followed by x and its quantity. For example:
          <strong> Chairs x20</strong>, <strong>Microphones x2</strong>.
          Items without a quantity default to 1.
        </p>

        <div className="grid gap-4 sm:grid-cols-3">
          {GROUPS.map(([key, label]) => (
            <div key={key}>
              <label
                htmlFor={`b-${key}`}
                className="mb-1.5 block text-sm font-medium text-navy"
              >
                {label}
              </label>
              <textarea
                id={`b-${key}`}
                rows={6}
                value={form[key]}
                onChange={set(key)}
                placeholder={
                  key === 'equipment'
                    ? 'Projector and screen x1\nChairs x20'
                    : key === 'services'
                      ? 'Technical support x1'
                      : 'Printed signage x2'
                }
                className="w-full rounded-xl border border-steel/40 px-3 py-2 text-sm text-navy placeholder:text-steel/70 focus:border-sky focus:outline-none focus:ring-2 focus:ring-sky/40"
              />
              {errors[key] && (
                <p className="mt-1 text-sm text-red-600">{errors[key]}</p>
              )}
            </div>
          ))}
        </div>

        <div className="flex justify-end gap-3 pt-2">
          <Button type="button" variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" loading={loading}>
            {bundle ? 'Save changes' : 'Create bundle'}
          </Button>
        </div>
      </form>
    </Modal>
  );
}



/* ----------------------------- Add-ons ----------------------------- */

function AddOnsTab({ readOnly, setNotice }) {
  const { data, loading, error, reload } = useLoad(async () => (await api.get('/add-ons')).data.addOns);
  const [editing, setEditing] = useState(null);

  const toggle = async (a) => {
    try {
      const res = await api.patch(`/add-ons/${a._id}/status`, { isActive: !a.isActive });
      setNotice({ type: 'success', text: res.data.message });
      reload();
    } catch (err) { setNotice({ type: 'error', text: errorMessage(err) }); }
  };

  const columns = [
    { key: 'name', label: 'Add-on', render: (a) => <div><p className="font-semibold">{a.name}</p>{a.description && <p className="text-xs text-steel">{a.description}</p>}</div> },
    { key: 'price', label: 'Price', render: (a) => <span className="font-semibold">{peso(a.price)}</span> },
    { key: 'isActive', label: 'Status', render: (a) => <Badge tone={a.isActive ? 'active' : 'inactive'}>{a.isActive ? 'Active' : 'Inactive'}</Badge> },
    ...(readOnly ? [] : [{ key: 'actions', label: '', className: 'text-right', render: (a) => (
      <div className="flex justify-end gap-2">
        <Button variant="secondary" className="!px-3 !py-1.5" onClick={() => setEditing(a)}><Pencil size={14} /> Edit</Button>
        <Button variant="secondary" className="!px-3 !py-1.5" onClick={() => toggle(a)}><Power size={14} /> {a.isActive ? 'Deactivate' : 'Activate'}</Button>
      </div>
    ) }]),
  ];

  return (
    <>
      {!readOnly && <div className="flex justify-end"><Button onClick={() => setEditing('new')}><Plus size={16} /> Add add-on</Button></div>}
      <LoadState loading={loading} error={error} hasData={!!data}>
        <DataTable columns={columns} rows={data || []} empty="No add-ons yet." />
      </LoadState>
      {editing && <AddOnForm addOn={editing === 'new' ? null : editing} onClose={() => setEditing(null)} onSaved={(text) => { setEditing(null); setNotice({ type: 'success', text }); reload(); }} />}
    </>
  );
}


function AddOnForm({ addOn, onClose, onSaved }) {
  const [form, setForm] = useState({
    name: addOn?.name || '',
    description: addOn?.description || '',
    quantity: addOn?.quantity ?? 1,
    price: addOn?.price ?? '',
  });

  const [errors, setErrors] = useState({});
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const set = (k) => (e) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setErrors({});

    const found = {};

    if (!form.name.trim()) {
      found.name = 'Add-on name is required.';
    }

    const quantity = Number(form.quantity);
    const price = Number(form.price);

    if (!Number.isInteger(quantity) || quantity < 1 || quantity > 10000) {
      found.quantity = 'Quantity must be a whole number from 1 to 10000.';
    }

    if (!Number.isInteger(price) || price < 1 || price > 10000000) {
      found.price = 'Enter a whole number of pesos (1 or more).';
    }

    if (Object.keys(found).length) {
      setErrors(found);
      return;
    }

    setLoading(true);

    try {
      const payload = {
        name: form.name.trim(),
        description: form.description.trim(),
        quantity,
        price,
      };

      if (addOn) {
        await api.patch(`/add-ons/${addOn._id}`, payload);
      } else {
        await api.post('/add-ons', payload);
      }

      onSaved(
        addOn
          ? 'Add-on updated. Existing bookings keep their original price and quantity.'
          : 'Add-on created.'
      );
    } catch (err) {
      setErrors(fieldErrors(err));
      setError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal title={addOn ? 'Edit add-on' : 'Add add-on'} onClose={onClose}>
      <form onSubmit={submit} noValidate className="space-y-4">
        <Alert type="error">{error}</Alert>

        <Field
          label="Name"
          placeholder="e.g. Additional Microphones"
          value={form.name}
          onChange={set('name')}
          error={errors.name}
        />

        <Field
          label="Description (optional)"
          placeholder="e.g. Extra microphones for presenters"
          value={form.description}
          onChange={set('description')}
          error={errors.description}
        />

        <Field
          label="Quantity (number of items supplied)"
          type="number"
          min={1}
          max={10000}
          placeholder="e.g. 2"
          value={form.quantity}
          onChange={set('quantity')}
          error={errors.quantity}
        />

        <Field
          label="Price (₱, flat per selected add-on)"
          type="number"
          min={1}
          placeholder="e.g. 1500"
          value={form.price}
          onChange={set('price')}
          error={errors.price}
        />

        <div className="flex justify-end gap-3 pt-2">
          <Button type="button" variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" loading={loading}>
            {addOn ? 'Save changes' : 'Create add-on'}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
