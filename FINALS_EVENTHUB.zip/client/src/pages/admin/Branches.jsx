import { useState } from 'react';
import { Plus, Pencil, Power } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import LoadState from '../../components/LoadState';
import Badge from '../../components/Badge';
import Button from '../../components/Button';
import Modal from '../../components/Modal';
import Field from '../../components/Field';
import Alert from '../../components/Alert';
import useLoad from '../../hooks/useLoad';
import api, { errorMessage, fieldErrors } from '../../api/client';

// Admin: manages ALL branches. A new branch automatically gets its 55 teams (11 event types x 5).
export default function Branches() {
  const { data, loading, error, reload } = useLoad(async () => (await api.get('/branches')).data.branches);
  const [editing, setEditing] = useState(null); // null | 'new' | branch
  const [notice, setNotice] = useState({ type: '', text: '' });

  const toggle = async (b) => {
    setNotice({ type: '', text: '' });
    try {
      await api.patch(`/branches/${b._id}/status`, { isActive: !b.isActive });
      setNotice({ type: 'success', text: b.isActive ? `${b.name} deactivated.` : `${b.name} activated.` });
      reload();
    } catch (err) { setNotice({ type: 'error', text: errorMessage(err) }); }
  };

  const columns = [
    { key: 'name', label: 'Branch', render: (b) => <div><p className="font-semibold">{b.name}</p><p className="text-xs text-steel">{b.code}</p></div> },
    { key: 'address', label: 'Address', render: (b) => b.address || <span className="text-steel">—</span> },
    { key: 'teamCount', label: 'Teams' },
    { key: 'staffCount', label: 'Staff' },
    { key: 'isActive', label: 'Status', render: (b) => <Badge tone={b.isActive ? 'active' : 'inactive'}>{b.isActive ? 'Active' : 'Inactive'}</Badge> },
    { key: 'actions', label: '', className: 'text-right', render: (b) => (
      <div className="flex justify-end gap-2">
        <Button variant="secondary" className="!px-3 !py-1.5" onClick={() => setEditing(b)}><Pencil size={14} /> Edit</Button>
        <Button variant="secondary" className="!px-3 !py-1.5" onClick={() => toggle(b)}><Power size={14} /> {b.isActive ? 'Deactivate' : 'Activate'}</Button>
      </div>
    ) },
  ];

  const totalTeams = (data || []).reduce((n, b) => n + b.teamCount, 0);

  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader
        title="Branches"
        subtitle={data ? `${data.length} branches · ${totalTeams} teams. Organizers and teams belong to a branch, and customers choose a branch when they book.` : 'Manage every EventHub branch.'}
        action={<Button onClick={() => setEditing('new')}><Plus size={16} /> Add branch</Button>}
      />
      <div className="mb-4"><Alert type={notice.type || 'info'}>{notice.text}</Alert></div>
      <LoadState loading={loading} error={error} hasData={!!data}>
        <DataTable columns={columns} rows={data || []} empty="No branches yet." />
      </LoadState>
      {editing && <BranchForm branch={editing === 'new' ? null : editing} onClose={() => setEditing(null)} onSaved={(msg) => { setEditing(null); setNotice({ type: 'success', text: msg }); reload(); }} />}
    </div>
  );
}

function BranchForm({ branch, onClose, onSaved }) {
  const [form, setForm] = useState({ name: branch?.name || '', code: branch?.code || '', address: branch?.address || '' });
  const [errors, setErrors] = useState({});
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setError(''); setErrors({});
    const found = {};
    if (!form.name.trim()) found.name = 'Branch name is required.';
    if (!branch && !/^[A-Za-z]{2,6}$/.test(form.code.trim())) found.code = 'Use 2 to 6 letters (e.g. MNL).';
    if (Object.keys(found).length) return setErrors(found);
    setLoading(true);
    try {
      if (branch) await api.patch(`/branches/${branch._id}`, { name: form.name, address: form.address });
      else await api.post('/branches', form);
      onSaved(branch ? 'Branch updated.' : 'Branch created with all 55 teams.');
    } catch (err) { setErrors(fieldErrors(err)); setError(errorMessage(err)); }
    finally { setLoading(false); }
  };

  return (
    <Modal title={branch ? 'Edit branch' : 'Add branch'} onClose={onClose}>
      <form onSubmit={submit} noValidate className="space-y-4">
        <Alert type="error">{error}</Alert>
        <Field label="Branch name" value={form.name} onChange={set('name')} error={errors.name} placeholder="e.g. Iloilo Branch" />
        <Field label="Code" value={form.code} onChange={set('code')} error={errors.code} readOnly={!!branch} maxLength={6}
          placeholder="e.g. ILO" hint={branch ? 'The code cannot be changed.' : 'Cannot be changed later.'} />
        <Field label="Address (optional)" placeholder="e.g. 123 Ayala Avenue, Makati City" value={form.address} onChange={set('address')} error={errors.address} />
        <div className="flex justify-end gap-3 pt-2">
          <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
          <Button type="submit" loading={loading}>{branch ? 'Save changes' : 'Create branch'}</Button>
        </div>
      </form>
    </Modal>
  );
}
