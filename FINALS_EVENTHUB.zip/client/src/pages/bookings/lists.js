import { EVENT_STATUSES, REQUEST_STATUSES } from '../../config/bookingStatus';

// How each role's list pages behave (from the EventHub flow and permissions).
export const LISTS = {
  user: {
    title: 'My Events', scope: undefined, basePath: '/my-events', action: true,
    subtitle: 'All your bookings. Open one to follow its status, pay, and see what happens next.',
    statuses: [...REQUEST_STATUSES, ...EVENT_STATUSES], showTotal: true, empty: 'You have no bookings yet. Use Book an Event to create your first one.',
  },
  adminRequests: {
    title: 'Booking Requests', scope: 'requests', basePath: '/admin/booking-requests', showCompany: true, showBranch: true, showTotal: true, branchFilter: true,
    subtitle: 'Review requests, approve or reject them, and verify down payments. Open a request to act on it.',
    statuses: REQUEST_STATUSES, empty: 'No booking requests match.',
  },
  adminEvents: {
    title: 'Events', scope: 'events', sort: 'date', basePath: '/admin/events', showCompany: true, showBranch: true, showTotal: true, branchFilter: true,
    subtitle: 'Confirmed and completed events across all branches.',
    statuses: EVENT_STATUSES, empty: 'No confirmed events yet.',
  },
  organizerRequests: {
    title: 'Booking Requests', scope: 'requests', basePath: '/organizer/booking-requests', showCompany: true, viewOnly: true,
    subtitle: 'Incoming requests for your branch. View only: approving or rejecting bookings and verifying payments belong to Admin.',
    statuses: REQUEST_STATUSES, empty: 'No booking requests for your branch.',
  },
  organizerEvents: {
    title: 'My Events', scope: 'events', sort: 'date', basePath: '/organizer/my-events', showCompany: true,
    subtitle: 'Confirmed events for your branch, soonest first. Open one to see everything you need to prepare it.',
    statuses: EVENT_STATUSES, empty: 'No confirmed events for your branch yet.',
  },
};
