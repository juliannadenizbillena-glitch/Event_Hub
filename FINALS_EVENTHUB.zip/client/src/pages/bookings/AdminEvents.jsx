import { useState } from 'react';
import BookingList from './BookingList';
import { AdminEventCalendar } from './CalendarPage';
import { LISTS } from './lists';

export default function AdminEvents() {
  const [view, setView] = useState('list');
  return (
    <div className="mx-auto max-w-6xl space-y-4">
      <div className="flex gap-2 border-b border-mist" role="tablist">
        {[['list', 'List'], ['calendar', 'Calendar']].map(([k, l]) => (
          <button key={k} role="tab" aria-selected={view === k} onClick={() => setView(k)} className={`-mb-px border-b-2 px-4 py-2.5 text-sm font-semibold transition ${view === k ? 'border-sky text-navy' : 'border-transparent text-steel hover:text-navy'}`}>{l}</button>
        ))}
      </div>
      {view === 'list' ? <BookingList config={LISTS.adminEvents} /> : <><h1 className="text-2xl font-bold text-navy">Events calendar</h1><AdminEventCalendar /></>}
    </div>
  );
}
