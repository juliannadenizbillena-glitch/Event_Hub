import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Check, ImagePlus, X } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import Field from '../../components/Field';
import Select from '../../components/Select';
import TimeSelect from '../../components/TimeSelect';
import { rules } from '../../utils/validators';
import Button from '../../components/Button';
import Alert from '../../components/Alert';
import AvailabilityCalendar from '../../components/AvailabilityCalendar';
import useLoad from '../../hooks/useLoad';
import { peso, formatDate, formatTime } from '../../utils/format';
import api, { errorCode, errorMessage } from '../../api/client';

const STEPS = ['Event', 'Date & time', 'Bundle', 'Add-ons', 'Details', 'Review'];
const NO_TEAMS = 'No team is available for your selected schedule. Please select another date.';

// The customer creates THEIR OWN event booking (not a marketplace). Nothing is paid here:
// the booking goes to Admin first, and the 50% down payment comes after approval.
export default function BookEvent() {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
  eventName: '',
  eventType: '',
  attendees: '',
  branch: '',
  durationMode: 'hourly',
  date: '',
  endDate: '',
  startTime: '',
  endTime: '',
  bundle: '',
  addOns: [],
  requirements: '',
});

  const [image, setImage] = useState(null);
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [quote, setQuote] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const setup = useLoad(async () => {
    const [t, b, a] = await Promise.all([api.get('/event-types'), api.get('/branches'), api.get('/add-ons')]);
    return { eventTypes: t.data.eventTypes, branches: b.data.branches, addOns: a.data.addOns };
  });
  const attendees = Number(form.attendees);
  const attendeesOk = Number.isInteger(attendees) && attendees >= 1 && attendees <= 500;
  const teamsNeeded = attendeesOk ? Math.ceil(attendees / 100) : null;

  const bundles = useLoad(async () => (form.eventType && attendeesOk ? (await api.get('/bundles', { params: { eventType: form.eventType, attendees } })).data.bundles : []), [form.eventType, attendees, attendeesOk]);

  // Changing the schedule inputs invalidates later choices.

useEffect(() => {
  setForm((f) => ({
    ...f,
    date: '',
    endDate: '',
  }));
}, [form.branch, form.eventType, attendees]);


  useEffect(() => { setForm((f) => ({ ...f, bundle: '', addOns: f.addOns })); }, [form.eventType]);
  useEffect(() => { 
    const chosen = bundles.data?.find((b) => b._id === form.bundle);
    if (form.bundle && chosen && chosen.fits === false) setForm((f) => ({ ...f, bundle: '' }));
  }, [bundles.data]); 

  useEffect(() => {
    if (step !== 5 || !form.bundle) return;
    api.post('/pricing/quote', { eventType: form.eventType, attendees, bundle: form.bundle, addOns: form.addOns })
      .then((r) => setQuote(r.data.quote)).catch((err) => { setQuote(null); setFormError(errorMessage(err)); });
  }, [step]); 
  
  const [touched, setTouched] = useState({});
  const RULES = {
    eventName: (v) => (!v.trim() ? 'This field is required.' : v.trim().length >= 3 ? '' : 'Use at least 3 characters.'),
    eventType: (v) => (v ? '' : 'Select an event type.'),
    attendees: rules.whole('the number of attendees', 100, 500),
    branch: (v) => (v ? '' : 'Select a branch.'),
    date: (v) => (v ? '' : 'Select an available (green) date.'),
    
  endDate: (v, f) =>
    f.durationMode !== 'multi_day'
      ? ''
      : !v
        ? 'Select an event end date.'
        : v < f.date
          ? 'End date cannot be before the start date.'
          : '',

  durationMode: (v) =>
    ['hourly', 'multi_day'].includes(v)
      ? ''
      : 'Select a valid booking duration.',

    startTime: (v) => (v ? '' : 'Select a start time.'),
    endTime: (v, f) => (!v ? 'Select an end time.' : f.startTime && v <= f.startTime ? 'End time must be after the start time.' : ''),
    bundle: (v) => (v ? '' : 'Select a bundle.'),
  };


  
const STEP_FIELDS = [
  ['eventName', 'eventType', 'attendees', 'branch'],
  ['date', 'endDate', 'startTime', 'endTime'],
  ['bundle'],
];

  const err = (n) => (touched[n] ? RULES[n](form[n], form) : '');
  const fieldProps = (n) => ({ error: err(n), valid: touched[n] && !RULES[n](form[n], form) && String(form[n]).trim() !== '', onBlur: () => setTouched((t) => ({ ...t, [n]: true })) });
  const validate = (s) => {
    const names = STEP_FIELDS[s] || [];
    setTouched((t) => ({ ...t, ...Object.fromEntries(names.map((n) => [n, true])) }));
    const e = {};
    names.forEach((n) => { const m = RULES[n](form[n], form); if (m) e[n] = m; });
    return e;
  };
  const next = () => { const e = validate(step); setErrors(e); setFormError(''); if (!Object.keys(e).length) setStep(step + 1); else requestAnimationFrame(() => document.querySelector('[aria-invalid="true"]')?.focus()); };
  const back = () => { setErrors({}); setFormError(''); setStep(step - 1); };

  const toggleAddOn = (id) => setForm((f) => ({ ...f, addOns: f.addOns.includes(id) ? f.addOns.filter((x) => x !== id) : [...f.addOns, id] }));
  const pickImage = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) { setErrors({ image: 'Use a JPG, PNG or WebP image.' }); return; }
    if (file.size > 5 * 1024 * 1024) { setErrors({ image: 'The image must be 5 MB or smaller.' }); return; }
    setErrors({}); setImage(file);
  };

  const submit = async () => {
    setFormError('');
    setSubmitting(true);
    let created;
    try {
      const res = await api.post('/bookings', { ...form, eventName: form.eventName.trim(), attendees, requirements: form.requirements.trim() });
      created = res.data.booking;
    } catch (err) {
      setFormError(errorMessage(err));
      if (errorCode(err) === 'NO_TEAMS_AVAILABLE') setErrors({ noTeams: true });
      setSubmitting(false);
      return;
    }
    let flash = 'Your booking was submitted. It is now pending Admin approval. You will be notified, and nothing is due until it is approved.';
    if (image) {
      try { const fd = new FormData(); fd.append('referenceImage', image); await api.post(`/bookings/${created._id}/reference-image`, fd); }
      catch { flash += ' The reference image could not be uploaded; you can mention it in your requirements instead.'; }
    }
    navigate(`/my-events/${created._id}`, { state: { flash } });
  };

  const selectedType = setup.data?.eventTypes.find((t) => t._id === form.eventType);
  const selectedBranch = setup.data?.branches.find((b) => b._id === form.branch);
  const selectedBundle = bundles.data?.find((b) => b._id === form.bundle);
  const chosenAddOns = useMemo(() => (setup.data?.addOns || []).filter((a) => form.addOns.includes(a._id)), [setup.data, form.addOns]);

  if (setup.error) return <Alert type="error">{setup.error}</Alert>;
  if (!setup.data) return null;

  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader title="Book an Event" subtitle="Create your own event booking. EventHub provides the venue, equipment, staff and teams. You pay nothing until Admin approves it." />

      <ol className="mb-6 flex flex-wrap gap-2" aria-label="Booking steps">
        {STEPS.map((label, i) => (
          <li key={label} className={`flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-semibold ${i === step ? 'bg-navy text-white' : i < step ? 'bg-mist text-navy' : 'bg-gray-100 text-steel'}`}>
            <span className={`flex h-5 w-5 items-center justify-center rounded-full text-[11px] ${i === step ? 'bg-sky text-navy' : 'bg-white/70'}`}>{i < step ? <Check size={12} /> : i + 1}</span>{label}
          </li>
        ))}
      </ol>

      <div className="rounded-2xl border border-mist bg-white p-6 shadow-sm">
        <Alert type="error">{formError}</Alert>

        {step === 0 && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-navy">Event information</h2>
            <Field label="Event name" placeholder="e.g. Annual Company Conference 2026" value={form.eventName} onChange={set('eventName')} {...fieldProps('eventName')} />
            <div className="grid gap-4 sm:grid-cols-2">
              <Select label="Event type" value={form.eventType} onChange={set('eventType')} {...fieldProps('eventType')}>
                <option value="">Select event type</option>
                {setup.data.eventTypes.map((t) => <option key={t._id} value={t._id}>{t.name}</option>)}
              </Select>
              <div>
                <Field
                 label="Number of attendees"
                 type="number"
                 min={100}
                max={500}
                placeholder="e.g. 150"
                value={form.attendees}
                onChange={set('attendees')}
                {...fieldProps('attendees')}
                 />
                 </div>
            </div>
            <Select label="Branch" value={form.branch} onChange={set('branch')} {...fieldProps('branch')}>
              <option value="">Select branch</option>
              {setup.data.branches.map((b) => <option key={b._id} value={b._id}>{b.name}</option>)}
            </Select>
          </div>
        )}

        
{step === 1 && (
  <div className="space-y-4">
    <h2 className="text-lg font-semibold text-navy">
      Date and time
    </h2>

    {/* NEW: Booking duration selector */}
   
<div className="space-y-1">
  <label
    htmlFor="durationMode"
    className="text-sm font-medium text-navy"
  >
    Booking duration
  </label>

  <select
    id="durationMode"
    value={form.durationMode}
    onChange={(e) =>
      setForm((f) => ({
        ...f,
        durationMode: e.target.value,
        date: '',
        endDate: '',
      }))
    }
    className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2"
  >
    <option value="hourly">Single Day</option>
    <option value="multi_day">Multi-Day</option>
  </select>
</div>



    <p className="text-sm font-medium text-navy">
      {form.date ? 'Selected date' : 'Select date'}
    </p>

    <AvailabilityCalendar
      branchId={form.branch}
      eventTypeId={form.eventType}
      attendees={attendees}
      selectedDate={form.date}
      onSelect={(date) => {
        setForm((f) => ({
          ...f,
          date,
          endDate:
            f.durationMode === 'hourly' ? date : '',
        }));
        setErrors({});
      }}
    />

    {err('date') && (
      <p className="text-xs text-red-600">{err('date')}</p>
    )}

    {form.date && (
      <p className="text-sm font-semibold text-navy">
        Selected: {formatDate(form.date)}
      </p>
    )}

    {/* NEW: End date for multi-day events */}
    
{form.durationMode === 'multi_day' && (
  <div className="space-y-2">
    <p className="text-sm font-medium text-navy">
      {form.endDate ? 'Selected end date' : 'Select event end date'}
    </p>

    {form.date ? (
      <AvailabilityCalendar
        branchId={form.branch}
        eventTypeId={form.eventType}
        attendees={attendees}
        selectedDate={form.endDate}
        onSelect={(date) =>
          setForm((f) => ({
            ...f,
            endDate: date,
          }))
        }
        minDate={form.date}
        selectionLabel="Event end date"
      />
    ) : (
      <p className="text-sm text-steel">
        Select the event start date first.
      </p>
    )}

  
        {err('endDate') && (
          <p className="text-xs text-red-600">
            {err('endDate')}
          </p>
        )}
      </div>
    )}

    <div className="grid gap-4 sm:grid-cols-2">
      <TimeSelect
        label="Start time"
        placeholder="Select start time"
        value={form.startTime}
        onChange={set('startTime')}
        {...fieldProps('startTime')}
      />

      <TimeSelect
        label="End time"
        placeholder="Select end time"
        after={form.startTime}
        value={form.endTime}
        onChange={set('endTime')}
        {...fieldProps('endTime')}
      />
    </div>

    <p className="text-xs text-steel">
      Teams must be available for every date of a multi-day event.
    </p>
  </div>
)}

        {step === 2 && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-navy">Select bundle</h2>
            <p className="text-sm text-steel">Bundle prices are flat. The number of attendees only decides which bundles fit.</p>
            {err('bundle') && <Alert type="error">{err('bundle')}</Alert>}
            <div className="grid gap-4 sm:grid-cols-2">
              {(bundles.data || []).map((b) => {
                const disabled = b.fits === false;
                const selected = form.bundle === b._id;
                return (
                  <button key={b._id} type="button" disabled={disabled} aria-pressed={selected} onClick={() => setForm((f) => ({ ...f, bundle: b._id }))}
                    className={`rounded-2xl border p-4 text-left transition ${selected ? 'border-sky bg-mist/40 ring-2 ring-sky' : 'border-mist bg-white hover:border-sky'} ${disabled ? 'cursor-not-allowed opacity-50' : ''}`}>
                    <p className="text-xs font-semibold uppercase tracking-wide text-steel">Level {b.level}</p>
                    <p className="mt-0.5 font-semibold text-navy">{b.name}</p>
                    <p className="mt-1 text-xl font-bold text-navy">{peso(b.price)}</p>
                    <p className="text-xs text-steel">{disabled ? `Allows up to ${b.capacity} attendees. Too small for ${attendees}.` : `Up to ${b.capacity} attendees`}</p>
                    {b.description && <p className="mt-2 text-sm text-steel">{b.description}</p>}

<div className="mt-3 space-y-2">
  {[
    ['equipment', 'Equipment'],
    ['services', 'Services'],
    ['resources', 'Resources'],
  ].map(([key, label]) => {
    const items = b.inclusions?.[key] || [];

    if (items.length === 0) return null;

    return (
      <div key={key}>
        <p className="text-xs font-semibold text-navy">{label}</p>
        <ul className="mt-1 space-y-1 text-xs text-navy">
          {items.map((item, index) => {
            const name =
              typeof item === 'string' ? item : item?.name;
            const quantity =
              typeof item === 'string' ? 1 : (item?.quantity ?? 1);

            if (!name) return null;

            return (
              <li key={`${key}-${name}-${index}`} className="flex gap-2">
                <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-sky" />
                <span>{name} × {quantity}</span>
              </li>
            );
          })}
        </ul>
      </div>
    );
  })}
</div>
        

                  </button>
                );
              })}
              {bundles.data?.length === 0 && <p className="col-span-full text-sm text-steel">No bundles are available for this event type right now.</p>}
            </div>
          </div>
        )}

        
{step === 3 && (
  <div className="space-y-4">
    <h2 className="text-lg font-semibold text-navy">
      Select add-ons{' '}
      <span className="text-sm font-normal text-steel">(optional)</span>
    </h2>

    <div className="space-y-2">
      {setup.data.addOns.map((a) => (
        <label
          key={a._id}
          className={`flex cursor-pointer items-center justify-between gap-3 rounded-xl border px-4 py-3 text-sm ${
            form.addOns.includes(a._id)
              ? 'border-sky bg-mist/40'
              : 'border-mist'
          }`}
        >
          <span className="flex items-center gap-3">
            <input
              type="checkbox"
              checked={form.addOns.includes(a._id)}
              onChange={() => toggleAddOn(a._id)}
              className="h-4 w-4 accent-[#5B52B9]"
            />

            <span>
              <span className="font-semibold text-navy">
                {a.name} x{a.quantity ?? 1}
              </span>
              {a.description && (
                <span className="block text-xs text-steel">
                  {a.description}
                </span>
              )}
            </span>
          </span>

          <span className="font-semibold text-navy">{peso(a.price)}</span>
        </label>
      ))}

      {setup.data.addOns.length === 0 && (
        <p className="text-sm text-steel">No add-ons are available.</p>
      )}
    </div>
  </div>
)}


        
        {step === 4 && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-navy">Additional requirements</h2>
            <div>
              <label htmlFor="req" className="mb-1.5 block text-sm font-medium text-navy">Additional requirements <span className="font-normal text-steel">(optional)</span></label>
              <textarea id="req" rows={5} maxLength={1000} value={form.requirements} onChange={set('requirements')} placeholder="e.g. Need 2 additional microphones and a registration table"
                className="w-full rounded-xl border border-steel/40 px-4 py-2.5 text-sm text-navy placeholder:text-steel/70 focus:border-sky focus:outline-none focus:ring-2 focus:ring-sky/40" />
              <p className="mt-1 text-right text-xs text-steel">{form.requirements.length}/1000</p>
            </div>
            <div>
              <p className="mb-1.5 text-sm font-medium text-navy">Event reference image <span className="font-normal text-steel">(optional)</span></p>
              {image ? (
                <div className="flex items-center gap-4 rounded-xl border border-mist p-3">
                  <img src={URL.createObjectURL(image)} alt="Reference preview" className="h-20 w-28 rounded-lg object-cover" />
                  <div className="flex-1 text-sm text-navy"><p className="font-semibold">{image.name}</p><p className="text-xs text-steel">{(image.size / 1024).toFixed(0)} KB</p></div>
                  <button type="button" onClick={() => setImage(null)} aria-label="Remove image" className="rounded-lg p-2 text-steel hover:bg-mist/50"><X size={18} /></button>
                </div>
              ) : (
                <label className="flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-steel/50 px-4 py-8 text-sm text-steel hover:bg-mist/30">
                  <ImagePlus size={20} /> Upload an image for reference (optional)
                  <input type="file" accept="image/jpeg,image/png,image/webp" onChange={pickImage} className="sr-only" aria-label="Reference image" />
                </label>
              )}
              {errors.image && <p className="mt-1 text-xs text-red-600">{errors.image}</p>}
            </div>
          </div>
        )}

        
{step === 5 && (
  <div className="space-y-5">
    <h2 className="text-lg font-semibold text-navy">
      Review and submit
    </h2>

    <dl className="grid gap-x-6 gap-y-3 text-sm sm:grid-cols-2">
      {[
        ['Event', form.eventName],
        ['Event type', selectedType?.name],
        ['Branch', selectedBranch?.name],
        
[
  'Duration',
  form.durationMode === 'multi_day'
    ? 'Multi-Day'
    : 'Single Day',
],

        [
          'Event dates',
          form.durationMode === 'multi_day'
            ? `${formatDate(form.date)} – ${
                form.endDate
                  ? formatDate(form.endDate)
                  : 'Select end date'
              }`
            : formatDate(form.date),
        ],
        [
          'Time',
          `${formatTime(form.startTime)} – ${formatTime(form.endTime)}`,
        ],
        [
          'Attendees',
          `${attendees} (needs ${teamsNeeded} ${
            teamsNeeded === 1 ? 'team' : 'teams'
          })`,
        ],
      ].map(([k, v]) => (
        <div key={k}>
          <dt className="text-xs font-semibold uppercase tracking-wide text-steel">
            {k}
          </dt>
          <dd className="font-medium text-navy">{v}</dd>
        </div>
      ))}
    </dl>

    {quote ? (
      <div className="rounded-xl bg-mist/30 p-4 text-sm text-navy">
        <div className="flex justify-between">
          <span>{quote.bundle.name}</span>
          <span className="font-semibold">
            {peso(quote.bundleTotal)}
          </span>
        </div>

       
{quote.addOns.map((a) => (
  <div
    key={a.addOn}
    className="flex justify-between gap-3 text-steel"
  >
    <span>+ {a.name} x{a.quantity ?? 1}</span>
    <span>{peso(a.price)}</span>
  </div>
))}


        <div className="mt-3 flex justify-between border-t border-steel/30 pt-3 text-base font-bold">
          <span>Event total</span>
          <span>{peso(quote.total)}</span>
        </div>

        <p className="mt-2 text-xs text-steel">
          After approval you pay 50% ({peso(quote.total / 2)})
          within 24 hours to confirm. The rest is paid after
          the event.
        </p>
      </div>
    ) : (
      !formError && (
        <p className="text-sm text-steel">
          Calculating price…
        </p>
      )
    )}

    {form.requirements && (
      <div className="text-sm">
        <p className="text-xs font-semibold uppercase tracking-wide text-steel">
          Requirements
        </p>
        <p className="text-navy">{form.requirements}</p>
      </div>
    )}

    {image && (
      <p className="text-sm text-navy">
        Reference image: <strong>{image.name}</strong>
      </p>
    )}


    {errors.noTeams && (
      <Button
        variant="secondary"
        onClick={() => {
          setErrors({});
          setFormError('');
          setStep(1);
        }}
      >
        Choose another date
      </Button>
    )}
  </div>
)}


        <div className="mt-8 flex items-center justify-between border-t border-mist pt-5">
          {step > 0 ? <Button variant="secondary" onClick={back} disabled={submitting}>Back</Button> : <Link to="/my-events" className="text-sm font-semibold text-steel hover:text-navy">Cancel</Link>}
          {step < 5
            ? <Button onClick={next}>Continue</Button>
            : <Button onClick={submit} loading={submitting} disabled={!quote}>Submit Booking Request</Button>}
        </div>
      </div>
    </div>
  );
}
