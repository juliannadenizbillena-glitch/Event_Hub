import { useState } from 'react';
import { Camera, ClipboardList, Trash2, Truck, Wallet } from 'lucide-react';
import Card from '../../components/Card';
import Alert from '../../components/Alert';
import Button from '../../components/Button';
import Field from '../../components/Field';
import Select from '../../components/Select';
import Badge from '../../components/Badge';
import useLoad from '../../hooks/useLoad';
import useForm from '../../hooks/useForm';
import { rules } from '../../utils/validators';
import { peso } from '../../utils/format';
import api, { errorMessage } from '../../api/client';

const area = 'w-full rounded-xl border border-steel/40 px-4 py-2.5 text-sm text-navy placeholder:text-steel/60 focus:border-sky focus:outline-none focus:ring-2 focus:ring-sky/40';
const EQ_TONE = { planned: 'info', prepared: 'green', returned: 'sky' };

/* ============================ Operations (event preparation and conduct) ============================ */
export function OperationsCard({ b, role, act }) {
  const ops = b.operations || {};
  const isOrganizer = role === 'organizer';
  const preparing = isOrganizer && b.status === 'confirmed';
  const options = useLoad(async () => (preparing ? (await api.get(`/bookings/${b._id}/operations/options`)).data : null), [b._id, b.status, ops.venue?._id]);
  const [plan, setPlan] = useState(null); // { equipmentId: quantity }
  const current = plan || Object.fromEntries((ops.equipment || []).map((e) => [String(e.equipment), e.quantity]));
  const done = (ops.checklist || []).filter((c) => c.done).length;

  if (role === 'user') {
    return ops.venueName ? <Card title="Venue" icon={Truck}><p className="text-sm font-medium text-navy">{ops.venueName}</p><p className="mt-1 text-xs text-steel">Prepared by EventHub for your event.</p></Card> : null;
  }
  const call = (fn) => () => act(fn);

  return (
    <Card title="Event operations" description={isOrganizer ? 'Prepare and run this event.' : 'Preparation status reported by the Organizer.'} icon={ClipboardList}>
      <div className="space-y-6">
        {/* ---- venue ---- */}
        <section>
          <p className="text-sm font-semibold text-navy">Venue</p>
          {preparing ? (
            <VenuePicker b={b} options={options.data} act={act} />
          ) : (
            <p className="mt-1 text-sm text-navy">{ops.venue?.name || <span className="text-steel">No venue assigned.</span>}</p>
          )}
        </section>

        {/* ---- equipment ---- */}
        <section>
          <p className="text-sm font-semibold text-navy">Equipment</p>
          {preparing && options.data ? (
            <div className="mt-2 space-y-3">
              <p className="text-xs text-steel">Add only what this event needs. Free counts are for {b.date}.</p>
              <div className="max-h-64 divide-y divide-mist/60 overflow-y-auto rounded-xl border border-mist">
                {options.data.equipment.map((e) => (
                  <label key={e._id} className="flex items-center justify-between gap-3 px-3 py-2 text-sm text-navy">
                    <span>{e.name} <span className="text-xs text-steel">· {e.free} free</span></span>
                    <input type="number" min={0} max={e.free} aria-label={`Quantity of ${e.name}`} value={current[e._id] ?? ''} placeholder="0"
                      onChange={(ev) => setPlan({ ...current, [e._id]: ev.target.value })} className="w-20 rounded-lg border border-steel/40 px-2 py-1 text-sm" />
                  </label>
                ))}
              </div>
              <Button variant="secondary" onClick={call(() => api.put(`/bookings/${b._id}/operations/equipment`, { items: Object.entries(current).filter(([, q]) => Number(q) > 0).map(([equipment, q]) => ({ equipment, quantity: Number(q) })) }))}>Save equipment plan</Button>
            </div>
          ) : null}
          {(ops.equipment || []).length === 0 && !preparing && <p className="mt-1 text-sm text-steel">No equipment planned.</p>}
          {(ops.equipment || []).length > 0 && (
            <ul className="mt-2 divide-y divide-mist/60 text-sm text-navy">
              {ops.equipment.map((e) => (
                <li key={e.equipment} className="flex flex-wrap items-center justify-between gap-2 py-2">
                  <span>{e.name} × {e.quantity}</span>
                  <span className="flex items-center gap-2">
                    <Badge tone={EQ_TONE[e.status]}>{e.status}</Badge>
                    {isOrganizer && ['confirmed', 'ongoing', 'completed_pending_final'].includes(b.status) && (
                      <>
                        {e.status === 'planned' && <button className="text-xs font-semibold underline" onClick={call(() => api.patch(`/bookings/${b._id}/operations/equipment/${e.equipment}`, { status: 'prepared' }))}>Mark prepared</button>}
                        {e.status === 'prepared' && b.status !== 'confirmed' && <button className="text-xs font-semibold underline" onClick={call(() => api.patch(`/bookings/${b._id}/operations/equipment/${e.equipment}`, { status: 'returned' }))}>Mark returned</button>}
                      </>
                    )}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* ---- checklist ---- */}
        <section>
          <p className="text-sm font-semibold text-navy">Preparation checklist <span className="font-normal text-steel">({done} of {(ops.checklist || []).length} done)</span></p>
          <ul className="mt-2 space-y-1.5">
            {(ops.checklist || []).map((c) => (
              <li key={c.index}>
                <label className="flex items-center gap-3 text-sm text-navy">
                  <input type="checkbox" checked={c.done} disabled={!preparing} aria-label={c.label} className="h-4 w-4 accent-[#5B52B9]"
                    onChange={(e) => act(() => api.patch(`/bookings/${b._id}/operations/checklist/${c.index}`, { done: e.target.checked }))} />
                  <span className={c.done ? 'text-steel line-through' : ''}>{c.label}</span>
                </label>
              </li>
            ))}
          </ul>
        </section>

        {/* ---- event-day actions (Organizer only) ---- */}
        {isOrganizer && (
          <div className="flex flex-wrap gap-3 border-t border-mist pt-4">
            {b.status === 'confirmed' && !ops.ready && <Button onClick={call(() => api.post(`/bookings/${b._id}/operations/ready`))}>Mark preparation complete</Button>}
            {b.status === 'confirmed' && ops.ready && <Button onClick={call(() => api.post(`/bookings/${b._id}/operations/start`))}>Start event</Button>}
            {b.status === 'ongoing' && <Button onClick={call(() => api.post(`/bookings/${b._id}/operations/complete`))}>Complete event</Button>}
            {b.status === 'confirmed' && ops.ready && <Badge tone="green">Preparation complete</Badge>}
          </div>
        )}
      </div>
    </Card>
  );
}

function VenuePicker({ b, options, act }) {
  const [venue, setVenue] = useState('');
  if (!options) return null;
  const current = b.operations?.venue?._id;
  return (
    <div className="mt-2 flex flex-wrap items-end gap-3">
      <Select label="Select venue" value={venue || current || ''} onChange={(e) => setVenue(e.target.value)} className="min-w-64 flex-1">
        <option value="">Select venue</option>
        {options.venues.map((v) => (
          <option key={v._id} value={v._id} disabled={v.taken || !v.fits || v.status !== 'available'}>
            {v.name} · {v.capacity} pax{v.taken ? ' · taken that day' : !v.fits ? ' · too small' : ''}
          </option>
        ))}
      </Select>
      <Button variant="secondary" disabled={!venue || venue === current} onClick={() => act(() => api.put(`/bookings/${b._id}/operations/venue`, { venue }))}>Assign venue</Button>
    </div>
  );
}

/* ============================ Damage ============================ */
export function DamageCard({ b, role, act }) {
  const reports = b.damageReports || [];
  const charges = b.damageCharges || [];
  const canReport = role === 'organizer' && b.status === 'completed_pending_final' && b.inspection?.status === 'pending';
  if (role === 'user') {
    if (!charges.length) return null;
    return (
      <Card title="Damage charges" description="Verified damage approved by EventHub. It is added to your remaining balance." icon={Wallet}>
        <ul className="divide-y divide-mist/60 text-sm text-navy">{charges.map((c, i) => <li key={i} className="flex justify-between gap-3 py-2"><span>{c.item} × {c.quantity}<span className="block text-xs text-steel">{c.description}</span></span><span className="font-semibold">{peso(c.approvedAmount)}</span></li>)}</ul>
      </Card>
    );
  }
  const afterEvent = ['completed_pending_final', 'payment_overdue', 'fully_paid'].includes(b.status);
  if (!reports.length && !canReport && !afterEvent) return null;
  return (
    <Card title="Damage reports" description={role === 'admin' ? 'Only damage you approve is charged to the company.' : 'Reports go to Admin. You cannot charge the customer.'} icon={Camera}>
      <div className="space-y-4">
        {reports.length === 0 && <p className="text-sm text-steel">No damage reported.</p>}
        {reports.map((d) => <DamageRow key={d._id} d={d} role={role} act={act} />)}
        {canReport && <DamageForm b={b} act={act} />}
        {canReport && <InspectionFinish b={b} act={act} />}
      </div>
    </Card>
  );
}

function DamageRow({ d, role, act }) {
  const [mode, setMode] = useState(null); // 'approve' | 'reject'
  const [amount, setAmount] = useState(d.estimatedCost);
  const [note, setNote] = useState('');
  const [error, setError] = useState('');
  const tone = { pending: 'yellow', approved: 'green', rejected: 'red' }[d.status];
  const submit = async () => {
    setError('');
    if (mode === 'reject' && note.trim().length < 3) return setError('Give a reason of at least 3 characters.');
    if (mode === 'approve' && !(Number(amount) >= 1)) return setError('Enter an amount of 1 or more.');
    await act(() => api.post(`/damage-reports/${d._id}/review`, { decision: mode, ...(mode === 'approve' ? { approvedAmount: Number(amount) } : {}), note: note.trim() || undefined }));
  };
  return (
    <div className="rounded-xl border border-mist p-4 text-sm text-navy">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div><p className="font-semibold">{d.item} × {d.quantity}</p><p className="text-steel">{d.description}</p>{d.details && <p className="text-xs text-steel">{d.details}</p>}</div>
        <Badge tone={tone}>{d.status}</Badge>
      </div>
      <p className="mt-2 text-xs text-steel">Estimated cost: {peso(d.estimatedCost)}{role === 'admin' && d.approvedAmount ? ` · Approved: ${peso(d.approvedAmount)}` : ''}{d.reviewNote ? ` · Note: ${d.reviewNote}` : ''}</p>
      {d.evidenceCount > 0 && (
        <div className="mt-2 flex flex-wrap gap-2">
          {Array.from({ length: d.evidenceCount }).map((_, i) => (
            <a key={i} href={`/api/damage-reports/${d._id}/evidence/${i}`} target="_blank" rel="noreferrer"><img src={`/api/damage-reports/${d._id}/evidence/${i}`} alt={`Evidence ${i + 1} for ${d.item}`} className="h-16 w-24 rounded-lg border border-mist object-cover" /></a>
          ))}
        </div>
      )}
      {role === 'admin' && d.status === 'pending' && (
        <div className="mt-3 space-y-3">
          {!mode && <div className="flex gap-2"><Button className="!px-3 !py-1.5" onClick={() => setMode('approve')}>Approve</Button><Button variant="secondary" className="!px-3 !py-1.5" onClick={() => setMode('reject')}>Reject</Button></div>}
          {mode && (
            <div className="space-y-3 rounded-xl bg-mist/30 p-3">
              <Alert type="error">{error}</Alert>
              {mode === 'approve' && <Field label="Approved amount (₱)" type="number" min={1} placeholder="e.g. 5000" value={amount} onChange={(e) => setAmount(e.target.value)} />}
              <Field label={mode === 'reject' ? 'Reason' : 'Note (optional)'} placeholder={mode === 'reject' ? 'e.g. Normal wear and tear' : 'e.g. Verified against the photos'} value={note} onChange={(e) => setNote(e.target.value)} />
              <div className="flex gap-2"><Button className="!px-3 !py-1.5" onClick={submit}>{mode === 'approve' ? 'Confirm approval' : 'Confirm rejection'}</Button><Button variant="secondary" className="!px-3 !py-1.5" onClick={() => { setMode(null); setError(''); }}>Cancel</Button></div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function DamageForm({ b, act }) {
  const form = useForm({ item: '', description: '', quantity: '', details: '', estimatedCost: '' }, {
    item: rules.required('This field is required.'), description: rules.required('This field is required.'),
    quantity: rules.whole('the quantity', 1, 10000), estimatedCost: rules.whole('the estimated cost', 1, 10000000),
  });
  const [files, setFiles] = useState([]);
  const [error, setError] = useState('');
  const [open, setOpen] = useState(false);
  const submit = async (e) => {
    e.preventDefault(); setError('');
    if (!form.validateAll()) return;
    const fd = new FormData();
    Object.entries(form.values).forEach(([k, v]) => v !== '' && fd.append(k, v));
    files.forEach((f) => fd.append('evidence', f));
    if (await act(() => api.post(`/bookings/${b._id}/damage-reports`, fd))) { form.reset(); setFiles([]); setOpen(false); }
  };
  if (!open) return <Button variant="secondary" onClick={() => setOpen(true)}>Report damage</Button>;
  return (
    <form onSubmit={submit} noValidate className="space-y-4 rounded-xl border border-mist p-4">
      <p className="text-sm font-semibold text-navy">New damage report</p>
      <Alert type="error">{error}</Alert>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Item" placeholder="e.g. Projector" {...form.field('item')} />
        <Field label="Quantity" type="number" min={1} placeholder="e.g. 1" {...form.field('quantity')} />
      </div>
      <Field label="Description" placeholder="e.g. Lens cracked" {...form.field('description')} />
      <Field label="Damage details (optional)" placeholder="e.g. Dropped during teardown" {...form.field('details')} />
      <Field label="Estimated repair / replacement cost (₱)" type="number" min={1} placeholder="e.g. 8000" {...form.field('estimatedCost')} />
      <div>
        <label htmlFor="evidence" className="mb-1.5 block text-sm font-medium text-navy">Photos / evidence (up to 5)</label>
        <input id="evidence" type="file" multiple accept="image/jpeg,image/png,image/webp" onChange={(e) => setFiles([...e.target.files].slice(0, 5))} className="block w-full text-sm text-navy file:mr-3 file:rounded-lg file:border-0 file:bg-mist file:px-4 file:py-2 file:text-sm file:font-semibold file:text-navy" />
      </div>
      <div className="flex gap-3"><Button type="submit">Send to Admin</Button><Button type="button" variant="secondary" onClick={() => setOpen(false)}>Cancel</Button></div>
    </form>
  );
}

function InspectionFinish({ b, act }) {
  const [notes, setNotes] = useState('');
  return (
    <div className="space-y-3 border-t border-mist pt-4">
      <p className="text-sm font-semibold text-navy">Finish inspection</p>
      <textarea rows={2} className={area} placeholder="e.g. Equipment and venue checked. No other damage found." aria-label="Inspection notes" value={notes} onChange={(e) => setNotes(e.target.value)} />
      <Button onClick={() => act(() => api.post(`/bookings/${b._id}/inspection/finish`, { notes: notes.trim() || undefined }))}>Finish inspection</Button>
      <p className="text-xs text-steel">After this, Admin reviews any reports and the final balance is issued. No more reports can be added.</p>
    </div>
  );
}

/* ============================ Internal costs & profit (Admin only) ============================ */
const COST_LABEL = { fuel: 'Fuel', transportation: 'Transportation', equipment: 'Equipment', utilities: 'Utilities', printing_materials: 'Printing / materials', cleaning: 'Cleaning', staff_transport_meals: 'Staff transport / meals', venue_preparation: 'Venue preparation', other: 'Other' };
export function CostsCard({ b, act }) {
  const costs = b.internalCosts;
  const form = useForm({ category: '', amount: '', note: '' }, { category: rules.required('Select a category.'), amount: rules.whole('the amount', 1, 100000000) });
  const [error, setError] = useState('');
  if (!costs) return null;
  const add = async (e) => {
    e.preventDefault(); setError('');
    if (!form.validateAll()) return;
    if (await act(() => api.post(`/bookings/${b._id}/costs`, { category: form.values.category, amount: Number(form.values.amount), note: form.values.note || undefined }))) form.reset();
  };
  return (
    <Card title="Internal costs and profit" description="Admin only. Never shown to the company or the Organizer." icon={Wallet}>
      <div className="grid gap-3 sm:grid-cols-3">
        {[['Revenue collected', costs.revenue], ['Internal costs', costs.total], ['Profit', costs.profit]].map(([l, v]) => (
          <div key={l} className="rounded-xl bg-mist/30 px-4 py-3"><p className="text-xs text-steel">{l}</p><p data-testid={`cost-${l.split(' ')[0].toLowerCase()}`} className="text-lg font-bold text-navy">{peso(v)}</p></div>
        ))}
      </div>
      <ul className="mt-4 divide-y divide-mist/60 text-sm text-navy">
        {costs.items.length === 0 && <li className="py-2 text-steel">No costs recorded yet.</li>}
        {costs.items.map((c) => (
          <li key={c._id} className="flex items-center justify-between gap-3 py-2">
            <span>{COST_LABEL[c.category]}{c.note ? <span className="text-xs text-steel"> · {c.note}</span> : ''}</span>
            <span className="flex items-center gap-3"><span className="font-semibold">{peso(c.amount)}</span><button aria-label={`Remove ${COST_LABEL[c.category]} cost`} onClick={() => act(() => api.delete(`/admin/costs/${c._id}`))} className="text-steel hover:text-navy"><Trash2 size={15} /></button></span>
          </li>
        ))}
      </ul>
      <form onSubmit={add} noValidate className="mt-4 grid gap-3 rounded-xl bg-mist/20 p-3 sm:grid-cols-[1.2fr_1fr_1.4fr_auto] sm:items-end">
        <Select label="Category" {...form.field('category')}>
          <option value="">Select category</option>
          {Object.entries(COST_LABEL).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
        </Select>
        <Field label="Amount (₱)" type="number" min={1} placeholder="e.g. 1500" {...form.field('amount')} />
        <Field label="Note (optional)" placeholder="e.g. Fuel for delivery truck" {...form.field('note')} />
        <Button type="submit">Add cost</Button>
      </form>
      <div className="mt-2"><Alert type="error">{error}</Alert></div>
    </Card>
  );
}

/* ============================ Payment form (50% down payment and final payment) ============================ */
export function PaymentForm({ endpoint, amount, title, onDone, instructions }) {
  const form = useForm({ method: '', referenceNumber: '' }, {
    method: rules.required('Select a payment method.'),
    referenceNumber: (v) => (!v.trim() ? 'This field is required.' : /^[A-Za-z0-9-]{4,40}$/.test(v.trim()) ? '' : 'Use 4 to 40 letters, numbers or dashes.'),
  });
  const [file, setFile] = useState(null);
  const [fileTouched, setFileTouched] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const fileError = fileTouched && !file ? 'Upload your receipt or a screenshot of the payment.' : '';
  const i = instructions;

  const submit = async (e) => {
    e.preventDefault(); setError(''); setFileTouched(true);
    if (!form.validateAll() || !file) return;
    setLoading(true);
    try {
      const fd = new FormData();
      fd.append('method', form.values.method); fd.append('referenceNumber', form.values.referenceNumber.trim()); fd.append('receipt', file);
      const res = await api.post(endpoint, fd);
      await onDone(res.data.message);
    } catch (err) {
      const fe = fieldErrors(err);
      form.setServerErrors(fe.referenceNumber ? fe : (/reference number/i.test(errorMessage(err)) ? { referenceNumber: errorMessage(err) } : {}));
      if (!Object.keys(fe).length && !/reference number/i.test(errorMessage(err))) setError(errorMessage(err));
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      {i && (
        <div className="grid gap-3 rounded-xl bg-white/70 p-4 text-xs sm:grid-cols-2">
          <div><p className="font-semibold text-navy">GCash</p><p className="text-steel">{i.gcash.accountName}</p><p className="font-mono text-navy">{i.gcash.number}</p></div>
          <div><p className="font-semibold text-navy">Bank transfer</p><p className="text-steel">{i.bankTransfer.bank} · {i.bankTransfer.accountName}</p><p className="font-mono text-navy">{i.bankTransfer.accountNumber}</p></div>
        </div>
      )}
      <form onSubmit={submit} noValidate className="space-y-4 rounded-xl bg-white p-4">
        <p className="text-sm font-semibold text-navy">{title} · {peso(amount)}</p>
        <Alert type="error">{error}</Alert>
        <div className="grid gap-4 sm:grid-cols-2">
          <Select label="Payment method" {...form.field('method')}>
            <option value="">Select payment method</option>
            <option value="gcash">GCash</option><option value="bank_transfer">Bank transfer</option>
          </Select>
          <Field label="Reference number" placeholder="e.g. 1234567890123" {...form.field('referenceNumber')} />
        </div>
        <div>
          <label htmlFor="receipt" className="mb-1.5 block text-sm font-medium text-navy">Receipt or screenshot</label>
          <input id="receipt" type="file" accept="image/jpeg,image/png,image/webp,application/pdf" aria-invalid={!!fileError} onBlur={() => setFileTouched(true)}
            onChange={(e) => { setFile(e.target.files?.[0] || null); setFileTouched(true); }}
            className="block w-full text-sm text-navy file:mr-3 file:rounded-lg file:border-0 file:bg-mist file:px-4 file:py-2 file:text-sm file:font-semibold file:text-navy" />
          {fileError ? <p className="mt-1 text-xs text-red-600">{fileError}</p> : <p className="mt-1 text-xs text-steel">Upload a receipt or screenshot (JPG, PNG, WebP or PDF, up to 5 MB).</p>}
        </div>
        <Button type="submit" loading={loading}>Submit payment</Button>
      </form>
    </div>
  );
}
