import { useEffect, useRef, useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { Archive, ArchiveRestore, ArrowLeft, CheckCircle2, Clock, FileText, Hourglass, ShieldAlert, Wallet, XCircle } from 'lucide-react';
import Card from '../../components/Card';
import Alert from '../../components/Alert';
import Button from '../../components/Button';
import Badge from '../../components/Badge';
import Modal from '../../components/Modal';
import Countdown from '../../components/Countdown';
import ReasonModal from '../../components/ReasonModal';
import LoadState from '../../components/LoadState';
import BookingStatusBadge from '../../components/BookingStatusBadge';
import { OperationsCard, DamageCard, CostsCard, PaymentForm } from './panels';
import useLoad from '../../hooks/useLoad';
import { useAuth } from '../../context/AuthContext';
import { STATUS, ARCHIVABLE } from '../../config/bookingStatus';
import { formatDate, formatDateTime, formatTime, peso } from '../../utils/format';
import api, { errorMessage } from '../../api/client';

const PAY_TONE = { pending: 'sky', verified: 'green', rejected: 'red' };
const Row = ({ label, children }) => (<div><dt className="text-xs font-semibold uppercase tracking-wide text-steel">{label}</dt><dd className="mt-0.5 text-sm font-medium text-navy">{children || '—'}</dd></div>);

// ONE page for every status and every role. The status decides which panel and which actions show;
// there is never a separate page per status.
export default function BookingDetails({ back }) {
  const { id } = useParams();
  const { state, pathname } = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: b, loading, error, reload } = useLoad(async () => (await api.get(`/bookings/${id}`)).data.booking, [id]);
  const [notice, setNotice] = useState({ type: state?.flash ? 'success' : '', text: state?.flash || '' });
  const [modal, setModal] = useState(null); // 'cancel' | 'admin-cancel'
  const cleared = useRef(false);
  useEffect(() => { if (state && !cleared.current) { cleared.current = true; navigate(pathname, { replace: true, state: null }); } }, []); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (notice.type !== 'success') return undefined; const t = setTimeout(() => setNotice({ type: '', text: '' }), 12000); return () => clearTimeout(t); }, [notice]);

  const role = user.role;
  const money = role !== 'organizer';
  // Runs an action, shows its message, reloads. Returns true when it worked (forms reset only then).
  const act = async (fn) => {
    setNotice({ type: '', text: '' });
    try { const res = await fn(); setNotice({ type: 'success', text: res.data.message }); await reload(); return true; }
    catch (err) { setNotice({ type: 'error', text: errorMessage(err) }); await reload(); return false; }
  };

  const canCancel = b && ((role === 'user' && (['pending_approval', 'payment_required'].includes(b.status) || (b.status === 'confirmed' && b.date > new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Manila' }))))
    || (role === 'admin' && ['pending_approval', 'payment_required', 'confirmed'].includes(b.status)));

  return (
    <div className="mx-auto max-w-4xl space-y-5">
      <Link to={back.to} className="inline-flex items-center gap-1.5 text-sm font-semibold text-steel hover:text-navy"><ArrowLeft size={16} /> {back.label}</Link>
      <LoadState loading={loading} error={error} hasData={!!b}>
        {b && (
          <>
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h1 className="text-2xl font-bold text-navy">{b.eventName}</h1>
                <p className="mt-1 text-sm text-steel">{b.code} · {b.eventType?.name} · {b.branch?.name}</p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                {b.isArchived && <Badge tone="gray">Archived</Badge>}
                <BookingStatusBadge status={b.status} />
              </div>
            </div>

            {(canCancel || (role === 'admin' && (ARCHIVABLE.includes(b.status) || b.isArchived))) && (
              <div className="flex flex-wrap gap-3">
                {canCancel && <Button variant="secondary" onClick={() => setModal(role === 'admin' ? 'admin-cancel' : 'cancel')}>Cancel booking</Button>}
                {role === 'admin' && ARCHIVABLE.includes(b.status) && !b.isArchived && <Button variant="secondary" onClick={() => act(() => api.post(`/bookings/${b._id}/archive`))}><Archive size={16} /> Archive</Button>}
                {role === 'admin' && b.isArchived && <Button variant="secondary" onClick={() => act(() => api.post(`/bookings/${b._id}/restore`))}><ArchiveRestore size={16} /> Restore</Button>}
              </div>
            )}
            <Alert type={notice.type || 'info'}>{notice.text}</Alert>

            <StatusPanel b={b} role={role} act={act} reload={reload} />

            <Card title="Event" icon={FileText}>
              <dl className="grid gap-x-6 gap-y-4 sm:grid-cols-2">
                {role !== 'user' && <Row label="Company">{b.company?.companyName}</Row>}
                {role !== 'user' && <Row label="Contact">{b.company ? `${b.company.contactName} · ${b.company.phone || ''}` : null}</Row>}
                <Row label="Event type">{b.eventType?.name}</Row>
                <Row label="Branch">{b.branch?.name}</Row>
                

<Row label="Date">
  {b.durationMode === 'multi_day' && b.endDate
    ? `${formatDate(b.date)} – ${formatDate(b.endDate)}`
    : formatDate(b.date)}
</Row>


                <Row label="Time">{`${formatTime(b.startTime)} – ${formatTime(b.endTime)}`}</Row>
                <Row label="Attendees">{`${b.attendees} (${b.teamsRequired} ${b.teamsRequired === 1 ? 'team' : 'teams'} required)`}</Row>
                {b.assignedTeams?.length > 0 && <Row label={['confirmed', 'ongoing', 'completed_pending_final', 'fully_paid', 'payment_overdue'].includes(b.status) ? 'Teams reserved' : 'Teams held'}>{b.assignedTeams.map((t) => t.name).join(', ')}</Row>}
                <Row label="Submitted">{formatDateTime(b.createdAt)}</Row>
              </dl>
              {b.requirements && <div className="mt-5"><p className="text-xs font-semibold uppercase tracking-wide text-steel">Additional requirements</p><p className="mt-1 whitespace-pre-wrap text-sm text-navy">{b.requirements}</p></div>}
              {b.hasReferenceImage && (
                <div className="mt-5">
                  <p className="text-xs font-semibold uppercase tracking-wide text-steel">Reference image</p>
                  <a href={`/api/bookings/${b._id}/reference-image`} target="_blank" rel="noreferrer"><img src={`/api/bookings/${b._id}/reference-image`} alt="Event reference" className="mt-2 max-h-64 rounded-xl border border-mist object-contain" /></a>
                </div>
              )}
            </Card>

            {['confirmed', 'ongoing', 'completed_pending_final', 'fully_paid', 'payment_overdue'].includes(b.status) && <OperationsCard b={b} role={role} act={act} />}
            <DamageCard b={b} role={role} act={act} />

            
<Card title="Bundle and add-ons" icon={FileText}>
  <div className="space-y-3 text-sm text-navy">
    <div className="flex justify-between gap-3">
      <span>
        <strong>{b.bundle?.name}</strong>{' '}
        <span className="text-steel">
          (up to {b.bundle?.capacity} attendees)
        </span>
      </span>
      {money && (
        <span className="font-semibold">{peso(b.bundle?.price)}</span>
      )}
    </div>

    {['equipment', 'services', 'resources'].map((group) => {
      const items = b.bundle?.inclusions?.[group] || [];
      if (items.length === 0) return null;

      return (
        <div key={group} className="pl-3">
          <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-steel">
            {group}
          </p>
          <ul className="space-y-1">
            {items.map((item, index) => {
              const name = typeof item === 'string' ? item : item.name;
              const quantity =
                typeof item === 'string' ? 1 : (item.quantity ?? 1);

              return (
                <li key={`${name}-${index}`} className="text-steel">
                  {name} x{quantity}
                </li>
              );
            })}
          </ul>
        </div>
      );
    })}

    {b.addOns?.map((a, index) => (
      <div
        key={a.addOn || `${a.name}-${index}`}
        className="flex justify-between gap-3 text-steel"
      >
        <span>+ {a.name} x{a.quantity ?? 1}</span>
        {money && <span>{peso(a.price)}</span>}
      </div>
    ))}

    {(!b.addOns || b.addOns.length === 0) && (
      <p className="text-steel">No add-ons selected.</p>
    )}
  </div>

  {money && (
    <dl className="mt-4 space-y-1.5 border-t border-mist pt-4 text-sm">
      <div className="flex justify-between font-bold text-navy">
        <dt>Event total</dt>
        <dd>{peso(b.total)}</dd>
      </div>
      <div className="flex justify-between text-navy">
        <dt>Down payment (50%)</dt>
        <dd>{peso(b.downPaymentAmount)}</dd>
      </div>
      <div className="flex justify-between text-navy">
        <dt>Remaining balance (after the event)</dt>
        <dd>{peso(b.remainingAmount)}</dd>
      </div>
    </dl>
  )}

  {!money && (
    <p className="mt-4 text-xs text-steel">
      Prices and payments are handled by Admin.
    </p>
  )}
</Card>


            {money && ['completed_pending_final', 'payment_overdue', 'fully_paid'].includes(b.status) && <FinalBalanceCard b={b} />}

            {money && b.payments?.length > 0 && (
              <Card title="Payments" icon={Wallet}>
                <ul className="divide-y divide-mist/70">
                  {b.payments.map((p) => (
                    <li key={p._id} className="flex flex-wrap items-start justify-between gap-3 py-3 text-sm">
                      <div>
                        <p className="font-semibold text-navy">{p.type === 'down' ? '50% down payment' : 'Final payment'} · {peso(p.amount)}</p>
                        <p className="text-xs text-steel">{p.method === 'gcash' ? 'GCash' : 'Bank transfer'} · Ref {p.referenceNumber} · {formatDateTime(p.submittedAt)}</p>
                        {p.rejectionReason && <p className="mt-1 text-xs text-red-700">Rejected: {p.rejectionReason}</p>}
                        {p.hasReceipt && <a href={`/api/payments/${p._id}/receipt`} target="_blank" rel="noreferrer" className="mt-1 inline-block text-xs font-semibold text-navy underline">View receipt</a>}
                      </div>
                      <Badge tone={PAY_TONE[p.status]}>{p.status === 'pending' ? 'Under review' : p.status[0].toUpperCase() + p.status.slice(1)}</Badge>
                    </li>
                  ))}
                </ul>
              </Card>
            )}

            {role === 'admin' && <CostsCard b={b} act={act} />}

            <Card title="Timeline" icon={Clock}>
              <ol className="space-y-4">
                {[...b.history].reverse().map((h, i) => (
                  <li key={i} className="flex gap-3">
                    <span className="mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full bg-sky" />
                    <div>
                      <p className="text-sm font-semibold text-navy">{STATUS[h.status]?.label || h.status}</p>
                      {h.note && <p className="text-sm text-steel">{h.note}</p>}
                      <p className="text-xs text-steel">{formatDateTime(h.at)} · {h.byRole === 'system' ? 'System' : h.byRole === 'admin' ? 'Admin' : h.byRole === 'organizer' ? 'Organizer' : 'Company'}</p>
                    </div>
                  </li>
                ))}
              </ol>
            </Card>

            {modal === 'cancel' && <CancelModal confirmed={b.status === 'confirmed'} onClose={() => setModal(null)} onConfirm={async (reason) => { setModal(null); await act(() => api.post(`/bookings/${b._id}/cancel`, { reason: reason || undefined })); }} />}
            {modal === 'admin-cancel' && <ReasonModal title="Cancel booking" label="Reason shown to the company" placeholder="e.g. The event could not be accommodated." confirmLabel="Cancel booking" onClose={() => setModal(null)} onConfirm={async (reason) => { try { const res = await api.post(`/bookings/${b._id}/cancel`, { reason }); setModal(null); setNotice({ type: 'success', text: res.data.message }); await reload(); } catch (err) { throw new Error(errorMessage(err)); } }} />}
          </>
        )}
      </LoadState>
    </div>
  );
}

function CancelModal({ confirmed, onClose, onConfirm }) {
  const [reason, setReason] = useState('');
  return (
    <Modal title="Cancel this booking?" onClose={onClose}>
      <div className="space-y-4 text-sm text-navy">
        {confirmed
          ? <Alert type="error">This booking is confirmed. If you cancel, the 50% down payment is non-refundable.</Alert>
          : <p>The booking will be cancelled and any held teams are released.</p>}
        <div>
          <label htmlFor="cancel-reason" className="mb-1.5 block font-medium">Reason (optional)</label>
          <textarea id="cancel-reason" rows={3} maxLength={300} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. Our plans changed" className="w-full rounded-xl border border-steel/40 px-4 py-2.5 text-sm text-navy placeholder:text-steel/60 focus:border-sky focus:outline-none focus:ring-2 focus:ring-sky/40" />
        </div>
        <div className="flex justify-end gap-3"><Button variant="secondary" onClick={onClose}>Keep booking</Button><Button variant="dark" onClick={() => onConfirm(reason.trim())}>Cancel booking</Button></div>
      </div>
    </Modal>
  );
}

function FinalBalanceCard({ b }) {
  const ready = b.finalAmountDue !== undefined && b.finalAmountDue !== null;
  return (
    <Card title="Final balance" description="Remaining 50% plus any damage approved by EventHub." icon={Wallet}>
      <dl className="space-y-1.5 text-sm text-navy">
        <div className="flex justify-between"><dt>Remaining balance (50%)</dt><dd>{peso(b.remainingAmount)}</dd></div>
        <div className="flex justify-between"><dt>Approved damage charges</dt><dd>{ready || b.damageTotal ? peso(b.damageTotal || 0) : 'Being reviewed'}</dd></div>
        <div className="flex justify-between border-t border-mist pt-2 text-base font-bold"><dt>Final amount due</dt><dd data-testid="final-due">{ready ? peso(b.finalAmountDue) : 'Being prepared'}</dd></div>
        {b.finalPaymentDueAt && b.status !== 'fully_paid' && <div className="flex justify-between text-xs text-steel"><dt>Pay before</dt><dd>{formatDateTime(b.finalPaymentDueAt)}</dd></div>}
        {b.finalPaidAt && <div className="flex justify-between text-xs text-steel"><dt>Paid on</dt><dd>{formatDateTime(b.finalPaidAt)}</dd></div>}
      </dl>
    </Card>
  );
}

/* --------------------- the panel that depends on status + role --------------------- */
function Box({ tone = 'info', icon: Icon, title, children }) {
  const tones = { info: 'border-mist bg-mist/30', success: 'border-emerald-200 bg-emerald-50', danger: 'border-red-200 bg-red-50', warn: 'border-orange-200 bg-orange-50' };
  return (
    <section className={`rounded-2xl border p-5 ${tones[tone]}`}>
      <div className="flex items-start gap-3">
        {Icon && <Icon size={22} className="mt-0.5 shrink-0 text-navy" />}
        <div className="flex-1 space-y-3 text-sm text-navy"><h2 className="text-base font-semibold">{title}</h2>{children}</div>
      </div>
    </section>
  );
}

function StatusPanel({ b, role, act, reload }) {
  const [modal, setModal] = useState(null);
  const instructions = useLoad(async () => (role === 'user' && ['payment_required', 'completed_pending_final', 'payment_overdue'].includes(b.status) ? (await api.get('/payments/instructions')).data.instructions : null), [b.status]);
  const pending = b.payments?.find((p) => p.status === 'pending');
  const lastRejected = [...(b.payments || [])].reverse().find((p) => p.status === 'rejected');
  const throwing = (fn) => async (reason) => { try { const res = await fn(reason); setModal(null); await act(async () => res); } catch (err) { throw new Error(errorMessage(err)); } };
  const finalReady = b.finalAmountDue !== undefined && b.finalAmountDue !== null;
  const done = async (message) => { await act(async () => ({ data: { message } })); };

  // ---------- Organizer ----------
  if (role === 'organizer') {
    if (b.status === 'confirmed') return <Box tone="success" icon={CheckCircle2} title="Confirmed event"><p>Teams are reserved. Assign the venue, plan equipment and finish the checklist below, then mark preparation complete. The event can be started on its date.</p></Box>;
    if (b.status === 'ongoing') return <Box tone="info" icon={Hourglass} title="Event in progress"><p>When the event ends, complete it below to start the inspection.</p></Box>;
    if (b.status === 'completed_pending_final') return <Box tone="info" icon={ShieldAlert} title={b.inspection?.status === 'completed' ? 'Inspection finished' : 'Inspection'}><p>{b.inspection?.status === 'completed' ? 'Admin reviews any damage reports and issues the final balance.' : 'Check equipment and property, report any damage, then finish the inspection.'}</p></Box>;
    if (['pending_approval', 'payment_required', 'payment_verification'].includes(b.status)) return <Box icon={Hourglass} title="View only"><p>You can see this request. Approving or rejecting bookings and verifying payments belong to Admin.</p></Box>;
    return null;
  }

  // ---------- Admin ----------
  if (role === 'admin') {
    if (b.status === 'pending_approval') {
      const ta = b.teamAvailability;
      const enough = ta && ta.free >= ta.required;
      return (
        <Box tone={enough ? 'info' : 'warn'} icon={ShieldAlert} title="Review this request">
          {ta && <p>Teams required: <strong>{ta.required}</strong> · free on {formatDate(b.date)}: <strong>{ta.free}</strong> of {ta.activeTeams} active.{!enough && ' There are not enough teams. Reject the request with a reason (for example, the schedule is no longer available).'}</p>}
          <p className="text-xs text-steel">Approving holds the required teams for 24 hours while the company pays the 50% down payment ({peso(b.downPaymentAmount)}).</p>
          <div className="flex flex-wrap gap-3">
            <Button disabled={!enough} onClick={() => act(() => api.post(`/bookings/${b._id}/approve`))}>Approve booking</Button>
            <Button variant="secondary" onClick={() => setModal('reject-booking')}>Reject booking</Button>
          </div>
          {modal === 'reject-booking' && <ReasonModal title="Reject booking" label="Reason shown to the company" placeholder="e.g. Requested schedule is no longer available." confirmLabel="Reject booking" onClose={() => setModal(null)} onConfirm={throwing((reason) => api.post(`/bookings/${b._id}/reject`, { reason }))} />}
        </Box>
      );
    }
    if (b.status === 'payment_required') {
      return <Box tone="warn" icon={Hourglass} title="Waiting for the down payment"><p>Teams are held for this booking. Time left to pay: <Countdown until={b.paymentDeadline} onExpire={reload} /></p>{lastRejected && <p className="text-xs text-red-700">Last payment rejected: {lastRejected.rejectionReason}</p>}</Box>;
    }
    if (pending && ['payment_verification', 'completed_pending_final', 'payment_overdue'].includes(b.status)) {
      const isFinal = pending.type === 'final';
      return (
        <Box icon={ShieldAlert} title={isFinal ? 'Verify the final payment' : 'Verify the down payment'}>
          <dl className="grid gap-3 sm:grid-cols-3">
            <Row label="Amount">{peso(pending.amount)}</Row>
            <Row label="Method">{pending.method === 'gcash' ? 'GCash' : 'Bank transfer'}</Row>
            <Row label="Reference number">{pending.referenceNumber}</Row>
          </dl>
          <p>Expected amount: <strong>{peso(isFinal ? b.finalAmountDue : b.downPaymentAmount)}</strong>. Check the receipt before deciding.</p>
          <a href={`/api/payments/${pending._id}/receipt`} target="_blank" rel="noreferrer" className="inline-block font-semibold underline">Open receipt</a>
          <div className="flex flex-wrap gap-3">
            <Button onClick={() => act(() => api.post(`/payments/${pending._id}/verify`))}>Verify payment</Button>
            <Button variant="secondary" onClick={() => setModal('reject-payment')}>Reject payment</Button>
          </div>
          {modal === 'reject-payment' && <ReasonModal title="Reject payment" label="Reason shown to the company" placeholder="e.g. The amount does not match." confirmLabel="Reject payment" onClose={() => setModal(null)} onConfirm={throwing((reason) => api.post(`/payments/${pending._id}/reject`, { reason }))} />}
        </Box>
      );
    }
    if (b.status === 'confirmed') return <Box tone="success" icon={CheckCircle2} title="Confirmed"><p>The down payment was verified and the teams are locked. The Organizer prepares the event. The remaining balance ({peso(b.remainingAmount)}) is collected after the event.</p></Box>;
    if (b.status === 'ongoing') return <Box tone="info" icon={Hourglass} title="Event in progress"><p>The Organizer started this event.</p></Box>;
    if (b.status === 'completed_pending_final') {
      const waiting = (b.damageReports || []).filter((d) => d.status === 'pending').length;
      return <Box tone="info" icon={Hourglass} title={finalReady ? 'Waiting for the final payment' : 'Event complete: inspection and damage review'}><p>{finalReady ? `The final balance of ${peso(b.finalAmountDue)} was issued to the company.` : b.inspection?.status !== 'completed' ? 'The Organizer is still inspecting. The final balance is issued after the inspection and any damage review.' : `${waiting} damage report(s) to review below. The final balance is issued once they are all reviewed.`}</p></Box>;
    }
    if (b.status === 'payment_overdue') return <Box tone="danger" icon={XCircle} title="Final payment overdue"><p>The company owes {peso(b.finalAmountDue)}. New bookings are blocked until it is paid.</p></Box>;
    if (b.status === 'fully_paid') return <Box tone="success" icon={CheckCircle2} title="Completed / Fully Paid"><p>Both payments were verified. You can archive this booking.</p></Box>;
    if (b.status === 'rejected') return <Box tone="danger" icon={XCircle} title="Rejected"><p>{b.rejectionReason}</p></Box>;
    if (b.status === 'payment_expired') return <Box tone="danger" icon={XCircle} title="Payment expired"><p>The 24-hour payment window ended without a verified payment. The teams were released.</p></Box>;
    if (b.status === 'cancelled') return <Box tone="info" icon={XCircle} title="Cancelled"><p>{b.cancellationReason || 'This booking was cancelled.'}</p></Box>;
    return null;
  }

  // ---------- User / Company ----------
  switch (b.status) {
    case 'pending_approval':
      return <Box icon={Hourglass} title="Waiting for Admin approval"><p>EventHub is reviewing your request. You will be notified. Nothing is due yet.</p></Box>;
    case 'rejected':
      return <Box tone="danger" icon={XCircle} title="Your booking was rejected"><p>{b.rejectionReason}</p><Link to="/book-event"><Button variant="secondary">Make a new booking request</Button></Link></Box>;
    case 'payment_required':
      return (
        <Box tone="warn" icon={Clock} title="Down payment required">
          <div className="grid gap-4 sm:grid-cols-2">
            <Row label="Amount (50%)"><span className="text-xl font-bold">{peso(b.downPaymentAmount)}</span></Row>
            <Row label="Time left to pay"><Countdown until={b.paymentDeadline} onExpire={reload} /></Row>
          </div>
          <p className="text-xs text-steel">Deadline: {formatDateTime(b.paymentDeadline)}. If it is not paid in time, the booking expires and the teams are released.</p>
          {lastRejected && <Alert type="error">Your last payment was rejected: {lastRejected.rejectionReason} You can submit it again before the deadline.</Alert>}
          <PaymentForm endpoint={`/bookings/${b._id}/payments`} amount={b.downPaymentAmount} title="Down payment (50%)" instructions={instructions.data} onDone={done} />
        </Box>
      );
    case 'payment_verification':
      return <Box icon={Hourglass} title="Payment under review"><p>We received your down payment{pending ? ` (ref ${pending.referenceNumber})` : ''}. EventHub will verify it shortly and confirm your event.</p></Box>;
    case 'confirmed':
      return <Box tone="success" icon={CheckCircle2} title="Your event is confirmed"><p>Your down payment was verified and your teams are reserved. The remaining balance of <strong>{peso(b.remainingAmount)}</strong> is due after the event (plus any approved damage fee).</p></Box>;
    case 'ongoing':
      return <Box icon={Hourglass} title="Your event is ongoing"><p>EventHub's team is running your event today.</p></Box>;
    case 'completed_pending_final':
    case 'payment_overdue': {
      const overdue = b.status === 'payment_overdue';
      if (!finalReady) return <Box icon={Hourglass} title="Your event is complete"><p>EventHub is inspecting equipment and property. Your final balance (the remaining 50% plus any approved damage) will be issued shortly, and you will be notified.</p></Box>;
      if (pending) return <Box icon={Hourglass} title="Final payment under review"><p>We received your final payment (ref {pending.referenceNumber}). EventHub will verify it shortly.</p></Box>;
      return (
        <Box tone={overdue ? 'danger' : 'warn'} icon={overdue ? XCircle : Clock} title={overdue ? 'Final payment overdue' : 'Final payment required'}>
          <p>{overdue ? 'This balance is past its due date. New bookings are on hold until it is paid.' : `Please pay before ${formatDateTime(b.finalPaymentDueAt)}.`}</p>
          {lastRejected && <Alert type="error">Your last payment was rejected: {lastRejected.rejectionReason}</Alert>}
          <PaymentForm endpoint={`/bookings/${b._id}/final-payment`} amount={b.finalAmountDue} title="Final payment" instructions={instructions.data} onDone={done} />
        </Box>
      );
    }
    case 'fully_paid':
      return <Box tone="success" icon={CheckCircle2} title="Event completed"><p>Your event is complete and fully paid. Thank you for choosing EventHub.</p></Box>;
    case 'payment_expired':
      return <Box tone="danger" icon={XCircle} title="Payment expired"><p>The 24-hour payment window ended, so this booking was cancelled and the teams were released.</p><Link to="/book-event"><Button variant="secondary">Create a new booking request</Button></Link></Box>;
    case 'cancelled':
      return <Box icon={XCircle} title="Booking cancelled"><p>{b.cancellationReason || 'This booking was cancelled.'}</p><Link to="/book-event"><Button variant="secondary">Create a new booking request</Button></Link></Box>;
    default:
      return null;
  }
}
