import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus } from 'lucide-react';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import LoadState from '../../components/LoadState';
import BookingStatusBadge from '../../components/BookingStatusBadge';
import Button from '../../components/Button';
import Select from '../../components/Select';
import useLoad from '../../hooks/useLoad';
import { STATUS } from '../../config/bookingStatus';
import { formatDate, peso } from '../../utils/format';
import api from '../../api/client';

// One list for every role. `config` (see lists.js) decides the scope, columns and wording, so each
// role only sees what the flow gives it: User: own bookings. Organizer: own branch, no prices.
// Admin: everything.
export default function BookingList({ config }) {
  const [filters, setFilters] = useState({ search: '', status: '', branch: '' });
  const [debounced, setDebounced] = useState(filters);
  const [page, setPage] = useState(1);
  useEffect(() => { const t = setTimeout(() => { setDebounced(filters); setPage(1); }, 300); return () => clearTimeout(t); }, [filters]);
  const set = (k) => (e) => setFilters((f) => ({ ...f, [k]: e.target.value }));

  const branches = useLoad(async () => (config.branchFilter ? (await api.get('/branches')).data.branches : []));
  const list = useLoad(async () => (await api.get('/bookings', {
    params: { scope: config.scope, sort: config.sort, page, limit: 15, ...Object.fromEntries(Object.entries(debounced).filter(([, v]) => v)) },
  })).data, [config.scope, debounced, page]);

  const columns = [
    { key: 'code', label: 'Booking', render: (b) => (
      <div><Link to={`${config.basePath}/${b._id}`} className="font-semibold text-navy hover:underline">{b.eventName}</Link><p className="text-xs text-steel">{b.code}</p></div>
    ) },
    ...(config.showCompany ? [{ key: 'company', label: 'Company', render: (b) => b.company?.companyName || '—' }] : []),
    { key: 'type', label: 'Type', render: (b) => b.eventType?.name },
    ...(config.showBranch ? [{ key: 'branch', label: 'Branch', render: (b) => b.branch?.name }] : []),
    {
     key: 'date',
    label: 'Date',
    render: (b) =>
    b.durationMode === 'multi_day' && b.endDate
      ? `${formatDate(b.date)} – ${formatDate(b.endDate)}`
      : formatDate(b.date),
},
    
    { key: 'attendees', label: 'Guests', render: (b) => b.attendees },
    ...(config.showTotal ? [{ key: 'total', label: 'Total', render: (b) => peso(b.total) }] : []),
    { key: 'status', label: 'Status', render: (b) => <BookingStatusBadge status={b.status} /> },
  ];

  const data = list.data;
  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader
        title={config.title}
        subtitle={config.subtitle}
        viewOnly={config.viewOnly}
      />
      <div className="mb-4 grid gap-3 sm:grid-cols-3">
        <div>
          <label htmlFor="bk-search" className="mb-1.5 block text-sm font-medium text-navy">Search</label>
          <input id="bk-search" value={filters.search} onChange={set('search')} placeholder={config.showCompany ? 'Event, code or company' : 'Event or code'}
            className="w-full rounded-xl border border-steel/40 px-3 py-2.5 text-sm text-navy placeholder:text-steel/70 focus:border-sky focus:outline-none focus:ring-2 focus:ring-sky/40" />
        </div>
        <Select label="Status" value={filters.status} onChange={set('status')}>
          <option value="">All statuses</option>
          {config.statuses.map((s) => <option key={s} value={s}>{STATUS[s].label}</option>)}
        </Select>
        {config.branchFilter && (
          <Select label="Branch" value={filters.branch} onChange={set('branch')}>
            <option value="">All branches</option>
            {branches.data?.map((b) => <option key={b._id} value={b._id}>{b.name}</option>)}
          </Select>
        )}
      </div>

      <LoadState loading={list.loading} error={list.error} hasData={!!data}>
        <DataTable columns={columns} rows={data?.bookings || []} empty={config.empty} />
        {data && data.pages > 1 && (
          <div className="mt-4 flex items-center justify-between text-sm text-steel">
            <span>{data.total} bookings · page {data.page} of {data.pages}</span>
            <div className="flex gap-2">
              <Button variant="secondary" className="!px-3 !py-1.5" disabled={page <= 1} onClick={() => setPage(page - 1)}>Previous</Button>
              <Button variant="secondary" className="!px-3 !py-1.5" disabled={page >= data.pages} onClick={() => setPage(page + 1)}>Next</Button>
            </div>
          </div>
        )}
      </LoadState>
    </div>
  );
}
