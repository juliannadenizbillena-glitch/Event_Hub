import { useState } from 'react';
import PageHeader from '../../components/PageHeader';
import Select from '../../components/Select';
import Field from '../../components/Field';
import AvailabilityCalendar from '../../components/AvailabilityCalendar';
import EventCalendar from '../../components/EventCalendar';
import useLoad from '../../hooks/useLoad';
import { useAuth } from '../../context/AuthContext';
import api from '../../api/client';

const Tabs = ({ tab, setTab, items }) => (
  <div className="flex gap-2 border-b border-mist" role="tablist">
    {items.map(([key, label]) => (
      <button key={key} role="tab" aria-selected={tab === key} onClick={() => setTab(key)} className={`-mb-px border-b-2 px-4 py-2.5 text-sm font-semibold transition ${tab === key ? 'border-sky text-navy' : 'border-transparent text-steel hover:text-navy'}`}>{label}</button>
    ))}
  </div>
);

// User: their own events + which dates they can book.  Organizer: their branch's schedule + team availability.
export default function CalendarPage() {
  const { user } = useAuth();
  const own = user.role === 'organizer';
  const [tab, setTab] = useState('events');
  const [branch, setBranch] = useState('');
  const [eventType, setEventType] = useState('');
  const [attendees, setAttendees] = useState('100');
  const lists = useLoad(async () => { const [b, t] = await Promise.all([api.get('/branches'), api.get('/event-types')]); return { branches: b.data.branches, eventTypes: t.data.eventTypes }; });
  const n = Number(attendees);
  const valid = Number.isInteger(n) && n >= 1 && n <= 500;

  return (
    <div className="mx-auto max-w-4xl space-y-5">
      <PageHeader title="Calendar" subtitle={own ? 'Your branch schedule, and how many teams are free on each date.' : 'Your events, and which dates are open for booking.'} />
      <Tabs tab={tab} setTab={setTab} items={[['events', own ? 'Event schedule' : 'My events'], ['availability', own ? 'Team availability' : 'Check availability']]} />
      {tab === 'events' ? <EventCalendar /> : (
        <>
          <div className="grid gap-4 sm:grid-cols-3">
            {!own && <Select label="Branch" value={branch} onChange={(e) => setBranch(e.target.value)}><option value="">Select branch</option>{lists.data?.branches.map((b) => <option key={b._id} value={b._id}>{b.name}</option>)}</Select>}
            {own && <Field label="Branch" value={user.branch?.name || '—'} readOnly />}
            <Select label="Event type" value={eventType} onChange={(e) => setEventType(e.target.value)}><option value="">Select event type</option>{lists.data?.eventTypes.map((t) => <option key={t._id} value={t._id}>{t.name}</option>)}</Select>
            <Field label="Attendees" type="number" min={1} max={500} placeholder="e.g. 150" value={attendees} onChange={(e) => setAttendees(e.target.value)} error={valid ? undefined : '1 to 500'} />
          </div>
          {eventType && valid && (branch || own)
            ? <AvailabilityCalendar branchId={own ? undefined : branch} branchOptional={own} eventTypeId={eventType} attendees={n} showCounts={own} />
            : <p className="rounded-2xl border border-mist bg-white px-4 py-10 text-center text-sm text-steel">Select {own ? 'an event type' : 'a branch and an event type'} to see availability.</p>}
        </>
      )}
    </div>
  );
}

// Admin: the "Events" page offers a list and a system-wide calendar (Admin has no separate Calendar menu item).
export function AdminEventCalendar() {
  const [branch, setBranch] = useState('');
  const branches = useLoad(async () => (await api.get('/branches')).data.branches);
  return (
    <div className="space-y-4">
      <Select label="Branch" value={branch} onChange={(e) => setBranch(e.target.value)} className="max-w-xs"><option value="">All branches</option>{branches.data?.map((b) => <option key={b._id} value={b._id}>{b.name}</option>)}</Select>
      <EventCalendar branch={branch} />
    </div>
  );
}
