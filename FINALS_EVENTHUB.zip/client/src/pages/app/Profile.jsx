import { useState } from 'react';
import { Mail, Phone, ShieldCheck, UserRound } from 'lucide-react';
import Card from '../../components/Card';
import Field from '../../components/Field';
import Button from '../../components/Button';
import Alert from '../../components/Alert';
import CodeInput from '../../components/CodeInput';
import PasswordRules from '../../components/PasswordRules';
import useForm from '../../hooks/useForm';
import { useAuth } from '../../context/AuthContext';
import { ROLE_LABEL } from '../../config/navigation';
import { rules } from '../../utils/validators';
import api, { errorMessage, fieldErrors } from '../../api/client';

const ReadOnly = ({ label, value, hint }) => <Field label={label} value={value || '—'} readOnly tabIndex={-1} hint={hint} />;

// Profile follows the flow: only the contact email, phone and password are editable.
// Name, role, company and the EventHub account email are system-controlled and read-only.
export default function Profile() {
  const { user, setUser } = useAuth();

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-navy">Profile</h1>
        <p className="mt-1 text-sm text-steel">Manage how EventHub can reach you and keep your account secure.</p>
      </div>

      <Card title="Account" icon={UserRound}>
        <div className="grid gap-4 sm:grid-cols-2">
          <ReadOnly label="First name" value={user.firstName} />
          <ReadOnly label="Last name" value={user.lastName} />
          <ReadOnly label="Role" value={ROLE_LABEL[user.role]} />
          {user.role === 'user' && <ReadOnly label="Company / organization" value={user.companyName} />}
          {user.role === 'organizer' && <ReadOnly label="Branch" value={user.branch?.name} />}
          {user.role === 'organizer' && <ReadOnly label="Position" value={user.position} />}
        </div>
      </Card>

      <EmailCard user={user} setUser={setUser} />
      <PhoneCard user={user} setUser={setUser} />
      <PasswordCard />
    </div>
  );
}

function EmailCard({ user, setUser }) {
  const [editing, setEditing] = useState(false);
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const form = useForm({ newContactEmail: '', currentPassword: '' }, {
    newContactEmail: (v, vals) => rules.contactEmail()(v) || (v.trim().toLowerCase() === user.contactEmail ? 'That is already your contact email.' : ''),
    currentPassword: rules.required('This field is required.'),
  });
  const pending = user.pendingContactEmail;

  const resendAccountEmail = async () => {
    setError(''); setSuccess('');
    try { const res = await api.post('/profile/account-email/resend'); setSent(true); setSuccess(res.data.message); setTimeout(() => { setSent(false); setSuccess(''); }, 6000); }
    catch (err) { setError(errorMessage(err)); }
  };

  const request = async (e) => {
    e.preventDefault();
    setError(''); setSuccess('');
    if (!form.validateAll()) return;
    setLoading(true);
    try {
      const res = await api.post('/profile/email/request', { newContactEmail: form.values.newContactEmail.trim().toLowerCase(), currentPassword: form.values.currentPassword });
      setUser({ ...user, pendingContactEmail: res.data.pendingContactEmail });
      form.reset(); setCode(''); setEditing(false);
    } catch (err) {
      const fe = fieldErrors(err);
      form.setServerErrors(fe);
      if (!Object.keys(fe).length) setError(errorMessage(err));
    } finally { setLoading(false); }
  };

  const confirm = async (e) => {
    e.preventDefault();
    setError(''); setSuccess(''); setLoading(true);
    try {
      const res = await api.post('/profile/email/confirm', { code });
      setUser(res.data.user); setCode('');
      setSuccess('Contact email updated.');
      setTimeout(() => setSuccess(''), 6000);
    } catch (err) { setError(errorMessage(err)); }
    finally { setLoading(false); }
  };

  const cancel = async () => {
    setError(''); setSuccess('');
    try { const res = await api.delete('/profile/email/pending'); setUser(res.data.user); setCode(''); }
    catch (err) { setError(errorMessage(err)); }
  };

  return (
    <Card title="Email" icon={Mail}>
      <div className="space-y-4">
        <div className="rounded-xl border border-mist bg-mist/20 px-4 py-3">
          <p className="text-sm font-medium text-navy">EventHub account email (your login)</p>
          <p className="mt-0.5 text-xs text-steel">For your security it is not shown here. It was sent to your registered email address.</p>
          <button type="button" onClick={resendAccountEmail} className="mt-2 text-sm font-semibold text-navy underline">{sent ? 'Sent. Check your inbox.' : 'Send it to me again'}</button>
        </div>

        <ReadOnly label="Contact email" value={user.contactEmail} />
        <Alert type="error">{error}</Alert>
        <Alert type="success">{success}</Alert>

        {pending ? (
          <form onSubmit={confirm} className="space-y-4 rounded-xl bg-mist/30 p-4">
            <p className="text-sm text-navy">Enter the 6-digit code sent to <span className="font-semibold">{pending}</span>.</p>
            <CodeInput value={code} onChange={setCode} disabled={loading} />
            <div className="flex flex-wrap gap-3">
              <Button type="submit" loading={loading} disabled={code.length !== 6}>Confirm new email</Button>
              <Button type="button" variant="secondary" onClick={cancel}>Cancel</Button>
            </div>
          </form>
        ) : editing ? (
          <form onSubmit={request} noValidate className="space-y-4 rounded-xl bg-mist/30 p-4">
            <Field label="New contact email" type="email" placeholder="e.g. juan.delacruz@gmail.com" autoComplete="email" {...form.field('newContactEmail')} />
            <Field label="Current password" type="password" placeholder="Enter your current password" autoComplete="current-password" {...form.field('currentPassword')} />
            <div className="flex flex-wrap gap-3">
              <Button type="submit" loading={loading}>Send code</Button>
              <Button type="button" variant="secondary" onClick={() => { setEditing(false); form.reset(); setError(''); }}>Cancel</Button>
            </div>
          </form>
        ) : (
          <Button variant="secondary" onClick={() => { setEditing(true); setSuccess(''); }}>Change contact email</Button>
        )}
      </div>
    </Card>
  );
}

function PhoneCard({ user, setUser }) {
  const form = useForm({ phone: user.phone || '' }, { phone: rules.phone });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);

  const save = async (e) => {
    e.preventDefault();
    setError(''); setSuccess('');
    if (!form.validateAll()) return;
    setLoading(true);
    try {
      const res = await api.patch('/profile', { phone: form.values.phone.trim() });
      setUser(res.data.user);
      setSuccess('Phone number updated.');
      setTimeout(() => setSuccess(''), 5000);
    } catch (err) {
      const fe = fieldErrors(err);
      form.setServerErrors(fe);
      if (!Object.keys(fe).length) setError(errorMessage(err));
    } finally { setLoading(false); }
  };

  return (
    <Card title="Phone number" icon={Phone}>
      <form onSubmit={save} noValidate className="space-y-4">
        <Alert type="error">{error}</Alert>
        <Alert type="success">{success}</Alert>
        <Field label="Phone number" type="tel" placeholder="09XXXXXXXXX" autoComplete="tel" {...form.field('phone')} />
        <Button type="submit" loading={loading} disabled={form.values.phone.trim() === (user.phone || '')}>Save phone number</Button>
      </form>
    </Card>
  );
}

function PasswordCard() {
  const form = useForm({ currentPassword: '', newPassword: '', confirmPassword: '' }, {
    currentPassword: rules.required('This field is required.'),
    newPassword: rules.password,
    confirmPassword: rules.confirm('newPassword'),
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);

  const save = async (e) => {
    e.preventDefault();
    setError(''); setSuccess('');
    if (!form.validateAll()) return;
    setLoading(true);
    try {
      await api.patch('/profile/password', form.values);
      form.reset();
      setSuccess('Password changed. Other devices were logged out.');
      setTimeout(() => setSuccess(''), 6000);
    } catch (err) {
      const fe = fieldErrors(err);
      form.setServerErrors(fe);
      setError(Object.keys(fe).length ? '' : errorMessage(err));
    } finally { setLoading(false); }
  };

  const np = form.field('newPassword');
  return (
    <Card title="Security" description="Change your password." icon={ShieldCheck}>
      <form onSubmit={save} noValidate className="space-y-4">
        <Alert type="error">{error}</Alert>
        <Alert type="success">{success}</Alert>
        <Field label="Current password" type="password" placeholder="Enter your current password" autoComplete="current-password" {...form.field('currentPassword')} />
        <Field label="New password" type="password" placeholder="Enter your new password" autoComplete="new-password" {...np} />
        <PasswordRules password={form.values.newPassword} visible={form.isFocused('newPassword') || (form.isTouched('newPassword') && !!np.error)} />
        <Field label="Confirm new password" type="password" placeholder="Re-enter your new password" autoComplete="new-password" {...form.field('confirmPassword')} />
        <Button type="submit" loading={loading}>Change password</Button>
      </form>
    </Card>
  );
}
