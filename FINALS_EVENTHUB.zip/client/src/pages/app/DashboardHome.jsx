import { Link } from 'react-router-dom';
import { AlertTriangle, ShieldCheck } from 'lucide-react';
import Card from '../../components/Card';
import StatCard from '../../components/StatCard';
import LoadState from '../../components/LoadState';
import BookingStatusBadge from '../../components/BookingStatusBadge';
import Badge from '../../components/Badge';
import useLoad from '../../hooks/useLoad';
import { useAuth } from '../../context/AuthContext';
import { ROLE_LABEL, ROLE_PERMISSIONS } from '../../config/navigation';
import { bookingPath } from '../../config/bookingStatus';
import { formatDate, formatDateTime, peso } from '../../utils/format';
import api from '../../api/client';

const EventRow = ({ b, role, right }) => (
  <li className="flex flex-wrap items-center justify-between gap-2 py-3 text-sm">
    <div><Link to={bookingPath(role, b)} className="font-semibold text-navy hover:underline">{b.eventName}</Link><p className="text-xs text-steel">{b.code} · {b.eventType?.name} · {formatDate(b.date)}{b.company?.companyName ? ` · ${b.company.companyName}` : ''}</p></div>
    {right || <BookingStatusBadge status={b.status} />}
  </li>
);
const List = ({ title, children, empty }) => (<Card title={title}>{children?.length ? <ul className="divide-y divide-mist/60">{children}</ul> : <p className="text-sm text-steel">{empty}</p>}</Card>);

// One dashboard per role, with only what that role needs. All numbers come from the API, scoped on the server.
export default function DashboardHome() {
  const { user } = useAuth();
  const { data: d, loading, error } = useLoad(async () => (await api.get('/dashboard')).data);
  const role = user.role;
  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-navy sm:text-[1.7rem]">Welcome, {user.firstName}</h1>
        <p className="mt-1 text-sm text-steel">{role === 'user' && user.companyName ? `${user.companyName} · ` : ''}{role === 'organizer' && user.branch?.name ? `${user.branch.name} · ` : ''}{ROLE_LABEL[role]}</p>
      </div>
      <LoadState loading={loading} error={error} hasData={!!d}>
        {d && role === 'user' && (
          <>
            <div className="eh-stats grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <StatCard label="Active bookings" value={d.activeBookings} testId="stat-active" />
              <StatCard label="Waiting for approval" value={d.counts.pending_approval || 0} />
              <StatCard label="Payment required" value={d.counts.payment_required || 0} attention={(d.counts.payment_required || 0) > 0} />
              <StatCard label="Confirmed events" value={(d.counts.confirmed || 0) + (d.counts.ongoing || 0)} />
            </div>
            <div className="grid gap-6 lg:grid-cols-2">
              <Card title="Upcoming event">
                {d.upcoming ? (
                 <ul>
                <EventRow b={d.upcoming} role={role} />
                </ul>
                 ) : (
                 <p className="text-sm text-steel">
                   No upcoming confirmed event.
                    </p>
                    )}
                  </Card>
              <Card title="Outstanding payment">
                <p data-testid="outstanding-total" className="text-2xl font-bold text-navy">{peso(d.outstanding.total)}</p>
                <ul className="mt-2 divide-y divide-mist/60 text-sm text-navy">{d.outstanding.items.length === 0 && <li className="py-2 text-steel">Nothing to pay right now.</li>}{d.outstanding.items.map((o) => <li key={o.bookingId} className="flex justify-between gap-3 py-2"><span><Link className="font-semibold hover:underline" to={`/my-events/${o.bookingId}`}>{o.eventName}</Link><span className="block text-xs text-steel">{o.reason}{o.dueAt ? ` · before ${formatDateTime(o.dueAt)}` : ''}</span></span><span className="font-semibold">{peso(o.amount)}</span></li>)}</ul>
              </Card>
            </div>
            <List title="Recent activity" empty="No activity yet.">{d.recent.map((b) => <EventRow key={b._id} b={b} role={role} right={<span className="text-xs text-steel">{b.lastNote}</span>} />)}</List>
          </>
        )}

        {d && role === 'organizer' && (
          <>
            <div className="eh-stats grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <StatCard label="Today's events" value={d.today.length} attention={d.today.length > 0} />
              <StatCard label="Upcoming events" value={d.upcoming.length} />
               <StatCard label="Damage reports needed" value={d.damageAttention.length} attention={d.damageAttention.length > 0} />
              <StatCard label="Preparation complete" value={d.preparation.ready} hint={`${d.preparation.notReady} not ready yet`} />
            </div>
            {d.reminders.length > 0 && (
              <Card title="Reminders" icon={AlertTriangle}><ul className="space-y-2 text-sm text-navy">{d.reminders.map((r) => <li key={r.bookingId + r.text} className="flex gap-3"><span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-sky" /><Link className="hover:underline" to={`/organizer/my-events/${r.bookingId}`}>{r.text}</Link></li>)}</ul></Card>
            )}
            <List title="Today" empty="No events today.">{d.today.map((b) => <EventRow key={b._id} b={b} role={role} />)}</List>
            <List title="Upcoming events" empty="No upcoming confirmed events.">{d.upcoming.map((b) => <EventRow key={b._id} b={b} role={role} right={<div className="text-right text-xs text-steel"><Badge tone={b.ready ? 'green' : 'yellow'}>{b.ready ? 'Ready' : 'Preparing'}</Badge><p className="mt-1">{b.venue || 'No venue yet'} · {b.teams.join(', ')}</p></div>} />)}</List>
          </>
        )}

        {d && role === 'admin' && (
          <>
            {d.alerts.length > 0 && (
              <Card title="Admin Alerts" icon={AlertTriangle}>
                <p className="mb-3 text-sm text-steel">Items that may need your attention. Select an alert to open the relevant page.</p>
                <ul className="grid gap-3 md:grid-cols-2">{d.alerts.map((a) => <li key={a.text} className={`rounded-xl border p-4 ${a.level === 'danger' ? 'border-red-200 bg-red-50 text-red-900' : a.level === 'warn' ? 'border-amber-200 bg-amber-50 text-amber-950' : 'border-mist bg-mist/20 text-navy'}`}><div className="mb-2 flex items-center gap-2"><span className={`rounded-full px-2 py-1 text-[11px] font-bold uppercase tracking-wide ${a.level === 'danger' ? 'bg-red-100 text-red-800' : a.level === 'warn' ? 'bg-amber-100 text-amber-900' : 'bg-white text-navy'}`}>{a.level === 'danger' ? 'Urgent' : a.level === 'warn' ? 'Review' : 'Notice'}</span></div><Link to={a.link} className="text-sm font-semibold hover:underline">{a.text}</Link><p className="mt-2 text-xs opacity-80">Open related records →</p></li>)}</ul>
              </Card>
            )}
            <div className="eh-stats grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <StatCard label="Pending requests" value={d.pendingRequests} attention={d.pendingRequests > 0} testId="stat-pending" />
              <StatCard label="Payments to verify" value={d.paymentsToVerify} attention={d.paymentsToVerify > 0} />
              <StatCard label="Damage to review" value={d.damageToReview} attention={d.damageToReview > 0} />
              <StatCard label="Active branches" value={d.system.activeBranches} />
              <StatCard label="Active teams" value={d.system.activeTeams} />
              <StatCard label="Outstanding payments" value={peso(d.outstanding.dueNow)} hint={`${peso(d.outstanding.upcoming)} upcoming · ${d.outstanding.overdueCount} overdue`} />
              <StatCard label="Revenue (all time)" value={peso(d.revenue.total)} hint={`This month ${peso(d.revenue.thisMonth)}`} testId="stat-revenue" />
              <StatCard label="Active staff" value={d.system.activeStaff} to="/admin/staff" />
            </div>
            <List title="Upcoming events" empty="No upcoming events.">{d.upcomingEvents.map((b) => <EventRow key={b._id} b={b} role={role} />)}</List>
          </>
        )}
      </LoadState>
    </div>
  );
}
