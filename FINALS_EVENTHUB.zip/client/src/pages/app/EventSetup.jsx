import { useState } from 'react';
import PageHeader from '../../components/PageHeader';
import EventTypes from '../admin/EventTypes';
import Pricing from '../admin/Pricing';

// Organizer: Event Setup is VIEW ONLY. Event types, team structure, bundles, add-ons and prices
// are official configuration owned by Admin; the Organizer uses them to prepare events.
export default function EventSetup() {
  const [tab, setTab] = useState('types');
  return (
    <div className="mx-auto max-w-6xl space-y-5">
      <PageHeader
        title="Event Setup"
        viewOnly
        subtitle="The official event types, team structures, bundles, add-ons and prices used to prepare your events. Admin manages them; you cannot change them."
      />
      <div className="flex gap-2 border-b border-mist">
        {[['types', 'Event types'], ['pricing', 'Bundles & add-ons']].map(([key, label]) => (
          <button key={key} onClick={() => setTab(key)}
            className={`-mb-px border-b-2 px-4 py-2.5 text-sm font-semibold transition ${tab === key ? 'border-sky text-navy' : 'border-transparent text-steel hover:text-navy'}`}>
            {label}
          </button>
        ))}
      </div>
      {tab === 'types' ? <EventTypes embedded /> : <Pricing readOnly embedded />}
    </div>
  );
}
