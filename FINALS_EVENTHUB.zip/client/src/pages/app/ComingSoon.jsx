import { useLocation } from 'react-router-dom';
import { Eye, Hammer } from 'lucide-react';
import Card from '../../components/Card';
import { useAuth } from '../../context/AuthContext';
import { flatItems } from '../../config/navigation';

// Stand-in for pages whose module is not built yet. It shows what the page is for,
// taken from the EventHub flow, so the navigation never drifts from the business rules.
export default function ComingSoon() {
  const { pathname } = useLocation();
  const { user } = useAuth();
  const item = flatItems(user.role).find((i) => i.to === pathname);
  if (!item) return null;
  const Icon = item.icon;

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="text-2xl font-bold text-navy">{item.label}</h1>
        {item.readOnly && (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-mist px-3 py-1 text-xs font-semibold text-navy"><Eye size={14} /> View only</span>
        )}
      </div>
      <Card title={`Planned: ${item.module} module`} icon={Hammer}>
        <p className="text-sm text-navy">{item.description}</p>
        <p className="mt-4 flex items-center gap-2 text-xs text-steel"><Icon size={14} /> This page is part of the {item.module} module and will be built next in the backend order.</p>
      </Card>
    </div>
  );
}
