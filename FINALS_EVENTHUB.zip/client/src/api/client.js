import axios from 'axios';

const api = axios.create({ baseURL: '/api', withCredentials: true });

// Message to show the user for any failed request.
export const errorMessage = (err) =>
  err?.response?.data?.message || 'Cannot reach the server. Check your connection and try again.';

// Machine-readable code from the API (e.g. EMAIL_NOT_VERIFIED, INVALID_CODE).
export const errorCode = (err) => err?.response?.data?.code;

// Field-level validation errors from the API: { email: 'message', ... }
export const fieldErrors = (err) =>
  Object.fromEntries((err?.response?.data?.errors || []).map((e) => [e.field, e.message]));

export default api;
