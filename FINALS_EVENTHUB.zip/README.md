# EventHub

A MERN event management service: companies create and book their own events; EventHub provides the venue, equipment, staff, teams, bundles and add-ons, and runs the event. Three roles: **User/Company**, **Organizer/Staff**, **Administrator**.
Target Client: **EventHub Event Management Services**.

```
eventhub/
├── server/    Express + MongoDB (Mongoose) API, seeds, scripts, API tests
├── client/    React + Vite + Tailwind app
└── docs/      Demo accounts, screenshots, project status
```

## Two emails per account
- **Account email** = the generated EventHub login (`firstnamelastname@user.eventhub.com`, `@organizer.eventhub.com`, `@admin.eventhub.com`; `2`, `3` ... if a name repeats). It never changes and it is **never shown on the website**: it is **emailed** to the contact email (after verification, after a password reset, on request from Profile, and in the Organizer invitation).
- **Contact email** = the real email. Codes, invitations and notices go there. It is never a login.

> **Reading emails while testing locally:** if `GMAIL_USER` / `GMAIL_APP_PASSWORD` are empty (development only), every email is **printed in the API console** instead of being sent, including the one that contains the account email. Watch the terminal that runs `npm run dev`.

## Run it locally (Node 20 or newer)
1. **Install** — `npm install` then `npm run install:all`
2. **Configure** — copy `server/.env.example` to `server/.env` and set at least `MONGO_URI`, `JWT_SECRET` (long random string), `ADMIN_CONTACT_EMAIL`, `ADMIN_PASSWORD`.
3. **Create the Admin and the system data**
   ```bash
   npm run create-admin     # prints the Admin's login email
   npm run seed             # 5 branches, 11 event types, 275 teams, 44 bundles, add-ons, equipment, venues
   ```
4. **Presentation data (optional, recommended before you present)**
   ```bash
   npm run seed:demo        # 12 companies, 5 organizers, 24 completed transactions + one booking in every status
   npm run check:presentation
   ```
   Login emails are listed in `docs/DEMO_ACCOUNTS.md`.
5. **Start** — `npm run dev` then open http://localhost:5173 (API on http://localhost:5000).

## MongoDB Atlas
Atlas → Database Access (create a user) → Network Access (allow your IP) → Connect → Drivers: copy the string, add the database name before `?`, e.g. `mongodb+srv://USER:PASSWORD@cluster0.xxxxx.mongodb.net/eventhub?retryWrites=true&w=majority` (URL-encode special characters in the password) and put it in `server/.env` as `MONGO_URI`.
Existing databases from the earlier single-email version are migrated automatically at startup (see `server/README.md`).

## Environment variables (`server/.env`)
`MONGO_URI`, `JWT_SECRET`, `CLIENT_URL`, `ADMIN_CONTACT_EMAIL`, `ADMIN_ACCOUNT_EMAIL` (optional, must end `@admin.eventhub.com`), `ADMIN_PASSWORD`, `ADMIN_FIRST_NAME`, `ADMIN_LAST_NAME`, `ADMIN_PHONE`, `GMAIL_USER`, `GMAIL_APP_PASSWORD` (optional in development), `PAYMENT_GCASH_NAME/NUMBER`, `PAYMENT_BANK_NAME/ACCOUNT_NAME/ACCOUNT_NUMBER`, `UPLOAD_DIR`, `DEMO_PASSWORD`. No secrets are included in this package.

## Data scripts (run from the project root)
| Command | Purpose |
|---|---|
| `npm run seed` | System configuration (idempotent) |
| `npm run seed:demo` | Presentation data built through the real workflow (idempotent; `-- --reset` rebuilds, `-- --live` refreshes in-progress bookings) |
| `npm run check:presentation` | Verifies ≥10 users, ≥20 completed transactions, every status, archive, no leftovers |
| `npm run cleanup:data` | **Dry run** of removing development/test records; add `-- --confirm` to delete (keeps Admin, Organizers, configuration, demo data) |
| `npm run migrate:emails` | Converts an older single-email database |

## Tests (from `server/`, they use `MONGO_URI` and clean up after themselves)
`npm run test:rules`, `test:accounts` (no database) · `test:auth`, `test:setup`, `test:pricing`, `test:booking`, `test:lifecycle` (complete workflow: register → verify → book → approve → pay → confirm → prepare → ongoing → complete → damage → final payment → fully paid → archive, plus failure and security cases).
Browser smoke test (Python + Playwright): `tests/browser/smoke.py` visits every page for every role (see the header of the file).

## Status at delivery (honest)
**Verified:** the API test suites (auth 80, setup 56, pricing 44, booking 102, lifecycle 121, plus unit tests) passed against a local MongoDB-compatible database; the browser smoke test visited every page of every role (50 checks passed); the demo seed produced 12 companies and 24 completed transactions.
**Not yet verified / known gaps:** see `docs/KNOWN_ISSUES.md`. In short: nothing has been run against your MongoDB Atlas cluster; the older per-feature browser suites were not rewritten for the latest changes; the technical documentation PDF, the 48-step document and the school compliance checklist were not part of this package.
